﻿using System.Collections.Generic;

using Dapper;

using MEDSEEK.Navigate.Data.Extensions;
using MEDSEEK.Navigate.Shared.Entities;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DataTests.Extensions
{
    [TestClass]
    public class DataHelperTests
    {
        #region Constants

        private const string TableTypeKeyIdTypeName = "ttypeKeyID";

        private const string TableTypeTaskTypeAndTypeIdName = "tblTaskTypeAndTypeID";

        #endregion

        #region ToTableTypeKeyId tests

        [TestMethod]
        public void ToTableTypeKeyId_ListIsNull_ADataTableWithTheCorrectColumnsIsReturned()
        {
            // arrange
            List<int> list = null;

            // act
            var dataTable = list.ToTableTypeKeyId();

            // assert
            Assert.AreEqual(1, dataTable.Columns.Count);
            Assert.AreEqual("tKeyId", dataTable.Columns[0].ColumnName);
            Assert.AreEqual(typeof(int), dataTable.Columns[0].DataType);
        }

        [TestMethod]
        public void ToTableTypeKeyId_ADataTableIsReturned_TheDataTableTypeNameIsSet()
        {
            // arrange
            List<int> list = null;

            // act
            var dataTable = list.ToTableTypeKeyId();

            // assert
            Assert.AreEqual(TableTypeKeyIdTypeName, dataTable.GetTypeName());
        }

        [TestMethod]
        public void ToTableTypeKeyId_ListIsNotNull_ADataTableWithTheCorrectColumnsIsReturned()
        {
            // arrange
            var list = new List<int>();

            // act
            var dataTable = list.ToTableTypeKeyId();

            // assert
            Assert.AreEqual(1, dataTable.Columns.Count);
            Assert.AreEqual("tKeyId", dataTable.Columns[0].ColumnName);
            Assert.AreEqual(typeof(int), dataTable.Columns[0].DataType);
        }

        [TestMethod]
        public void ToTableTypeKeyId_ListIsNull_AnEmptyDataTableIsReturned()
        {
            // arrange
            List<int> list = null;

            // act
            var dataTable = list.ToTableTypeKeyId();

            // assert
            Assert.AreEqual(0, dataTable.Rows.Count);
        }

        [TestMethod]
        public void ToTableTypeKeyId_ListIsEmpty_AnEmptyDataTableIsReturned()
        {
            // arrange
            var list = new List<int>();

            // act
            var dataTable = list.ToTableTypeKeyId();

            // assert
            Assert.AreEqual(0, dataTable.Rows.Count);
        }

        [TestMethod]
        public void ToTableTypeKeyId_ListIsPopulated_TheDataTableIsPopulated()
        {
            // arrange
            var list = new List<int> { 123, 456, 890 };

            // act
            var dataTable = list.ToTableTypeKeyId();

            // assert
            Assert.AreEqual(list.Count, dataTable.Rows.Count);

            for (var i = 0; i < list.Count; i++)
            {
                Assert.AreEqual(list[i], dataTable.Rows[i].ItemArray[0]);
            }
        }

        #endregion

        #region ToTaskTypeAndTypeId tests

        [TestMethod]
        public void ToTaskTypeAndTypeId_ADataTableIsReturned_TheDataTableTypeNameIsSet()
        {
            // arrange
            List<TaskSpecificType> taskSpecificTypes = null;

            // act
            var dataTable = taskSpecificTypes.ToTaskTypeAndTypeId();

            // assert
            Assert.AreEqual(TableTypeTaskTypeAndTypeIdName, dataTable.GetTypeName());
        }

        [TestMethod]
        public void ToTaskTypeAndTypeId_ListIsNull_DataTableWithTheCorrectColumnsIsReturned()
        {
            // arrange
            List<TaskSpecificType> taskSpecificTypes = null;

            // act
            var dataTable = taskSpecificTypes.ToTaskTypeAndTypeId();

            // assert
            Assert.AreEqual(2, dataTable.Columns.Count);
            Assert.AreEqual("TaskTypeID", dataTable.Columns[0].ColumnName);
            Assert.AreEqual(typeof(int), dataTable.Columns[0].DataType);
            Assert.AreEqual("TypeID", dataTable.Columns[1].ColumnName);
            Assert.AreEqual(typeof(int), dataTable.Columns[1].DataType);
        }

        [TestMethod]
        public void ToTaskTypeAndTypeId_ListIsNotNull_DataTableWithTheCorrectColumnsIsReturned()
        {
            // arrange
            var taskSpecificTypes = new List<TaskSpecificType>();

            // act
            var dataTable = taskSpecificTypes.ToTaskTypeAndTypeId();

            // assert
            Assert.AreEqual(2, dataTable.Columns.Count);
            Assert.AreEqual("TaskTypeID", dataTable.Columns[0].ColumnName);
            Assert.AreEqual(typeof(int), dataTable.Columns[0].DataType);
            Assert.AreEqual("TypeID", dataTable.Columns[1].ColumnName);
            Assert.AreEqual(typeof(int), dataTable.Columns[1].DataType);
        }

        [TestMethod]
        public void ToTaskTypeAndTypeId_ListIsNull_AnEmptyDataTableIsReturned()
        {
            // arrange
            List<TaskSpecificType> taskSpecificTypes = null;

            // act
            var dataTable = taskSpecificTypes.ToTaskTypeAndTypeId();

            // assert
            Assert.AreEqual(0, dataTable.Rows.Count);
        }

        [TestMethod]
        public void ToTaskTypeAndTypeId_ListIsEmpty_AnEmptyDataTableIsReturned()
        {
            // arrange
            var taskSpecificTypes = new List<TaskSpecificType>();

            // act
            var dataTable = taskSpecificTypes.ToTaskTypeAndTypeId();

            // assert
            Assert.AreEqual(0, dataTable.Rows.Count);
        }

        [TestMethod]
        public void ToTaskTypeAndTypeId_ListIsNotEmpty_DataTableIsPopulated()
        {
            // arrange
            var taskSpecificTypes = new List<TaskSpecificType>
                                        {
                                            new TaskSpecificType
                                                {
                                                    TaskTypeId = 123,
                                                    TaskSpecificId = 456
                                                },
                                            new TaskSpecificType
                                                {
                                                    TaskTypeId = 789,
                                                    TaskSpecificId = 135
                                                }
                                        };

            // act
            var dataTable = taskSpecificTypes.ToTaskTypeAndTypeId();

            // assert
            Assert.AreEqual(taskSpecificTypes.Count, dataTable.Rows.Count);

            for (var i = 0; i < taskSpecificTypes.Count; i++)
            {
                Assert.AreEqual(taskSpecificTypes[i].TaskTypeId, dataTable.Rows[i].ItemArray[0]);
                Assert.AreEqual(taskSpecificTypes[i].TaskSpecificId, dataTable.Rows[i].ItemArray[1]);
            }
        }

        #endregion
    }
}
