:setvar JobName "Navigate_PopulationDefinition_Refresh" 
:setvar RedeployJobs "yes"

PRINT 'Deploying job: $(JobName)'

DECLARE @JobId UNIQUEIDENTIFIER
DECLARE @ScheduleName SYSNAME
DECLARE @ScheduleID INT
DECLARE @JobStatus BIT

/*
Get JobID, ScheduleID, @ScheduleName and @JobStatus
ScheduleName is used for Validate is or not to create a New Schedule
JobStatus is used to set the job to its previous state (Enable/Disable)
*/
SELECT @JobId = [sJOB].[job_id],
	@ScheduleName = [sSCH].[name],
	@ScheduleID = [sSCH].[schedule_id],
	@JobStatus = [sJOB].[enabled]
FROM [msdb].[dbo].[sysjobs] AS [sJOB]
LEFT JOIN [msdb].[dbo].[sysjobschedules] AS [sJOBSCH]
	ON [sJOB].[job_id] = [sJOBSCH].[job_id]
LEFT JOIN [msdb].[dbo].[sysschedules] AS [sSCH]
	ON [sJOBSCH].[schedule_id] = [sSCH].[schedule_id]
WHERE [sJOB].[name] = '$(JobName)'

/*
Check to see if an alternate Schedule exists with the Schedule Name
*/
IF @ScheduleName IS NULL
BEGIN
	SELECT @ScheduleName = [sSCH].[name]
	FROM [msdb].[dbo].[sysschedules] AS [sSCH]
	WHERE [sSCH].[name] = 'Schedule_$(JobName)'
END

/*
Set Job to Enabled if its created the first time
*/
SET @JobStatus = ISNULL(@JobStatus, 1)

/*
First we check existence of the specified job name and whether the RedeployJobs parameter has been 
set to "Yes".
*/
IF UPPER('$(RedeployJobs)') = 'YES'
	OR @JobId IS NULL
BEGIN
	/*
	Either this is a new job or the RedeployJobs parameter is set to Schedule.  If its an existing 
	job we need to remove it so that we can "redeploy" it.
	*/
	IF @JobId IS NOT NULL
	BEGIN
		/*
		Detach Existing Schedule with @delete_unused_schedule = 0 so as to re-attach 
		old(Any Custom Client Specific) schedule post deployment
		*/
		IF @ScheduleID IS NOT NULL
		BEGIN
			EXEC msdb.dbo.sp_detach_schedule @job_id = @JobId,
				@schedule_id = @ScheduleID,
				@delete_unused_schedule = 0
		END

		PRINT '	Deleting existing job'

		EXEC msdb.dbo.sp_delete_job @job_id = @JobId

		/*
		Set the @JobId variable to NULL for the sp_add_job command later on.  If it is not null the
        server things the job is from a MSX server
		*/
		SET @JobId = NULL
	END

	/*
     * Add the job
     */

   EXEC msdb.dbo.sp_add_job @job_name=N'$(JobName)', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'navigate', 
		@job_id = @jobId OUTPUT
	/*
     * Add the job step(s)
     */

   EXEC msdb.dbo.sp_add_jobstep @job_id=@jobId, 
		@step_name=N'Step-1: PopulationDefinition_Refresh', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
		
IF OBJECT_ID(''tempdb..##EnrollCount'') IS NOT NULL DROP TABLE ##EnrollCount

      CREATE TABLE ##EnrollCount
		(Comments VARCHAR(8000))
	  Declare @ID INT
		INSERT INTO ETLProcessLog
		(
		Name,
		StartTime
		)
		VALUES
		(
		''PDRefresh'',
		 GETDATE()	
		)
		SELECT @ID = SCOPE_IDENTITY()
		
		DECLARE @DailyRefreshTable TABLE (
	ID INT IDENTITY(1, 1)
	,Script VARCHAR(500)
	)
DECLARE @MonthlyRefreshTable TABLE (
	ID INT IDENTITY(1, 1)
	,Script VARCHAR(500)
	)
DECLARE @StartLoop INT = 1
DECLARE @EndLoop INT
DECLARE @i_ProgramId INT
DECLARE @UserID VARCHAR(10)
DECLARE @ErrorScript VARCHAR(4000)
DECLARE @TodayDate DATE = GETDATE()
SELECT @UserID = MIN(UserID)
FROM Users
SELECT @i_ProgramId = ProgramId 
FROM Program 
WHERE ProgramName = ''All Patients Managed population''

IF @i_ProgramID IS NOT NULL 

BEGIN
	
        EXEC dbo.[usp_AllPatientsManagedpopulation_Enrollment] 
		
        @i_ProgramID = @i_ProgramID

END
INSERT INTO @DailyRefreshTable
SELECT ''[usp_PopulationDefinitionUsers_InsertByCriteria] '' + @UserID + '','' + CAST(pc.PopulationDefinitionID AS VARCHAR(10))
FROM PopulationDefinition pd
INNER JOIN PopulationDefinitionCriteria pc ON pd.PopulationDefinitionID = pc.PopulationDefinitionID
INNER JOIN PopulationDefPanelConfiguration pdp ON pdp.PopulationDefPanelConfigurationID = pc.PopulationDefPanelConfigurationID
WHERE ProductionStatus = ''F''
	AND StatusCode = ''A''
	AND pdp.PanelorGroupName = ''Build Definition''
	AND pdp.PopulationType = ''Population''
	AND pd.RefreshPatientListDaily = 1


SELECT @EndLoop= MAX(ID) FROM @DailyRefreshTable
WHILE @StartLoop <= @EndLoop
BEGIN
	DECLARE @DailyRefreshSQL VARCHAR(4000)
	SELECT @ErrorScript = Script
	FROM @DailyRefreshTable
	WHERE ID = @StartLoop
	SET @DailyRefreshSQL = ''BEGIN TRY'' + CHAR(13) + CHAR(10)
	SELECT @DailyRefreshSQL = @DailyRefreshSQL + ''EXECUTE '' + Script + CHAR(13) + CHAR(10)
	FROM @DailyRefreshTable
	WHERE ID = @StartLoop
	SET @DailyRefreshSQL = @DailyRefreshSQL 
						+ ''END TRY'' + CHAR(13) + CHAR(10) 
						+ ''BEGIN CATCH'' + CHAR(13) + CHAR(10) 
						+ ''	PRINT ''''Error in code: '' + @ErrorScript + '''''''' + CHAR(13) + CHAR(10) 
						+ ''END CATCH'' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)
	EXEC (@DailyRefreshSQL)
	SET @StartLoop = @StartLoop + 1
END
SET @StartLoop = 1
INSERT INTO @MonthlyRefreshTable
SELECT ''[usp_PopulationDefinitionUsers_InsertByCriteria] '' + @UserID + '','' + CAST(pc.PopulationDefinitionID AS VARCHAR(10))
FROM PopulationDefinition pd
INNER JOIN PopulationDefinitionCriteria pc ON pd.PopulationDefinitionID = pc.PopulationDefinitionID
INNER JOIN PopulationDefPanelConfiguration pdp ON pdp.PopulationDefPanelConfigurationID = pc.PopulationDefPanelConfigurationID
WHERE ProductionStatus = ''F''
	AND StatusCode = ''A''
	AND pdp.PanelorGroupName = ''Build Definition''
	AND pdp.PopulationType = ''Population''
	AND pd.RefreshPatientListDaily = 0
	AND DAY(@TodayDate) = 1
SELECT @EndLoop = @@Identity
WHILE @StartLoop <= @EndLoop
BEGIN
	DECLARE @MonthlyRefreshSQL VARCHAR(4000)
	SELECT @ErrorScript = Script
	FROM @MonthlyRefreshTable
	WHERE ID = @StartLoop
	SET @MonthlyRefreshSQL = ''BEGIN TRY'' + CHAR(13) + CHAR(10)
	SELECT @MonthlyRefreshSQL = @MonthlyRefreshSQL + ''EXECUTE '' + Script + CHAR(13) + CHAR(10)
	FROM @MonthlyRefreshTable
	WHERE ID = @StartLoop
	SET @MonthlyRefreshSQL = @MonthlyRefreshSQL 
							+ ''END TRY'' + CHAR(13) + CHAR(10) 
							+ ''BEGIN CATCH'' + CHAR(13) + CHAR(10) 
							+ ''	PRINT ''''Error in code: '' + @ErrorScript + '''''''' + CHAR(13) + CHAR(10) 
							+ ''END CATCH'' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)
	EXEC (@MonthlyRefreshSQL)
	SET @StartLoop = @StartLoop + 1
END

UPDATE ETLProcessLog
		SET EndTime = GETDATE()
		,ISComplete = 1
		,Runtime = CONVERT(VARCHAR(15),DATEADD(MILLISECOND,DATEDIFF(MILLISECOND,StartTime,GETDATE()),CAST(''2000-01-01'' as datetime)),114)
		,Comments = ''PDID, EnrolledCount, DisEnrolledCount''+CHAR(10)+(SELECT STUFF((SELECT  CHAR(10)+Comments FROM ##EnrollCount FOR XML PATH ('''')),1,1,''''))
		WHERE LogID = @ID

', 
		@database_name=N'$(DatabaseName)', 
		@flags=0

	/*
    Add the job schedule
    */
	IF @ScheduleName IS NULL /* @ScheduleName if NULL implies that a New Schedule has to be created */
	BEGIN
		PRINT ' No Schedule existed. Creating New Schedule';
	
   EXEC msdb.dbo.sp_add_jobschedule 
		@job_id=@jobId, 
		@name=N'Schedule_$(JobName)', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=62, 
		@freq_subday_type=8, 
		@freq_subday_interval=12, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140401, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
		
	END
	ELSE /* @ScheduleName if NOT NULL implies that a Schedule already existed */
	BEGIN
		PRINT '	Schedule exists. Attaching previous schedule';
		EXEC msdb.dbo.sp_attach_schedule @job_id = @jobId,	@schedule_name = @ScheduleName
	END

	/*
    Add the job server
    */
	EXEC msdb.dbo.sp_add_jobserver @job_id = @jobId,
		@server_name = N'(local)'

	PRINT ' Created the job "$(JobName)"'
END
ELSE
BEGIN
	PRINT ' Bypassing job "$(JobName)" deployment as job exists and RedeployJob parameter is "$(RedeployJobs)"'
END
GO