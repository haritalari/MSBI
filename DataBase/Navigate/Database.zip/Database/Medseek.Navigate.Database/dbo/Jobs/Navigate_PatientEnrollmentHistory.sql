:setvar JobName "Navigate_PatientEnrollmentHistory" 
:setvar RedeployJobs "yes"

PRINT 'Deploying job: $(JobName) with DefaultSSISPackagePath : $(DefaultSSISPackagePath)'

DECLARE @JobId UNIQUEIDENTIFIER
DECLARE @ScheduleName SYSNAME
DECLARE @ScheduleID INT
DECLARE @JobStatus BIT

/*
Get JobID, ScheduleID, @ScheduleName and @JobStatus
ScheduleName is used for Validate is or not to create a New Schedule
JobStatus is used to set the job to its previous state (Enable/Disable)
*/
SELECT @JobId = [sJOB].[job_id],
	@ScheduleName = [sSCH].[name],
	@ScheduleID = [sSCH].[schedule_id],
	@JobStatus = [sJOB].[enabled]
FROM [msdb].[dbo].[sysjobs] AS [sJOB]
LEFT JOIN [msdb].[dbo].[sysjobschedules] AS [sJOBSCH]
	ON [sJOB].[job_id] = [sJOBSCH].[job_id]
LEFT JOIN [msdb].[dbo].[sysschedules] AS [sSCH]
	ON [sJOBSCH].[schedule_id] = [sSCH].[schedule_id]
WHERE [sJOB].[name] = '$(JobName)'

/*
Check to see if an alternate Schedule exists with the Schedule Name
*/
IF @ScheduleName IS NULL
BEGIN
	SELECT @ScheduleName = [sSCH].[name]
	FROM [msdb].[dbo].[sysschedules] AS [sSCH]
	WHERE [sSCH].[name] = 'Schedule_$(JobName)'
END

/*
Set Job to Enabled if its created the first time
*/
SET @JobStatus = ISNULL(@JobStatus, 1)

/*
First we check existence of the specified job name and whether the RedeployJobs parameter has been 
set to "Yes".
*/
IF UPPER('$(RedeployJobs)') = 'YES'
	OR @JobId IS NULL
BEGIN
	/*
	Either this is a new job or the RedeployJobs parameter is set to Schedule.  If its an existing 
	job we need to remove it so that we can "redeploy" it.
	*/
	IF @JobId IS NOT NULL
	BEGIN
		/*
		Detach Existing Schedule with @delete_unused_schedule = 0 so as to re-attach 
		old(Any Custom Client Specific) schedule post deployment
		*/
		IF @ScheduleID IS NOT NULL
		BEGIN
			EXEC msdb.dbo.sp_detach_schedule @job_id = @JobId,
				@schedule_id = @ScheduleID,
				@delete_unused_schedule = 0
		END

		PRINT '	Deleting existing job'

		EXEC msdb.dbo.sp_delete_job @job_id = @JobId

		/*
		Set the @JobId variable to NULL for the sp_add_job command later on.  If it is not null the
        server things the job is from a MSX server
		*/
		SET @JobId = NULL
	END

	/*
     * Add the job
     */
	EXEC msdb.dbo.sp_add_job @job_name = N'$(JobName)',
		@enabled = 0,
		@notify_level_eventlog = 0,
		@notify_level_email = 2,
		@notify_level_netsend = 2,
		@notify_level_page = 2,
		@delete_level = 0,
		@description = N'No description available.',
		@category_name = N'[Uncategorized (Local)]',
		@owner_login_name = N'$(DatabaseName)',
		@job_id = @jobId OUTPUT

	/*
     * Add the job step(s)
     */
	EXEC msdb.dbo.sp_add_jobstep @job_id = @jobId,
		@step_name = N'Step1: PatientEnrollmentHistory',
		@step_id = 1,
		@cmdexec_success_code = 0,
		@on_success_action = 1,
		@on_fail_action = 2,
		@retry_attempts = 0,
		@retry_interval = 0,
		@os_run_priority = 0,
		@subsystem = N'SSIS',
		@command = N'/FILE "\"$(DefaultSSISPackagePath)\PatientEnrollmentHistory\PatientEnrollmentHistory.dtsx\"" /CONFIGFILE "\"$(DefaultSSISPackagePath)\PatientEnrollmentHistory\PatientEnrollmentHistory.dtsConfig\"" /CHECKPOINTING OFF /REPORTING E',
		@database_name = N'$(DatabaseName)',
		@flags = 0

	/*
    Add the job schedule
    */
	IF @ScheduleName IS NULL /* @ScheduleName if NULL implies that a New Schedule has to be created */
	BEGIN
		PRINT ' No Schedule existed. Creating New Schedule';

		EXEC msdb.dbo.sp_add_jobschedule @job_id = @jobId,
			@name = N'Schedule_$(JobName)',
			@enabled = 1,
			@freq_type = 4,
			@freq_interval = 1,
			@freq_subday_type = 1,
			@freq_subday_interval = 0,
			@freq_relative_interval = 0,
			@freq_recurrence_factor = 1,
			@active_start_date = 20151012,
			@active_end_date = 99991231,
			@active_start_time = 0,
			@active_end_time = 235959
	END
	ELSE /* @ScheduleName if NOT NULL implies that a Schedule already existed */
	BEGIN
		PRINT '	Schedule exists. Attaching previous schedule';
		EXEC msdb.dbo.sp_attach_schedule @job_id = @jobId,	@schedule_name = @ScheduleName
	END

	/*
    Add the job server
    */
	EXEC msdb.dbo.sp_add_jobserver @job_id = @jobId,
		@server_name = N'(local)'

	PRINT ' Created the job "$(JobName)"'
END
ELSE
BEGIN
	PRINT ' Bypassing job "$(JobName)" deployment as job exists and RedeployJob parameter is "$(RedeployJobs)"'
END
GO

