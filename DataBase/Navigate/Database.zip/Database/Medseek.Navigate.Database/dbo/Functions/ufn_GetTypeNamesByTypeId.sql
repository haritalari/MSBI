﻿/*                
------------------------------------------------------------------------------                
Function Name: ufn_GetTypeNamesByTypeId
Description   : This Function Returns TypeName by TypeID 
Created By    : Rathnam
Created Date  : 26-June-2012
------------------------------------------------------------------------------
Log History :
DD-MM-YYYY     BY      DESCRIPTION
09/07/2013:Santosh Changed the name 'Program Enrollment' to 'Managed Population Enrollment'
12-Jun-2014 NagaBabu Added script for tasktype 'Goal' and 'Activity', Script deleted for the tasktype 'Life Style Goal\Activity Follow Up'
05-Jan-2015 Nagasiva updated Tasktype name Patient Education Material to Education Material.
05-Jan-2016 Rathnam added goal table to maintain unique goals as per NAVI-4706
23-Feb-2016 Rathnam Modifed as per new Task architecture 
20-July-2016 Yugandhar Modifed the logic when tasktypename is 'Schedule Procedure' as per NAVI-6488
------------------------------------------------------------------------------                
*/
CREATE FUNCTION [dbo].[ufn_GetTypeNamesByTypeId] (
	@v_TaskTypeName VARCHAR(50)
	,@i_TypeId KEYID
	)
RETURNS VARCHAR(200)
AS
BEGIN
	DECLARE @v_TypeName VARCHAR(500)

	IF @v_TaskTypeName = 'Assessment'
	BEGIN
		SELECT @v_TypeName = Questionaire.QuestionaireName
		FROM Questionaire WITH (NOLOCK)
		WHERE Questionaire.QuestionaireId = @i_TypeId
	END
	ELSE IF @v_TaskTypeName = 'Schedule Procedure'
	BEGIN
		SELECT @v_TypeName = CG.CodeGroupingName + ' - ' + CTG.CodeTypeGroupersName 
		FROM CodeGrouping CG WITH(NOLOCK)
		INNER JOIN CodeTypeGroupers CTG ON CTG.CodeTypeGroupersID = CG.CodeTypeGroupersID	
		WHERE CG.CodeGroupingID = @i_TypeId
	END
	ELSE IF @v_TaskTypeName = 'Education Material'
	BEGIN
		SELECT @v_TypeName = em.NAME
		FROM EducationMaterial em WITH (NOLOCK)
		WHERE em.EducationMaterialID = @i_TypeId
	END
	ELSE IF @v_TaskTypeName = 'Other Tasks'
	BEGIN
		SELECT @v_TypeName = at.NAME
		FROM OtherTask at WITH (NOLOCK)
		WHERE at.OtherTaskId = @i_TypeId
	END
	ELSE IF @v_TaskTypeName = 'Goal'
	BEGIN
		SELECT @v_TypeName = pg.GoalName
		FROM Goal pg WITH (NOLOCK)
		WHERE GoalId = @i_TypeId
	END
	ELSE IF @v_TaskTypeName = 'Activity'
	BEGIN
		SELECT @v_TypeName = a.NAME
		FROM Activity a WITH (NOLOCK)
		WHERE a.ActivityId = @i_TypeId
	END

	RETURN @v_TypeName
END