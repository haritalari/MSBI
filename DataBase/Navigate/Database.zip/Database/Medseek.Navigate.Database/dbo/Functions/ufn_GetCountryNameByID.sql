/*                    
------------------------------------------------------------------------------                    
Function Name: [ufn_GetCountryNameByID]    
Description   : This Function is used to get a country name for a particular codesetcountry.   
Created By    : Prashanth    
Created Date  : 09-Sep-2015
------------------------------------------------------------------------------                    
*/
    
CREATE FUNCTION [dbo].[ufn_GetCountryNameByID]
     (    
        @i_PrimaryCountryCodeId KEYID    
     )    
RETURNS VARCHAR(150)    
AS    
BEGIN    
      DECLARE @v_PrimaryCountryCodeName VARCHAR(150)    
      
	  SELECT 
		 @v_PrimaryCountryCodeName =  cs.CountryName 
	  FROM     
		CodeSetCountry cs
   WHERE cs.CountryID = @i_PrimaryCountryCodeId 
     
   
   RETURN @v_PrimaryCountryCodeName    
END