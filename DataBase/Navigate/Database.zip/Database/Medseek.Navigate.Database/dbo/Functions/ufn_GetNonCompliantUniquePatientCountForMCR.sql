﻿/*                  
------------------------------------------------------------------------------                  
Function Name : [dbo].[ufn_GetCompletedAssessmentCountForMCR]         
Description   : This Function Returns Unique Assessment Count for given Months
Created By    : Wasim              
Created Date  : 15-Mar-2016
------------------------------------------------------------------------------                  
Log History   :                   
DD-MM-YYYY     BY      DESCRIPTION  
21-Jun-2016 Nagababu Modified the logic as per NAVI-6265                      
------------------------------------------------------------------------------                  
*/      
CREATE FUNCTION [dbo].[ufn_GetNonCompliantUniquePatientCountForMCR]
(
  @assessmentUniqueNo varchar(MAX),
  @assessmentCompletedDate varchar(MAX),
  @vc_AnswerUnqiueNos VARCHAR(MAX)
)
RETURNS int
AS 
BEGIN
	DECLARE @i_patientCount AS INT ,
	 		@i_TaskTypeId INT ,
			@i_TaskStatusId INT

	SELECT @i_TaskTypeId = TaskTypeId
	FROM TaskType
	WHERE TaskTypeName = 'Assessment'

	SELECT @i_TaskStatusID = TaskStatusId 
	FROM TaskStatus WHERE TaskStatusText = 'Closed Complete' 
	
	SELECT @i_patientCount = COUNT(DISTINCT PT.PatientId)
	FROM PatientTask PT WITH(NOLOCK)
	INNER JOIN PatientAssessmentAnswer PAA WITH(NOLOCK)
		ON PT.PatientTaskId = PAA.PatientTaskId
	INNER JOIN 	(SELECT DISTINCT Q.QuestionaireId ,A.AnswerId
				 FROM Questionaire Q WITH(NOLOCK)
				 INNER JOIN QuestionaireQuestionSet QQS WITH(NOLOCK)
					 ON Q.QuestionaireId = QQS.QuestionaireId
				 INNER JOIN QuestionSetQuestion QSQ WITH(NOLOCK) 
					 ON QQS.QuestionSetId = QSQ.QuestionSetId
				 INNER JOIN Question QS WITH(NOLOCK)
					 ON QS.QuestionId = QSQ.QuestionId
				 INNER JOIN Answer A WITH(NOLOCK)
					 ON A.QuestionId = QS.QuestionId
				 INNER JOIN (SELECT KeyValue 
							FROM dbo.udf_SplitStringToTable(@vc_AnswerUnqiueNos,',')) DT
					ON DT.KeyValue = A.UniqueId
				 WHERE Q.UniqueId = @assessmentUniqueNo) TA 
		ON PT.TypeId = TA.QuestionaireId
	AND PAA.AnswerId = TA.AnswerId
	WHERE PT.TaskTypeId = @i_TaskTypeId
	AND PT.TaskStatusId = @i_TaskStatusID
	AND RIGHT(CONVERT(VARCHAR(10), PT.DateTaken, 103), 7) = @assessmentCompletedDate

	RETURN @i_patientCount	

END
