﻿

CREATE FUNCTION [dbo].[udf_GetProvidersByPatient] (
	@i_AppuserID INT
	,@tblPatient ttypeKeyID READONLY
	)
RETURNS @output TABLE (
	PatientID INT
	,ProviderID INT
	)

BEGIN
	

	INSERT INTO @output
	SELECT DISTINCT PCP.PatientId
		,phc.ParentProviderID
	FROM ProviderHierarchyDetail phc WITH (NOLOCK)
	INNER JOIN PatientPCP pcp WITH (NOLOCK)
		ON phc.ChildProviderID = pcp.ProviderID
	INNER JOIN UserGroup UG WITH (NOLOCK)
		ON UG.ProviderID = phc.ParentProviderID
	INNER JOIN @tblPatient pt
		ON pt.tKeyId = pcp.PatientId
	
	UNION
	
	SELECT DISTINCT PCP.PatientId
		,pcp.ProviderID
	FROM PatientPCP pcp WITH (NOLOCK)
	INNER JOIN @tblPatient pt
		ON pt.tKeyId = pcp.PatientId
	INNER JOIN UserGroup UG WITH (NOLOCK)
		ON UG.ProviderID = pcp.ProviderID
	
	UNION
	
	SELECT DISTINCT pp.PatientID
		,ctm.ProviderID
	FROM PatientProgram pp WITH (NOLOCK)
	INNER JOIN @tblPatient pt
		ON pt.tKeyId = pp.PatientId
	INNER JOIN ProgramCareTeam pct WITH (NOLOCK)
		ON pct.ProgramID = pp.ProgramID
	INNER JOIN CareTeamMembers ctm WITH (NOLOCK)
		ON ctm.CareTeamID = pct.CareTeamID
	INNER JOIN UserGroup UG WITH (NOLOCK)
		ON UG.ProviderID = ctm.ProviderID
	WHERE pp.StatusCode = 'E'
		AND ctm.StatusCode = 'A'
	
	UNION
	
	SELECT DISTINCT ui.PatientID
		,P.ProviderID
	FROM PatientInsurance ui WITH (NOLOCK)
	INNER JOIN @tblPatient pt
		ON pt.tKeyId = ui.PatientId
	INNER JOIN PatientInsuranceBenefit b WITH (NOLOCK)
		ON b.PatientInsuranceID = ui.PatientInsuranceID
	INNER JOIN InsuranceGroupPlan igp WITH (NOLOCK)
		ON igp.InsuranceGroupPlanID = ui.InsuranceGroupPlanID
	INNER JOIN InsuranceGroup ig WITH (NOLOCK)
		ON ig.InsuranceGroupID = igp.InsuranceGroupID
	INNER JOIN Provider P WITH (NOLOCK)
		ON P.InsuranceGroupID = ig.InsuranceGroupID
	INNER JOIN UserGroup UG WITH (NOLOCK)
		ON UG.ProviderID = P.ProviderID
	
	RETURN
END
