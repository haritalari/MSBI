﻿/*  
--------------------------------------------------------------------------------------- 
Function Name: [dbo].[ufn_GetAgeEligiblePopulation] 
Description   : This function is used to get the eligible patients data for configured PD or MP from loaded eligibility data and used in 
				configured denominators stored proc to get the denominators patients data.
Created By    :
Created Date 
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION 
05-june-2015  Nagasiva removed unused Left joins and unused columns to improve performance.
----------------------------------------------------------------------------------------  
*/
CREATE FUNCTION [dbo].[ufn_GetAgeEligiblePopulation]
(
	@AnchorDate_Year int,
	@AnchorDate_Month int,
	@AnchorDate_Day int,

	@Num_Months_Prior int,
	@Num_Months_After int,

	@EligibleAge_MIN int,
	@EligibleAge_MAX int,

	@IsDeceased bit,
	@PatientStatus varchar(1)
)
RETURNS TABLE
AS

RETURN
(
	/************************************************************ INPUT PARAMETERS ************************************************************

	 @AnchorDate_Year = Year of the Anchor Date for which Eligible Population is to be constructed.

	 @AnchorDate_Month = Month of the Anchor Date for which Eligible Population is to be constructed.

	 @AnchorDate_Day = Day in the Month of the Anchor Date for which Eligible Population is to be constructed.

	 @Num_Months_Prior_EligiblePop int = Number of Months Before the Anchor Date from which Age-Eligible Population is to be constructed.

	 @Num_Months_After_EligiblePop int = Number of Months After the Anchor Date from which Age-Eligible Population is to be constructed.

	 @EligibleAge_MIN = Minimum Age at which an Individual can be included in the Age-Eligible Population to be constructed.

	 @EligibleAge_MAX - Maximum Age at which an Individual can be included in the Age-Eligible Population to be constructed.

	 @IsDeceased = Deceased Status of Individuals selected for inclusion in the Age-Eligible Population.
				   Examples = 1 ('Yes, Is DEAD'), 0 ('No, Is ALIVE'), or NULL (unspecified).

	 @PatientStatus = Status of Individual Patients selected for inclusion in the Age-Eligible Population.
					  Examples = 'A' ('Yes, Patient is Active'), 'I' ('No, Accout is Inactive/Disabled'), etc.

	 *********************************************************************************************************************************************/


	SELECT pat.[PatientID], 
		  pat.[AccountStatusCode] AS 'PatientStatus', 
		   pat.[Gender] ,pat.[UserID]
	FROM 
		[dbo].[Patient] pat
	
    WHERE (((@IsDeceased IS NULL) OR (@IsDeceased = 0)) AND ((pat.[IsDeceased] IS NULL) OR
															 (pat.[IsDeceased] = 0) OR
															 (pat.[DateDeceased] > (CONVERT(varchar, @AnchorDate_Year) + '-' +
																					CONVERT(varchar, @AnchorDate_Month) + '-' +
																					CONVERT(varchar, @AnchorDate_Day))))) AND

		  ((@EligibleAge_MIN IS NULL) OR
		   (DateDIFF(YYYY, pat.[DateOfBirth], (CONVERT(varchar, @AnchorDate_Year) + '-' +
											   CONVERT(varchar, @AnchorDate_Month) + '-' +
											   CONVERT(varchar, @AnchorDate_Day))) >= @EligibleAge_MIN) OR
		   (DateDIFF(YYYY, pat.[DateOfBirth], DATEADD(MM, @Num_Months_After, (CONVERT(varchar, @AnchorDate_Year) + '-' +
																			  CONVERT(varchar, @AnchorDate_Month) + '-' +
																			  CONVERT(varchar, @AnchorDate_Day)))) >= @EligibleAge_MIN)) AND

		  ((@EligibleAge_MAX IS NULL) OR
		   (DateDIFF(YYYY, pat.[DateOfBirth], DATEADD(MM, -@Num_Months_Prior, (CONVERT(varchar, @AnchorDate_Year) + '-' +
																			   CONVERT(varchar, @AnchorDate_Month) + '-' +
																			   CONVERT(varchar, @AnchorDate_Day)))) <= @EligibleAge_MAX) OR
		   (DateDIFF(YYYY, pat.[DateOfBirth], (CONVERT(varchar, @AnchorDate_Year) + '-' +
											   CONVERT(varchar, @AnchorDate_Month) + '-' +
											   CONVERT(varchar, @AnchorDate_Day))) <= @EligibleAge_MAX))

);


