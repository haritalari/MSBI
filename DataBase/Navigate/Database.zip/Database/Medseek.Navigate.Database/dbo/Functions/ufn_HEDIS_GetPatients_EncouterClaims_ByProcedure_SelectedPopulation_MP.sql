﻿/*  
---------------------------------------------------------------------------------------  
Function Name: [dbo].[ufn_HEDIS_GetPatients_EncouterClaims_ByProcedure_SelectedPopulation_MP]
Description   : This function is used to get the patients data for configured PD or MP from loaded claims data and used in 
				configured numerators stored proc to get the numerators data.
Created By    :   
Created Date  : 
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
05-june-2015 Nagasiva removed unused Left joins and unused AND conditions in Join statements to improve performance.
----------------------------------------------------------------------------------------  
*/
CREATE FUNCTION [dbo].[ufn_HEDIS_GetPatients_EncouterClaims_ByProcedure_SelectedPopulation_MP] (
	@ECTTableName VARCHAR(30)
	,@PopulationDefinitionID INT
	,@AnchorYear_NumYearsOffset INT
	,@Num_Months_Prior INT
	,@Num_Months_After INT
	,@ECTCodeVersion_Year INT
	,@ECTCodeStatus VARCHAR(1)
	,@AnchorDate_Year INT = 2012
	,@AnchorDate_Month VARCHAR(2) = 12
	,@AnchorDate_Day VARCHAR(2) = 31
	,@i_ManagedPopulationID INT
	,@c_ReportType CHAR(1) = 'P' --P For Population ,S- stratagic 
	)
RETURNS @OUTPUT TABLE (
	PatientID INT
	,BeginServiceDate Date
	,ProcedureCode VARCHAR(10)
	)

BEGIN
	/************************************************************ INPUT PARAMETERS ************************************************************  
  
  @PopulationDefinitionID = Handle to the selected Population of Patients from which the Eligible Population of Patients of the Numerator  
          are to be constructed.  
  
  @AnchorYear_NumYearsOffset = Number of Years of OFFSET -- After (+) or Before (-) -- from the Anchor Year around which the Patients in the  
          selected Population was chosen, serving as the new Anchor Year around which the Eligible Population of  
          Patients is to be constructed.  
  
  @ECTTableName = Name of the ECT Table containing Medical Codes (i.e. CPT, CPT-II, HCPCS, and ICD Procedure) to be used for  
      determining Eligible Population of Patients with qualifying Medical Claims.  
  
  @Num_Months_Prior = Number of Months Prior to the Anchor Date from which Eligible Population of Patients with Encounters/Event  
       Diagnoses is to be constructed.  
  
  @Num_Months_After = Number of Months After the Anchor Date from which Eligible Population of Patients with Encounters/Diagnoses  
       is to be constructed.  
  
  @ECTCodeVersion_Year = Code Version Year from which HEDIS-associated ECT Codes (e.g. ICD-9-CM, ICD-10-CM, etc.) that are to be used to  
       select Patients for inclusion in the Eligible Population of Patients, with health claims for Encounters/Event  
       Diagnoses that are for Diseases and Health Conditions associated with the Measure, to be constructed for the  
       Measurement Period.  
  
  @ECTCodeStatus = Status of HEDIS-associated ECT Codes (e.g. ICD-9-CM, ICD-10-CM, etc.) that are to be used to select Patients for inclusion  
       in the Eligible Population of Patients, with health claims for Encounters/Event Diagnoses that are for Diseases and Health  
       Conditions associated with the Measure, to be constructed for the Measurement Period.  
       Examples = 'A' (for 'Active') or 'I' (for 'Inactive').  
  
  *********************************************************************************************************************************************/
	DECLARE @DateKey VARCHAR(10)

	SET @DateKey = CONVERT(VARCHAR(10), @AnchorDate_Year) + CONVERT(VARCHAR(10), @AnchorDate_Month) + CONVERT(VARCHAR(10), @AnchorDate_Day)

	
		INSERT INTO @OUTPUT
		SELECT ci.[PatientID],
			cl.[BeginServiceDate],
			cod_proc.ProcedureCode
		FROM [dbo].[ClaimLine] cl WITH (NOLOCK)
		INNER JOIN [dbo].[ClaimInfo] ci WITH (NOLOCK) ON ci.[ClaimInfoID] = cl.[ClaimInfoID]
		INNER JOIN [dbo].[PopulationDefinitionPatients] p WITH (NOLOCK) ON p.[PatientID] = ci.[PatientID]
		INNER JOIN PopulationDefinitionPatientAnchorDate pdpad
		   ON pdpad.PopulationDefinitionPatientID = p.PopulationDefinitionPatientID	
		INNER JOIN PatientProgram pp WITH (NOLOCK) ON pp.PatientID = p.PatientID
		INNER JOIN [dbo].[CodeSetProcedure] cod_proc WITH (NOLOCK) ON (cod_proc.[ProcedureCodeID] = cl.[ProcedureCodeID])
		INNER JOIN (SELECT [ECTCode]
					FROM dbo.ufn_HEDIS_GetECTCodeInfo_ByTableName(@ECTTableName, @ECTCodeVersion_Year, @ECTCodeStatus)
					WHERE [ECTHedisCodeTypeCode] IN (
							'CPT'
							,'CPT-CAT-II'
							,'HCPCS'
							)) cpt
							on cpt.ECTCode = cod_proc.ProcedureCode
		WHERE (
				cl.[BeginServiceDate] BETWEEN (DATEADD(MM, - @Num_Months_Prior, DATEADD(YYYY, @AnchorYear_NumYearsOffset, pdpad.OutPutAnchorDate)))
					AND (DATEADD(MM, @Num_Months_After, DATEADD(YYYY, @AnchorYear_NumYearsOffset, pdpad.OutPutAnchorDate)))
				)
			AND PopulationDefinitionID = @PopulationDefinitionID
			AND pp.ProgramID = @i_ManagedPopulationID
			AND pdpad.DateKey = @DateKey
			AND pdpad.OutPutAnchorDate  = CASE 
						WHEN pdpad.OutPutAnchorDate BETWEEN DATEADD(dd, - (DAY(PP.EnrollmentStartDate) - 1), PP.EnrollmentStartDate)
								AND CASE 
										WHEN YEAR(ISNULL(PP.EnrollmentEndDate, '9999-12-31')) = 9999
											THEN ISNULL(PP.EnrollmentEndDate, '9999-12-31')
										ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, PP.EnrollmentEndDate) + 1, 0))
										END
							THEN pdpad.OutPutAnchorDate
						ELSE NULL
						END
		
		UNION
		
		SELECT ci.[PatientID]
			,Ci.[DateOfAdmit] AS BeginServiceDate
			,cod_iproc.ProcedureCode
		FROM [dbo].[ClaimInfo] ci WITH (NOLOCK)
		INNER JOIN [dbo].[PopulationDefinitionPatients] p ON p.[PatientID] = ci.[PatientID]
		INNER JOIN PatientProgram pp WITH (NOLOCK) ON pp.PatientID = p.PatientID
		INNER JOIN PopulationDefinitionPatientAnchorDate pdpad WITH (NOLOCK) 
		ON pdpad.PopulationDefinitionPatientID = P.PopulationDefinitionPatientID
		INNER JOIN [dbo].[ClaimProcedure] cp WITH (NOLOCK) ON cp.[ClaimInfoID] = ci.[ClaimInfoID]
		INNER JOIN [dbo].[CodeSetICDProcedure] cod_iproc WITH (NOLOCK) ON (cod_iproc.[ProcedureCodeID] = cp.[ProcedureCodeID])
		INNER JOIN (
					SELECT [ECTCode]
					FROM dbo.ufn_HEDIS_GetECTCodeInfo_ByTableName(@ECTTableName, @ECTCodeVersion_Year, @ECTCodeStatus)
					WHERE [ECTHedisCodeTypeCode] IN (
							'ICD9-Proc'
							,'ICD10-Proc'
							)
					) icdproc
					on icdproc.ECTCode = cod_iproc.ProcedureCode
		
		WHERE (
				ci.[DateOfAdmit] BETWEEN (DATEADD(MM, - @Num_Months_Prior, DATEADD(YYYY, @AnchorYear_NumYearsOffset, pdpad.OutPutAnchorDate)))
					AND (DATEADD(MM, @Num_Months_After, DATEADD(YYYY, @AnchorYear_NumYearsOffset, pdpad.OutPutAnchorDate)))
				)
			AND PopulationDefinitionID = @PopulationDefinitionID
			AND pp.ProgramID = @i_ManagedPopulationID
			AND pdpad.DateKey = @DateKey
			AND pdpad.OutPutAnchorDate  = CASE 
						WHEN pdpad.OutPutAnchorDate BETWEEN DATEADD(dd, - (DAY(PP.EnrollmentStartDate) - 1), PP.EnrollmentStartDate)
								AND CASE 
										WHEN YEAR(ISNULL(PP.EnrollmentEndDate, '9999-12-31')) = 9999
											THEN ISNULL(PP.EnrollmentEndDate, '9999-12-31')
										ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, PP.EnrollmentEndDate) + 1, 0))
										END
							THEN pdpad.OutPutAnchorDate
						ELSE NULL
						END
	
	
	RETURN
END
