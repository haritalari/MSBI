﻿
CREATE FUNCTION [dbo].[ufn_FormatMasterCode_ICD10Diag] (
	@ip_ICD10Code VARCHAR(10),
	@ip_MinimumNumDigits TINYINT = NULL,
	@ip_MaximumNumDigits TINYINT = NULL,
	@ip_RemoveALLBlanks BIT = NULL,
	@ip_RemoveLeadingZeros BIT = NULL,
	@ip_RemoveTrailingZeros BIT = NULL,
	@ip_PadWithLeadingZeros BIT = NULL,
	@ip_PadWithTrailingZeros BIT = NULL
	)
RETURNS VARCHAR(10)
AS
BEGIN
	/************************************************************ INPUT PARAMETERS ************************************************************

	 @ICD10Code = The ICD-10-CM Diagnosis Code to be formatted.

	 @MinimumNumDigits = Minimum Number of Digits/Characters that make up a properly-formatted Code.

	 @MaximumNumDigits = Maximum Number of Digits/Characters that make up a properly-formatted Code.

	 @RemoveALLBlanks = Indicator of whether to remove or filter-out ALL Blanks or Empty String (" ") from the ICD-10-CM Diagnosis Code to be
						formatted.

	 @RemoveLeadingZeros = Indicator of whether to remove or filter-out Leading Zeros (0's) from the ICD-10-CM Diagnosis Code to be formatted.

	 @RemoveTrailingZeros = Indicator of whether to remove or filter-out Trailing Zeros (0's) from the ICD-10-CM Diagnosis Code to be formatted.
	 
	 @PadWithLeadingZeros = Indicator of whether to pad or fill-in Leading Zeros (0's) from the ICD-10-CM Diagnosis Code to be formatted.

	 @PadWithTrailingZeros = Indicator of whether to pad or fill-in Trailing Zeros (0's) from the ICD-10-CM Procedure Code to be formatted.

	 *********************************************************************************************************************************************/
	DECLARE @MinimumNumDigits TINYINT,
		@MaximumNumDigits TINYINT,
		@RemoveALLBlanks BIT,
		@RemoveLeadingZeros BIT,
		@RemoveTrailingZeros BIT,
		@PadWithLeadingZeros BIT,
		@PadWithTrailingZeros BIT,
		@StrLen INT,
		@StrChars VARCHAR(100),
		@CurrentPtr INT,
		@StrChr VARCHAR(10),
		@ICD10Code VARCHAR(10)

	SET @MinimumNumDigits = @ip_MinimumNumDigits
	SET @MaximumNumDigits = @ip_MaximumNumDigits
	SET @RemoveALLBlanks = @ip_RemoveALLBlanks
	SET @RemoveLeadingZeros = @ip_RemoveLeadingZeros
	SET @RemoveTrailingZeros = @ip_RemoveTrailingZeros
	SET @PadWithLeadingZeros = @ip_PadWithLeadingZeros
	SET @PadWithTrailingZeros = @ip_PadWithTrailingZeros
	SET @ICD10Code = @ip_ICD10Code

	/* Retrieve Code-Formatting Parameters for the Code to be Formatted. */
	IF (
			@MinimumNumDigits IS NULL
			OR @MaximumNumDigits IS NULL
			OR @RemoveALLBlanks IS NULL
			OR @RemoveLeadingZeros IS NULL
			OR @RemoveTrailingZeros IS NULL
			OR @PadWithLeadingZeros IS NULL
			OR @PadWithTrailingZeros IS NULL
			)
		SELECT @MinimumNumDigits = CASE 
				WHEN @MinimumNumDigits IS NULL
					THEN [MinimumNumDigits]
				ELSE @MinimumNumDigits
				END,
			@MaximumNumDigits = CASE 
				WHEN @MaximumNumDigits IS NULL
					THEN [MaximumNumDigits]
				ELSE @MaximumNumDigits
				END,
			@RemoveALLBlanks = CASE 
				WHEN @RemoveALLBlanks IS NULL
					THEN [RemoveALLBlanks]
				ELSE @RemoveALLBlanks
				END,
			@RemoveLeadingZeros = CASE 
				WHEN @RemoveLeadingZeros IS NULL
					THEN [RemoveLeadingZeros]
				ELSE @RemoveLeadingZeros
				END,
			@RemoveTrailingZeros = CASE 
				WHEN @RemoveTrailingZeros IS NULL
					THEN [RemoveTrailingZeros]
				ELSE @RemoveTrailingZeros
				END,
			@PadWithLeadingZeros = CASE 
				WHEN @PadWithLeadingZeros IS NULL
					THEN [PadWithLeadingZeros]
				ELSE @PadWithLeadingZeros
				END,
			@PadWithTrailingZeros = CASE 
				WHEN @PadWithTrailingZeros IS NULL
					THEN [PadWithTrailingZeros]
				ELSE @PadWithTrailingZeros
				END
		FROM [dbo].[LkUpCodeType]
		WHERE [CodeTypeCode] = 'ICD-10-CM-Diag'

	-- Removes ALL Blanks (" ") from the Code to be formatted.
	IF @RemoveALLBlanks = 1
		SET @ICD10Code = RTRIM(LTRIM(REPLACE(@ICD10Code, ' ', '')));

	--Checks if the Code is an EMPTY , return NULL if YES
	IF @ICD10Code = ''
		SET @ICD10Code = NULL;

	--Removes 'Leading Zeros' if RemoveLeadingZeros = 1
	IF @RemoveLeadingZeros = 1
	BEGIN
		SET @StrLen = LEN(@ICD10Code);
		SET @CurrentPtr = 1;

		WHILE @CurrentPtr < @StrLen
		BEGIN
			IF SUBSTRING(@ICD10Code, @CurrentPtr, 1) <> '0'
				BREAK;

			SET @CurrentPtr = @CurrentPtr + 1
		END

		SET @ICD10Code = SUBSTRING(@ICD10Code, @CurrentPtr, @StrLen);
	END

	--Removes 'Trailing Zeros' if RemoveTrailingZeros = 1
	IF @RemoveTrailingZeros = 1
	BEGIN
		SET @StrLen = LEN(@ICD10Code);

		WHILE @StrLen > 1
		BEGIN
			IF SUBSTRING(@ICD10Code, @StrLen, 1) <> '0'
				BREAK;

			SET @StrLen = @StrLen - 1;
		END

		SET @ICD10Code = SUBSTRING(@ICD10Code, 1, @StrLen);
	END

	/* Checks and confirms that the FIRST (1st) Digit of the Code is an Alphabetic character 
	  and the SECOND (2nd) Digit is Numeric if not, the function Returns a NULL value. */
	IF SUBSTRING(@ICD10Code, 1, 1) NOT LIKE '[a-z]'
		OR SUBSTRING(@ICD10Code, 2, 1) NOT LIKE '[0-9]'
		SET @ICD10Code = NULL;

	/* The Code includes a Decimal Point '.'.  And, if Yes, additional processing will be performed to
	  ensure that the Code meets the 'Code with Decimal Point' requirement -- Number of Digits (a
	  Minimum of THREE (3)) BEFORE the Decimal Point, PLUS optional FOURTH alphanumeric digits
	  after the Decimal Point. 
	  
	  3-7 Characers
	  Character 1 is alpha
	  Character 2 is numeric
	  Characters 3 - 7 can be alpha numeric
	*/
	IF @ICD10Code LIKE '%.%'
	BEGIN
		/* Checks the Code for the Number of Digits it has BEFORE the Decimal Point.  The Code is PADDED
		 with Leading Zeros, if necessary, to meet the 'Minimum 3 Digits' BEFORE the Decimal Point.
		 But, if the Number of Digits is GREATER THAN 3, the function Exits and Returns a NULL value. */
		SET @CurrentPtr = CHARINDEX('.', @ICD10Code, 1);
		SET @StrChars = SUBSTRING(@ICD10Code, 1, @CurrentPtr - 1);

		IF LEN(@StrChars) > @MinimumNumDigits
			SET @ICD10Code = NULL;
		ELSE
		BEGIN
			IF @PadWithLeadingZeros = 1
				SET @ICD10Code = RIGHT('000' + @ICD10Code, @MinimumNumDigits);
		END

		/* Checks the Code for the Number of Optional Digits it has AFTER the Decimal Point.  If the
		 Number of Digits is GREATER THAN 4, the function Exits and Returns a NULL value.  And, if
		 required, the Code is PADDED with a Trailing Zero. */
		SET @CurrentPtr = CHARINDEX('.', @ICD10Code, 1);
		SET @StrChars = SUBSTRING(@ICD10Code, @CurrentPtr + 1, LEN(@ICD10Code));

		--Check and confirm if the number of characters after the decimal is upto 4 characters long
		IF LEN(@StrChars) > 4
			SET @ICD10Code = NULL;
		ELSE
		BEGIN
			IF (@PadWithTrailingZeros = 1)
				SET @ICD10Code = LEFT(@ICD10Code + '0000', @MaximumNumDigits - @MinimumNumDigits);
		END
	END
	ELSE
	BEGIN
		/* Checks the Total Number of Digits that the Code has.  The Code is PADDED with Leading Zeros,
		 if necessary, to meet the 'Minimum 3 Digits' length requirement. */
		IF LEN(@ICD10Code) < @MinimumNumDigits
		BEGIN
			IF @PadWithLeadingZeros = 1
				SET @ICD10Code = RIGHT('000' + @ICD10Code, @MinimumNumDigits);
		END

		/* Checks the Total Number of Digits that the Code has.  The Code is PADDED with Leading Zeros,
		 if necessary, to meet the 'Minimum 3 Digits' length requirement.  But, if the Number of
		 Digits of the Code is GREATER THAN 5, the function Exits and Returns a NULL value. */
		IF (LEN(@ICD10Code) < @MaximumNumDigits)
		BEGIN
			IF @PadWithTrailingZeros = 1
				SET @ICD10Code = LEFT(@ICD10Code + '00000', @MaximumNumDigits);
		END
	END

	/* Removes the Decimal Point (.) from the Code being formatted. */
	SET @ICD10Code = REPLACE(@ICD10Code, '.', '');

	/* Outputs the formatted code, if it meets the 'Code Length' requirements -- both MINIMUM and MAXIMUM -- of Codes
	  of its Code Type.  Otherwise, no Code (NULL) is outputed. */
	IF (LEN(@ICD10Code) < @MinimumNumDigits)
		OR (LEN(@ICD10Code) > @MaximumNumDigits)
		SET @ICD10Code = NULL;
	
	/*	V-Codes should always be exactly 7 characters long
		V-code to be valid in ICD10, it must have all 7 characters.  
		Therefore, any V-code with 2, 3 or 4 numeric codes following will always be an ICD9 code
	*/
	IF LEFT(@ICD10Code,1) = 'V' AND LEN(@ICD10Code) <> 7
		SET @ICD10Code = @ICD10Code
	
	-- Outputs the Formatted Code, or NULL. --
	RETURN (@ICD10Code);
END;

