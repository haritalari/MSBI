﻿/*                  
------------------------------------------------------------------------------                  
Function Name : [dbo].[ufn_GetActiveProgramIds]      
Description   : This Function Returns Active Programs for Filters
Created By    : Wasim Ahmed
Created Date  : 01-Sep-2015
------------------------------------------------------------------------------                  
Log History   :                   
DD-MM-YYYY     BY      DESCRIPTION                  
------------------------------------------------------------------------------                  
*/      
CREATE FUNCTION [dbo].[ufn_GetActiveProgramIds]
(
  @v_ProgramIds VARCHAR(MAX)
)
RETURNS  VARCHAR(MAX)
AS
BEGIN

	if (@v_ProgramIds is not null or @v_ProgramIds <> '') 
	begin
		DECLARE @List VARCHAR(max)
	
		SELECT @List = COALESCE(@List + ',', '') + CAST(ProgramId AS VARCHAR)
		FROM
		  (SELECT ElementVal
		   FROM dbo.ufn_ConvertListToTable_String(@v_ProgramIds,len(@v_ProgramIds),',')) d,
			 Program p
		WHERE p.ProgramId = d.ElementVal	 		
		RETURN @List
	end
	 
	 
	return @v_ProgramIds
	 
END