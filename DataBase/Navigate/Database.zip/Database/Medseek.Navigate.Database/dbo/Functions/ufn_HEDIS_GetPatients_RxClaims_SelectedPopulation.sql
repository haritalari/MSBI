﻿/*  
--------------------------------------------------------------------------------------- 
Function Name: [dbo].[ufn_HEDIS_GetPatients_RxClaims_SelectedPopulation] 
Description   : This function is used to get the patients data for configured PD or MP from loaded claims and Rx Claims data and used in 
				configured numerators stored proc to get the numerators data.
Created By    :
Created Date 
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION 
05-june-2015  Nagasiva removed unused Left joins and unused AND conditions in Join statements to improve performance.
----------------------------------------------------------------------------------------  
*/
CREATE FUNCTION [dbo].[ufn_HEDIS_GetPatients_RxClaims_SelectedPopulation] (
	@ECTTableName VARCHAR(30)
	,@PopulationDefinitionID INT
	,@AnchorYear_NumYearsOffset INT
	,@Num_Months_Prior INT
	,@Num_Months_After INT
	,@ECTCodeVersion_Year INT
	,@ECTCodeStatus VARCHAR(1)
	,@AnchorDate_Year INT = 2012
	,@AnchorDate_Month VARCHAR(2) = 12
	,@AnchorDate_Day VARCHAR(2) = 31
	,@ReportKey CHAR(1) ='P'--P for Population S for Strategic
	)
RETURNS @Output TABLE
( PatientID INT
,Datefilled  DATE
  
)
		/************************************************************ INPUT PARAMETERS ************************************************************  
	    
	    @ECTTableName = Name of the ECT Table containing NDC Drug Codes to be used for selection of Patients for inclusion in the Eligible  
	    Population of Patients with qualifying Rx/Pharmacy Claims are to be drawn or selected from.  
	    
	    @PopulationDefinitionID = Handle to the selected Population of Patients from which the Eligible Population of Patients of the Numerator  
	    are to be constructed.  
	    
	    @AnchorYear_NumYearsOffset = Number of Years of OFFSET -- After (+) or Before (-) -- from the Anchor Year around which the Patients in the  
	    selected Population was chosen, serving as the new Anchor Year around which the Eligible Population of  
	    Patients is to be constructed.  
	    
	    @Num_Months_Prior = Number of Months Before the Anchor Date from which Eligible Population of Patients with "Diabetes" Pharmacy/Rx Claims  
	    is to be constructed.  
	    
	    @Num_Months_After = Number of Months After the Anchor Date from which Eligible Population of Patients with "Diabetes" Pharmacy/Rx Claims  
	    is to be constructed.  
	    
	    @ECTCodeVersion_Year = Code Version Year from which HEDIS-associated NDC Drug Codes that are used to select Patients for inclusion in  
	    the Eligible Population of Patients, with Rx/Pharmacy claims that are for Diseases and Health Conditions  
	    associated with the Measure, to be constructed for the Measurement Year/Period.  
	    
	    @ECTCodeStatus = Status of HEDIS-associated NDC Drug Codes that are used to select Patients for inclusion in the Eligible Population of  
	    Patients, with Rx/Pharmacy claims that are for Diseases and Health Conditions associated with the Measure, to be  
	    constructed for the Measurement Year/Period.  
	    Examples = 1 (for 'Enabled') or 0 (for 'Disabled').  
	     *********************************************************************************************************************************************/
BEGIN
        DECLARE @datekey INT
		SET @datekey = CONVERT(VARCHAR(10), @AnchorDate_Year) + CONVERT(VARCHAR(10), @AnchorDate_Month) + CONVERT(VARCHAR(10), @AnchorDate_Day)
		
		INSERT INTO @OutPut
		SELECT DISTINCT  rx_clm.[PatientID]
						,rx_clm.[DateFilled]
		FROM [RxClaim] rx_clm
		INNER JOIN [dbo].[PopulationDefinitionPatients] p
			ON p.[PatientID] = rx_clm.[PatientID]
		INNER JOIN PopulationDefinitionPatientAnchorDate pdpa
			ON pdpa.PopulationDefinitionPatientID = p.PopulationDefinitionPatientID
		INNER JOIN [CodeSetDrug] rx
			ON (rx.[DrugCodeId] = rx_clm.[DrugCodeId])
		INNER JOIN (
					SELECT [DrugCode]
					FROM dbo.ufn_HEDIS_GetDrugInfo_ByTableName(@ECTTableName, @ECTCodeVersion_Year, @ECTCodeStatus)
					) rxx
					on rxx.DrugCode = rx.DrugCode
		WHERE (
				rx_clm.[DateFilled] BETWEEN (DATEADD(YYYY, - @Num_Months_Prior, DATEADD(YYYY, @AnchorYear_NumYearsOffset, pdpa.OutPutAnchorDate)))
					AND (DATEADD(YYYY, @Num_Months_After, DATEADD(YYYY, @AnchorYear_NumYearsOffset, pdpa.OutPutAnchorDate)))
				)
			AND p.PopulationdefinitionID = @PopulationDefinitionID
			AND pdpa.DateKey = @datekey

RETURN 
END
