﻿CREATE FUNCTION [dbo].[ufn_GetTaskLastcompletedDate] (
	@i_PatientID INT
	,@i_TaskTypeID INT
	,@i_TypeID INT
	,@i_TaskStatusID INT
	,@c_IsTaskID BIT
	)
RETURNS  VARCHAR(500)
AS
BEGIN
	DECLARE @v_Out VARCHAR(500)

	SELECT TOP 1 @v_Out = CASE WHEN @c_IsTaskID = 0 THEN CONVERT(VARCHAR(20), DateTaken, 101) WHEN @c_IsTaskID = 1 THEN CONVERT(VARCHAR(20), PatientTaskId) END
	FROM PatientTask WITH (NOLOCK)
	WHERE PatientId = @i_PatientID
		AND TaskStatusId = @i_TaskStatusID
		AND TypeId = @i_TypeID
		AND TaskTypeId = @i_TaskTypeID
	ORDER BY DateTaken DESC

	RETURN @v_Out
END