﻿/*                
------------------------------------------------------------------------------                
Function Name: ufn_GetPatientMeasureLatestValue          
Description   : This Function Returns Patient Latest MeasureValue for patient
Created By    : Pramod                
Created Date  : 09-July-2010                
------------------------------------------------------------------------------                
Log History   :                 
DD-MM-YYYY     BY      DESCRIPTION                
05-Setp-2011 Rathnam modified the exist clause
------------------------------------------------------------------------------                
*/    
CREATE FUNCTION [dbo].[ufn_GetPatientMeasureLatestValue]
(
   @i_PatientUserId KeyId ,
   @i_MeasureId KeyId
)
RETURNS VARCHAR(200)
AS
BEGIN
		DECLARE @vc_MeasureValue VARCHAR(200)
		SELECT @vc_MeasureValue = ISNULL(CAST(PatientMeasure.MeasureValueNumeric AS VARCHAR(15)), PatientMeasure.MeasureValueText) 
        FROM
            PatientMeasure
        INNER JOIN Measure
            ON Measure.MeasureId = PatientMeasure.MeasureId
        WHERE
              PatientMeasure.PatientId = @i_PatientUserId
          AND PatientMeasure.MeasureId = @i_MeasureId
          AND PatientMeasure.StatusCode = 'A'
          AND Measure.StatusCode = 'A'
          --AND UserMeasure.DateTaken > DATEADD(YEAR, -1, GETDATE())
          AND EXISTS  
				 ( SELECT MAX(UM2.Datetaken)
					 FROM PatientMeasure UM2  
					WHERE UM2.PatientId = PatientMeasure.PatientId  
					  AND UM2.MeasureId = PatientMeasure.MeasureId  
				   AND UM2.StatusCode = 'A'  
				   HAVING MAX(UM2.Datetaken) = PatientMeasure.Datetaken
				  )
		 ORDER BY PatientMeasure.DateTaken DESC, Measure.Name
		RETURN @vc_MeasureValue 
END
