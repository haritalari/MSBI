﻿
/*                  
------------------------------------------------------------------------------                  
Function Name : [dbo].[ufn_GetPCPName_TVF]             
Description   : This Function Returns PCPName for patient  
Created By    : Gourishankar              
Created Date  : 18-Nov-2015                 
------------------------------------------------------------------------------                  
Log History   :                   
DD-MM-YYYY     BY      DESCRIPTION                  
18-Nov-2015	Gourishankar Converted ufn_GetPCPName to TableValied Functions as part of optamization
------------------------------------------------------------------------------                  
*/
CREATE FUNCTION [dbo].[ufn_GetPCPName_TVF] (@i_PatientUserId KeyId)
RETURNS @v_UserName TABLE (PCPName VARCHAR(250))

BEGIN
	DECLARE @i_PCPId KeyId

	SELECT TOP 1 @i_PCPId = ProviderID
	FROM PatientPCP pp
	WHERE pp.PatientId = @i_PatientUserId
	ORDER BY ISNULL(CareEndDate, CareBeginDate) DESC

	INSERT INTO @v_UserName
	SELECT COALESCE(ISNULL(LastName, '') + ' ' + ISNULL(FirstName, '') + ' ' + ISNULL(MiddleName, ''), '')
	FROM Provider
	WHERE ProviderID = @i_PCPId

	IF @@ROWCOUNT = 0
	BEGIN
		INSERT INTO @v_UserName
		SELECT ' '
	END

	RETURN
END