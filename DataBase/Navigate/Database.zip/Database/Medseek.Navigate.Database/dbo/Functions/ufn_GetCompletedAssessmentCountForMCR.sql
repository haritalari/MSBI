﻿/*                  

------------------------------------------------------------------------------                  
Function Name : [dbo].[ufn_GetCompletedAssessmentCountForMCR]         
Description   : This Function Returns Assessment Count for given Months
Created By    : Wasim              
Created Date  : 15-Mar-2016
------------------------------------------------------------------------------                  
Log History   :                   
DD-MM-YYYY     BY      DESCRIPTION  
21-Jun-2016 Nagababu Modified the logic as per NAVI-6265                
------------------------------------------------------------------------------                  
*/      
CREATE FUNCTION [dbo].[ufn_GetCompletedAssessmentCountForMCR]
(
	@assessmentUniqueNo VARCHAR(MAX),
	@assessmentMonth VARCHAR(MAX)
)
RETURNS INT
AS 
BEGIN
	DECLARE @i_assessmentCount AS INT ,
			@i_TaskTypeId INT ,
			@i_TaskStatusId INT

	SELECT @i_TaskTypeId = TaskTypeId
	FROM TaskType
	WHERE TaskTypeName = 'Assessment'

	SELECT @i_TaskStatusID = TaskStatusId 
	FROM TaskStatus WHERE TaskStatusText = 'Closed Complete'

	SELECT @i_assessmentCount = COUNT(QuestionaireId)
	FROM PatientTask PT WITH(NOLOCK)
	INNER JOIN Questionaire Q WITH(NOLOCK)
	ON PT.TypeId = Q.QuestionaireId
	WHERE PT.TaskTypeId = @i_TaskTypeId
	AND Q.UniqueId = @assessmentUniqueNo
	AND PT.TaskStatusId = @i_TaskStatusID
	AND RIGHT(CONVERT(VARCHAR(10), PT.DateTaken, 103), 7) = @assessmentMonth
			
	RETURN @i_assessmentCount	

END
