﻿
/*                  
------------------------------------------------------------------------------                  
Function Name : [dbo].[ufn_GetProviderName]             
Description   : This Function Returns PCPName for patient  
Created By    : Rathnam              
Created Date  : 18-April-2013                
------------------------------------------------------------------------------                  
Log History   :                   
DD-MM-YYYY     BY      DESCRIPTION 
18-Nov-2015	Gourishankar Converted ufn_GetProviderName to TableValied Functions as part of optamization
------------------------------------------------------------------------------                  
*/
CREATE FUNCTION [dbo].[ufn_GetProviderName_TVF] (@i_ProviderID KeyId)
RETURNS @v_UserName TABLE (ProviderName VARCHAR(250))
AS
BEGIN
	INSERT INTO @v_UserName
	SELECT CASE 
			WHEN DESCRIPTION IN ('Clinic')
				THEN OrganizationName
			WHEN DESCRIPTION IN ('Insurance')
				THEN IG.GroupName
			ELSE COALESCE(ISNULL(LastName, '') + ' ' + ISNULL(FirstName, '') + ' ' + ISNULL(MiddleName, ''), '')
			END
	FROM Provider WITH (NOLOCK)
	LEFT JOIN CodeSetProviderType WITH (NOLOCK)
		ON CodeSetProviderType.ProviderTypeCodeID = Provider.ProviderTypeID
	LEFT JOIN InsuranceGroup IG
		ON Provider.InsuranceGroupID = IG.InsuranceGroupID
	WHERE ProviderID = @i_ProviderID

	IF @@ROWCOUNT = 0
	BEGIN
		INSERT INTO @v_UserName
		SELECT ' '
	END

	RETURN
END