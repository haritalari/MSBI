﻿CREATE FUNCTION [dbo].[ufn_GetPatientspecificCriteria] (
	@v_Panel VARCHAR(100)
	,@v_InputSQL NVARCHAR(max)
	,@v_DisenrollDate VARCHAR(50)
	,@i_PatientID INT
	)
RETURNS NVARCHAR(max)
AS
BEGIN
	DECLARE @v_OutputSQL NVARCHAR(max)

	IF @v_Panel IN (
			'NDC'
			,'Medication Groupers'
			)
	BEGIN
		SELECT @v_OutputSQL = replace(@v_InputSQL, 'AND 2 = 2', ' AND PatientID = '+ CONVERT(VARCHAR(20),@i_PatientID) + '  AND  DateFilled >= ''' + @v_DisenrollDate +'''' + ' ')
	END
	ELSE IF @v_Panel IN (
			'ICD-9-CM-Diag'
			,'CPT'
			,'Utilization Groupers'
			,'Procedure Groupers'
			,'Diagnosis Groupers'
			,'CPT-CAT-II'
			,'ICD-9-CM-Proc'
			,'UB-Revenue'
			,'HCPCS'
			)
	BEGIN
		SELECT @v_OutputSQL = replace(@v_InputSQL, 'AND 2 = 2', ' AND PatientID = '+ CONVERT(VARCHAR(20),@i_PatientID) + ' AND DateOfAdmit >= ''' + @v_DisenrollDate +'''' + ' ')
	END
	ELSE IF @v_Panel IN (
			'LOINC'
			,'Lab Groupers'
			)
	BEGIN
		SELECT @v_OutputSQL = replace(@v_InputSQL, 'AND 2 = 2', ' AND PatientID = '+ CONVERT(VARCHAR(20),@i_PatientID) + ' AND  DateTaken >= ''' + @v_DisenrollDate +'''' + ' ')
	END
	ELSE IF @v_Panel IN (
			'Assessment Name'
			,'Answers and Scores'
			)
	BEGIN
	
		SELECT @v_OutputSQL = replace(@v_InputSQL, 'AND 2 = 2', ' AND pqe.PatientID = '+ CONVERT(VARCHAR(20),@i_PatientID) + ' AND  pqe.CreatedDate >= ''' + @v_DisenrollDate +'''' + ' ')
	END
	ELSE IF @v_Panel IN (
			'Admission'
			,'ER'
			)
	BEGIN
		SELECT @v_OutputSQL = replace(@v_InputSQL, 'AND 2 = 2', ' AND PatientID = '+ CONVERT(VARCHAR(20),@i_PatientID) + ' AND  VisitAdmitdate >= ''' + @v_DisenrollDate +'''' + ' ')
	END
	ELSE IF @v_Panel = 'Discharge'
	BEGIN
		SELECT @v_OutputSQL = replace(@v_InputSQL, 'AND 2 = 2', ' AND PatientID = '+ CONVERT(VARCHAR(20),@i_PatientID) + ' AND  VisitDischargedate >= ''' + @v_DisenrollDate +'''' + ' ')
	END
	ELSE 
	BEGIN
	 SELECT @v_OutputSQL = @v_InputSQL
	END

	RETURN @v_OutputSQL
END