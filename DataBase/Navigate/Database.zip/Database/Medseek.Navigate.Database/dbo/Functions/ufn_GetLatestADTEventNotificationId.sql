﻿

/*                
------------------------------------------------------------------------------                
Function Name : [ufn_GetLatestADTEventNotificationId]
Description   : This function is used to get the latest PatientEventNotificationId from PatientEventNotification table and PatientEventId from PatientEvent table
Created By    : Nagababu
Created Date  : 21-Apr-2015
------------------------------------------------------------------------------
Log History :
DD-MM-YYYY     BY      DESCRIPTION
15-Jun-2015 Nagababu Modified the function as per the impact analysis on 'A40'
12-Nov-2015 Nagababu Modified as per the NAVI-4201 & 4202
------------------------------------------------------------------------------                
*/ 
CREATE FUNCTION [dbo].[ufn_GetLatestADTEventNotificationId]
(
@i_PatientId INT ,
@b_IsNotification BIT 
)
RETURNS INT
AS
BEGIN
	DECLARE @i_Id INT
	IF @b_IsNotification = 1
		SELECT @i_Id = MAX(PatientEventNotificationId)
		FROM PatientEventNotification N WITH(NOLOCK)
		INNER JOIN PatientEvent E WITH(NOLOCK)
		ON N.PatientEventId = E.PatientEventId
		WHERE E.PatientId = @i_PatientId
		AND E.AssessmentID IS NULL AND MergePatientId IS NULL
		AND ISNULL(E.IsInternal,0) = 0
	ELSE 
		SELECT @i_Id = MAX(E.PatientEventId)
		FROM PatientEvent E WITH(NOLOCK)
		WHERE E.PatientId = @i_PatientId
		AND E.AssessmentID IS NULL AND MergePatientId IS NULL
		AND ISNULL(E.IsInternal,0) = 0

	RETURN @i_Id
END