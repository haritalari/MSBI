﻿/*                    
------------------------------------------------------------------------------                    
Function Name: [ufn_GetStateNameByID]    
Description   : This Function is used to get a state name for a particular codesetstate.   
Created By    : Nagasiva    
Created Date  : 22-Jan-2015
------------------------------------------------------------------------------    
Log History :    
DD-MM-YYYY     BY			DESCRIPTION  
30-01-2015  Sai Chaitanya	Renamed the function name and removed the hard coded value (NAVI-2091)
------------------------------------------------------------------------------                    
*/
    
CREATE FUNCTION [dbo].[ufn_GetStateNameByID]
     (    
        @i_PrimaryStateCodeId KEYID    
     )    
RETURNS VARCHAR(150)    
AS    
BEGIN    
      DECLARE @v_PrimaryStateCodeName VARCHAR(150)    
      
	  SELECT 
		 @v_PrimaryStateCodeName =  cs.StateName   
	  FROM     
		CodeSetState cs
   WHERE cs.StateID = @i_PrimaryStateCodeId 
     
   
   RETURN @v_PrimaryStateCodeName    
END