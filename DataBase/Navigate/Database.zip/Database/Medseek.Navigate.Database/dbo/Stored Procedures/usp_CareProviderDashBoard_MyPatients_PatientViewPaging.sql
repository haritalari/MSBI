﻿/*      
--------------------------------------------------------------------------------------------------------------      
Procedure Name: usp_CareProviderDashBoard_MyPatients_PatientViewPaging 88024,1,50  
Description   : This procedure is to be used for applying filter on care provider dashboard on MyPatients tab by Patientview  
Created By    : Rathnam  
Created Date  : 18-Dec-2010    
---------------------------------------------------------------------------------------------------------------      
Log History   :       
DD-Mon-YYYY  BY  DESCRIPTION    
08/09/2013:Santosh added the params @i_childProviderID and @i_ProviderID to fetch the data accordig to the PCP and Clinic
19-08-2014 Santosh removed the condition IsPatientDeclinedEnrollment while inserting into #program table
23-Sep-2014  Rathnam upgraded pagination logic from 2008r2 to 2012 using fetch next statement
19-mar-2015 Nagasiva Navi-2535 performance issue fix.applied pagination logic after build the dymic sql string.
01-April-2015  Rathnam modified the code as per NAVI-2630 # changes are ISNULL(t.IsProgramTask,0) = 1 instead of AND ((ty.IsTask = 0 AND t.TaskCompletedDate IS NOT NULL) OR ty.IsTask = 1)
03-April-2015 Rathnam cleandup unused paramters and code. done performance tuning
11-June-2015 Santosh modified the SP as per NAVI-2721
16-June-2015 Santosh modified the SP as Per NAVI-3102
09/07/2015 : Prashanth Kumar modified the code as per NAVI-3063 to add DOB filtering parameters
24/07/2015 : Chaitanya teja modified the code as per NAVI-3332 to get Missed Opportunities count same in patients tasks and mypatients
08-Sep-2015  Nagababu Modified this stored procedures as per the NAVI - 3513,NAVI - 3667,NAVI - 3515,NAVI - 3514 
10-Sep-2015 Santosh Modified the SP as per NAVI-3770
22-Sep-2015 NagaBabu Modified the functionality as per the NAVI-3934 for fetching caregaps for all users
09-Oct-2015 NagaBabu Added filter to restrict 'All Patients Managed population'
25-Jan-2016 Prashanth Fixed age filter issue
04-Feb-2016 NagaBabu Modified the logic as replacing poplationdefinitions with Codegroupings as per NAVI-4430
10-03-2016  Nagasiva As per Navi-4931 restricted inactive managed population patients while sending the providers as a table parameter input.
24-Mar-2016 Nagababu Modified the logic for caregaps as per new task architecture for NAVI-5539
29-Mar-2016 Rathnam modified as per 5421 where in allowing inactive managedpopulation pending enrollments
13-Apr-2016 Rathnam Modified as per NAVI-5791
27-Apr-2016 Rathnam Modified as per NAVI-5808
04-May-2016 Rathnam Optimized the stored procedure as per NAVI-5912
13-May-2016 Naga Babu Optimized the stored procedure as per NAVI-5948,NAVI-5950,NAVI-5951
18-May-2016 Rathnam Modified  the stored procedure as per NAVI-5217
13-Jun-2016 Nagababu Modified the logic as per NAVI-6238
28-Jun-2016 Gouri Optamized as part of NAVI-6248
29-Jun-2016 Gouri Optamized as part of NAVI-6250
23-Aug-2016 Rathnam modified the conditions logic as per NAVI-6524
-------------------------------------------------------------------------------------------------------------------------------------------------------      
*/
--exec [usp_CareProviderDashBoard_MyPatients_PatientViewPaging] @i_AppUserId = 87033, @i_StartIndex = 1,@i_EndIndex = 10,@vc_RoleName = 'Care Manager',@v_dobValue1 = '1996-07-02',@v_dobValue2 = '2015-07-03',@v_AgeOperator1 = ">=",@v_AgeOperator2 = "<="
CREATE PROCEDURE [dbo].[usp_CareProviderDashBoard_MyPatients_PatientViewPaging] --10
	(
	@i_AppUserId INT
	,@i_StartIndex INT = 1
	,@i_EndIndex INT = 10
	,@i_CareTeamId INT = NULL
	,@v_PatientLastName VARCHAR(50) = NULL
	,@d_AgeFrom DATE = NULL
	,@d_AgeTo DATE = NULL
	,@i_InsuranceGroupId INT = NULL
	,@t_tProgramID TTYPEKEYID READONLY
	,@t_tDiseaseID TTYPEKEYID READONLY
	,@t_tProvider TTYPEKEYID READONLY
	,@i_StateID INT = NULL
	,@i_PCPID INT = NULL
	,@i_ClinicID INT = NULL
	,@v_SortBy VARCHAR(50) = NULL
	,@v_SortType VARCHAR(5) = NULL
	,@vc_RoleName VARCHAR(50) = NULL
	,@c_ProductType CHAR(1) = NULL
	,@v_dobValue1 DATE = NULL
	,@v_dobValue2 DATE = NULL
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	-- Check if valid Application User ID is passed      
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END

	--Declare Variables
	DECLARE @v_ManagerRole NVARCHAR(MAX)
	DECLARE @v_CareTeam NVARCHAR(MAX)
	DECLARE @v_State VARCHAR(25)
	DECLARE @v_paramdef NVARCHAR(MAX)
	DECLARE @v_SQLForAll NVARCHAR(MAX)
	DECLARE @v_SQL NVARCHAR(MAX)
	DECLARE @v_SQLJoins NVARCHAR(MAX)
	DECLARE @v_SQLWhereClause NVARCHAR(MAX)
	DECLARE @v_SQLCareTeam NVARCHAR(MAX)
	DECLARE @v_SQLFiltered NVARCHAR(MAX)
	DECLARE @v_SQLFilteredOnDB NVARCHAR(MAX)
	DECLARE @v_SQLProgramList NVARCHAR(MAX)
	DECLARE @v_SQLProgramList1 NVARCHAR(MAX)
	DECLARE @v_SQLWhereClauseCareTeamParameter NVARCHAR(MAX)
	DECLARE @v_SQLJoinClauseCareTeamParameter NVARCHAR(MAX)
	DECLARE @i_PrgCnt INT
	DECLARE @i_PrvCnt INT
	DECLARE @i_ConditionCnt INT
	DECLARE @i_ProgramID INT
	DECLARE @LastYearDate DATE
	DECLARE @i_IncompleteTaskStatusID INT
	DECLARE @i_DisEnrollTaskStatusID INT

	IF OBJECT_ID('tempdb..#tblPatients')IS NOT NULL
		DROP TABLE #tblPatients
	IF OBJECT_ID('tempdb..#CodeGroup')IS NOT NULL
		DROP TABLE #CodeGroup
	IF OBJECT_ID('tempdb..#tmpPatientByData')IS NOT NULL
		DROP TABLE #tmpPatientByData

	
	--Create Temp Tables
	CREATE TABLE #InsuranceGroupPlan (InsuranceGroupPlanId INT PRIMARY KEY CLUSTERED)
	CREATE TABLE #Disease (Diseaseid INT PRIMARY KEY CLUSTERED)
	DECLARE @tProvider TABLE (ProviderId INT PRIMARY KEY CLUSTERED)
	DECLARE @Prg TABLE (ProgramID INT PRIMARY KEY CLUSTERED )
	CREATE TABLE #ProgPatient (Patientid INT PRIMARY KEY CLUSTERED)
	DECLARE @tProgram TABLE (ProgramId INT PRIMARY KEY CLUSTERED)
	
	CREATE TABLE #Pat (Patientid INT PRIMARY KEY CLUSTERED)
	CREATE TABLE #RolePatient (Patientid INT PRIMARY KEY CLUSTERED)
	CREATE TABLE #tblPatients
					(ID INT IDENTITY PRIMARY KEY CLUSTERED
					,UserID INT
					,PatientName VARCHAR(100)
					,DateOfBirth DATE
					,Gender VARCHAR(1)
					,TotalCount INT)
	CREATE TABLE #CodeGroup
					(CodeGroupingId INT PRIMARY KEY CLUSTERED
					,CodeGroupingName VARCHAR(500))

	CREATE NONCLUSTERED INDEX [IX_#CodeGroup_CodeGroupingName_CGID] 
	ON #CodeGroup (CodeGroupingName) 
	INCLUDE (CodeGroupingId)
	
	--Initiate Variables
	SET @LastYearDate = DATEADD(YY, - 1, GETDATE())
	SET @v_SQLJoins = ''
	SET @v_SQLWhereClause = ''
	SET @v_ManagerRole = ''
	SET @v_paramdef = '	 @i_AppUserId KEYID' + CHAR(13)+CHAR(10)
					+ '	,@i_StartIndex INT' + CHAR(13)+CHAR(10)
					+ '	,@i_EndIndex INT' + CHAR(13)+CHAR(10)
					+ '	,@i_CareTeamId KEYID' + CHAR(13)+CHAR(10)
					+ '	,@i_StateID INT' + CHAR(13)+CHAR(10)
					+ '	,@v_PatientLastName LASTNAME' + CHAR(13)+CHAR(10)
					+ '	,@d_AgeFrom DATE' + CHAR(13)+CHAR(10)
					+ '	,@d_AgeTo DATE' + CHAR(13)+CHAR(10)
					+ '	,@v_dobValue1 DATE' + CHAR(13)+CHAR(10)
					+ '	,@v_dobValue2 DATE' + CHAR(13)+CHAR(10)
					+ '	,@v_State VARCHAR(25)' + CHAR(13)+CHAR(10)
					+ '	,@i_PCPID INT' + CHAR(13)+CHAR(10)
					+ '	,@i_ClinicID INT' + CHAR(13)+CHAR(10)
					+ '	,@i_InsuranceGroupId KEYID' + CHAR(13)+CHAR(10)
					+ '	,@c_ProductType CHAR(1)' + CHAR(13)+CHAR(10)
					+ '	,@v_SortBy VARCHAR(50)' + CHAR(13)+CHAR(10)
					+ '	,@v_SortType VARCHAR(4)' + CHAR(13)+CHAR(10)
	SELECT @i_ConditionCnt = COUNT(1)
	FROM @t_tDiseaseID

	SELECT @i_PrgCnt = COUNT(1)
	FROM @t_tProgramID

	SELECT @i_PrvCnt = COUNT(1)
	FROM @t_tProvider
	
	SELECT @i_ProgramID = ProgramId
	FROM Program
	WHERE ProgramName = 'All Patients Managed population'

	SELECT @i_IncompleteTaskStatusID = ts.TaskStatusId
	FROM TaskStatus ts
	WHERE TaskStatusText = 'Closed Incomplete'

	SELECT @i_DisEnrollTaskStatusID = ts.TaskStatusId
	FROM TaskStatus ts
	WHERE TaskStatusText = 'DisEnroll'

	INSERT INTO @tProvider
	SELECT tKeyId
	FROM @t_tProvider

	IF @i_PrgCnt > 0
		BEGIN
			INSERT INTO @Prg (ProgramID)
			SELECT tKeyId
			FROM @t_tProgramID tt
			WHERE (EXISTS (
					SELECT 1
					FROM ProgramCareTeam pct WITH(NOLOCK)
					WHERE pct.CareTeamId = @i_CareTeamId
						   AND pct.ProgramId = tt.tKeyId)
						   OR @i_CareTeamId IS NULL)
		END
	ELSE
		BEGIN
			INSERT INTO @Prg (ProgramID)
			SELECT ProgramId
			FROM Program WITH(NOLOCK)
			WHERE (EXISTS (
					SELECT 1
					FROM ProgramCareTeam pct WITH(NOLOCK)
					WHERE pct.CareTeamId = @i_CareTeamId
						   AND pct.ProgramId = Program.ProgramId)
						   OR @i_CareTeamId IS NULL)

			DELETE FROM @Prg
			WHERE ProgramID = @i_ProgramID
		END

	IF @vc_RoleName NOT IN ('Care Manager' ,'Care Team Member')
	BEGIN
		
		INSERT INTO #ProgPatient
		SELECT DISTINCT pp.PatientID
		FROM PatientProgram pp WITH (NOLOCK)
		WHERE PP.StatusCode = 'E'
		AND EXISTS (SELECT 1
					FROM @Prg tp
					WHERE TP.ProgramID = PP.ProgramID
					AND (@i_PrgCnt > 0 OR PP.ProgramID <> @i_ProgramID))

	END			

	IF @vc_RoleName = 'Clinic Administrator'
	BEGIN
		INSERT INTO #RolePatient
		SELECT DISTINCT PCP.PatientId
		FROM ProviderHierarchyDetail phc WITH (NOLOCK)
		INNER JOIN PatientPCP pcp WITH (NOLOCK) 
			ON phc.ChildProviderID = pcp.ProviderID
		INNER JOIN #ProgPatient pp 
			ON pp.Patientid = pcp.PatientId
		WHERE phc.ParentProviderID = @i_AppuserID
	END
	ELSE 
	IF @vc_RoleName = 'Physician'
	BEGIN
		INSERT INTO #RolePatient
		SELECT DISTINCT PCP.PatientId
		FROM PatientPCP pcp WITH (NOLOCK)
		INNER JOIN #ProgPatient pp 
			ON pp.Patientid = pcp.PatientId
		WHERE pcp.ProviderID = @i_AppuserID
	END
	ELSE 
	IF @vc_RoleName IN ('Care Manager', 'Care Team Member')
	BEGIN
		INSERT INTO #RolePatient
		SELECT DISTINCT pp.PatientID
		FROM PatientProgram pp WITH (NOLOCK)
		INNER JOIN (SELECT P.ProgramId 
					FROM ProgramCareTeam pct WITH (NOLOCK) 
					INNER JOIN CareTeamMembers ctm WITH (NOLOCK) 
						ON ctm.CareTeamID = pct.CareTeamID
					INNER JOIN @Prg P 
						ON P.ProgramId = PCT.ProgramId
					WHERE CTM.ProviderID = @i_AppUserId
					AND CTM.StatusCode = 'A' )DT
		ON dt.ProgramID = pp.ProgramID
		WHERE PP.StatusCode = 'E'

	END
	ELSE 
	IF @vc_RoleName = 'Insurance Group Provider'
	BEGIN
		DECLARE @i_ProviderInsuranceGroupID INT

		SELECT @i_ProviderInsuranceGroupID = InsuranceGroupID
		FROM Provider WITH (NOLOCK)
		WHERE ProviderID = @i_AppuserID

		INSERT INTO #RolePatient
		SELECT DISTINCT ui.PatientID
		FROM PatientInsurance ui WITH (NOLOCK)
		INNER JOIN InsuranceGroupPlan igp WITH (NOLOCK) 
			ON igp.InsuranceGroupPlanID = ui.InsuranceGroupPlanID
		INNER JOIN #ProgPatient PP 
			ON UI.PatientID = PP.Patientid
		WHERE igp.InsuranceGroupId = @i_ProviderInsuranceGroupID
	END
	ELSE 
	IF @vc_RoleName = 'Administrator'
	BEGIN
		INSERT INTO #RolePatient
		SELECT pp.PatientID
		FROM #ProgPatient pp
	END

	SET @v_SQL  = 'INSERT INTO #tblPatients (UserId, PatientName, DateOfBirth, Gender, TotalCount)' + CHAR(13)+CHAR(10)
				+ 'SELECT Patient.PatientID' + CHAR(13)+CHAR(10)
				+ '	,COALESCE(ISNULL(Patient.LastName, '''') + '', '' + ISNULL(Patient.FirstName, '''') + ''.'' + ISNULL(Patient.MiddleName, '''') + '''' + ISNULL(Patient.NameSuffix, ''''), '''') AS Fullname' + CHAR(13)+CHAR(10)
				+ '	,DateOfBirth AS DateOfBirth' + CHAR(13)+CHAR(10)
				+ '	,Gender AS Gender' + CHAR(13)+CHAR(10)
				+ '	,COUNT(*) OVER () AS [Count]' + CHAR(13)+CHAR(10)
				+ 'FROM Patient WITH (NOLOCK)' + CHAR(13)+CHAR(10)
				+ 'INNER JOIN #RolePatient RP' + CHAR(13)+CHAR(10)
				+ '	ON RP.Patientid = patient.Patientid' + CHAR(13)+CHAR(10)
  
    IF @i_PrvCnt > 0
	BEGIN

	 INSERT INTO #Pat
		SELECT DISTINCT Patientid 
			FROM PatientProgram PP WITH(NOLOCK)
			INNER JOIN @Prg pr
				ON pr.ProgramId = pp.ProgramID
			INNER JOIN @tProvider TP
				ON TP.ProviderId = PP.Providerid
			WHERE PP.StatusCode = 'E'

	 SET @v_SQLJoins = COALESCE(@v_SQLJoins + CHAR(13)+CHAR(10), '')
				+ 'INNER JOIN #Pat ' + CHAR(13)+CHAR(10)
				+ '	ON #Pat.PatientID = RP.Patientid' + CHAR(13)+CHAR(10)

	END


	IF @i_StateID IS NOT NULL
	BEGIN
		SET @v_SQLJoins = COALESCE(@v_SQLJoins + CHAR(13)+CHAR(10), '')
				+ 'INNER JOIN CodeSetState CSS' + CHAR(13)+CHAR(10)
				+ '		 ON Patient.PrimaryAddressStateCodeID = css.StateID ' + CHAR(13)+CHAR(10)
				+ '		 AND css.stateid = @i_StateID' + CHAR(13)+CHAR(10)
	END

	
    
	IF @i_ConditionCnt > 0
	BEGIN
		INSERT INTO #Disease (Diseaseid)
		SELECT tkeyid
		FROM @t_tDiseaseID

		SET @v_SQLJoins = @v_SQLJoins + SPACE(1) 
						+ 'INNER JOIN (' + CHAR(13)+CHAR(10)
						+ '	SELECT DISTINCT CI.PatientID' + CHAR(13)+CHAR(10)
						+ '	FROM ClaimCodeGroup CCG WITH (NOLOCK)' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN ClaimInfo CI WITH (NOLOCK)' + CHAR(13)+CHAR(10)
						+ '		ON CCG.ClaimInfoId = CI.ClaimInfoId' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN #RolePatient pat' + CHAR(13)+CHAR(10)
						+ '		ON Pat.PatientID = ci.Patientid' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN #Disease c' + CHAR(13)+CHAR(10)
						+ '		ON CCG.CodeGroupingId = c.Diseaseid' + CHAR(13)+CHAR(10)
						+ '	) pd' + CHAR(13)+CHAR(10)
						+ '	ON pd.PatientID = rp.PatientID' + CHAR(13)+CHAR(10)
	END
	
	IF @i_InsuranceGroupId IS NOT NULL
		AND @c_ProductType IS NULL
		BEGIN
			INSERT INTO #InsuranceGroupPlan
			SELECT InsuranceGroupPlanId
			FROM InsuranceGroupPlan WITH(NOLOCK)  
			WHERE InsuranceGroupId = @i_InsuranceGroupId
			
			SET @v_SQLJoins = @v_SQLJoins + SPACE(1) 
						+ 'INNER JOIN (' + CHAR(13)+CHAR(10)
						+ '	SELECT DISTINCT PatientInsurance.PatientID' + CHAR(13)+CHAR(10)
						+ '	FROM PatientInsurance WITH (NOLOCK)' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN #InsuranceGroupPlan TIGP' + CHAR(13)+CHAR(10)
						+ '		ON TIGP.InsuranceGroupPlanId = PatientInsurance.InsuranceGroupPlanId' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN #RolePatient pat' + CHAR(13)+CHAR(10)
						+ '		ON Pat.PatientID = PatientInsurance.PatientID' + CHAR(13)+CHAR(10)
						+ '	WHERE PatientInsurance.StatusCode = ''' + 'A' + '''' + CHAR(13)+CHAR(10)
						+ '	) PIG' + CHAR(13)+CHAR(10)
						+ '	ON PIG.PatientId = RP.PatientID' + CHAR(13)+CHAR(10)
		END

	IF @c_ProductType IS NOT NULL
		AND @i_InsuranceGroupId IS NULL
		BEGIN
			INSERT INTO #InsuranceGroupPlan
			SELECT InsuranceGroupPlanId
			FROM InsuranceGroupPlan WITH(NOLOCK)  
			WHERE ProductType = @c_ProductType 

			SET @v_SQLJoins = @v_SQLJoins + SPACE(1) 
						+ 'INNER JOIN (' + CHAR(13)+CHAR(10)
						+ '	SELECT DISTINCT PatientInsurance.PatientID' + CHAR(13)+CHAR(10)
						+ '	FROM PatientInsurance WITH (NOLOCK)' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN #InsuranceGroupPlan TIGP' + CHAR(13)+CHAR(10)
						+ '		ON TIGP.InsuranceGroupPlanId = PatientInsurance.InsuranceGroupPlanId' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN #RolePatient pat' + CHAR(13)+CHAR(10)
						+ '		ON Pat.PatientID = PatientInsurance.PatientID' + CHAR(13)+CHAR(10)
						+ '	WHERE PatientInsurance.StatusCode = ''' + 'A' + '''' + CHAR(13)+CHAR(10)
						+ '	) PIP' + CHAR(13)+CHAR(10)
						+ '	ON PIP.PatientId = RP.PatientId' + CHAR(13)+CHAR(10)
		END

	IF @c_ProductType IS NOT NULL
		AND @i_InsuranceGroupId IS NOT NULL
		BEGIN 
			INSERT INTO #InsuranceGroupPlan
			SELECT InsuranceGroupPlanId
			FROM InsuranceGroupPlan WITH(NOLOCK)  
			WHERE InsuranceGroupId = @i_InsuranceGroupId
			AND ProductType = @c_ProductType 

			SET @v_SQLJoins = @v_SQLJoins + SPACE(1) 
						+ 'INNER JOIN (' + CHAR(13)+CHAR(10)
						+ '	SELECT DISTINCT PatientInsurance.PatientID' + CHAR(13)+CHAR(10)
						+ '	FROM PatientInsurance WITH (NOLOCK)' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN #InsuranceGroupPlan TIGP' + CHAR(13)+CHAR(10)
						+ '		ON TIGP.InsuranceGroupPlanID = PatientInsurance.InsuranceGroupPlanID' + CHAR(13)+CHAR(10)
						+ '	WHERE PatientInsurance.StatusCode = ''A''' + CHAR(13)+CHAR(10)
						+ '	) PIPI' + CHAR(13)+CHAR(10)
						+ '	ON PIPI.PatientId = RP.PatientId' + CHAR(13)+CHAR(10)
		END
	IF @i_PCPID IS NOT NULL AND @i_ClinicID IS NULL
	BEGIN
		SET @v_SQLJoins = @v_SQLJoins + SPACE(1) 
						+ 'INNER JOIN (' + CHAR(13)+CHAR(10)
						+ '	SELECT PCP.PatientId' + CHAR(13)+CHAR(10)
						+ '	FROM PatientPCP PCP WITH (NOLOCK)' + CHAR(13)+CHAR(10)
						+ '	WHERE PCP.Providerid = @i_PCPID' + CHAR(13)+CHAR(10)
						+ '	) DP' + CHAR(13)+CHAR(10)
						+ '	ON DP.PatientId = RP.PatientId' + CHAR(13)+CHAR(10)
	END

	IF @i_ClinicID IS NOT NULL
		AND @i_PCPID IS NULL
	BEGIN
		SET @v_SQLJoins = @v_SQLJoins + SPACE(1) 
						+ 'INNER JOIN (' + CHAR(13)+CHAR(10)
						+ '	SELECT PCP.PatientId' + CHAR(13)+CHAR(10)
						+ '	FROM PatientPCP PCP WITH (NOLOCK)' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN ProviderHierarchyDetail PD WITH (NOLOCK)' + CHAR(13)+CHAR(10)
						+ '		ON PCP.Providerid = PD.ChildProviderid' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN #RolePatient pat' + CHAR(13)+CHAR(10)
						+ '		ON Pat.PatientID = PCP.PatientID' + CHAR(13)+CHAR(10)
						+ '	WHERE PD.ParentProviderid = @i_ClinicID' + CHAR(13)+CHAR(10)
						+ '	) DTC' + CHAR(13)+CHAR(10)
						+ '	ON DTC.PatientId = RP.PatientId' + CHAR(13)+CHAR(10)
	END

	IF @i_PCPID IS NOT NULL
		AND @i_ClinicID IS NOT NULL
	BEGIN
		SET @v_SQLJoins = @v_SQLJoins + SPACE(1) 
						+ 'INNER JOIN (' + CHAR(13)+CHAR(10)
						+ '	SELECT PCP.PatientId' + CHAR(13)+CHAR(10)
						+ '	FROM PatientPCP PCP WITH (NOLOCK)' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN ProviderHierarchyDetail PD WITH (NOLOCK)' + CHAR(13)+CHAR(10)
						+ '		ON PCP.Providerid = PD.ChildProviderid' + CHAR(13)+CHAR(10)
						+ '	INNER JOIN #RolePatient pat' + CHAR(13)+CHAR(10)
						+ '		ON Pat.PatientID = PCP.PatientID' + CHAR(13)+CHAR(10)
						+ '	WHERE PD.ParentProviderid = @i_ClinicID' + CHAR(13)+CHAR(10)
						+ '		AND PD.childProviderid = @i_PCPID' + CHAR(13)+CHAR(10)
						+ '	) DT' + CHAR(13)+CHAR(10)
						+ '	ON DT.PatientId = RP.PatientId' + CHAR(13)+CHAR(10)
	END

	SET @v_SQLWhereClause = SPACE(1) + 'WHERE 1 = 1 ' + CHAR(13)+CHAR(10)

	IF @v_PatientLastName IS NOT NULL
		SET @v_SQLWhereClause = @v_SQLWhereClause + SPACE(1) 
						+ 'AND ( PATINDEX ('''' + @v_PatientLastName + ''%'', Patient.LastName)  >0 ) ' + CHAR(13)+CHAR(10)
    
	
	IF (
			@d_AgeFrom is not null
			OR @d_AgeTo is not null
			)
	BEGIN
		SET @v_SQLWhereClause = @v_SQLWhereClause + SPACE(1) 
						+ 'AND ( Patient.DateOfBirth BETWEEN ''' + CAST(@d_AgeFrom AS VARCHAR) + ''' AND ''' + CAST(@d_AgeTo AS VARCHAR) + ''' )' + CHAR(13)+CHAR(10)
	END
	

	IF (
			@v_dobValue1 IS NOT NULL
			OR @v_dobValue2 IS NOT NULL
			)
	BEGIN
		IF @v_dobValue1 IS NOT NULL
			AND @v_dobValue2 IS NOT NULL
			SET @v_SQLWhereClause = @v_SQLWhereClause + SPACE(1) 
						+ 'AND ( Patient.DateOfBirth BETWEEN ''' + CAST(@v_dobValue1 AS VARCHAR) + ''' AND ''' + CAST(@v_dobValue2 AS VARCHAR) + ''' )' + CHAR(13)+CHAR(10)
		ELSE IF @v_dobValue1 IS NOT NULL
			AND @v_dobValue2 IS NULL
			SET @v_SQLWhereClause = @v_SQLWhereClause + SPACE(1) 
						+ 'AND ( Patient.DateOfBirth  = ''' + CAST(@v_dobValue1 AS VARCHAR) + ''' ) ' + CHAR(13)+CHAR(10)
		ELSE
			SET @v_SQLWhereClause = @v_SQLWhereClause + SPACE(1) 
						+ 'AND ( Patient.DateOfBirth  = ''' + CAST(@v_dobValue2 AS VARCHAR) + ''' ) ' + CHAR(13)+CHAR(10)
	END

	DECLARE @v_OrderByClause NVARCHAR(4000)

	IF @v_SortBy IS NOT NULL
	BEGIN
		IF @v_SortBy = 'PatientID'
			SET @v_OrderByClause = ' ORDER BY Patient.PatientID ' + ISNULL(@v_SortType, '') + CHAR(13)+CHAR(10)

		IF @v_SortBy = 'MrnNumber'
			SET @v_OrderByClause = ' ORDER BY Patient.MedicalRecordNumber ' + ISNULL(@v_SortType, '') + CHAR(13)+CHAR(10)

		IF @v_SortBy = 'Name'
			SET @v_OrderByClause = ' ORDER BY Patient.LastName, Patient.FirstName, Patient.MiddleName, Patient.NameSuffix ' + ISNULL(@v_SortType, '') + CHAR(13)+CHAR(10)

		IF @v_SortBy = 'Age'
			SET @v_OrderByClause = ' ORDER BY Patient.DateOfBirth ' + ISNULL(@v_SortType, '') + CHAR(13)+CHAR(10)

		IF @v_SortBy = 'Gender'
			SET @v_OrderByClause = ' ORDER BY Patient.Gender' + ' ' + ISNULL(@v_SortType, '') + CHAR(13)+CHAR(10)
	END
	ELSE
	BEGIN
		SET @v_OrderByClause = 'ORDER BY Patient.LastName, Patient.FirstName, Patient.MiddleName, Patient.NameSuffix ASC' + CHAR(13)+CHAR(10)
	END

	SET @v_SQL = ISNULL(@v_SQL, '') + ISNULL(@v_SQLJoins, '') + ISNULL(@v_SQLWhereClause, '') + ISNULL(@v_OrderByClause, '') + '  OFFSET (@i_StartIndex - 1) * @i_EndIndex  ROWS  FETCH NEXT  @i_EndIndex ROWS ONLY '
	
	EXEC SP_EXECUTESQL @v_SQL
		,@v_paramdef
		,@i_AppUserId = @i_AppUserId
		,@i_StartIndex = @i_StartIndex
		,@i_EndIndex = @i_EndIndex
		,@i_CareTeamId = @i_CareTeamId
		,@i_StateID = @i_StateID
		,@v_PatientLastName = @v_PatientLastName
		,@d_AgeFrom = @d_AgeFrom 
		,@d_AgeTo = @d_AgeTo 
		,@v_dobValue1 = @v_dobValue1
		,@v_dobValue2 = @v_dobValue2
		,@i_InsuranceGroupId = @i_InsuranceGroupId
		,@c_ProductType = @c_ProductType
		,@i_PCPID = @i_PCPID
		,@i_ClinicID = @i_ClinicID
		,@v_State = @v_State
		,@v_SortBy = @v_SortBy
		,@v_SortType = @v_SortType

	SELECT PatientProgram.PatientID
		,Program.ProgramId
		,program.ProgramName
		,PatientProgram.EnrollmentStartDate
	INTO #ProgramName
	FROM Program WITH (NOLOCK)
	INNER JOIN PatientProgram WITH (NOLOCK) 
		ON PatientProgram.ProgramId = Program.ProgramId
	INNER JOIN #tblPatients p 
		ON p.UserID = PatientProgram.PatientID
	INNER JOIN @Prg pg 
		ON pg.ProgramID = Program.ProgramId
	WHERE PatientProgram.StatusCode = 'E'

	SELECT STUFF((
				SELECT '|' + ProgramName
				FROM #ProgramName p
				WHERE p.PatientID = tp.UserID
				ORDER BY EnrollmentStartDate DESC
				FOR XML PATH('')
				), 1, 1, '') MPList
		,UserID PatientID
	INTO #MPPatient
	FROM #tblPatients tp

	INSERT INTO #CodeGroup
	(
		CodeGroupingId,
		CodeGroupingName
	)
	SELECT CG.CodeGroupingID
		,CG.CodeGroupingName
	FROM CodeGrouping CG WITH (NOLOCK)
	INNER JOIN CodeTypeGroupers CTG WITH (NOLOCK)
		ON CG.CodeTypeGroupersID = CTG.CodeTypeGroupersID
	WHERE CTG.CodeTypeGroupersName IN ('AHRQ Procedure Groupers','AHRQ Diagnosis Groupers')
		AND CG.StatusCode = 'A'

	SELECT DISTINCT CG.CodeGroupingName AS Name ,
		CG.CodeGroupingId AS PopulationDefinitionID ,
		t.UserID AS PatientID 
	INTO #Condition
	FROM ClaimCodeGroup CCG WITH(NOLOCK)
	INNER JOIN #CodeGroup CG 
		ON CG.CodeGroupingId = CCG.CodeGroupingID
	INNER JOIN ClaimInfo CI WITH(NOLOCK)
		ON CCG.ClaimInfoID = ci.ClaimInfoId
	INNER JOIN #tblPatients t ON t.UserID = CI.PatientID

	SELECT STUFF((
				SELECT '|' + Name
				FROM  #Condition p
				WHERE p.PatientID = tp.UserID
				FOR XML PATH('')
				), 1, 1, '') ConditionList
		,UserID PatientID
	INTO #Conditionpat
	FROM #tblPatients tp

	IF @vc_RoleName IN (
			'Care Manager'
			,'Care Team Member'
			)
		INSERT INTO @tProgram
		SELECT DISTINCT p.ProgramID
		FROM ProgramCareTeam pct
		INNER JOIN CareTeamMembers ctm ON ctm.CareTeamId = pct.CareTeamId
		INNER JOIN Program p ON p.ProgramId = pct.ProgramId
		WHERE ctm.StatusCode = 'A'
			AND ctm.ProviderID = @i_AppUserId
			AND P.ProgramId != @i_ProgramID
	ELSE
		INSERT INTO @tProgram
		SELECT p.ProgramID
		FROM Program p
		WHERE P.ProgramId != @i_ProgramID
		
	;WITH CTE_ADT
	AS (
		SELECT pae.PatientId
			,MAX(VisitAdmitdate) AS DateOfService
		FROM PatientEvent pae WITH (NOLOCK)
		INNER JOIN PatientEventNotification nf WITH (NOLOCK)
			ON nf.PatientEventId = pae.PatientEventId
		INNER JOIN EventType et WITH (NOLOCK)
			ON et.EventTypeID = nf.EventTypeID
		INNER JOIN #tblPatients p
			ON p.UserID = pae.PatientID
		WHERE et.MessageType = 'ADT'
			AND pae.VisitAdmitdate > @LastYearDate
		GROUP BY pae.PatientId
		)
		,CTE_Claim
	AS (
		SELECT CI.PatientID
			,MAX(ci.DateOfAdmit) DateofService
		FROM ClaimInfo ci WITH (NOLOCK)
		INNER JOIN #tblPatients p
			ON p.UserID = ci.PatientID
		WHERE ci.DateOfAdmit > @LastYearDate
		GROUP BY ci.PatientID
		)
	SELECT dis.ID
		,p.PatientID Userid
		,P.MedicalRecordNumber AS MemberNum
		,dis.PatientName AS PatientName
		,dis.DateOfBirth AS DateOfBirth
		,dis.Gender AS Gender
		,ISNULL(CADT.DateOfService, CCL.DateofService) AS LastOfficeVisit
		,mp.MPList AS ProgramName
		,cp.ConditionList AS DiseaseName
		,(
			SELECT COUNT(1)
			FROM #ProgramName TPN
			WHERE TPN.PatientID = dis.Userid
			) AS ProgramCount
		,(
			SELECT COUNT(t.PopulationDefinitionId)
			FROM #Condition t
			WHERE t.PatientID = dis.Userid
				AND (
					EXISTS (
						SELECT 1
						FROM #Disease tblDes
						WHERE tblDes.Diseaseid = t.PopulationDefinitionID
						)
					OR @i_ConditionCnt = 0
					)
			) AS DiseaseCount
		,(
			SELECT SUM(CASE 
						WHEN t.PatientTaskId IS NULL
							THEN 0
						ELSE 1
						END)
			FROM PatientTask t WITH (NOLOCK)
			INNER JOIN TaskType ty WITH (NOLOCK)
				ON t.TaskTypeId = ty.TaskTypeId
			INNER JOIN @tProgram pt
				ON t.ManagedPopulationId = pt.ProgramID
			WHERE t.PatientID = dis.UserId
				AND (
					(
						t.TaskStatusId IN (
							@i_IncompleteTaskStatusID
							,@i_DisEnrollTaskStatusID
							)
						AND IsTask = 1
						)
					OR (
						t.TaskStatusId = @i_DisEnrollTaskStatusID
						AND IsTask = 0
						)
					)
			) CareGaps
	INTO #tmpPatientByData
	FROM #tblPatients dis
	INNER JOIN Patient p  WITH (NOLOCK)
		ON p.PatientID = dis.UserID
	LEFT JOIN #MPPatient mp
		ON mp.PatientID = dis.UserID
	LEFT JOIN #Conditionpat cp
		ON cp.PatientID = dis.UserID
	LEFT JOIN CTE_ADT CADT
		ON CADT.PatientId = dis.UserID
	LEFT JOIN CTE_Claim CCL
		ON CCL.PatientID = dis.UserID

	--CREATE NONCLUSTERED INDEX [IX_tbl_tmpPatientByDataSearch] ON #tmpPatientByData ([ID]);

	SELECT TMPP.ID
		,TMPP.Userid
		,MemberNum
		,PatientName
		,DateOfBirth
		,Gender
		,CONVERT(VARCHAR,LastOfficeVisit,101) AS LastOfficeVisit
		,ProgramName
		,ProgramCount
		,DiseaseName
		,DiseaseCount
		,CareGaps
		,'Admit' AS ADTStatus
	FROM #tmpPatientByData TMPP
	ORDER BY ID
	
	SELECT TOP 1 TotalCount AS PatientCount 
	FROM #tblPatients
		
END TRY

BEGIN CATCH
	----------------------------------------------------------------------------------------------------------     
	-- Handle exception      
	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorLine
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH