﻿
/*    
----------------------------------------------------------------------------------------------   
Procedure Name: [usp_Batch_TaskMissedOpportunity]
Description   : This Stored procedure to move the tasks to the missed opportunity if it is not 
				completed by Caremanager
Created By    : Rathnam   
Created Date  : 09-Mar-2016
----------------------------------------------------------------------------------------------
Log History   :     
DD-MM-YYYY  BY   DESCRIPTION 
24-Mar-2016 Nagababu Modified the logic as per NAVI-5547
-----------------------------------------------------------------------------------------------
*/
CREATE PROCEDURE [dbo].[usp_Batch_TaskMissedOpportunity] 
(@i_AppUserId KEYID)
AS
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @l_TranStarted BIT = 0

	IF (@@TRANCOUNT = 0)
	BEGIN
		BEGIN TRANSACTION

		SET @l_TranStarted = 1 -- Indicator for start of transactions
	END

	DECLARE @i_TaskStatusID INT
		,@d_UTCCurrentDate DATETIME = GETDATE()

	SELECT @i_TaskStatusID = TaskStatusId
	FROM TaskStatus
	WHERE TaskStatusText = 'Open'

	SELECT PatientTaskId
		,PatientId
		,PatientTaskTemplateScheduleId
		,NextContactDate
	INTO #missedopportunitytask
	FROM PatientTask WITH (NOLOCK)
	WHERE TaskStatusId = @i_TaskStatusID
		AND MissedOpportunityDate < = @d_UTCCurrentDate

	DECLARE @i_IncompleteStatusID INT

	SELECT @i_IncompleteStatusID = TaskStatusId
	FROM TaskStatus WITH (NOLOCK)
	WHERE TaskStatusText = 'Closed Incomplete'

	UPDATE PatientTask
	SET DateTaken = @d_UTCCurrentDate
		,Comments = ISNULL(Comments, '') + ' Incomplete'
		,TaskStatusId = @i_IncompleteStatusID
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @d_UTCCurrentDate
	FROM #missedopportunitytask t
	WHERE t.PatientTaskId = PatientTask.PatientTaskId
		AND PatientTask.TaskStatusId = @i_TaskStatusID


	SELECT DISTINCT m.PatientId, ppm.ProgramID ManagedPopulationID, ppm.ProviderID 
	INTO #patientprogram
	FROM #missedopportunitytask m
		INNER JOIN PatientProgram ppm WITH(NOLOCK)
		on m.PatientId = ppm.PatientID
		WHERE ppm.StatusCode = 'E'

	DECLARE @tblPatientTask PatientTask

	INSERT INTO @tblPatientTask
	SELECT DISTINCT pp.ProviderID
		,ptt.PatientTaskTemplateId
		,m.NextContactDate
	FROM #missedopportunitytask m
	INNER JOIN PatientTaskTemplateSchedule ptts WITH(NOLOCK) ON m.PatientTaskTemplateScheduleId = ptts.PatientTaskTemplateScheduleId
	INNER JOIN PatientTaskTemplate ptt WITH(NOLOCK) ON ptt.PatientTaskTemplateId = ptts.PatientTaskTemplateId
	LEFT JOIN #patientprogram pp ON pp.PatientId = m.PatientId
	and pp.ManagedPopulationID = ptts.ManagedPopulationId
	WHERE ptt.StatusCode = 'A'
		AND ptts.StatusCode = 'A'

	EXEC usp_Batch_TaskSchedule 
	     @i_AppUserId = @i_AppUserId
		,@t_PatientTask = @tblPatientTask

	IF (@l_TranStarted = 1) -- If transactions are there, then commit
	BEGIN
		SET @l_TranStarted = 0

		COMMIT TRANSACTION
	END
END TRY

--------------------------------------------------------     
BEGIN CATCH
	-- Handle exception  
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH