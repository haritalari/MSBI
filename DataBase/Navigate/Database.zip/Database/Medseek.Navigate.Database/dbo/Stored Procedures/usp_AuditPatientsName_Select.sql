﻿
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*    
------------------------------------------------------------------------------    
Procedure Name: [usp_AuditPatientsName_Select]  23,'sha'
Description   : This procedure is used Search Patientnames in  Records
Created By    : SANTHOSH for inline search in UserActivityLog report
Created Date  : 11-Dec-2013  
27-Oct-2016 Nagasiva modified the sp as per NAVI-6853
------------------------------------------------------------------------------    
*/
CREATE PROCEDURE [dbo].[usp_AuditPatientsName_Select]
(
@i_AppUserID INT,
@vc_PatientSearch varchar(50)
)
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON
		IF(@i_AppUserID IS NULL)OR (@i_AppUserID<=0)
			BEGIN
				RAISERROR ( N'Invalid Application User ID %d passed.' ,              
				17 ,              
				1 ,              
				@i_AppUserID) 
			END
		SELECT DISTINCT p.LastName+' , '+p.FirstName AS PatientName,p.PatientID as PatientID 
		FROM Patient p WITH(Nolock)
		WHERE ((p.FirstName LIKE @vc_PatientSearch+ '%') 
				OR (p.LastName LIKE @vc_PatientSearch +'%') 
				)			
	END TRY
	BEGIN CATCH
		DECLARE @i_ReturnedErrorID INT              
		EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId              
		RETURN @i_ReturnedErrorID  
	END CATCH 
END

