﻿
/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_ADT_ValidatePatientByGUID]  64,'DFF2C2D7-014F-42C8-AA68-F6678FB967BF'
Description   : This proc is used to validate the patient by unique identifier during HL7 data load
Created By    : Rathnam  
Created Date  : 13-Aug-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  

----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_ADT_ValidatePatientByGUID] (
	@vc_Mid NVARCHAR(MAX)
	,@b_IsValidPatientOUT BIT OUT
	)
AS
BEGIN TRY
	SET NOCOUNT ON
	SET @b_IsValidPatientOUT = 0

	IF dbo.[IsValidGuid](@vc_Mid) = 1
	BEGIN
		SELECT @b_IsValidPatientOUT = 1
		FROM Patient
		WHERE PatientPrimaryId = @vc_Mid

		SELECT @b_IsValidPatientOUT IsValidPatient
	END
	ELSE
	BEGIN
		SELECT @b_IsValidPatientOUT IsValidPatient
	END
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = 1
END CATCH