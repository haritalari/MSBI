﻿
/*            
--------------------------------------------------------------------------------------------------------------            
Procedure Name: [dbo].[usp_Batch_PatientMerge]
Description   : This procedure is to merge the tasks      
Created By    : Rathnam         
Created Date  : 05-June-2015
---------------------------------------------------------------------------------------------------------------            
Log History   :             
DD-Mon-YYYY  BY  DESCRIPTION 
29-Jun-2015 Nagababu Added some more columns from task into PatientMerge table in the formate of XML
01-Jul-2015 Chaitanya updating notification status as read while completing the merge for NAVI-3182
02-Jul-2015 Nagababu Updating IsFavourite as 0 for inactive patient in PatientDemographicHistory table
            and added some more columns in XML for Questionaire in PatientMerge table
20-Aug-2015 Santosh Modified the SP as per NAVI-3489
28-Aug-2015 NagaBabu Added two columns PatientEventId,PatientName Column to the PatientMerge table and added logic to populate these fileds as per NAVI-3647 
28-oct-2015 Santosh Modified the SP as per NAVI-4266
21-Dec-2015 NagaBabu Replaced PatientDemographicHistory Update statement by the delete statement where to delete Mergepatient demographic history details as discussed with Gouri
						and team in case of fixing the issue as a patient having multiple uniquidentifiers in PatientDemographicHistory table
06/01/2016 Nagababu Made changes as per NAVI-4907
25/01/2016 Rathnam Changed as per NAVI-5080
30-Mar-2016 Nagababu Modified the logic as per NAVI-5417
13-Apr-2016 Nagababu NAVI-5777 which impacts recurring tasks and has to be discussed
01-Jun-2016 Rathnam  Added functionality for Admin notifications as per NAVI- 5972
16-Jun-2016 Rathnam  Modified as per NAVI- 5790
15-Jul-2016 Nagababu Added a column InvalidatedReasonId into the set for the column Task as per NAVI-5414
18-July-2016 Rathnam added EventDescription = 'Merge Completed' as per 6463
28-July-2016 Rathnam modified as per NAVI-6540
----------------------------------------------------------------------------------------------------------------        
 */
CREATE PROCEDURE [dbo].[usp_Batch_PatientMerge] (
	@i_AppUserId INT
	,@i_PatientID INT
	,@tblTaskID ttypeKeyID READONLY
	,@tblPatientTaskTemplateScheduleID ttypeKeyID READONLY
	,@i_PatientEventNotificationId INT
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @l_TranStarted BIT = 0

	IF (@@TRANCOUNT = 0)
	BEGIN
		BEGIN TRANSACTION

		SET @l_TranStarted = 1 -- Indicator for start of transactions
	END

	DECLARE @i_PatientEventId INT
		,@i_ActivePatientId INT
		,@i_MergePatientId INT
		,@i_TaskTypeId INT
		,@i_AssessmentTaskTypeId INT

	SELECT @i_PatientEventId = PatientEventId
	FROM PatientEventNotification WITH (NOLOCK)
	WHERE PatientEventNotificationId = @i_PatientEventNotificationId

	SELECT @i_ActivePatientId = PatientId
		,@i_MergePatientId = MergePatientId
	FROM PatientEvent WITH (NOLOCK)
	WHERE PatientEventId = @i_PatientEventId

	SELECT @i_AssessmentTaskTypeId = TaskTypeId
	FROM TaskType
	WHERE TaskTypeName = 'Assessment'

	DECLARE @t_Patient ttypeKeyID

	INSERT INTO @t_Patient
	VALUES (@i_ActivePatientId)
		,(@i_MergePatientId)

	INSERT INTO PatientMerge (
		[PatientEventId]
		,[PatientID]
		,[PatientName]
		,[MergePatientID]
		,[MergePatientName]
		,[Identifier]
		,[MergeIdentifier]
		,[Mid]
		,[MergeMid]
		,[MergeDemographics]
		,[MergeDemographicsHistory]
		,[Event]
		,[Communication]
		,[TimeStamp]
		,[Notes]
		,[Document]
		,[Measure]
		,[VitalSignBloodPressure]
		,[VitalSignBMI]
		,[Messages]
		,[NRValue]
		,[MessageRecipients]
		,[ActivityLog]
		,[Insurance]
		,[PCP]
		,[RxClaim]
		,[Claim]
		,[Program]
		,[PopulationDefinition]
		,[NRCount]
		,[Questionaire]
		,[Task]
		,[CareCommunity]
		,[PatientCarePlan]
		,[CreatedByUserID]
		,[PatientTaskTemplate]
		)
	SELECT @i_PatientEventId
		,AP.PatientId
		,COALESCE(ISNULL(AP.LastName, '') + ', ' + ISNULL(AP.FirstName, '') + '. ' + ISNULL(AP.MiddleName, ''), '')
		,PP.PatientID
		,COALESCE(ISNULL(PP.LastName, '') + ', ' + ISNULL(pp.FirstName, '') + '. ' + ISNULL(pp.MiddleName, ''), '')
		,AP.MedicalRecordNumber
		,PP.MedicalRecordNumber
		,AP.PatientPrimaryId
		,PP.PatientPrimaryId
		,(
			SELECT FirstName AS 'FirstName'
				,MiddleName AS 'MiddleName'
				,LastName AS 'LastName'
				,SSN AS 'SSN'
				,CAST(DateOfBirth AS DATE) AS 'DateOfBirth'
				,ISNULL(IsDeceased, 0) AS 'IsDeceased'
				,DateDeceased AS 'DateDeceased'
				,Gender AS 'Gender'
				,EmploymentStatus AS 'EmploymentStatus'
				,MedicalRecordNumber AS 'MedicalRecordNumber'
				,PrimaryAddressLine1 AS 'PrimaryAddressLine1'
				,PrimaryAddressLine2 AS 'PrimaryAddressLine2'
				,PrimaryAddressLine3 AS 'PrimaryAddressLine3'
				,PrimaryAddressCity AS 'PrimaryAddressCity'
				,PrimaryAddressStateCodeID AS 'PrimaryAddressStateCodeID'
				,PrimaryAddressCountyID AS 'PrimaryAddressCountyID'
				,PrimaryAddressPostalCode AS 'PrimaryAddressPostalCode'
				,PrimaryAddressCountryCodeID AS 'PrimaryAddressCountryCodeID'
			FROM Patient WITH (NOLOCK)
			WHERE PatientID = PP.PatientID
			FOR XML PATH('Patient')
			) AS [MergeDemographics]
		,(
			SELECT HistoryId AS 'HistoryId'
				,PatientID AS 'PatientID'
				,FirstName AS 'FirstName'
				,MiddleName AS 'MiddleName'
				,LastName AS 'LastName'
				,MedicalRecordNumber AS 'MedicalRecordNumber'
				,SSN AS 'SSN'
				,DateOfBirth AS 'DateOfBirth'
				,Gender AS 'Gender'
				,PrimaryPhoneNumber AS 'PrimaryPhoneNumber'
				,SecondaryPhoneNumber AS 'SecondaryPhoneNumber'
				,PrimaryEmailAddress AS 'PrimaryEmailAddress'
				,SecondaryEmailAddress AS 'SecondaryEmailAddress'
				,PatientAddress AS 'PatientAddress'
				,CreatedByUserID AS 'CreatedByUserID'
				,CreatedDate AS 'CreatedDate'
				,SourceTypeId AS 'SourceTypeId'
				,IsFavourite AS 'IsFavourite'
				,SecondaryIdentifier AS 'SecondaryIdentifier'
				,MobileNumber AS 'MobileNumber'
				,PreferredName AS 'PreferredName'
			FROM PatientDemographicHistory WITH (NOLOCK)
			WHERE PatientDemographicHistory.PatientID = PP.PatientID
			FOR XML PATH('Patient')
			) AS [MergeDemographicsHistory]
		,(
			SELECT PE.PatientEventId AS 'PatientEventId'
			FROM PatientEvent PE WITH (NOLOCK)
			WHERE PE.PatientId = PP.PatientID
			FOR XML PATH('Event')
			) AS [Event]
		,(
			SELECT PC.PatientCommunicationId AS 'PatientCommunicationId'
			FROM PatientCommunication PC WITH (NOLOCK)
			WHERE PC.PatientId = PP.PatientID
			FOR XML PATH('Communication')
			) AS [Communication]
		,(
			SELECT PT.DashboardTimestampId AS 'DashboardTimestampId'
			FROM PatientTimeStamp PT WITH (NOLOCK)
			WHERE PT.PatientUserID = PP.PatientID
			FOR XML PATH('TimeStamp')
			) AS [TimeStamp]
		,(
			SELECT PN.PatientNotesId AS 'PatientNotesId'
			FROM PatientNotes PN WITH (NOLOCK)
			WHERE PN.PatientId = PP.PatientID
			FOR XML PATH('Notes')
			) AS [Notes]
		,(
			SELECT PD.PatientDocumentId AS 'PatientDocumentId'
			FROM PatientDocument PD WITH (NOLOCK)
			WHERE PD.PatientId = PP.PatientID
			FOR XML PATH('Document')
			) AS [Document]
		,(
			SELECT PM.PatientMeasureID AS 'PatientMeasureID'
			FROM PatientMeasure PM WITH (NOLOCK)
			WHERE PM.PatientId = PP.PatientID
			FOR XML PATH('Measure')
			) AS [Measure]
		,(
			SELECT PVBP.PatientVitalSignBPID AS 'PatientVitalSignBPID'
			FROM PatientVitalSignBloodPressure PVBP WITH (NOLOCK)
			WHERE PVBP.PatientId = PP.PatientID
			FOR XML PATH('VitalSignBloodPressure')
			) AS [VitalSignBloodPressure]
		,(
			SELECT PBMI.PatientVitalSignBMIID AS 'PatientVitalSignBMIID'
			FROM PatientVitalSignBMI PBMI WITH (NOLOCK)
			WHERE PBMI.PatientId = PP.PatientID
			FOR XML PATH('VitalSignBMI')
			) AS [VitalSignBMI]
		,(
			SELECT UM.UserMessageId AS 'UserMessageId'
			FROM UserMessages UM WITH (NOLOCK)
			WHERE UM.PatientId = PP.PatientID
			FOR XML PATH('Messages')
			) AS [Messages]
		,(
			SELECT NrPV.NRPatientValueID AS 'NRPatientValueID'
				,NrPV.NRDefID AS 'NRDefID'
				,NrPV.PatientID AS 'PatientID'
				,NrPV.MetricID AS 'MetricID'
				,NrPV.Value AS 'Value'
				,NrPV.ValueDate AS 'ValueDate'
				,NrPV.IsIndicator AS 'IsIndicator'
				,NrPV.CreatedByUserId AS 'CreatedByUserId'
				,NrPV.CreatedDate AS 'CreatedDate'
				,NrPV.LastModifiedByUserId AS 'LastModifiedByUserId'
				,NrPV.LastModifiedDate AS 'LastModifiedDate'
				,NrPV.DateKey AS 'DateKey'
				,NrPV.FrequencyID AS 'FrequencyID'
			FROM NRPatientValue NrPV WITH (NOLOCK)
			WHERE NrPV.PatientId = PP.PatientID
			FOR XML PATH('NRValue')
			) AS [NRValue]
		,(
			SELECT UMR.UserMessageRecipientID AS 'UserMessageRecipientID'
			FROM UserMessageRecipients UMR WITH (NOLOCK)
			WHERE UMR.PatientId = PP.PatientID
			FOR XML PATH('MessageRecipients')
			) AS [MessageRecipients]
		,(
			SELECT UAL.ActivityID AS 'ActivityID'
			FROM UserActivityLog UAL WITH (NOLOCK)
			WHERE UAL.PatientId = PP.PatientID
			FOR XML PATH('ActivityLog')
			) AS [ActivityLog]
		,(
			SELECT PIN.PatientInsuranceID AS 'PatientInsuranceID'
			FROM PatientInsurance PIN WITH (NOLOCK)
			WHERE PIN.PatientId = PP.PatientID
			FOR XML PATH('Insurance')
			) AS [Insurance]
		,(
			SELECT PCP.PCPHistoryID AS 'PCPHistoryID'
				,PCP.PatientId AS 'PatientId'
				,PCP.ProviderID AS 'ProviderID'
				,PCP.PCPSystem AS 'PCPSystem'
				,PCP.CareBeginDate AS 'CareBeginDate'
				,PCP.CareEndDate AS 'CareEndDate'
				,PCP.DataSourceID AS 'DataSourceID'
				,PCP.DataSourceFileID AS 'DataSourceFileID'
				,PCP.CreatedByUserId AS 'CreatedByUserId'
				,PCP.CreatedDate AS 'CreatedDate'
				,PCP.LastModifiedByUserId AS 'LastModifiedByUserId'
				,PCP.LastModifiedDate AS 'LastModifiedDate'
				,PCP.IslatestPCP AS 'IslatestPCP'
			FROM PatientPCP PCP WITH (NOLOCK)
			WHERE PCP.PatientId = PP.PatientID
			FOR XML PATH('PCP')
			) AS [PCP]
		,(
			SELECT RxC.RxClaimId AS 'RxClaimId'
			FROM RxClaim RxC WITH (NOLOCK)
			WHERE RxC.PatientId = PP.PatientID
			FOR XML PATH('RxClaim')
			) AS [RxClaim]
		,(
			SELECT CI.ClaimInfoId AS 'ClaimInfoId'
			FROM ClaimInfo CI WITH (NOLOCK)
			WHERE CI.PatientId = PP.PatientID
			FOR XML PATH('Claim')
			) AS [Claim]
		,(
			SELECT PPR.PatientProgramID AS 'PatientProgramID'
			FROM PatientProgram PPR WITH (NOLOCK)
			WHERE PPR.PatientId = PP.PatientID
			FOR XML PATH('Program')
			) AS [Program]
		,(
			SELECT PDP.PopulationDefinitionPatientID AS 'PopulationDefinitionPatientID'
				,PDP.PopulationDefinitionID AS 'PopulationDefinitionID'
				,PDP.PatientID AS 'PatientID'
				,PDP.StatusCode AS 'StatusCode'
				,PDP.LeaveInList AS 'LeaveInList'
				,PDP.CreatedByUserId AS 'CreatedByUserId'
				,PDP.CreatedDate AS 'CreatedDate'
			FROM PopulationDefinitionPatients PDP WITH (NOLOCK)
			WHERE PDP.PatientId = PP.PatientID
			FOR XML PATH('PopulationDefinition')
			) AS [PopulationDefinition]
		,(
			SELECT NRPC.NRPatientCountID AS 'NRPatientCountID'
				,NRPC.NRDefID AS 'NRDefID'
				,NRPC.PatientID AS 'PatientID'
				,NRPC.MetricID AS 'MetricID'
				,NRPC.[Count] AS 'Count'
				,NRPC.IsIndicator AS 'IsIndicator'
				,NRPC.CreatedByUserId AS 'CreatedByUserId'
				,NRPC.CreatedDate AS 'CreatedDate'
				,NRPC.DateKey AS 'DateKey'
				,NRPC.FrequencyID AS 'FrequencyID'
			FROM NRPatientCount NRPC WITH (NOLOCK)
			WHERE NRPC.PatientId = PP.PatientID
			FOR XML PATH('NRCount')
			) AS [NRCount]
		,(
			SELECT PT.PatientTaskId AS 'PatientQuestionaireId'
				,PT.PatientProgramId AS 'PatientProgramID'
				,PT.TypeId AS 'QuestionaireId'
				,PT.DateTaken AS 'DateTaken'
				,PT.DueDate AS 'DateDue'
				,PT.AssessmentScore AS 'TotalScore'
				,1 AS 'IsProgramTask'
				,UQA.PatientAssessmentAnswerId AS 'UserQuestionaireAnswersID'
				,UQA.AnswerID AS 'AnswerID'
				,UQA.QuestionSetQuestionId AS 'QuestionSetQuestionId'
				,UQA.AnswerComments AS 'AnswerComments'
				,UQA.AnswerString AS 'AnswerString'
			FROM PatientAssessmentAnswer UQA WITH (NOLOCK)
			INNER JOIN PatientTask PT WITH (NOLOCK) ON UQA.PatientTaskId = PT.PatientTaskId
			WHERE PT.TaskTypeId = @i_AssessmentTaskTypeId
				AND PT.PatientId = PP.PatientID
			FOR XML PATH('Questionaire')
			) AS [Questionaire]
		,(
			SELECT T.PatientTaskId AS 'TaskId'
				,T.TaskTypeId AS 'TaskTypeId'
				,T.DueDate AS 'TaskDueDate'
				,T.DateTaken AS 'TaskCompletedDate'
				,T.TaskStatusId AS 'TaskStatusId'
				,NULL AS 'PatientTaskID'
				,T.ManagedPopulationId AS 'ProgramID'
				,T.PatientProgramId AS 'PatientProgramID'
				,NULL AS 'Isadhoc'
				,1 AS 'IsProgramTask'
				,T.PatientTaskTemplateScheduleId AS 'PatientTaskTemplateScheduleId'
				,T.PatientId AS 'PatientId'
				,T.TypeId AS 'TypeId'
				,T.MissedOpportunityDate AS 'MissedOpportunityDate'
				,T.NextContactDate AS 'NextContactDate'
				,T.NextOccurence AS 'NextOccurence'
				,T.ProviderId AS 'ProviderId'
				,T.Comments AS 'Comments'
				,T.CreatedByUserId AS 'CreatedByUserId'
				,T.CreatedDate AS 'CreatedDate'
				,T.LastModifiedByUserId AS 'LastModifiedByUserId'
				,T.LastModifiedDate AS 'LastModifiedDate'
				,T.AssessmentScore AS 'AssessmentScore'
				,T.ActivityPercentage AS 'ActivityPercentage'
				,T.PatientGoalId AS 'PatientGoalId'
				,T.IsBatchProcess AS 'IsBatchProcess'
				,T.InvalidatedReasonId AS 'InvalidatedReasonId'
				,PEMD.PatientTaskTemplateDocumentId AS 'PatientTaskTemplateDocumentId'
				,PEMD.CreatedByUserId AS 'TaskDocumentCreatedByUserId'
				,PEMD.CreatedDate AS 'TaskDocumentCreatedDate'
			FROM PatientTask T WITH (NOLOCK)
			LEFT JOIN PatientEducationMaterialDocument PEMD WITH (NOLOCK) ON T.PatientTaskId = PEMD.PatientTaskId
			WHERE T.PatientID = PP.PatientID
			FOR XML PATH('Task')
			) AS [Task]
		,(
			SELECT PCC.CarecommunityID AS 'patientcarecommunity'
			FROM patientcarecommunity PCC WITH (NOLOCK)
			WHERE PCC.PatientId = PP.PatientID
			FOR XML PATH('patientcarecommunity')
			) AS [patientcarecommunity]
		,(
			SELECT PCP.careplanID AS 'patientcareplan'
				,PCP.PdfContent AS 'PdfContent'
			FROM patientcareplan PCP WITH (NOLOCK)
			WHERE PCP.PatientId = PP.PatientID
			FOR XML PATH('patientcareplan')
			) AS [patientcareplan]
		,1 AS CreatedByUserId
		,(
			SELECT PTT.PatientTaskTemplateId AS 'PatientTaskTemplateId'
				,PTT.PatientId AS 'PatientId'
				,PTT.TaskTypeId AS 'TaskTypeId'
				,PTT.AssessmentId AS 'AssessmentId'
				,PTT.ProcedureId AS 'ProcedureId'
				,PTT.EducationMaterialId AS 'EducationMaterialId'
				,PTT.OtherTaskId AS 'OtherTaskId'
				,PTT.StatusCode AS 'StatusCode'
				,PTT.CreatedByUserId AS 'CreatedByUserId'
				,PTT.CreatedDate AS 'CreatedDate'
				,PTT.LastModifiedByUserId AS 'LastModifiedByUserId'
				,PTT.LastModifiedDate AS 'LastModifiedDate'
				,PTS.PatientTaskTemplateScheduleId AS 'PatientTaskTemplateScheduleId'
				,PTS.ManagedPopulationId AS 'ManagedPopulationId'
				,PTS.Recurrence AS 'Recurrence'
				,PTS.StartDate AS 'StartDate'
				,PTS.EndDate AS 'EndDate'
				,PTS.DueDate AS 'DueDate'
				,PTS.OccurrenceType AS 'OccurrenceType'
				,PTS.Occurrence AS 'Occurrence'
				,PTS.StartScheduleType AS 'StartScheduleType'
				,PTS.StartScheduleOccurrence AS 'StartScheduleOccurrence'
				,PTS.EndScheduleType AS 'EndScheduleType'
				,PTS.EndScheduleOccurrence AS 'EndScheduleOccurrence'
				,PTS.MissedopportunityType AS 'MissedopportunityType'
				,PTS.StatusCode AS 'ScheduleStatusCode'
				,PTS.LastModifiedByUserId AS 'ScheduleLastModifiedByUserId'
				,PTS.LastModifiedDate AS 'ScheduleLastModifiedDate'
				,PTI.PatientTaskTemplateIntervalId AS 'PatientTaskTemplateIntervalId'
				,PTI.Interval AS 'Interval'
				,PTI.DayOfTheMonth AS 'DayOfTheMonth'
				,PTI.StatusCode AS 'IntervalStatusCode'
				,PTI.LastModifiedByUserId AS 'IntervalLastModifiedByUserId'
				,PTI.LastModifiedDate AS 'IntervalLastModifiedDate'
				,PTTD.PatientTaskTemplateDocumentId AS 'PatientTaskTemplateDocumentId'
				,PTTD.DocumentName AS 'DocumentName'
				,PTTD.eDocument AS 'eDocument'
				,PTTD.MimeType AS 'MimeType'
				,PTTD.CreatedByUserId AS 'DocumentCreatedByUserId'
				,PTTD.CreatedDate AS 'DocumentCreatedDate'
			FROM PatientTaskTemplate PTT WITH (NOLOCK)
			INNER JOIN PatientTaskTemplateSchedule PTS WITH (NOLOCK) ON PTT.PatientTaskTemplateId = PTS.PatientTaskTemplateId
			LEFT JOIN PatientTaskTemplateInterval PTI WITH (NOLOCK) ON PTS.PatientTaskTemplateScheduleId = PTI.PatientTaskTemplateScheduleId
			LEFT JOIN PatientTaskTemplateDocument PTTD WITH (NOLOCK) ON PTTD.PatientTaskTemplateScheduleId = PTS.PatientTaskTemplateScheduleId
			WHERE PTT.PatientId = PP.PatientID
			FOR XML PATH('PatientTaskTemplate')
			)
	FROM PatientEvent EM WITH (NOLOCK)
	INNER JOIN Patient AP WITH (NOLOCK) ON EM.PatientId = AP.PatientID
	INNER JOIN Patient PP WITH (NOLOCK) ON EM.MergePatientId = PP.PatientID
	WHERE EM.PatientEventId = @i_PatientEventId

	-----------------------------------------------------------------------------------
	DECLARE @dt_CurrentDate DATETIME

	SELECT @dt_CurrentDate = GETDATE()

	UPDATE PatientBarrier
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE PatientCarePlan
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE PatientCareCommunity
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE PatientCommunication
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE PatientTimeStamp
	SET PatientUserId = @i_ActivePatientId
	WHERE PatientUserId = @i_MergePatientId

	UPDATE PatientNotes
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE PatientDocument
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE PatientMeasure
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE PatientVitalSignBloodPressure
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE PatientVitalSignBMI
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE UserMessages
	SET PatientId = @i_ActivePatientId
	WHERE PatientId = @i_MergePatientId
		----------------------------------------------------------------
		;

	WITH CTE_NRPatientValue
	AS (
		SELECT ISNULL(NULLIF(PatientID, @i_ActivePatientId), @i_MergePatientId) AS PatientId
			,MetricID
			,Value
			,ValueDate
			,DateKey
		FROM NRPatientValue NRPC WITH (NOLOCK)
		INNER JOIN @t_Patient TP ON NRPC.PatientID = TP.tKeyId
		GROUP BY ISNULL(NULLIF(PatientID, @i_ActivePatientId), @i_MergePatientId)
			,MetricID
			,Value
			,ValueDate
			,DateKey
		HAVING COUNT(*) > 1
		)
	DELETE
	FROM NRPatientValue
	WHERE EXISTS (
			SELECT 1
			FROM CTE_NRPatientValue CNRV
			WHERE CNRV.PatientId = NRPatientValue.PatientID
				AND CNRV.MetricID = NRPatientValue.MetricID
				AND ISNULL(CNRV.Value, 0) = ISNULL(NRPatientValue.Value, 0)
				AND CNRV.ValueDate = NRPatientValue.ValueDate
				AND CNRV.DateKey = NRPatientValue.DateKey
			)

	UPDATE NRPatientValue
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	---------------------------------------------------------------------
	UPDATE UserMessageRecipients
	SET PatientId = @i_ActivePatientId
	WHERE PatientId = @i_MergePatientId

	UPDATE UserActivityLog
	SET PatientId = @i_ActivePatientId
	WHERE PatientId = @i_MergePatientId

	UPDATE Audit_UserActivity
	SET PatientId = @i_ActivePatientId
	WHERE PatientId = @i_MergePatientId

	UPDATE PatientInsurance
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId
		-------------------------------------------------------------------
		;

	WITH CTE_PCP
	AS (
		SELECT ISNULL(NULLIF(PatientID, @i_ActivePatientId), @i_MergePatientId) AS PatientId
			,ProviderID
			,CareBeginDate
			,CareEndDate
		FROM PatientPCP PCP WITH (NOLOCK)
		INNER JOIN @t_Patient TP ON PCP.PatientID = TP.tKeyId
		GROUP BY ISNULL(NULLIF(PatientID, @i_ActivePatientId), @i_MergePatientId)
			,ProviderID
			,CareBeginDate
			,CareEndDate
		HAVING COUNT(*) > 1
		)
	DELETE
	FROM PatientPCP
	WHERE EXISTS (
			SELECT 1
			FROM CTE_PCP PCP
			WHERE PCP.PatientId = PatientPCP.PatientID
				AND PCP.ProviderID = PatientPCP.ProviderID
				AND PCP.CareBeginDate = PatientPCP.CareBeginDate
				AND PCP.CareEndDate = PatientPCP.CareEndDate
			)

	UPDATE PatientPCP
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	DELETE
	FROM PatientPCP
	WHERE PatientId = @i_ActivePatientId
		AND EXISTS (
			SELECT 1
			FROM PatientPCP PCP
			WHERE PCP.PatientId = PatientPCP.PatientId
			GROUP BY PCP.PatientId
			HAVING COUNT(*) > 1
			)
		AND ProviderID = (
			SELECT ProviderId
			FROM Provider
			WHERE FirstName = 'No PCP Assigned'
			)

	-------------------------------------------------------------------
	UPDATE RxClaim
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE ClaimInfo
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	--------------------------------------------------------------------------
	UPDATE PatientProgram
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId;

	SELECT PatientProgramID
		,PatientID
		,ProgramID
		,DENSE_RANK() OVER (
			PARTITION BY PatientId
			,ProgramID ORDER BY StatusCode 
				,PatientProgramID
			) AS RNO
	INTO #CTE_PatientProgram
	FROM PatientProgram
	WHERE PatientID = @i_ActivePatientId
		AND EnrollmentEndDate IS NULL

	UPDATE PatientTask
	SET PatientProgramId = (
			SELECT PatientProgramId
			FROM #CTE_PatientProgram t
			WHERE t.Rno = 1
				AND t.ProgramID = c.ProgramID
				AND t.PatientID = c.PatientID
			)
	FROM #CTE_PatientProgram c
	WHERE c.PatientProgramID = PatientTask.PatientProgramId
		AND c.Rno > 1

	DELETE
	FROM PatientProgram
	WHERE EXISTS (
			SELECT 1
			FROM #CTE_PatientProgram c
			WHERE c.PatientProgramID = PatientProgram.PatientProgramId
				AND c.Rno > 1
			)

	--------------------------------------------------------------------------
	SELECT PDP.PopulationDefinitionPatientID
	INTO #PopulationDefPatient
	FROM PopulationDefinitionPatients PDP
	INNER JOIN (
		SELECT ISNULL(NULLIF(PatientId, @i_ActivePatientId), @i_MergePatientId) AS PatientId
			,PopulationDefinitionID
		FROM PopulationDefinitionPatients PDP WITH (NOLOCK)
		INNER JOIN @t_Patient TP ON PDP.PatientID = TP.tKeyId
		GROUP BY ISNULL(NULLIF(PatientId, @i_ActivePatientId), @i_MergePatientId)
			,PopulationDefinitionID
		HAVING COUNT(*) > 1
		) DT ON PDP.PopulationDefinitionID = DT.PopulationDefinitionID
		AND PDP.PatientID = DT.PatientId

	DELETE
	FROM PopulationDefinitionPatientAnchorDate
	WHERE EXISTS (
			SELECT 1
			FROM #PopulationDefPatient TPDP
			WHERE TPDP.PopulationDefinitionPatientID = PopulationDefinitionPatientAnchorDate.PopulationDefinitionPatientID
			)

	DELETE
	FROM PopulationDefinitionPatients
	WHERE EXISTS (
			SELECT 1
			FROM #PopulationDefPatient TPDP
			WHERE TPDP.PopulationDefinitionPatientID = PopulationDefinitionPatients.PopulationDefinitionPatientID
			)

	UPDATE PopulationDefinitionPatients
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId
		--------------------------------------------------------------------------
		;

	WITH CTE_NRPatientCount
	AS (
		SELECT ISNULL(NULLIF(PatientID, @i_ActivePatientId), @i_MergePatientId) AS PatientId
			,MetricID
			,DateKey
		FROM NRPatientCount NRPC WITH (NOLOCK)
		INNER JOIN @t_Patient TP ON NRPC.PatientID = TP.tKeyId
		GROUP BY ISNULL(NULLIF(PatientID, @i_ActivePatientId), @i_MergePatientId)
			,MetricID
			,DateKey
		HAVING COUNT(*) > 1
		)
	DELETE
	FROM NRPatientCount
	WHERE EXISTS (
			SELECT 1
			FROM CTE_NRPatientCount CNRC
			WHERE CNRC.PatientId = NRPatientCount.PatientID
				AND CNRC.MetricID = NRPatientCount.MetricID
				AND CNRC.DateKey = NRPatientCount.DateKey
			)

	UPDATE NRPatientCount
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId
		------------------------------------------------------------
		;

	WITH CTE_PCT
	AS (
		SELECT ISNULL(NULLIF(PatientID, @i_ActivePatientId), @i_MergePatientId) AS PatientId
			,CareTeamID
			,ProgramID
		FROM PatientCareTeam PCT WITH (NOLOCK)
		INNER JOIN @t_Patient TP ON PCT.PatientID = TP.tKeyId
		GROUP BY ISNULL(NULLIF(PatientID, @i_ActivePatientId), @i_MergePatientId)
			,CareTeamID
			,ProgramID
		HAVING COUNT(*) > 1
		)
	DELETE
	FROM PatientCareTeam
	WHERE EXISTS (
			SELECT 1
			FROM CTE_PCT CPCT
			WHERE CPCT.PatientId = PatientCareTeam.PatientID
				AND CPCT.CareTeamID = PatientCareTeam.CareTeamID
				AND CPCT.ProgramID = PatientCareTeam.ProgramID
			)

	UPDATE PatientCareTeam
	SET PatientId = @i_ActivePatientId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE PatientEvent
	SET PatientId = @i_ActivePatientId
		,LastModifiedUserId = @i_AppUserId
		,LastModifiedDate = @dt_CurrentDate
	WHERE PatientId = @i_MergePatientId

	UPDATE PatientTaskTemplateSchedule
	SET Recurrence = 0
		,StatusCode = 'I'
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = GETDATE()
	FROM @tblPatientTaskTemplateScheduleID t
	WHERE t.tKeyId = PatientTaskTemplateSchedule.PatientTaskTemplateScheduleId

	SELECT PatientTaskTemplateId
		,PatientId
		,TaskTypeId
		,COALESCE(t.AssessmentId, t.ProcedureID, t.EducationMaterialID, t.OtherTaskId) TaskID
		,DENSE_RANK() OVER (
			PARTITION BY t.TaskTypeId
			,COALESCE(t.AssessmentId, t.ProcedureID, t.EducationMaterialID, t.OtherTaskId) ORDER BY CASE 
					WHEN PatientId = @i_ActivePatientId
						THEN 0
					ELSE 1
					END
			) AS RNO
	INTO #X
	FROM PatientTaskTemplate t
	WHERE PATIENTID IN (
			@i_ActivePatientId
			,@i_MergePatientId
			)

	UPDATE PatientTaskTemplateSchedule
	SET PatientTaskTemplateId = (
			SELECT a.PatientTaskTemplateId
			FROM #x a
			WHERE a.TaskTypeId = x.TaskTypeId
				AND a.TaskID = x.TaskID
				AND a.PatientId = @i_ActivePatientId
			)
	FROM #X x
	WHERE x.PatientTaskTemplateId = PatientTaskTemplateSchedule.PatientTaskTemplateId
		AND x.PatientId = @i_MergePatientId
		AND x.RNO > 1

	UPDATE PatientTaskTemplate
	SET PatientId = @i_ActivePatientId
	FROM #X a
	WHERE a.PatientTaskTemplateId = PatientTaskTemplate.PatientTaskTemplateId
		AND a.PatientId = @i_MergePatientId

	DELETE
	FROM PatientTaskTemplate
	WHERE EXISTS (
			SELECT 1
			FROM #x x
			WHERE rno > 1
				AND PatientTaskTemplate.PatientTaskTemplateId = x.PatientTaskTemplateId
			)

	UPDATE PatientTask
	SET PatientId = @i_ActivePatientId
		,Comments = ISNULL(Comments, '') + ' MERGED FROM-' + CONVERT(VARCHAR(50), @i_MergePatientId) + '-' + CONVERT(VARCHAR(50), getdate())
	WHERE PatientId = @i_MergePatientId

	DELETE
	FROM PatientEducationMaterialDocument
	WHERE EXISTS (
			SELECT 1
			FROM @tblTaskID t
			WHERE t.tKeyId = PatientEducationMaterialDocument.PatientTaskId
			)

	DELETE
	FROM PatientTask
	WHERE EXISTS (
			SELECT 1
			FROM @tblTaskID t
			WHERE t.tKeyId = PatientTask.PatientGoalId
			)

	DELETE
	FROM PatientTask
	WHERE EXISTS (
			SELECT 1
			FROM @tblTaskID t
			WHERE t.tKeyId = PatientTask.PatientTaskId
			)

	-------------------------------------------------------------------------
	DELETE
	FROM PatientDemographicHistory
	WHERE PatientId = @i_MergePatientId

	DELETE
	FROM Patient
	WHERE PatientID = @i_MergePatientId

	UPDATE PatientEventNotification
	SET IsMerged = 0
	WHERE PatientEventNotificationId = @i_PatientEventNotificationId

	UPDATE ProviderEventNotification
	SET IsRead = 1
	WHERE PatientEventNotificationId = @i_PatientEventNotificationId

	DECLARE @i_EventTypeId INT

	SELECT @i_EventTypeId = EventTypeId
	FROM EventType
	WHERE EventDescription = 'Merge Completed'

	INSERT INTO PatientEventNotification (
		PatientEventId
		,EventTypeId
		,EventDate
		,CreatedByUserId
		,VisitType
		,SourceId
		,IsMerged
		)
	SELECT PatientEventId
		,@i_EventTypeId
		,@dt_CurrentDate
		,@i_AppUserId
		,VisitType
		,NULL
		,1
	FROM PatientEventNotification
	WHERE PatientEventNotificationId = @i_PatientEventNotificationId

	DECLARE @i_CompleteEventNotificationId INT = SCOPE_IDENTITY()
	DECLARE @i_ProgramID INT

	SELECT @i_ProgramID = ProgramId
	FROM Program
	WHERE ProgramName = 'All Patients Managed Population'

	SELECT DISTINCT pm.ProgramID
	INTO #prg
	FROM PatientProgram pm
	INNER JOIN @t_Patient s ON pm.PatientID = s.tKeyId
	WHERE pm.StatusCode = 'E'
		AND pm.ProgramID <> @i_ProgramID

	IF EXISTS (
			SELECT 1
			FROM #prg
			)
	BEGIN
			;

		WITH prgprov
		AS (
			SELECT DISTINCT pp.ProviderID
			FROM ProgramProvider PP
			INNER JOIN #prg p ON pp.ProgramID = p.ProgramID
			)
		INSERT INTO ProviderEventNotification (
			PatientEventNotificationID
			,ProviderID
			)
		SELECT @i_CompleteEventNotificationId
			,ProviderID
		FROM prgprov
	END
	ELSE
	BEGIN
			;

		WITH prv
		AS (
			SELECT ug.ProviderID
			FROM UserGroup ug
			INNER JOIN SecurityRole sr ON ug.SecurityRoleId = sr.SecurityRoleId
			WHERE RoleName = 'Administrator'
				AND ug.StatusCode = 'A'
			)
		INSERT INTO ProviderEventNotification (
			PatientEventNotificationID
			,ProviderID
			)
		SELECT @i_CompleteEventNotificationId
			,ProviderID
		FROM prv
	END

	IF (@l_TranStarted = 1) -- If transactions are there, then commit
	BEGIN
		SET @l_TranStarted = 0

		COMMIT TRANSACTION
	END
END TRY

BEGIN CATCH
	----------------------------------------------------------------------------------------------------------           
	-- Handle exception  
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH