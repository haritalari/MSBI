﻿/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_OLAPBridgePopulationReport]1
Description   : This proc is used to populate the data into OLAP tables to refresh the cube
Created By    : Rathnam
Created Date  : 15-Dec-2014
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION 
05-Jan-2015 NagaBabu Added a Parameter @vc_TableName and modified to conditional statements 
13-Feb-2015 Nagasiva  assigned null value to  @i_AppUserId  Parameter to remove the hardcoded userid in cube execution package
02-May-2016  : NAVI-5936 # Ratnam Added conditon for displaying only Enrolled ManagedPopulations in Cube Reports
---------------------------------------------------------------------------------------------------------------------------------------------
*/

CREATE PROCEDURE [dbo].[usp_Batch_OLAPBridgePopulationReport]
(
	@i_AppUserId KEYID =NULL
)
AS
BEGIN TRY
	SET NOCOUNT ON;
			
			SELECT @i_AppUserId=MIN(UserId) FROM Users WITH(NOLOCK)
    
			IF OBJECT_ID('TEMPDB..##OLAP_BridgeReportConfiguration') IS NOT NULL
				DROP TABLE ##OLAP_BridgeReportConfiguration
				
			SELECT DISTINCT rf.ReportID AS ReportKey
				,rfc.MetricId AS MetricKey
				,rfc.DrID AS DrKey
				,rfd.AnchorDate AS DateKey
				,rfc.IsPrimary
			INTO ##OLAP_BridgeReportConfiguration
			FROM ReportFrequencyConfiguration rfc WITH(NOLOCK)
			INNER JOIN ReportFrequencyDate rfd WITH(NOLOCK)
				ON rfc.ReportFrequencyId = rfd.ReportFrequencyId
			INNER JOIN ReportFrequency rf WITH(NOLOCK)
				ON rf.ReportFrequencyId = rfc.ReportFrequencyId
			INNER JOIN ##OLAP_DimReport r
				ON r.ReportKey = rf.ReportID
			INNER JOIN ##OLAP_DimPopulation dp
				ON DP.PopulationKey = rfc.DrID
			INNER JOIN ##OLAP_DimAnchordate da
				ON da.DateKey = rfd.AnchorDate


			IF OBJECT_ID('TEMPDB..##OLAP_BridgePatientDr') IS NOT NULL
				DROP TABLE ##OLAP_BridgePatientDr
						
			CREATE TABLE #OLAP_BridgePatientDr
			(
				DrKey INT ,
				PatientKey INT ,
				DateKey INT ,
				ClaimAmt MONEY ,
				SequenceNo INT ,
			)
			
			INSERT INTO #OLAP_BridgePatientDr
			(
				DrKey ,
				PatientKey ,
				DateKey ,
				ClaimAmt
			)
			SELECT DISTINCT pdp.PopulationDefinitionID
				,pdp.PatientID
				,pdpad.DateKey
				,pdpad.ClaimAmt
			FROM 
				PopulationDefinitionPatients AS pdp WITH(NOLOCK) 
			INNER JOIN ##OLAP_DimPatient dpp 
				ON dpp.PatientKey = pdp.PatientID
			INNER JOIN PopulationDefinitionPatientAnchorDate AS pdpad WITH(NOLOCK)
				ON pdp.PopulationDefinitionPatientID = pdpad.PopulationDefinitionPatientID
			INNER JOIN ##OLAP_DimPopulation dp
				ON dp.PopulationKey = pdp.PopulationDefinitionID
			INNER JOIN ##OLAP_DimAnchordate ad
				ON ad.Datekey = pdpad.DateKey
				

			UPDATE #OLAP_BridgePatientDr
			SET SequenceNo = CASE 
					WHEN T.cnt > = 8
						THEN 8
					ELSE t.cnt
					END
			FROM (
				SELECT bpd.PatientKey
					,bpd.DateKey
					,COUNT(DISTINCT brc.DrKey) cnt
				FROM #OLAP_BridgePatientDr bpd
				INNER JOIN ##OLAP_BridgeReportConfiguration brc
					ON brc.DrKey = bpd.DrKey
				INNER JOIN ##OLAP_DimReport dr
					ON DR.ReportKey = brc.ReportKey
						AND brc.DateKey = bpd.DateKey
				WHERE DR.Description = 'Comorbidity'
				GROUP BY bpd.PatientKey
					,bpd.DateKey
				) T
			WHERE T.PatientKey = #OLAP_BridgePatientDr.PatientKey
				AND t.DateKey = #OLAP_BridgePatientDr.DateKey
				AND #OLAP_BridgePatientDr.DrKey IN (SELECT DISTINCT brc.DrKey
													FROM ##OLAP_BridgeReportConfiguration brc
													INNER JOIN ##OLAP_DimReport dr
														ON DR.ReportKey = brc.ReportKey
													WHERE DR.Description = 'Comorbidity')
			
			SELECT 
				DrKey ,
				PatientKey ,
				DateKey ,
				ClaimAmt ,
				SequenceNo
			INTO ##OLAP_BridgePatientDr
			FROM #OLAP_BridgePatientDr 
			

			IF OBJECT_ID('TEMPDB..##OLAP_BridgeMetricNrFrequency') IS NOT NULL
				DROP TABLE ##OLAP_BridgeMetricNrFrequency
						
			SELECT mnf.MetricNumeratorFrequencyId AS FrequencyKey
				,mnf.MetricId AS MetricKey
				,ISNULL(mnf.FromOperator, '') + ' ' + CONVERT(VARCHAR(10), ISNULL(mnf.FromFrequency, '')) + CASE 
					WHEN mnf.ToOperator IS NOT NULL
						THEN ' ' + mnf.ToOperator + ' ' + isnull(CONVERT(VARCHAR(10), mnf.ToFrequency), '')
					ELSE ''
					END [Range]
				,mnf.Label
			INTO ##OLAP_BridgeMetricNrFrequency	
			FROM MetricNumeratorFrequency mnf WITH(NOLOCK)

	
			IF OBJECT_ID('TEMPDB..##OLAP_BridgePatientNr') IS NOT NULL
				DROP TABLE ##OLAP_BridgePatientNr
						
			;WITH CTE
			AS (
				SELECT Sno = ROW_NUMBER() OVER (
						PARTITION BY MetricId
						,NRPatientValue.PatientID
						,NRPatientValue.DateKey ORDER BY ValueDate DESC
						)
					,MetricID
					,NRPatientValue.PatientID
					,NRPatientValue.DateKey
					,FrequencyID
				FROM NRPatientValue WITH(NOLOCK)
				INNER JOIN ##OLAP_DimPatient dpp 
				 ON dpp.PatientKey = NRPatientValue.PatientID
				INNER JOIN ##OLAP_DimAnchordate DA
				  ON DA.DateKey = NRPatientValue.DateKey
				WHERE Value IS NOT NULL
				)
			
			SELECT m.MetricId AS MetricKey
				,OMR.PatientID AS PatientKey
				,OMR.DateKey
				,m.DenominatorID AS Drkey
				,OMR.FrequencyID AS FrequencyKey
			INTO ##OLAP_BridgePatientNr	
			FROM Metric AS m WITH(NOLOCK)
			INNER JOIN (
				SELECT nc.MetricID
					,nc.PatientID
					,nc.DateKey
					,nc.FrequencyID
				FROM NRPatientCount AS nc WITH(NOLOCK)
				INNER JOIN ##OLAP_DimPatient Dpp
				  ON nc.PatientID = Dpp.PatientKey
				INNER JOIN ##OLAP_DimAnchordate DA
				ON DA.DateKey = nc.DateKey
				UNION ALL
				
				SELECT MetricID
					,PatientID
					,DateKey
					,FrequencyID
				FROM CTE
				WHERE Sno = 1
				) AS OMR
				ON m.MetricId = OMR.MetricID
				 
		
		
			IF OBJECT_ID('TEMPDB..##OLAP_BridgeHealthPlan') IS NOT NULL
				DROP TABLE ##OLAP_BridgeHealthPlan
						
			SELECT DISTINCT dhp.HealthPlanKey
				,pi1.PatientID AS PatientKey
				,ad.DateKey
			INTO ##OLAP_BridgeHealthPlan	
			FROM 
			  PatientInsuranceBenefit AS pib WITH (NOLOCK)
			INNER JOIN PatientInsurance AS pi1 WITH (NOLOCK)
				ON pi1.PatientInsuranceID = pib.PatientInsuranceID
			INNER JOIN InsuranceGroupPlan AS igp WITH (NOLOCK)
				ON igp.InsuranceGroupPlanId = pi1.InsuranceGroupPlanId
			INNER JOIN ##OLAP_DimPatient AS dp1
				ON dp1.PatientKey = pi1.PatientID
			INNER JOIN ##OLAP_DimProduct AS dp
				ON dp.ProductCode = igp.ProductType
			INNER JOIN ##OLAP_DimHealthPlan AS dhp
				ON dhp.HealthPlanKey = igp.InsuranceGroupId
			INNER JOIN ##OLAP_DimAnchordate AS ad
				ON ad.AnchorDate = CASE 
						WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pib.DateOfEligibility) - 1), pib.DateOfEligibility)
								AND CASE 
										WHEN YEAR(pib.CoverageEndsDate) = 9999
											THEN pib.CoverageEndsDate
										ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, pib.CoverageEndsDate) + 1, 0))
										END
							THEN ad.AnchorDate
						ELSE NULL
						END
			
		
			
			IF OBJECT_ID('TEMPDB..##OLAP_BridgeProduct') IS NOT NULL
				DROP TABLE ##OLAP_BridgeProduct
				
			SELECT DISTINCT dp.ProductKey
				,pi1.PatientID AS PatientKey
				,ad.DateKey
			INTO ##OLAP_BridgeProduct	
			FROM PatientInsuranceBenefit AS pib WITH (NOLOCK)
			INNER JOIN PatientInsurance AS pi1 WITH (NOLOCK)
				ON pi1.PatientInsuranceID = pib.PatientInsuranceID
			INNER JOIN InsuranceGroupPlan AS igp WITH (NOLOCK)
				ON igp.InsuranceGroupPlanId = pi1.InsuranceGroupPlanId
			INNER JOIN ##OLAP_DimPatient AS dp1
				ON dp1.PatientKey = pi1.PatientID
			INNER JOIN ##OLAP_DimProduct AS dp
				ON dp.ProductCode = igp.ProductType
			INNER JOIN ##OLAP_DimAnchordate AS ad
				ON ad.AnchorDate = CASE 
						WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pib.DateOfEligibility) - 1), pib.DateOfEligibility)
								AND CASE 
										WHEN YEAR(pib.CoverageEndsDate) = 9999
											THEN pib.CoverageEndsDate
										ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, pib.CoverageEndsDate) + 1, 0))
										END
							THEN ad.AnchorDate
						ELSE NULL
						END
			

	
			IF OBJECT_ID('TEMPDB..##OLAP_BridgeCareProvider') IS NOT NULL
				DROP TABLE ##OLAP_BridgeCareProvider
				
			SELECT DISTINCT p.ProviderID AS CareProviderkey
				,m.PatientID AS PatientKey
				,ad.DateKey
			INTO ##OLAP_BridgeCareProvider	
			FROM 
				PatientProgram m WITH(NOLOCK)
			INNER JOIN  ##OLAP_DimPatient dpp
			    ON dpp.PatientKey = m.PatientID
			INNER JOIN (
				SELECT mp.Programid
					,ctm.ProviderID
				FROM ProgramCareTeam pct WITH (NOLOCK)
				INNER JOIN careteammembers ctm WITH (NOLOCK)
					ON pct.CareTeamId = ctm.CareTeamId
				INNER JOIN Program mp WITH (NOLOCK)
					ON mp.ProgramId = pct.ProgramId
						AND ctm.StatusCode = 'A'
				) p
				ON m.ProgramID = p.ProgramId
			INNER JOIN ##OLAP_DimProvider DP
				ON DP.ProviderKey = P.ProviderID	
			INNER JOIN ##OLAP_DimAnchordate AS ad
				ON ad.AnchorDate = CASE 
						WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(m.EnrollmentStartDate) - 1), m.EnrollmentStartDate)
								AND CASE 
										WHEN YEAR(ISNULL(m.EnrollmentEndDate, '9999-12-31')) = 9999
											THEN ISNULL(m.EnrollmentEndDate, '9999-12-31')
										ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, m.EnrollmentEndDate) + 1, 0))
										END
							THEN ad.AnchorDate
						ELSE NULL
						END


			IF OBJECT_ID('TEMPDB..##OLAP_BridgePCP') IS NOT NULL
				DROP TABLE ##OLAP_BridgePCP

			SELECT DISTINCT pp.PatientID AS PatientKey
				,ad.DateKey
				,pp.ProviderID AS PCPkey
				,Clinic.ParentProviderID AS ClinicKey
			INTO ##OLAP_BridgePCP	
			FROM PatientPCP pp WITH(NOLOCK)
			INNER JOIN ##OLAP_DimPatient dpa
			   ON pp.PatientId = dpa.PatientKey
			INNER JOIN ##OLAP_DimProvider dp
				ON dp.ProviderKey = pp.ProviderID
			INNER JOIN ##OLAP_DimAnchordate ad
				ON ad.AnchorDate = CASE 
						WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pp.CareBeginDate) - 1), pp.CareBeginDate)
								AND CASE 
										WHEN YEAR(pp.CareEndDate) = 9999
											THEN pp.CareEndDate
										ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, pp.CareEndDate) + 1, 0))
										END
							THEN ad.AnchorDate
						ELSE NULL
						END
			INNER JOIN (
				SELECT DISTINCT pp.ParentProviderID
					,pp.ChildProviderID
					,ad.DateKey
				FROM ProviderHierarchyDetail pp WITH(NOLOCK)
				INNER JOIN ##OLAP_DimProvider clinc
					ON pp.ParentProviderID = clinc.ProviderKey
				INNER JOIN ##OLAP_DimProvider pcp
					ON pcp.ProviderKey = pp.ChildProviderID
				INNER JOIN ##OLAP_DimAnchordate ad
					ON ad.AnchorDate = CASE 
							WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pp.BeginDate) - 1), pp.BeginDate)
									AND CASE 
											WHEN YEAR(pp.EndDate) = 9999
												THEN pp.EndDate
											ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, pp.EndDate) + 1, 0))
											END
								THEN ad.AnchorDate
							ELSE NULL
							END
				) Clinic
				ON Clinic.ChildProviderID = pp.ProviderID
					AND Clinic.DateKey = ad.DateKey
		
	

			DECLARE @i_ValueMetricID INT
				,@i_CntMetricID INT

			SELECT @i_ValueMetricID = max(metrickey)
			FROM ##OLAP_DimMetric
			WHERE NumeratorType = 'v'
				AND NAME = 'No Metric Available'
			GROUP BY NAME

			SELECT @i_CntMetricID = MAX(metrickey)
			FROM ##OLAP_DimMetric
			WHERE NumeratorType = 'c'
				AND MetricType = 'N'
				AND NAME = 'No Metric Available'
			GROUP BY NAME
			
			
			
			INSERT INTO ##OLAP_BridgeReportConfiguration
			(
				ReportKey ,
				MetricKey ,
				DrKey ,
				DateKey ,
				IsPrimary
			)
			SELECT DISTINCT brc.ReportKey
				,CASE 
					WHEN t.NumeratorType = 'C'
						THEN @i_CntMetricID
					WHEN t.NumeratorType = 'V'
						THEN @i_ValueMetricID
					END
				,drkey
				,brc.DateKey
				,1
			FROM ##OLAP_BridgeReportConfiguration brc
			CROSS JOIN (
				SELECT DISTINCT dm.MetricType
					,dm.NumeratorType
				FROM ##OLAP_DimMetric dm
				WHERE MetricType = 'n'
				) t
			WHERE NOT EXISTS (
					SELECT 1
					FROM (
						SELECT TBRC.*
							,dm1.NAME
							,dm1.NumeratorType
						FROM ##OLAP_BridgeReportConfiguration TBRC
						INNER JOIN ##OLAP_DimMetric dm1
							ON dm1.MetricKey = TBRC.MetricKey
						WHERE dm1.MetricType = 'n'
						) brc1
					WHERE brc.ReportKey = brc1.ReportKey
						AND brc.DrKey = brc1.DrKey
						AND t.NumeratorType = brc1.NumeratorType
					)
			ORDER BY 3
		

			IF OBJECT_ID('TEMPDB..##OLAP_BridgePatientProgram') IS NOT NULL
				DROP TABLE ##OLAP_BridgePatientProgram
	
			SELECT DISTINCT m.ProgramID AS ProgramKey
				,m.PatientID AS PatientKey
				,ad.DateKey
			INTO ##OLAP_BridgePatientProgram
			FROM PatientProgram m WITH(NOLOCK)
			INNER JOIN ##OLAP_DimPatient dpp
				ON dpp.PatientKey= m.PatientID
			INNER JOIN ##OLAP_DimAnchordate AS ad
				ON ad.AnchorDate = CASE 
						WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(m.EnrollmentStartDate) - 1), m.EnrollmentStartDate)
								AND CASE 
										WHEN YEAR(ISNULL(m.EnrollmentEndDate, '9999-12-31')) = 9999
											THEN ISNULL(m.EnrollmentEndDate, '9999-12-31')
										ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, m.EnrollmentEndDate) + 1, 0))
										END
							THEN ad.AnchorDate
						ELSE NULL
						END
						WHERE m.StatusCode IN ('E','I')
						
			
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT;

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId;
END CATCH;