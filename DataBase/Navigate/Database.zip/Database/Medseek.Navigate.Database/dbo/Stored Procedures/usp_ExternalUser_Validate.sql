﻿
/*    
----------------------------------------------------------------------------------------------   
Procedure Name: [usp_ExternalUser_Validate]
Description   : This procedure is used to validate & bring AppUserID & Externaluserid from Navigate
Created By    : Rathnam   
Created Date  : 06-Oct-2016 
----------------------------------------------------------------------------------------------
Log History   :     
DD-MM-YYYY  BY   DESCRIPTION 
-----------------------------------------------------------------------------------------------
*/
CREATE PROCEDURE [dbo].[usp_ExternalUser_Validate] 
	(
	 @i_ExternalUserId INT
	,@v_ExternalUserName VARCHAR(500)
	,@v_SourceType VARCHAR(100)
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @O_ExternalUserId INT
		,@i_AppUserId INT

	IF NOT EXISTS (
			SELECT 1
			FROM ExternalUser
			WHERE UserId = @i_ExternalUserId
				AND SourceType = @v_SourceType
			)
	BEGIN
		INSERT INTO ExternalUser (
			UserId
			,UserName
			,SourceType
			,CreatedDate
			)
		SELECT @i_ExternalUserId
			,@v_ExternalUserName
			,@v_SourceType
			,GETDATE()

		SET @O_ExternalUserId = SCOPE_IDENTITY()
	END

	IF @O_ExternalUserId IS NULL
	BEGIN
		SELECT @O_ExternalUserId = ExternalUserID
		FROM ExternalUser WITH (NOLOCK)
		WHERE UserId = @i_ExternalUserId
			AND SourceType = @v_SourceType
	END

	SELECT @i_AppUserId = ug.ProviderID
	FROM Users u WITH (NOLOCK)
	INNER JOIN UserGroup ug WITH (NOLOCK) ON u.UserId = ug.UserID
	WHERE UserLoginName = 'ExternalUser'

	SELECT @O_ExternalUserId ExternalUserId, @i_AppUserId AppUserId
END TRY

--------------------------------------------------------     
BEGIN CATCH
	-- Handle exception  
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH