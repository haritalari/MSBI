﻿/*---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_HEDIS_HealthPlans_ART_GetNumerator_DMARD_Testing_Indicator_2012]
Description   : This proc is used to populating the configuerd numerator Patient count 
Created By    :   
Created Date  : 
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY	DESCRIPTION  
25/08/2015  NagaSiva Added parameter @ECTTableName and modified code to optimize performance Navi-4455
08/12/2015  Srinivas  Added parameter Sniffing to avoid unnecessary compilations, and reducing the number of ad-hoc queries in the plan cache
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_HEDIS_HealthPlans_ART_GetNumerator_DMARD_Testing_Indicator_2012] (
	@PopulationDefinitionID INT
	,@MetricID INT
	,@Num_Months_Prior INT = 12
	,@Num_Months_After INT = 0
	,@ECTCodeVersion_Year INT = 2012
	,@ECTCodeStatus VARCHAR(1) = 'A'
	,@AnchorDate_Year INT = 2012
	,@AnchorDate_Month VARCHAR(2) = 12
	,@AnchorDate_Day VARCHAR(2) = 31
	,@ReportType CHAR(1)='P'--S For Strategic Companion,P for Population
	,@ECTTableName VARCHAR(20)='ART-C'
	)
AS
BEGIN
SET NOCOUNT ON
/************************************************************ INPUT PARAMETERS ************************************************************

	 @PopulationDefinitionID = Handle to the selected Population of Patients from which the Eligible Population of Patients of the Numerator
							   are to be constructed.

	 @Num_Months_Prior = Number of Months Before the Anchor Date from which Eligible Population of Patients with desired Encounter Claims
						 is to be constructed.

	 @Num_Months_After = Number of Months After the Anchor Date from which Eligible Population of Patients with desired Encounter Claims
						 is to be constructed.

	 @ECTCodeVersion_Year = Code Version Year from which valid HEDIS-associated ECT and Drug Codes during the Measurement Period that are
						    retrieved to identify Patients for inclusion in the Eligible Population of Patients.

	 @ECTCodeStatus = Status of valid HEDIS-associated ECT and Drug Codes during the Measurement Period that are retrieved to identify Patients
					  for inclusion in the Eligible Population of Patients during the Measurement Period.
					  Examples = 1 (for 'Enabled') or 0 (for 'No').


	 *********************************************************************************************************************************************/
DECLARE @v_DenominatorType VARCHAR(1)
	,@i_ManagedPopulationID INT
	,@DateKey VARCHAR(10)
	,@vc_tableName VARCHAR(50)='##NrPatientCount'
	,@vc_Sql VARCHAR(MAX)
	,@Param_PopulationDefinitionID INT
	,@Param_MetricID INT
	,@Param_Num_Months_Prior INT 
	,@Param_Num_Months_After INT 
	,@Param_ECTCodeVersion_Year INT 
	,@Param_ECTCodeStatus VARCHAR(1) 
	,@Param_AnchorDate_Year INT
	,@Param_AnchorDate_Month VARCHAR(2) 
	,@Param_AnchorDate_Day VARCHAR(2)
	,@Param_ReportType CHAR(1) --S For Strategic Companion,P for Population
	,@Param_ECTTableName VARCHAR(20)

	SET @Param_PopulationDefinitionID = @PopulationDefinitionID
	SET @Param_MetricID = @MetricID
	SET @Param_Num_Months_Prior = @Num_Months_Prior
	SET @Param_Num_Months_After = @Num_Months_After
	SET @Param_ECTCodeVersion_Year = @ECTCodeVersion_Year
	SET @Param_ECTCodeStatus = @ECTCodeStatus
	SET @Param_AnchorDate_Year = @AnchorDate_Year
	SET @Param_AnchorDate_Month = @AnchorDate_Month
	SET @Param_AnchorDate_Day = @AnchorDate_Day
	SET @Param_ReportType = @ReportType
	SET @Param_ECTTableName = @ECTTableName

SELECT @v_DenominatorType = m.DenominatorType
	,@i_ManagedPopulationID = m.ManagedPopulationID
FROM Metric m
WHERE m.MetricId = @Param_MetricID

SET @DateKey = CONVERT(VARCHAR(10), @Param_AnchorDate_Year) + CONVERT(VARCHAR(10),@Param_AnchorDate_Month) + CONVERT(VARCHAR(10),@Param_AnchorDate_Day)

CREATE TABLE #PDNR (
	PatientID INT
	,[Count] INT
	,IsIndicator BIT
	)
	 
	
	SELECT [DrugCode] INTO #rxx
	FROM dbo.ufn_HEDIS_GetDrugInfo_ByTableName(@Param_ECTTableName, @Param_ECTCodeVersion_Year, @Param_ECTCodeStatus)

IF @v_DenominatorType = 'M'
	AND @i_ManagedPopulationID IS NOT NULL
BEGIN
	INSERT INTO #PDNR
	SELECT DISTINCT  rx_clm.[PatientID]
					,1 AS 'Count'
					,1 AS 'IsIndicator'
		FROM [RxClaim] rx_clm
		INNER JOIN [dbo].[PopulationDefinitionPatients] p
			ON p.[PatientID] = rx_clm.[PatientID]
		INNER JOIN PatientProgram pp WITH(nolock)
		    ON pp.PatientID = p.PatientID	
		INNER JOIN PopulationDefinitionPatientAnchorDate pdpa
			ON pdpa.PopulationDefinitionPatientID = p.PopulationDefinitionPatientID
		INNER JOIN [CodeSetDrug] rx
			ON (rx.[DrugCodeId] = rx_clm.[DrugCodeId])
		INNER JOIN #rxx rxx on rxx.DrugCode = rx.DrugCode
		WHERE (
				rx_clm.[DateFilled] BETWEEN (DATEADD(YYYY, - @Param_Num_Months_Prior, DATEADD(YYYY, 0, pdpa.OutPutAnchorDate)))
					AND (DATEADD(YYYY, @Param_Num_Months_After, DATEADD(YYYY, 0, pdpa.OutPutAnchorDate)))
				)
			AND p.PopulationdefinitionID = @Param_PopulationDefinitionID
			AND pp.ProgramID = @i_ManagedPopulationID
			AND pdpa.DateKey =@datekey
			AND pdpa.OutPutAnchorDate  = CASE 
						WHEN pdpa.OutPutAnchorDate BETWEEN DATEADD(dd, - (DAY(PP.EnrollmentStartDate) - 1), PP.EnrollmentStartDate)
								AND CASE 
										WHEN YEAR(ISNULL(PP.EnrollmentEndDate, '9999-12-31')) = 9999
											THEN ISNULL(PP.EnrollmentEndDate, '9999-12-31')
										ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, PP.EnrollmentEndDate) + 1, 0))
										END
							THEN pdpa.OutPutAnchorDate
						ELSE NULL
						END 
END
ELSE
BEGIN
	INSERT INTO #PDNR
	SELECT DISTINCT rx_clm.[PatientID]
		,1 AS 'Count'
		,1 AS 'IsIndicator'
	FROM [RxClaim] rx_clm
	INNER JOIN [dbo].[PopulationDefinitionPatients] p
		ON p.[PatientID] = rx_clm.[PatientID]
	INNER JOIN PopulationDefinitionPatientAnchorDate pdpa
		ON pdpa.PopulationDefinitionPatientID = p.PopulationDefinitionPatientID
	INNER JOIN [CodeSetDrug] rx
		ON (rx.[DrugCodeId] = rx_clm.[DrugCodeId])
	INNER JOIN #rxx rxx
		ON rxx.DrugCode = rx.DrugCode
	WHERE (
			rx_clm.[DateFilled] BETWEEN (DATEADD(YYYY, - @Param_Num_Months_Prior, DATEADD(YYYY, 0, pdpa.OutPutAnchorDate)))
				AND (DATEADD(YYYY, @Param_Num_Months_After, DATEADD(YYYY, 0, pdpa.OutPutAnchorDate)))
			)
		AND p.PopulationdefinitionID = @Param_PopulationDefinitionID
		AND pdpa.DateKey = @datekey
END

IF EXISTS(SELECT 1 FROM TempDb.Dbo.sysobjects WHERE Name =@vc_tableName+'_'+@datekey)
	BEGIN 
	    
		SET @vc_Sql =' DELETE FROM ' +@vc_tableName+'_'+@datekey+ ' WHERE Datekey ='+@datekey+' AND MetricId ='+CAST(@Param_MetricID AS VARCHAR)
			EXEC(@vc_Sql)		
		SET	@vc_Sql= 'INSERT INTO '+@vc_tableName+'_'+@datekey+'(MetricID,PatientID,[Count],IsIndicator,DateKey)
					  SELECT '+CAST(@Param_MetricID AS VARCHAR)+' ,'+'PatientID,[Count],IsIndicator,'+@DateKey +' FROM #PDNR'
		--PRINT(@vc_SQL)
		EXEC(@vc_Sql)
	END
	ELSE
	BEGIN
		SET @vc_Sql ='SELECT '+CAST(@Param_MetricID AS VARCHAR)+' AS MetricId,PatientID,[Count],IsIndicator,'+@DateKey + 'AS DateKey INTO '+@vc_tableName+'_'+@datekey+' FROM #PDNR'
	
		--PRINT(@vc_Sql)
		EXEC(@vc_Sql)
	END
	

	
DROP TABLE #PDNR
DROP TABLE #rxx
END
