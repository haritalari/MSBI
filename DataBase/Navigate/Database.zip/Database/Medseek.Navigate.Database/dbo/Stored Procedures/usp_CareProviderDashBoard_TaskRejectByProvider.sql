﻿
/*                  
------------------------------------------------------------------------------                  
Procedure Name: usp_CareProviderDashBoard_TaskRejectByProvider
Description   : This procedure is used to reject the patient submitted task by the caremanager
Created By    : Rathnam                  
Created Date  : 28-Oct-2010                  
------------------------------------------------------------------------------                  
Log History   :                   
DD-MM-YYYY  BY   DESCRIPTION
28-Oct-2016 Rathnam modified as per NAVI-6933
------------------------------------------------------------------------------       
*/
CREATE PROCEDURE [dbo].[usp_CareProviderDashBoard_TaskRejectByProvider] (
	@i_AppUserId INT
	,@i_PatientTaskId INT
	,@i_PatientTaskSubmitStatusId INT
	,@i_RejectReasonId INT
	,@v_Comments VARCHAR(500) = NULL
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @l_TranStarted BIT = 0

	IF (@@TRANCOUNT = 0)
	BEGIN
		BEGIN TRANSACTION

		SET @l_TranStarted = 1 -- Indicator for start of transactions
	END

	DECLARE @i_TaskStatusId INT

	SELECT @i_TaskStatusId = TaskStatusId
	FROM TaskStatus
	WHERE TaskStatusText = 'Reject'

	UPDATE PatientTaskSubmitStatus
	SET RejectDate = GETDATE()
		,RejectBy = @i_AppUserId
		,Comments = @v_Comments
		,RejectReasonId = @i_RejectReasonId
	WHERE PatientTaskSubmitStatusId = @i_PatientTaskSubmitStatusId

	UPDATE PatientTask
	SET TaskStatusId = @i_TaskStatusId
		,LastModifiedByUserId = @i_AppUserId
		,LastModifiedDate = GETDATE()
		,Comments = ISNULL(Comments, '') + ' Rejected'
	WHERE PatientTaskId = @i_PatientTaskId

	DECLARE @i_TaskTypeId INT

	SELECT @i_TaskTypeId = TaskTypeId
	FROM TaskType
	WHERE TaskTypeName = 'Goal'

	IF EXISTS (
			SELECT 1
			FROM PatientTask WITH (NOLOCK)
			WHERE PatientTaskId = @i_PatientTaskId
				AND TaskTypeId = @i_TaskTypeId
			)
	BEGIN
		SELECT pa.PatientTaskId
		INTO #activity
		FROM PatientTask pa WITH (NOLOCK)
		INNER JOIN TaskStatus ts WITH (NOLOCK) ON pa.TaskStatusId = ts.TaskStatusId
		WHERE pa.PatientGoalId = @i_PatientTaskId
			AND ts.TaskStatusText IN (
				'Open'
				,'Submit'
				)

		UPDATE PatientTaskSubmitStatus
		SET RejectDate = GETDATE()
			,RejectBy = @i_AppUserId
			,Comments = @v_Comments
			,RejectReasonId = @i_RejectReasonId
		FROM #activity a
		WHERE a.PatientTaskId = PatientTaskSubmitStatus.PatientTaskId
			AND PatientTaskSubmitStatus.RejectReasonId IS NULL

		UPDATE PatientTask
		SET TaskStatusId = @i_TaskStatusId
			,LastModifiedByUserId = @i_AppUserId
			,LastModifiedDate = GETDATE()
			,Comments = ISNULL(Comments, '') + ' Rejected'
		FROM #activity a
		WHERE a.PatientTaskId = PatientTask.PatientTaskId
	END

	IF (@l_TranStarted = 1) -- If transactions are there, then commit
	BEGIN
		SET @l_TranStarted = 0

		COMMIT TRANSACTION
	END
END TRY

--------------------------------------------------------                   
BEGIN CATCH
	-- Handle exception                  
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH
