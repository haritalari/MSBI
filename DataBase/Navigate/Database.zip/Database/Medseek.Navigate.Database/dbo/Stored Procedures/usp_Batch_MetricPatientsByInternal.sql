﻿/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_MetricPatientsByInternal]  
Description   : This proc is used to fetch the Nr OR Utilization patients
Created By    : Rathnam  
Created Date  : 08-AUG-2013
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION
17/12/2015  Naga siva Removed Merge statement and used Global temp tables  to process the inernal Metrics at a time

----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_MetricPatientsByInternal] --1,@v_DateKey
	(
	@i_AppUserId KEYID
	,@v_DateKey VARCHAR(8)
	,@i_MetricID INT
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	-- Check if valid Application User ID is passed  
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END;

		DECLARE @vc_Sql VARCHAR(MAX)

		SELECT pdc.MetricID
			,pcg.PatientID
			,CASE 
				WHEN ISNULL(nr.IsIndicator, 0) = 1
					THEN 1
				ELSE COUNT(DISTINCT pcg.DateOfService)
				END [Count]
			,ISNULL(nr.IsIndicator, 0) IsIndicator
			,@i_AppUserId CreatedByUserId
			,@v_DateKey DateKey INTO #PDNRC
		FROM vw_PatientCodeGroup pcg WITH (NOLOCK)
		INNER JOIN PopulationDefinitionPatients pdp WITH (NOLOCK)
			ON pdp.PatientID = pcg.PatientID
		INNER JOIN PopulationDefinitionPatientAnchorDate pdpad WITH (NOLOCK)
			ON pdpad.PopulationDefinitionPatientID = pdp.PopulationDefinitionPatientID
		INNER JOIN PopulationDefinitionConfiguration pdc WITH (NOLOCK)
			ON pdc.CodeGroupingID = pcg.CodeGroupingID
		INNER JOIN Metric m WITH (NOLOCK)
			ON m.MetricId = pdc.MetricID
				AND m.DenominatorID = pdp.PopulationDefinitionID
		INNER JOIN PopulationDefinition nr WITH (NOLOCK)
			ON nr.PopulationDefinitionID = m.NumeratorID
		WHERE pdc.MetricID IS NOT NULL
			AND pdc.CodeGroupingID IS NOT NULL
			AND pcg.DateOfService > = DATEADD(DAY, - pdc.TimeInDays, pdpad.OutPutAnchorDate)
			AND pcg.DateOfService < = pdpad.OutPutAnchorDate
			AND pdpad.DateKey = @v_DateKey
			AND m.DenominatorType <> 'M'
			AND nr.NumeratorType = 'C'
			AND (m.MetricId = @i_MetricID)
		GROUP BY pdc.MetricID
			,pcg.PatientID
			,ISNULL(nr.IsIndicator, 0)
		
		UNION ALL
		
		SELECT m.MetricID
			,pcg.PatientID
			,COUNT(DISTINCT pcg.DrugCodeId)
			,0
			,@i_AppUserId
			,@v_DateKey
		FROM RxClaim pcg WITH (NOLOCK)
		INNER JOIN PopulationDefinitionPatients pdp WITH (NOLOCK)
			ON pdp.PatientID = pcg.PatientID
		INNER JOIN PopulationDefinitionPatientAnchorDate pdpad WITH (NOLOCK)
			ON pdpad.PopulationDefinitionPatientID = pdp.PopulationDefinitionPatientID
		INNER JOIN Metric m WITH (NOLOCK)
			ON m.DenominatorID = pdp.PopulationDefinitionID
		INNER JOIN PopulationDefinitionConfiguration pdc WITH (NOLOCK)
			ON pdc.MetricID = m.MetricID
		INNER JOIN PopulationDefinition nr WITH (NOLOCK)
			ON nr.PopulationDefinitionID = m.NumeratorID
		WHERE pdc.MetricID IS NOT NULL
			AND pdc.CodeGroupingID IS NULL
			AND pcg.DateFilled > = DATEADD(DAY, - pdc.TimeInDays, pdpad.OutPutAnchorDate)
			AND pcg.DateFilled < = pdpad.OutPutAnchorDate
			AND pdpad.DateKey = @v_DateKey
			AND m.DenominatorType <> 'M'
			AND nr.NumeratorType = 'C'
			AND nr.PopulationDefinitionName = 'Unique NDC Count'
			AND (m.MetricId = @i_MetricID)
		GROUP BY m.MetricID
			,pcg.PatientID
		

	
		SELECT DISTINCT pdc.MetricID
			,pcg.PatientID
			,ISNULL(nr.IsIndicator, 0) IsIndicator
			,@i_AppUserId CreatedByUserId
			,@v_DateKey DateKey
			,CASE 
				WHEN nr.IsIndicator = 1
					THEN 1
				ELSE pm.MeasureValueNumeric
				END Value
			,CASE 
				WHEN nr.IsIndicator = 1
					THEN pdpad.OutPutAnchorDate
				ELSE pm.DateTaken
				END ValueDate INTO #PDNRV
		FROM vw_PatientCodeGroup pcg WITH (NOLOCK)
		INNER JOIN PopulationDefinitionPatients pdp WITH (NOLOCK)
			ON pdp.PatientID = pcg.PatientID
		INNER JOIN PopulationDefinitionPatientAnchorDate pdpad WITH (NOLOCK)
			ON pdpad.PopulationDefinitionPatientID = pdp.PopulationDefinitionPatientID
		INNER JOIN PatientMeasure pm  WITH (NOLOCK)
			ON pm.PatientID = pdp.PatientID
		INNER JOIN PopulationDefinitionConfiguration pdc WITH (NOLOCK)
			ON pdc.CodeGroupingID = pcg.CodeGroupingID
		INNER JOIN Metric m WITH (NOLOCK)
			ON m.MetricId = pdc.MetricID
				AND m.DenominatorID = pdp.PopulationDefinitionID
		INNER JOIN PopulationDefinition nr WITH (NOLOCK)
			ON nr.PopulationDefinitionID = m.NumeratorID
		WHERE pdc.MetricID IS NOT NULL
			AND pdc.CodeGroupingID IS NOT NULL
			AND pcg.DateOfService > = DATEADD(DAY, - pdc.TimeInDays, pdpad.OutPutAnchorDate)
			AND pcg.DateOfService < = pdpad.OutPutAnchorDate
			AND pm.DateTaken > = DATEADD(DAY, - pdc.TimeInDays, pdpad.OutPutAnchorDate)
			AND pm.DateTaken < = pdpad.OutPutAnchorDate
			AND pdpad.DateKey = @v_DateKey
			AND m.DenominatorType <> 'M'
			AND nr.NumeratorType = 'V'
			AND (m.MetricId = @i_MetricID)
			
	IF EXISTS(SELECT 1 FROM tempdb.dbo.sysobjects WHERE Name ='##NRPatientCount_'+@v_DateKey)
	BEGIN 
	    
		SET @vc_Sql =' DELETE FROM ##NrPatientCount'+'_'+@v_DateKey+ ' WHERE Datekey ='+@v_DateKey+' AND MetricId ='+CAST(@i_MetricID AS VARCHAR)
			EXEC(@vc_Sql)		
		SET	@vc_Sql= 'INSERT INTO ##NrPatientCount'+'_'+@v_DateKey+'(MetricID,PatientID,[Count],IsIndicator,DateKey)
					  SELECT '+CAST(@i_MetricID AS VARCHAR)+' ,'+'PatientID,[Count],IsIndicator,'+@v_DateKey +' FROM #PDNRC'
		--PRINT(@vc_SQL)
		EXEC(@vc_Sql)
	END
	ELSE
	BEGIN
		SET @vc_Sql ='SELECT '+CAST(@i_MetricID AS VARCHAR)+' AS MetricId,PatientID,[Count],IsIndicator,'+@v_DateKey + 'AS DateKey INTO NRPatientCount'+'_'+@v_DateKey+' FROM #PDNRC'
	
		--PRINT(@vc_Sql)
		EXEC(@vc_Sql)
	END
	
	IF EXISTS(SELECT 1 FROM tempdb.dbo.sysobjects WHERE Name ='##NRPatientValue_'+@v_DateKey)
	BEGIN 
	    
		SET @vc_Sql =' DELETE FROM ##NrPatientValue'+'_'+@v_DateKey+ ' WHERE Datekey ='+@v_DateKey+' AND MetricId ='+CAST(@i_MetricID AS VARCHAR)
			EXEC(@vc_Sql)		
		SET	@vc_Sql= 'INSERT INTO ##NrPatientValue'+'_'+@v_DateKey+'(MetricID,PatientID,,Value,ValueDate,IsIndicator,DateKey)
					  SELECT '+CAST(@i_MetricID AS VARCHAR)+' ,'+'PatientID,Value,ValueDate,IsIndicator,'+@v_DateKey +' FROM #PDNRV'
		--PRINT(@vc_SQL)
		EXEC(@vc_Sql)
	END
	ELSE
	BEGIN
		SET @vc_Sql ='SELECT '+CAST(@i_MetricID AS VARCHAR)+' AS MetricId,PatientID,Value,ValueDate,IsIndicator,'+@v_DateKey + 'AS DateKey INTO NrPatientValue'+'_'+@v_DateKey+' FROM #PDNRV'
	
		--PRINT(@vc_Sql)
		EXEC(@vc_Sql)
	END

	
		
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH


