﻿/*                
------------------------------------------------------------------------------                
Procedure Name: [usp_DashBoard_PatientHomePage_ProgramEncounters]  88024,107,0,1, null, null             
Description   : This procedure is used to get the details from UserEncounters table               
Created By    : Kalyan                
Created Date  : 19-June-2010                
------------------------------------------------------------------------------                
Log History   :                 
DD-MM-YYYY  BY				DESCRIPTION                
03-04-2013	Mohan			Modified UserEncounters to PatientEncounters  CodeSetSpecialty Tables.          
06-11-2013	Gourishankar	Removed CodeGrouping Logic and reinstated PatientProcedure and CodeSetSpecialty Tables  
02-08-2013	Santosh			added the column UserEncounterID 
06-11-2014	Santosh			updated the Readmission Flag select statement
01-09-2014	Santosh			restricted the other encounters as per the new functionality
04-02-2015	Santosh			changed the ADT Functionality as per the new adt functionality
24-03-2015	Nagababu		Modified the querry for fetching EventDate with respect to 'Admission' and 'Discharge'
26-03-2015	Nagababu		Modified the querry for fetching EventDate for all events and EventDescription also modified in case statement for 'E'
02-07-2015	Nagababu		Added case statement for the event 'A40' in the column EventType in second resultset
25-11-2015	Gourishankar	Added DiagnosisCodeFormatted as Part of NAVI-4362
25-11-2015	Nagababu		Changed Join querry with DiagnosisCodeId column when fetching PrimaryDiagnosiscodes as Part of NAVI-4362
07-01-2016  Prashanth		To bring Primary DiagnosisCode for HL7 ADT eveent NAVI-4561
21-Jan-2016 Nagababu		Modified code as per NAVI-5024
31-Mar-2016	Prashanth		NAVI-5570
11-Apr-2016 Rathnam         NAVI-5738
11-Apr-2016 Rathnam         Modified as per NAVI-5773
18-May-2016 Nagababu Modified the logic as per NAVI-5973
------------------------------------------------------------------------------                
*/
CREATE PROCEDURE [dbo].[usp_DashBoard_PatientHomePage_ProgramEncounters] (
	@i_AppUserId KEYID
	,@i_UserId KEYID
	,@b_isLV ISINDICATOR = 0
	,@b_ispopup ISINDICATOR = 0
	,@i_PageIndex INT = 1
	,@i_PageSize INT = 10
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	-- Check if valid Application User ID is passed              
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END

	DECLARE @d_ToDaydate DATE = GETDATE();

	WITH pos
	AS (
		SELECT ROW_NUMBER() OVER (
				PARTITION BY i.ClaimInfoId ORDER BY cl.ClaimLineID
				) sno
			,cl.PlaceOfServiceCodeID
			,i.ClaimInfoId
		FROM ClaimInfo i WITH (NOLOCK)
		LEFT JOIN ClaimLine cl WITH (NOLOCK) ON cl.ClaimInfoID = i.ClaimInfoId
			
		WHERE i.DateOfAdmit > DATEADD(YEAR, - 1, @d_ToDaydate)
		AND i.PatientID = @i_UserId
		)
	SELECT PlaceOfServiceCodeID
		,ClaimInfoId
	INTO #poc
	FROM pos
	WHERE sno = 1

	IF @i_PageIndex = 0 AND @i_PageSize = 0
	BEGIN
		DECLARE @i_ClaimCount INT = 0
			,@i_EventCount INT = 0

		SELECT @i_ClaimCount = COUNT(1)
		FROM #poc

		SELECT @i_EventCount = COUNT(1)
		FROM PatientEvent P WITH (NOLOCK)
		INNER JOIN PatientEventNotification pae WITH (NOLOCK) ON P.PatientEventId = pae.PatientEventId
		INNER JOIN EventType ae WITH (NOLOCK) ON pae.EventTypeId = ae.EventTypeId
		WHERE PatientId = @i_UserId
			AND CONVERT(DATE, pae.EventDate) BETWEEN DATEADD(YEAR, - 1, @d_ToDaydate)
				AND @d_ToDaydate
			AND AE.EventCode <> 'A40'
			AND AE.MessageType = 'ADT'

		SELECT @i_ClaimCount + @i_EventCount TotalCount
	END
	ELSE
	BEGIN
		IF @b_ispopup = 0
		BEGIN
			IF @b_isLV = 1
			BEGIN
				SELECT ROW_NUMBER() OVER (
						ORDER BY (
								SELECT NULL
								)
						) AS UserEncounterID
					,ISNULL(poe.PlaceOfServiceName, '') Encounter
					,CONVERT(VARCHAR(10), ci.DateOfAdmit, 101) AS 'Date'
					,COALESCE(ISNULL(P1.LastName, '') + ' ' + ISNULL(P1.FirstName, '') + ' ' + ISNULL(P1.MiddleName, ''), '') AS 'ProviderName'
					,CodesetCMSProviderSpecialty.ProviderSpecialtyName 'ProviderSpeciality'
					,ci.DateOfAdmit AS DateTaken
				FROM ClaimInfo ci WITH (NOLOCK)
				INNER JOIN #poc pos ON pos.ClaimInfoId = ci.ClaimInfoId
				LEFT JOIN ClaimProvider cp WITH (NOLOCK) ON cp.ClaimInfoID = ci.ClaimInfoID
				LEFT JOIN Provider P1 WITH (NOLOCK) ON P1.ProviderID = cp.ProviderID
				LEFT JOIN ProviderSpecialty WITH (NOLOCK) ON ProviderSpecialty.ProviderID = P1.ProviderID
				LEFT JOIN CodesetCMSProviderSpecialty WITH (NOLOCK) ON CodesetCMSProviderSpecialty.CMSProviderSpecialtyCodeID = ProviderSpecialty.CMSProviderSpecialtyCodeID
				LEFT JOIN CodeSetCMSPlaceOfService poe WITH (NOLOCK) ON poe.PlaceOfServiceCodeID = pos.PlaceOfServiceCodeID
				WHERE ci.PatientID = @i_UserId
					AND ci.DateOfAdmit > DATEADD(YEAR, - 1, @d_ToDaydate)
			END
			ELSE
			BEGIN
				SELECT ROW_NUMBER() OVER (
						ORDER BY (
								SELECT NULL
								)
						) AS UserEncounterID
					,ci.PatientID UserId
					,COALESCE(ISNULL(P1.LastName, '') + ' ' + ISNULL(P1.FirstName, '') + ' ' + ISNULL(P1.MiddleName, ''), '') AS CareProvider
					,CONVERT(VARCHAR(10), ci.DateOfAdmit, 101) AS EncounterDate
					,ISNULL(poe.PlaceOfServiceName, '') EncounterType
					,poe.PlaceOfServiceCodeID EncounterTypeId
					,p1.ProviderID UserProviderID
					,'' CPTCode
					,ISNULL((
							SELECT DISTINCT COALESCE(CAST(NULLIF(DiagnosisCodeFormatted, '') AS VARCHAR(10)), CAST(CSD.DiagnosisCode AS VARCHAR)) + ' - ' + ISNULL(NULLIF(CSD.DiagnosisLongDescription, ''), 'No description found')
							FROM ClaimPrimaryDiagnosis CPD WITH (NOLOCK)
							INNER JOIN CodeSetICDDiagnosis CSD WITH (NOLOCK) ON CSD.DiagnosisCodeID = CPD.DiagnosisCodeId
							WHERE CPD.ClaimInfoId = ci.ClaimInfoId
							), 'Code not found') AS ICDCode
					,CodesetCMSProviderSpecialty.ProviderSpecialtyName ProviderSpeciality
					,CASE 
						WHEN poe.PlaceOfServiceName = 'Inpatient Hospital'
							THEN STUFF((
										SELECT DISTINCT '$$ ' + CAST(csi.ProcedureCode AS VARCHAR) + ' - ' + csi.ProcedureShortDescription
										FROM ClaimProcedure cp WITH (NOLOCK)
										INNER JOIN CodeSetICDProcedure csi WITH (NOLOCK) ON cp.ProcedureCodeID = csi.ProcedureCodeID
										INNER JOIN CodeGroupingDetailInternal cgdi WITH (NOLOCK) ON cgdi.CodeGroupingCodeID = csi.ProcedureCodeID
										INNER JOIN CodeGrouping cg WITH (NOLOCK) ON cg.CodeGroupingID = cgdi.CodeGroupingID
										INNER JOIN CodeTypeGroupers ctg WITH (NOLOCK) ON ctg.CodeTypeGroupersID = cg.CodeTypeGroupersID
										WHERE cp.ClaimInfoID = ci.ClaimInfoId
											AND ctg.CodeTypeGroupersName = 'CCS ICD Procedure 4Classes'
											AND cg.CodeGroupingCode IN (
												3
												,4
												)
										FOR XML PATH('')
										), 1, 2, '')
						ELSE ''
						END MajorProcedures
				FROM ClaimInfo ci WITH (NOLOCK)
				INNER JOIN #poc pos ON pos.ClaimInfoId = ci.ClaimInfoId
				LEFT JOIN ClaimProvider cp WITH (NOLOCK) ON cp.ClaimInfoID = ci.ClaimInfoID
				LEFT JOIN Provider P1 WITH (NOLOCK) ON P1.ProviderID = cp.ProviderID
				LEFT JOIN ProviderSpecialty WITH (NOLOCK) ON ProviderSpecialty.ProviderID = P1.ProviderID
				LEFT JOIN CodesetCMSProviderSpecialty WITH (NOLOCK) ON CodesetCMSProviderSpecialty.CMSProviderSpecialtyCodeID = ProviderSpecialty.CMSProviderSpecialtyCodeID
				LEFT JOIN CodeSetCMSPlaceOfService poe WITH (NOLOCK) ON poe.PlaceOfServiceCodeID = pos.PlaceOfServiceCodeID
				WHERE ci.PatientID = @i_UserId
					AND ci.DateOfAdmit > DATEADD(YEAR, - 1, @d_ToDaydate)
				ORDER BY CAST(DateOfAdmit AS DATE) DESC OFFSET(COALESCE(@i_PageIndex, 1) - 1) * @i_PageSize ROWS

				FETCH NEXT @i_PageSize ROWS ONLY
			END;

			WITH CTE
			AS (
				SELECT CASE 
						WHEN ae.EventCode = 'A04'
							THEN CASE 
									WHEN pae.VisitType = 'O'
										THEN 'OutPatient'
									WHEN pae.VisitType = 'E'
										THEN 'Emergency Registration'
									END
						WHEN ae.EventCode = 'A40'
							THEN CASE 
									WHEN ISNULL(pae.IsMerged, 0) = 0
										THEN ae.EventDescription + ' (Initiated)'
									ELSE ae.EventDescription + ' (Completed)'
									END
						ELSE ae.EventDescription
						END EventType
					,CASE 
						WHEN ae.EventCode IN (
								'A01'
								,'A04'
								,'A06'
								)
							THEN P.VisitAdmitdate
						WHEN ae.EventCode = 'A03'
							THEN ISNULL(p.VisitDischargedate, pae.EventDate)
						ELSE pae.EventDate
						END AS EventDate
					,(
						SELECT OrganizationName
						FROM Provider p2 WITH (NOLOCK)
						WHERE p2.ProviderID = p.FacilityId
						) DisChargeFacilityName
					,CASE 
						WHEN ae.EventCode IN (
								'A01'
								,'A06'
								)
							THEN DATEDIFF(DAY, (
										SELECT MAX(pae.VisitDischargedate)
										FROM PatientEvent pa WITH (NOLOCK)
										INNER JOIN PatientEvent pae WITH (NOLOCK) ON pa.PatientId = pae.PatientId
										INNER JOIN PatientEventNotification nf WITH (NOLOCK) ON nf.PatientEventId = pae.PatientEventId
										INNER JOIN EventType et WITH (NOLOCK) ON et.EventTypeID = nf.EventTypeID
										WHERE pae.PatientEventId < pa.PatientEventId
											AND pa.PatientEventid = p.PatientEventId
											AND et.MessageType = 'ADT'
										), VisitAdmitdate)
						END NumberOfDays
					,CASE 
						WHEN ae.EventDescription = 'Discharge'
							THEN DATEDIFF(DAY, VisitAdmitdate, VisitDischargedate)
						END Inpatientdays
					,CASE 
						WHEN ae.EventCode IN (
								'A01'
								,'A06'
								)
							THEN ISNULL(P.IsReadmit, 0)
						ELSE 0
						END ReadmissionFlag
					,ISNULL((
							SELECT DISTINCT COALESCE(CAST(NULLIF(CSD.DiagnosisCodeFormatted, '') AS VARCHAR(10)), CAST(CSD.DiagnosisCode AS VARCHAR)) + ' - ' + ISNULL(NULLIF(CSD.DiagnosisLongDescription, ''), 'No description found')
							FROM CodeSetICDDiagnosis CSD WITH (NOLOCK)
							INNER JOIN PatientEventNotification PEN WITH (NOLOCK) ON CSD.DiagnosisCodeID = PEN.DiagnosisCodeId
							WHERE PEN.PatientEventId = P.PatientEventId
								AND PEN.PatientEventNotificationId = pae.PatientEventNotificationId
							), 'Code not found') AS Diagnosis
				FROM PatientEvent P WITH (NOLOCK)
				INNER JOIN PatientEventNotification pae WITH (NOLOCK) ON P.PatientEventId = pae.PatientEventId
				INNER JOIN EventType ae WITH (NOLOCK) ON pae.EventTypeId = ae.EventTypeId
				WHERE PatientId = @i_UserId
					AND CONVERT(DATE, pae.EventDate) BETWEEN DATEADD(YEAR, - 1, @d_ToDaydate)
						AND @d_ToDaydate
					AND AE.EventCode <> 'A40'
					AND AE.MessageType = 'ADT'
				)
			SELECT EventType
				,EventDate
				,DisChargeFacilityName
				,NumberOfDays
				,Inpatientdays
				,ReadmissionFlag
				,Diagnosis
			FROM CTE
			ORDER BY EventDate DESC OFFSET(COALESCE(@i_PageIndex, 1) - 1) * @i_PageSize ROWS

			FETCH NEXT @i_PageSize ROWS ONLY
		END
		ELSE
		BEGIN
				;

			WITH CTE_Enc
			AS (
				SELECT ISNULL(poe.PlaceOfServiceName, '') AS EncounterType
					,CONVERT(VARCHAR(10), ci.DateOfAdmit, 101) AS EncounterDate
					,COALESCE(ISNULL(P1.LastName, '') + ' ' + ISNULL(P1.FirstName, '') + ' ' + ISNULL(P1.MiddleName, ''), '') AS CareProvider
					,CSPS.ProviderSpecialtyName AS ProviderSpeciality
				FROM ClaimInfo ci WITH (NOLOCK)
				INNER JOIN #poc pos ON pos.ClaimInfoId = ci.ClaimInfoId
				LEFT JOIN ClaimProvider cp WITH (NOLOCK) ON cp.ClaimInfoID = ci.ClaimInfoID
				LEFT JOIN Provider P1 WITH (NOLOCK) ON P1.ProviderID = cp.ProviderID
				LEFT JOIN ProviderSpecialty PS WITH (NOLOCK) ON PS.ProviderID = P1.ProviderID
				LEFT JOIN CodeSetCMSProviderSpecialty CSPS WITH (NOLOCK) ON CSPS.CMSProviderSpecialtyCodeID = PS.CMSProviderSpecialtyCodeID
				LEFT JOIN CodeSetCMSPlaceOfService poe WITH (NOLOCK) ON poe.PlaceOfServiceCodeID = pos.PlaceOfServiceCodeID
				WHERE ci.PatientID = @i_UserId
					AND ci.DateOfAdmit > DATEADD(YEAR, - 1, @d_ToDaydate)
				
				UNION
				
				SELECT CASE 
						WHEN et.EventCode = 'A04'
							THEN CASE 
									WHEN nf.VisitType = 'O'
										THEN 'OutPatient'
									WHEN nf.VisitType = 'E'
										THEN 'Emergency Registration'
									END
						WHEN et.EventCode = 'A06'
							THEN 'InPatient'
						ELSE EventDescription
						END AS EncounterType
					,CONVERT(VARCHAR(10), VisitAdmitdate, 101) AS EncounterDate
					,'' AS CareProvider
					,'' AS ProviderSpeciality
				FROM PatientEvent pae WITH (NOLOCK)
				INNER JOIN PatientEventNotification nf WITH (NOLOCK) ON nf.PatientEventId = pae.PatientEventId
				INNER JOIN EventType et WITH (NOLOCK) ON et.EventTypeID = nf.EventTypeID
				WHERE pae.PatientId = @i_UserId
					AND et.MessageType = 'ADT'
					AND ET.EventCode IN (
						'A01'
						,'A04'
						,'A06'
						)
					AND pae.VisitAdmitdate > DATEADD(YEAR, - 1, @d_ToDaydate)
				)
			SELECT EncounterType
				,EncounterDate
				,CareProvider
				,ProviderSpeciality
				,TotalCount = COUNT(1) OVER ()
			FROM CTE_Enc
			ORDER BY CAST(EncounterDate AS DATE) DESC
		END
	END
END TRY

--------------------------------------------------------                 
BEGIN CATCH
	-- Handle exception  
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH
