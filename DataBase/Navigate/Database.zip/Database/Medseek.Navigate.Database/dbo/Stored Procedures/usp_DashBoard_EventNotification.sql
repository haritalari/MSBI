﻿
/*			
--------------------------------------------------------------------------------------------------------------            
Procedure Name: [dbo].[usp_DashBoard_EventNotification] 92098,'G',null,null,1,10
Description   : This procedure is to fetch the notifications      
Created By    : Rathnam         
Created Date  : 25-June-2015
---------------------------------------------------------------------------------------------------------------            
Log History   :             
DD-Mon-YYYY  BY  DESCRIPTION 
07-08-2015 Santosh Added the column PatientEventId as NAVI-3209
28-Aug-2015 NagaBabu Modified the logic to populate PatientName filed as per NAVI-3647 
09-Nov-2015 Santosh Modified the code as per NAVI-4202
06-Jan-2016 Rathnam modified as per NAVI-4618
03-Feb-2016 Nagababu Added the logic to not consider OutPatient visits as per NAVI-5157
11-Feb-2016 Prashanth Added PatientId parameter as per NAVI-5068
03-Mar-2016 Kalyan optimized the code for better perfomance
29-Mar-2016 Rathnam modified as per 5421 where in allowing inactive managedpopulation pending enrollments
04-Apr-2016 Rathnam modified as per 5699
02-May-2016 Rathnam modified as per NAVI-5918 
05-May-2016 Rathnam Optimized as per NAVI-5941
02-Jun-2016 Rathnam modified as per NAVI-5972
20-Jun-2016 Wasim modified as per NAVI-5292
05-Jul-2016 Rathnam modified as per NAVI-6142
06-Jul-2016 Rathnam modified as per NAVI-5723
24-Aug-2016 Gurumoorthy Added MergeStatus column  as per NAVI-6645
27-Oct-2016 Nagasiva modified the sp as per NAVI-6853
----------------------------------------------------------------------------------------------------------------        
 */
CREATE PROCEDURE [dbo].[usp_DashBoard_EventNotification] (
	@i_AppUserId INT
	,@c_ProcessType CHAR(1) --> C--> FlierCnt, F--> Flier & G--> Grid
	,@d_FromDate DATE = NULL
	,@d_ToDate DATE = NULL
	,@i_StartRowIndex INT = 1
	,@i_EndRowIndex INT = 100
	,@b_Status BIT = NULL
	,@i_PatientId INT = NULL
	,@tblEventtype ttypeKeyID READONLY
	,@tblFacility ttypeKeyID READONLY
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @dt_CareBeginDate DATETIME
	DECLARE @vc_Rolename VARCHAR(25)
	DECLARE @i_Eventtype INT
	DECLARE @VisitType TABLE (VisitType CHAR(1))


	SELECT @i_Eventtype = EventTypeID
	FROM EventType
	WHERE EventDescription = 'Patient Reassignment'
	
	INSERT INTO @VisitType
	SELECT 'E' UNION ALL
	SELECT ''

	IF @c_ProcessType ='C'
	BEGIN
		SELECT COUNT(1) [Count]
		FROM ProviderEventNotification pde WITH (NOLOCK)
		INNER JOIN PatientEventNotification PEN WITH (NOLOCK) 
			ON PDE.PatientEventNotificationID = PEN.PatientEventNotificationId
		INNER JOIN @VisitType vt
			ON vt.VisitType = ISNULL(PEN.VisitType, '')
		WHERE pde.IsRead = 0
			AND ProviderID = @i_AppUserId
	END

	IF @c_ProcessType = 'F'
	BEGIN
		SELECT pde.PatientEventNotificationId
			,pde.PatientEventId
			,pa.PatientID AS PatientId
			,pde.EventDate
			,CASE 
				WHEN IsMerged IS NULL
					THEN (
							SELECT COALESCE(ISNULL(p2.LastName , '') + ', ' + ISNULL(p2.FirstName , '') + '. ' + ISNULL(p2.MiddleName , '') + ' ' + ISNULL(p2.NameSuffix , '') , '')
							FROM Patient p2 WITH (NOLOCK)
							WHERE p2.PatientID = pa.PatientId
							)
				ELSE (
						SELECT pm.PatientName
						FROM PatientMerge pm WITH (NOLOCK)
						WHERE pm.PatientEventId = pa.PatientEventId
						)
				END AS PatientName
			,CASE 
				WHEN IsMerged IS NULL
					THEN (
							SELECT  COALESCE(ISNULL(p2.LastName , '') + ', ' + ISNULL(p2.FirstName , '') + '. ' + ISNULL(p2.MiddleName , '') + ' ' + ISNULL(p2.NameSuffix , '') , '')
							FROM Patient p2 WITH (NOLOCK)
							WHERE p2.PatientID = pa.MergePatientId
							)
				ELSE (
						SELECT pm.MergePatientName
						FROM PatientMerge pm WITH (NOLOCK)
						WHERE pm.MergePatientID = pa.MergePatientId
						)
				END AS MergePatientName
			,pa.MergePatientId
			,CASE 
				WHEN at.EventCode = 'R01'
					THEN 'Incomplete Assessment -' + (
							SELECT QuestionaireName
							FROM Questionaire
							WHERE QuestionaireId = pa.AssessmentID
							)
				WHEN at.EventTypeID = @i_Eventtype
					THEN CASE 
							WHEN pen.isAssigned = 1
								THEN 'Reassigned'
							ELSE 'Removed'
							END
				WHEN at.EventDescription IN ('Deceased','Not Deceased')
					THEN at.EventDescription
				WHEN at.EventCode = 'IA'
					THEN (
							SELECT QuestionaireName + ' has been Invalidated.'
							FROM Questionaire
							WHERE QuestionaireId = pa.AssessmentID
							)
				ELSE  
					 at.EventDescription
				END AS EventDescription,
			CASE 
				WHEN pde.IsMerged IS NULL
					THEN 'Initiated'
				ELSE 'Completed'
			END MergeStatus
			,DBO.ufn_GetProviderName(pa.CreatedByUserId) AS AssisgnedByName
			,CASE 
				WHEN pa.ProgramID IS NOT NULL
					AND IsInternal = 1
					AND NOT EXISTS (
						SELECT 1
						FROM PatientEvent pe1 WITH (NOLOCK)
						INNER JOIN PatientEventNotification pen1 WITH (NOLOCK) 
							ON pe1.PatientEventId = pen1.PatientEventId
						WHERE ISNULL(pen1.IsMerged, 0) = 0
							AND pe1.MergePatientId = pa.PatientId
						)
					THEN (
							SELECT PatientProgramID
							FROM PatientProgram pp WITH (NOLOCK)
							INNER JOIN Program p 
								ON p.ProgramId = pp.ProgramID
								AND pp.PatientID = pa.PatientId
								AND pp.StatusCode = 'P'
								AND p.Programid = pa.ProgramID
							)
				ELSE NULL
			 END PatientProgramID
			,p.ProgramName
			,pa.ProgramId
			,CASE P.StatusCode
				WHEN 'A' 
					THEN 1
				WHEN 'I' 
					THEN 0
				ELSE ''
			 END AS ProgramStatus
			,COUNT(1) OVER () [Count]
		FROM PatientEventNotification pde WITH (NOLOCK)
		INNER JOIN ProviderEventNotification pen WITH (NOLOCK) 
			ON pen.PatientEventNotificationID = pde.PatientEventNotificationID
		INNER JOIN PatientEvent pa WITH (NOLOCK) 
			ON pde.PatientEventID = pa.PatientEventId
		INNER JOIN EventType at WITH (NOLOCK) 
			ON at.EventTypeId = pde.EventTypeId
		LEFT JOIN Program p WITH (NOLOCK) 
			ON p.ProgramId = pa.ProgramID
		INNER JOIN @VisitType vt
			ON vt.VisitType = ISNULL(pde.VisitType, '')
		WHERE pen.IsRead = 0
			AND pen.ProviderID = @i_AppUserId
		ORDER BY pde.EventDate DESC OFFSET(@i_StartRowIndex - 1) * @i_EndRowIndex ROWS
		FETCH NEXT @i_EndRowIndex ROWS ONLY
	END

	IF @c_ProcessType = 'G'
	BEGIN
		DECLARE @i_EventCnt INT
			,@v_SQL NVARCHAR(MAX)
			,@v_WhereClause NVARCHAR(MAX)
			,@v_JoinClause NVARCHAR(MAX)
			,@v_CntSQL NVARCHAR(MAX)
			,@v_OrderByClause NVARCHAR(MAX)
			,@i_FacilityCnt INT
		DECLARE @v_paramdef NVARCHAR(MAX) = '@i_AppUserId KEYID' + CHAR(13) + CHAR(10)
										  + ',@i_StartRowIndex INT' + CHAR(13) + CHAR(10)
										  + ',@i_EndRowIndex INT' + CHAR(13) + CHAR(10)
										  + ',@c_ProcessType CHAR(1)' + CHAR(13) + CHAR(10)
										  + ',@d_FromDate DATE' + CHAR(13) + CHAR(10)
										  + ',@d_ToDate DATE' + CHAR(13) + CHAR(10)
										  + ',@b_Status BIT' + CHAR(13) + CHAR(10) 
										  + ',@i_PatientId INT' + CHAR(13) + CHAR(10)

		SET @v_WhereClause  = 'INNER JOIN @VisitType vt' + CHAR(13) + CHAR(10) 
							+ 'ON vt.VisitType = ISNULL(pde.VisitType, '''')' + CHAR(13) + CHAR(10) 
							+ 'WHERE pen.ProviderID = @i_AppUserId' + CHAR(13) + CHAR(10)
		
		IF @d_FromDate IS NOT NULL
			AND @d_ToDate IS NOT NULL
		BEGIN
			SET @v_WhereClause = @v_WhereClause + '	AND CONVERT(DATE, pde.EventDate) BETWEEN @d_FromDate AND @d_ToDate' + CHAR(13) + CHAR(10) 
		END

		IF @i_PatientId IS NOT NULL
		BEGIN
			SET @v_WhereClause = @v_WhereClause + '	AND pa.PatientId = @i_PatientId' + CHAR(13) + CHAR(10) 
		END

		IF @b_Status IS NOT NULL
		BEGIN
			SET @v_WhereClause = @v_WhereClause + '	AND pen.IsRead = @b_Status' + CHAR(13) + CHAR(10) 
		END


		SELECT @i_EventCnt = COUNT(1)
		FROM @tblEventtype

		IF @i_EventCnt > 0
		BEGIN
			SELECT t.tKeyId, e.EventCode
			INTO #Evnt
			FROM @tblEventtype t
			INNER JOIN EventType e 
				ON t.tKeyId = e.EventTypeID
			
			SET @v_JoinClause   = CHAR(13) + CHAR(10) 
								+ 'INNER JOIN #Evnt e' + CHAR(13) + CHAR(10) 
								+ '	ON e.tKeyId = pde.EventTypeID' + CHAR(13) + CHAR(10) 
								+ '	AND ((IsMerged IS NULL AND EventCode  = ''A40'') OR EventCode ! = ''A40'')' + CHAR(13) + CHAR(10) 
		END

		SELECT @i_FacilityCnt = COUNT(1)
		FROM @tblFacility

		IF @i_FacilityCnt > 0
		BEGIN
			SELECT *
			INTO #Facility
			FROM @tblFacility

			SET @v_JoinClause = CHAR(13) + CHAR(10) 
							  + 'INNER JOIN #Facility f' + CHAR(13) + CHAR(10) 
							  + '	ON f.tKeyId = pa.FacilityId' + CHAR(13) + CHAR(10) 
		END

		CREATE TABLE #eve (
			PatientEventNotificationId INT
			,PatientEventId INT
			,PatientID INT
			,MergePatientId INT
			,EventDate DATE
			,EventTypeId INT
			,IsRead BIT
			,IsMerged BIT
			,ProgramID INT
			,IsInternal BIT
			,CreatedByUserId INT
			,AssessmentID INT
			,isAssigned BIT
			,ProviderID INT
			,[Count] INT
			)

		SET @v_SQL  = 'DECLARE @VisitType TABLE (VisitType CHAR(1))' + CHAR(13) + CHAR(10) 
					+ 'INSERT INTO @VisitType' + CHAR(13) + CHAR(10) 
					+ 'SELECT ''E'' UNION ALL ' + CHAR(13) + CHAR(10) 
					+ 'SELECT '''' ' + CHAR(13) + CHAR(10) 
					+ '' + CHAR(13) + CHAR(10) 
					+ 'INSERT INTO #eve' + CHAR(13) + CHAR(10) 
					+ 'SELECT pde.PatientEventNotificationId' + CHAR(13) + CHAR(10) 
					+ '		,pde.PatientEventId' + CHAR(13) + CHAR(10) 
					+ '		,pa.PatientID AS PatientId' + CHAR(13) + CHAR(10) 
					+ '		,pa.MergePatientId' + CHAR(13) + CHAR(10) 
					+ '		,pde.EventDate' + CHAR(13) + CHAR(10) 
					+ '		,pde.EventTypeId' + CHAR(13) + CHAR(10) 
					+ '		,pen.IsRead' + CHAR(13) + CHAR(10) 
					+ '		,pde.IsMerged' + CHAR(13) + CHAR(10) 
					+ '		,pa.ProgramID' + CHAR(13) + CHAR(10) 
					+ '		,IsInternal' + CHAR(13) + CHAR(10) 
					+ '		,pa.CreatedByUserId' + CHAR(13) + CHAR(10) 
					+ '		,pa.AssessmentID' + CHAR(13) + CHAR(10) 
					+ '		,pen.isAssigned' + CHAR(13) + CHAR(10) 
					+ '		,pa.FacilityId' + CHAR(13) + CHAR(10) 
					+ '		,COUNT(1) OVER () [Count]' + CHAR(13) + CHAR(10) 
					+ 'FROM PatientEventNotification pde WITH (NOLOCK)' + CHAR(13) + CHAR(10) 
					+ 'INNER JOIN ProviderEventNotification pen WITH (NOLOCK) ' + CHAR(13) + CHAR(10) 
					+ '	ON pen.PatientEventNotificationID = pde.PatientEventNotificationID' + CHAR(13) + CHAR(10) 
					+ 'INNER JOIN PatientEvent pa WITH (NOLOCK) ' + CHAR(13) + CHAR(10)
					+ '	ON pde.PatientEventID = pa.PatientEventId' + CHAR(13) + CHAR(10) 
		
		SET @v_OrderByClause = 'ORDER BY pde.EventDate DESC OFFSET(@i_StartRowIndex - 1) * @i_EndRowIndex ROWS FETCH NEXT @i_EndRowIndex ROWS ONLY' + CHAR(13) + CHAR(10)
		SET @v_SQL = ISNULL(@v_SQL, '') + ISNULL(@v_JoinClause, '') + ISNULL(@v_WhereClause, '') + ISNULL(@v_OrderByClause, '')
		SET @v_CntSQL = ISNULL(@v_CntSQL, '') + ISNULL(@v_JoinClause, '') + ISNULL(@v_WhereClause, '')

		EXEC SP_EXECUTESQL @v_SQL
			,@v_paramdef
			,@i_AppUserId = @i_AppUserId
			,@i_StartRowIndex = @i_StartRowIndex
			,@i_EndRowIndex = @i_EndRowIndex
			,@c_ProcessType = @c_ProcessType
			,@d_FromDate = @d_FromDate
			,@d_ToDate = @d_ToDate
			,@b_Status = @b_Status
			,@i_PatientId = @i_PatientId

		SELECT DISTINCT pe.MergePatientId PatientId
		INTO #TaskReconciliationOff
		FROM PatientEvent pe WITH (NOLOCK)
		INNER JOIN PatientEventNotification pen WITH (NOLOCK) 
			ON pe.PatientEventId = pen.PatientEventId
		INNER JOIN #eve t 
			ON t.PatientID = pe.MergePatientId
		WHERE ISNULL(pen.IsMerged, 0) = 0

		SELECT cte_PN.PatientEventNotificationId
			,cte_PN.PatientEventId
			,cte_PN.PatientId
			,CASE 
				WHEN cte_PN.IsMerged IS NULL
					THEN (
							SELECT CONCAT (p.LastName + ', ', p.FirstName + '. ', p.MiddleName + ' ', p.NameSuffix) AS FullName
							FROM Patient p WITH (NOLOCK)
							WHERE p.PatientID = cte_PN.PatientId
							)
				ELSE (
						SELECT pm.PatientName
						FROM PatientMerge pm WITH (NOLOCK)
						WHERE pm.PatientEventId = cte_PN.PatientEventId
						)
			 END AS PatientName
			,CASE 
				WHEN IsMerged IS NULL
					THEN (
							SELECT CONCAT (p.LastName + ', ', p.FirstName + '. ', p.MiddleName + ' ', p.NameSuffix) AS FullName
							FROM Patient p WITH (NOLOCK)
							WHERE p.PatientID = cte_PN.MergePatientId
							)
				ELSE (
						SELECT pm.MergePatientName
						FROM PatientMerge pm WITH (NOLOCK)
						WHERE pm.MergePatientID = cte_PN.MergePatientId
						)
			 END AS MergePatientName
			,cte_PN.MergePatientId
			,cte_PN.EventDate
			,CASE 
				WHEN at.EventCode = 'R01'
					THEN 'Incomplete Assessment -' + (
							SELECT QuestionaireName
							FROM Questionaire WITH (NOLOCK)
							WHERE QuestionaireId = cte_PN.AssessmentID
							)
				WHEN at.EventTypeID = @i_Eventtype
					THEN CASE 
							WHEN cte_PN.isAssigned = 1
								THEN 'reassigned'
							ELSE 'removed'
						 END
				WHEN at.EventDescription IN ('Deceased', 'Not Deceased'
						)
					THEN at.EventDescription
				WHEN at.EventCode = 'IA'
					THEN (
							SELECT QuestionaireName + ' has been Invalidated.'
							FROM Questionaire
							WHERE QuestionaireId = cte_PN.AssessmentID
							)
				ELSE    at.EventDescription
			 END AS EventDescription,
			 CASE 
				WHEN cte_PN.IsMerged IS NULL
					THEN 'Initiated'
				ELSE 'Completed'
			END MergeStatus
			,DBO.ufn_GetProviderName(cte_PN.ProviderID) Facility
			,CASE 
				WHEN cte_PN.IsRead = 0
					THEN 'Pending'
				ELSE 'Complete'
			 END AS ReadStatus
			,DBO.ufn_GetProviderName(cte_PN.CreatedByUserId) AS AssisgnedByName
			,CASE 
				WHEN cte_PN.ProgramID IS NOT NULL
					AND cte_PN.IsInternal = 1
					AND t.PatientId IS NULL /*IF patient has merge should not allow for task reconciliation*/
					THEN PP.PatientProgramID
				ELSE NULL
			 END PatientProgramID
			,CASE 
				WHEN cte_PN.ProgramID IS NOT NULL
					THEN p.ProgramName
				ELSE NULL
			 END ProgramName
			,cte_PN.ProgramId
			,CASE P.StatusCode
				WHEN 'A'
					THEN 1
				WHEN 'I'
					THEN 0
				ELSE ''
			 END AS ProgramStatus
			,[Count]
		FROM #eve cte_PN
		INNER JOIN EventType at WITH (NOLOCK) 
			ON at.EventTypeId = cte_PN.EventTypeId
		LEFT JOIN Program p WITH (NOLOCK) 
			ON p.ProgramId = cte_PN.ProgramID
		LEFT JOIN PatientProgram pp WITH (NOLOCK) 
			ON pp.PatientID = cte_PN.PatientId
			AND pp.StatusCode = 'P'
			AND p.Programid = pp.ProgramID
			AND p.Programid = cte_PN.ProgramID
		LEFT JOIN #TaskReconciliationOff t 
			ON t.PatientId = cte_pn.PatientID
	END
END TRY

BEGIN CATCH
	----------------------------------------------------------------------------------------------------------           
	-- Handle exception            
	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorLine
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH