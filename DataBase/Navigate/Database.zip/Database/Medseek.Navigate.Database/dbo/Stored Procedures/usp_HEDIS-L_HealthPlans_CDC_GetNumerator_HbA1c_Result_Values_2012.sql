﻿/*---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_HEDIS-L_HealthPlans_CDC_GetNumerator_HbA1c_Result_Values_2012]
Description   : This proc is used to populating the configuerd numerator value
Created By    :   
Created Date  : 
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY	DESCRIPTION  
24/09/2015  NagaSiva Added parameter @ECTTableName and modified code to optimize performance Navi-4455 
08/12/2015  Srinivas Added parameter Sniffing to avoid unnecessary compilations, and reducing the number of ad-hoc queries in the plan cache
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_HEDIS-L_HealthPlans_CDC_GetNumerator_HbA1c_Result_Values_2012] (
	@PopulationDefinitionID INT
	,@MetricID INT
	,@Num_Months_Prior INT = 12
	,@Num_Months_After INT = 0
	,@ECTCodeVersion_Year INT = 2012
	,@ECTCodeStatus VARCHAR(1) = 'A'
	,@AnchorDate_Year INT = 2012
	,@AnchorDate_Month VARCHAR(2) = 12
	,@AnchorDate_Day VARCHAR(2) = 31
	,@ReportType CHAR(1) = 'P' --S For Strategic Companion,P Population
	,@ECTTableName VARCHAR(20)='CDC-D'
	)
AS
BEGIN
SET NOCOUNT ON
/************************************************************ INPUT PARAMETERS ************************************************************

	 @PopulationDefinitionID = Handle to the selected Population of Patients from which the Eligible Population of Patients of the Numerator
							   are to be constructed.

	 @Num_Months_Prior = Number of Months Before the Anchor Date from which Eligible Population of Patients with desired Encounter Claims
						 is to be constructed.

	 @Num_Months_After = Number of Months After the Anchor Date from which Eligible Population of Patients with desired Encounter Claims
						 is to be constructed.

	 @ECTCodeVersion_Year = Code Version Year from which valid HEDIS-associated ECT and Drug Codes during the Measurement Period that are
						    retrieved to identify Patients for inclusion in the Eligible Population of Patients.

	 @ECTCodeStatus = Status of valid HEDIS-associated ECT and Drug Codes during the Measurement Period that are retrieved to identify Patients
					  for inclusion in the Eligible Population of Patients during the Measurement Period.
					  Examples = 1 (for 'Enabled') or 0 (for 'No').

	 *********************************************************************************************************************************************/
/* Retrieves Lab Test Values of Patients with Performed Lab Tests with LOINC Codes during the Measurement Period. */
DECLARE @v_DenominatorType VARCHAR(1)
	,@i_ManagedPopulationID INT
	,@DateKey VARCHAR(10)
	,@vc_tableName VARCHAR(50)='##NrPatientValue'
	,@vc_Sql VARCHAR(MAX)
	,@param_PopulationDefinitionID INT
	,@param_MetricID INT
	,@param_Num_Months_Prior INT 
	,@param_Num_Months_After INT 
	,@param_ECTCodeVersion_Year INT
	,@param_ECTCodeStatus VARCHAR(1) 
	,@param_AnchorDate_Year INT 
	,@param_AnchorDate_Month VARCHAR(2)
	,@param_AnchorDate_Day VARCHAR(2)
	,@param_ReportType CHAR(1)  
	,@param_ECTTableName VARCHAR(20)

	SET @param_PopulationDefinitionID = @PopulationDefinitionID
	SET @param_MetricID = @MetricID
	SET @param_Num_Months_Prior = @Num_Months_Prior
	SET @param_Num_Months_After = @Num_Months_After
	SET @param_ECTCodeVersion_Year = @ECTCodeVersion_Year
	SET @param_ECTCodeStatus = @ECTCodeStatus
	SET @param_AnchorDate_Year = @AnchorDate_Year
	SET @param_AnchorDate_Month = @AnchorDate_Month
	SET @param_AnchorDate_Day = @AnchorDate_Day
	SET @param_ReportType = @ReportType
	SET @param_ECTTableName = @ECTTableName


SELECT @v_DenominatorType = m.DenominatorType
	,@i_ManagedPopulationID = m.ManagedPopulationID
FROM Metric m
WHERE m.MetricId = @param_MetricID

CREATE TABLE #PDNR (
	PatientID INT
	,[Value] DECIMAL(10, 2)
	,ValueDate DATE
	,IsIndicator BIT
	)

SET @DateKey = CONVERT(VARCHAR(10), @param_AnchorDate_Year) + CONVERT(VARCHAR(10),@param_AnchorDate_Month) + CONVERT(VARCHAR(10),@param_AnchorDate_Day)

SELECT [ECTCode] INTO #Loinc
		FROM dbo.ufn_HEDIS_GetECTCodeInfo_ByTableName(@param_ECTTableName, @param_ECTCodeVersion_Year, @param_ECTCodeStatus)
		WHERE [ECTHedisCodeTypeCode] = 'LOINC'
IF @v_DenominatorType = 'M'
	AND @i_ManagedPopulationID IS NOT NULL
BEGIN
	INSERT INTO #PDNR
	SELECT DISTINCT pm.[PatientID]
		,[MeasureValueNumeric] AS 'Value'
		,[DateTaken] AS 'ValueDate'
		,0 AS 'IsIndicator'
	FROM [dbo].[PatientMeasure] pm
		INNER JOIN [dbo].[PopulationDefinitionPatients] p		
			ON p.[PatientID] = pm.[PatientID]
		INNER JOIN [dbo].[PopulationDefinitionPatientAnchorDate] pa
			ON pa.[PopulationDefinitionPatientID] = p.[PopulationDefinitionPatientID]	
		INNER JOIN PatientProgram pp WITH(nolock)
		    ON pp.PatientID = p.PatientID	
		INNER JOIN PopulationDefinitionPatientAnchorDate pdpa ON pdpa.PopulationDefinitionPatientID = p.PopulationDefinitionPatientID
		INNER JOIN [dbo].[Measure] m
			ON m.[MeasureId] = pm.[MeasureId]
		INNER JOIN [dbo].[CodeSetLOINC] cod_loinc
			ON cod_loinc.[LOINCCodeID] = pm.[LOINCCodeID]
		INNER JOIN #Loinc lnc ON lnc.ECTCode = cod_loinc.LoincCode
		WHERE (
				pm.[DateTaken] BETWEEN (DATEADD(YYYY, - @param_Num_Months_Prior, DATEADD(YYYY, 0, pdpa.OutPutAnchorDate)))
					AND (DATEADD(YYYY, @param_Num_Months_After, DATEADD(YYYY, 0, pdpa.OutPutAnchorDate)))
				)
		  AND P.PopulationDefinitionID = @param_PopulationDefinitionID
		  AND pp.ProgramID = @i_ManagedPopulationID
		  AND pdpa.DateKey =@DateKey
		  AND pdpa.OutPutAnchorDate  = CASE 
						WHEN pdpa.OutPutAnchorDate BETWEEN DATEADD(dd, - (DAY(PP.EnrollmentStartDate) - 1), PP.EnrollmentStartDate)
								AND CASE 
										WHEN YEAR(ISNULL(PP.EnrollmentEndDate, '9999-12-31')) = 9999
											THEN ISNULL(PP.EnrollmentEndDate, '9999-12-31')
										ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, PP.EnrollmentEndDate) + 1, 0))
										END
							THEN pdpa.OutPutAnchorDate
						ELSE NULL
						END 
	ORDER BY [PatientID]
		,[DateTaken]

		
END
ELSE
BEGIN
	INSERT INTO #PDNR
	SELECT DISTINCT pm.[PatientID]
		,[MeasureValueNumeric] AS 'Value'
		,[DateTaken] AS 'ValueDate'
		,0 AS 'IsIndicator'
	
		FROM [dbo].[PatientMeasure] pm
		INNER JOIN [dbo].[PopulationDefinitionPatients] p ON p.[PatientID] = pm.[PatientID]
		INNER JOIN PopulationDefinitionPatientAnchorDate pdpa ON pdpa.PopulationDefinitionPatientID = p.PopulationDefinitionPatientID
		INNER JOIN [dbo].[CodeSetLOINC] cod_loinc ON cod_loinc.[LOINCCodeID] = pm.[LOINCCodeID]
		INNER JOIN #loinc lnc
					on lnc.ECTCode = cod_loinc.LoincCode
		WHERE (
				pm.[DateTaken] BETWEEN (DATEADD(YYYY, - @param_Num_Months_Prior, DATEADD(YYYY, 0, pdpa.OutPutAnchorDate)))
					AND (DATEADD(YYYY, @param_Num_Months_After, DATEADD(YYYY, 0, pdpa.OutPutAnchorDate)))
				)
			AND P.PopulationDefinitionID = @param_PopulationDefinitionID
			AND pdpa.DateKey = @DateKey
	ORDER BY [PatientID]
		,[DateTaken]
END

	
IF EXISTS(SELECT 1 FROM tempdb.dbo.sysobjects WHERE Name =@vc_tableName+'_'+@datekey)
	BEGIN 
	    
		SET @vc_Sql =' DELETE FROM ' +@vc_tableName+'_'+@datekey+ ' WHERE Datekey ='+@datekey+' AND MetricId ='+CAST(@param_MetricID AS VARCHAR)
			EXEC(@vc_Sql)		
		SET	@vc_Sql= 'INSERT INTO '+@vc_tableName+'_'+@datekey+'(MetricID,PatientID,Value,ValueDate,IsIndicator,DateKey)
					  SELECT '+CAST(@param_MetricID AS VARCHAR)+' ,PatientID,Value,ValueDate,IsIndicator,'+@DateKey +' FROM #PDNR'
		--PRINT(@vc_SQL)
		EXEC(@vc_Sql)
	END
	ELSE
	BEGIN
		SET @vc_Sql ='SELECT '+CAST(@param_MetricID AS VARCHAR)+' AS MetricId,PatientID,Value,ValueDate,IsIndicator,'+@DateKey + 'AS DateKey INTO '+@vc_tableName+'_'+@datekey+' FROM #PDNR'
	
		--PRINT(@vc_Sql)
		EXEC(@vc_Sql)
	END
	
DROP TABLE #Loinc

DROP TABLE #PDNR
END
