﻿/*             
------------------------------------------------------------------------------              
Procedure Name: usp_CareProviderDashBoard_MissedOpportunityByPatientID 4011,23  23,226585,NULL,23  
Description   : This procedure is used to get the open tasks select by patientID         
Created By    : Komala             
Created Date  : 28-Oct-2010              
------------------------------------------------------------------------------              
Log History   :               
DD-MM-YYYY  BY   DESCRIPTION   
08-Jan-2012 Nagababu Added @t_DueDate as Input parameter and implemented the functionality  
22-Feb-2013 Rathnam added #tblCareTeamMember temp table and join for getting the related provider tasks    
23-APR-2013 prathyusha modified the SP for filter the patients by TaskName.  
25-July-2013 Rathnam removed the condition and placed the program name  
20-August-2013 Santosh Converted the datetime columns TaskDueDate,MissedOppertunityDates to date
20-02-2014 Rathnam commented the assigned careprovider functionality as we need to get the tasks based on tasktypes 
04-Sep-2014 Rathnam restricted goal & Activity tasktypes
31-12-2014 Rathnam modified the code as per sprint 4 NAVI-2006 -- Missed Opportunity report & NAVI - 2072
30-03-2015 Rathnam modifed the proce to not to display the adhoc tasks as per 2611 impacts did not modify 
09-07-2015 Santosh modofied the SP as per NAVI-2529
26-11-2015 Yugandhar Modified the SP as per NAVI-3907
14-03-2016 Rathnam Modified sp as per NAVI-5312
30-03-2016 Yugandhar Modified the SP as per NAVI-5632
06-04-2016 Nagababu Modified the SP as per NAVI-5733
------------------------------------------------------------------------------   
[usp_CareProviderDashBoard_MissedOpprtunityByPatientID]  
*/
CREATE PROCEDURE [dbo].[usp_CareProviderDashBoard_MissedOpportunityByPatientID] (
	@i_AppUserId KEYID,
	@i_PatientUserID KEYID,
	@t_ProgramID TTYPEKEYID READONLY,
	@t_tblTaskTypeIDAndTypeID TBLTASKTYPEANDTYPEID READONLY ,
	@t_CareTeamMemberId TTYPEKEYID READONLY
	,@vc_Status VARCHAR(25)= 'Closed Incomplete'
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	-- Check if valid Application User ID is passed          
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.',
				17,
				1,
				@i_AppUserId
				)
	END
	
	CREATE TABLE #TotalMissedOpportunities (
		TaskID INT,
		PatientID INT,
		ProgramID INT
		,MissedopportunityDate DATETIME
		,typeid INT
		,tasktypeid INT
		,taskduedate DATETIME
		,Tasktypename varchar(500)
		)

	CREATE TABLE #Program (ProgramID INT)

	INSERT INTO #Program
	SELECT tKeyId
	FROM @t_ProgramID

	CREATE TABLE #TaskType (TaskTypeID INT, TaskTypeName Varchar(50))

	INSERT INTO #TaskType
	SELECT TaskTypeId,TaskTypeName FROM TaskType WHERE IsTask = 1

	DECLARE @v_Select VARCHAR(MAX) = '',
		@v_WhereClause VARCHAR(MAX) = '',
		@v_JoinClause VARCHAR(MAX) = '',
		@v_SQL VARCHAR(MAX) = ''

		
				SET @v_WhereClause = ' WHERE ts.TaskStatusText = '''+ @vc_Status  +'''
				AND t.PatientID = ' + CONVERT(VARCHAR(20), @i_PatientUserID)
			
	SET @v_Select = ' INSERT INTO #TotalMissedOpportunities  
          SELECT  
              t.PatientTaskID taskid  
              ,t.PatientID  
              ,t.ManagedPopulationID ProgramID 
			  ,DateTaken 
			  ,t.typeid
			  ,t.tasktypeid
			  ,t.DueDate taskduedate
			  ,ty.TaskTypeName
          FROM  
              PatientTask t WITH(NOLOCK)  
          INNER JOIN #Program pr  
              ON t.ManagedPopulationId = pr.ProgramID  
          INNER JOIN #TaskType ty  
              ON ty.TaskTypeID = t.TaskTypeId                
	      INNER JOIN TaskStatus ts WITH(NOLOCK)  
              ON ts.TaskStatusId = t.TaskStatusId   
          
              '

	IF EXISTS (
			SELECT 1
			FROM @t_tblTaskTypeIDAndTypeID
			)
	BEGIN
		SELECT ttt.TaskTypeID,
			ttt.TypeID
		INTO #tblTaskTypeIDAndTypeID
		FROM @t_tblTaskTypeIDAndTypeID ttt

		SET @v_JoinClause = @v_JoinClause + ' INNER JOIN #tblTaskTypeIDAndTypeID    
                               ON #tblTaskTypeIDAndTypeID.TaskTypeID = ty.TaskTypeID    
                               AND #tblTaskTypeIDAndTypeID.TypeID = t.TypeID    
                               '
	END

	SET @v_SQL = @v_Select + ISNULL(@v_JoinClause, '') + ISNULL(@v_WhereClause, '')


	EXEC (@v_SQL)

	SELECT t.TaskId,
		p.ProgramName,
		t.TaskTypeName AS TaskType,
		dbo.ufn_GetTypeNamesByTypeId(t.TaskTypeName, t.TypeID) AS TaskName,
		t.TaskDuedate,
		t.MissedopportunityDate,
		p.StatusCode AS ProgramStatus
	FROM #TotalMissedOpportunities t
	INNER JOIN Program p WITH (NOLOCK) ON p.ProgramId = t.ProgramID
	ORDER BY t.TaskDuedate DESC
END TRY 

BEGIN CATCH
	----------------------------------------------------------------------------------------------------------         
	-- Handle exception  
	IF (@@TRANCOUNT > 0)
	BEGIN
	ROLLBACK TRANSACTION;
	END

		DECLARE @ErrorNumber INT = ERROR_NUMBER();
		DECLARE @ErrorLine INT = ERROR_LINE();
		DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
		DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
		DECLARE @ErrorState INT = ERROR_STATE();
		DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

		INSERT INTO Audit_Errors (
			Userid
			,Source
			,Type
			,ErrorDate
			,[Message]
			,[Procedure]
			)
		SELECT @i_AppUserId
			,'Database'
			,@ErrorSeverity
			,GETDATE()
			,@ErrorMessage
			,@ErrorProcedure
END CATCH