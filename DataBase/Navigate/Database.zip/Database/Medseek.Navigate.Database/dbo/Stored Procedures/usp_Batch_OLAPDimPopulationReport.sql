﻿
/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_OLAPDimPopulationReport]1
Description   : This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Rathnam  
Created Date  : 15-Dec-2014
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
05-Jan-2015 NagaBabu Added a Parameter @vc_TableName and modified to conditional statements
06-Jan-2015 NagaBabu Removed the Parameter @vc_TableName and modified to conditional statements
05-Jan-2015 Nagasiva  assigned null value to  @i_AppUserId  Parameter to remove the hardcoded userid in cube execution package
11-Apr-2016 Nagababu Modified the logic as per NAVI-5691
01-Nov-2016 Yugandhar modified the sp as NAVI-6935
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_OLAPDimPopulationReport]
(
	@i_AppUserId KEYID=NULL
)
AS
BEGIN TRY
	SET NOCOUNT ON

	
		SELECT @i_AppUserId =MIN(Userid) FROM Users WITH(NOLOCK)

	
			IF OBJECT_ID('TEMPDB..##OLAP_DimAnchordate') IS NOT NULL
				DROP TABLE ##OLAP_DimAnchordate

			SELECT DateKey
				,convert(DATE, convert(VARCHAR(10), DateKey)) AS AnchorDate
			INTO ##OLAP_DimAnchordate
			FROM AnchorDate WITH(NOLOCK)
			

			IF OBJECT_ID('TEMPDB..##OLAP_DimReport') IS NOT NULL
				DROP TABLE ##OLAP_DimReport

			SELECT ReportID AS ReportKey
				,ReportName AS [Description]
			INTO ##OLAP_DimReport
			FROM Report pcc WITH(NOLOCK)
			WHERE pcc.StatusCode = 'A'
	
	
			IF OBJECT_ID('TEMPDB..##OLAP_DimProviderType') IS NOT NULL
				DROP TABLE ##OLAP_DimProviderType

			SELECT ProviderTypeCodeID AS TypeKey 
				,Description 
			INTO ##OLAP_DimProviderType
			FROM CodeSetProviderType WITH(NOLOCK)
		

	
			IF OBJECT_ID('TEMPDB..##OLAP_DimPatient') IS NOT NULL
				DROP TABLE ##OLAP_DimPatient

			SELECT DISTINCT PatientID AS PatientKey
				,ISNULL(FirstName + ' ','') + '' + ISNULL(LastName,'') AS FullName
				,ISNULL(MedicalRecordNumber, MemberID) MedicalRecordNumber
				,DateOfBirth
				,dbo.ufn_GetAgeByDOB(DateOfBirth) AS Age
				,Gender
				,PrimaryPhoneNumber AS PhoneNo
			INTO ##OLAP_DimPatient
			FROM Patient WITH(NOLOCK)
		
			
			IF OBJECT_ID('TEMPDB..##OLAP_DimPopulation') IS NOT NULL
				DROP TABLE ##OLAP_DimPopulation

			SELECT PopulationDefinitionID AS PopulationKey
				,PopulationDefinitionName AS Name
			INTO ##OLAP_DimPopulation	
			FROM PopulationDefinition WITH(NOLOCK)
			WHERE DefinitionType IN (
					'C'
					,'P'
					)


			IF OBJECT_ID('TEMPDB..##OLAP_DimMetric') IS NOT NULL
				DROP TABLE ##OLAP_DimMetric

			SELECT DISTINCT m.MetricId AS MetricKey
				,m.NAME
				,pd.DefinitionType AS MetricType
				,pd.NumeratorType
			INTO ##OLAP_DimMetric
			FROM Metric m WITH(NOLOCK)
			INNER JOIN PopulationDefinition pd WITH(NOLOCK)
				ON m.NumeratorID = pd.PopulationDefinitionID


			IF OBJECT_ID('TEMPDB..##OLAP_DimHealthPlan') IS NOT NULL
				DROP TABLE ##OLAP_DimHealthPlan

			SELECT InsuranceGroupID AS HealthPlanKey
				,GroupName AS Name
			INTO ##OLAP_DimHealthPlan
			FROM InsuranceGroup WITH(NOLOCK)
			WHERE NULLIF(GroupName,'') IS NOT NULL


			DECLARE @i_NoInsuranceGroupId INT
			SELECT @i_NoInsuranceGroupId = IG.InsuranceGroupId
			FROM InsuranceGroup IG
			WHERE IG.InternalID = '000'

			IF OBJECT_ID('TEMPDB..##OLAP_DimProduct') IS NOT NULL
				DROP TABLE ##OLAP_DimProduct
			
			CREATE TABLE ##OLAP_DimProduct
			(
				ProductKey INT IDENTITY(1,1) ,
				ProductCode CHAR(1) ,
				[Description] VARCHAR(50)
			) 

			INSERT INTO ##OLAP_DimProduct
			(
				ProductCode ,
				[Description]	
			)
			SELECT DISTINCT ProductType AS ProductCode
				,CASE 
					WHEN h.InsuranceGroupId = @i_NoInsuranceGroupId AND ProductType = 'N' 
						THEN 'No insurance info'
					WHEN ProductType = 'C'
						THEN 'Commercial'
					WHEN ProductType = 'M'
						THEN 'Medicare'
					WHEN ProductType = 'H'
						THEN 'HMO'
					WHEN ProductType = 'P'
						THEN 'PPO'
					END [Description]
			FROM InsuranceGroupplan h WITH(NOLOCK)
			WHERE ProductType IS NOT NULL


			IF OBJECT_ID('TEMPDB..##OLAP_DimProvider') IS NOT NULL
				DROP TABLE ##OLAP_DimProvider

			SELECT ProviderID AS ProviderKey
				,LTRIM(DBO.[ufn_GetProviderName](ProviderID)) FullName
				,ProviderTypeID AS TypeKey
				,NPINumber
				,TaxID_EIN_SSN AS TaxIDNumber
			INTO ##OLAP_DimProvider
			FROM [Provider] p WITH(NOLOCK) 
			LEFT JOIN CodeSetProviderType pt WITH(NOLOCK)
				ON p.ProviderTypeID = pt.ProviderTypeCodeID
			WHERE Description <> 'Administrator'
			AND LTRIM(DBO.[ufn_GetProviderName](ProviderID)) <> ''

	
			IF OBJECT_ID('TEMPDB..##OLAP_DimProgram') IS NOT NULL
				DROP TABLE ##OLAP_DimProgram

			SELECT DISTINCT p.ProgramId AS ProgramKey
				,p.ProgramName AS Name
			INTO ##OLAP_DimProgram
			FROM Program p WITH(NOLOCK)
		
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH

GO
