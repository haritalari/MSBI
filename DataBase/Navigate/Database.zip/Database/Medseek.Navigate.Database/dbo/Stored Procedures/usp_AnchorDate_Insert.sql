﻿

/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_AnchorDate_Insert]
Description   : This proc is used to insert Datekey after two full loads are complete.(Firstday of third week)
				This is done to ensure the reports have some data for the datekey being processed.
Created By    : Nagasiva  
Created Date  : 04-Feb-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION 
18-Feb-2015   :Gouri Added Last 3 years anchor dates insertion logic for cube automation.
23-Feb-2015   :Nagasiva added reportFrequency mapping with anchordate for all reports automation logic.
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_AnchorDate_Insert] -- 1
( 
	@i_AppUserId KeyId =NULL
)
AS
BEGIN TRY
	SET NOCOUNT ON

	
	      DECLARE @dt_TodayDate DATETIME
		  DECLARE @str_TodayDate VARCHAR(10)
		  DECLARE @dt_FirstDayofMonth DATETIME
		  DECLARE @dt_LastDayofMonth DATETIME
		  DECLARE @dt_LastMonthDate DATETIME
		  DECLARE @dt_LastMonthEndDate DATETIME
		  DECLARE @i_LastMonthDatekey INT
		  DECLARE @dt_CheckDate DATETIME
		  DECLARE @i_LatestDatekey INT
		  DECLARE @i_Id INT
		  DECLARE @i_CurrentWeekDay VARCHAR(20)
		  DECLARE @dt_DateKeySwitchoverDay DATE
		  DECLARE @d_StartDate DATE
	      DECLARE @d_EndDate DATE
		 
		SELECT @i_AppUserId = MIN(UserId) FROM Users
		
		
		DECLARE @FridayList TABLE (
			  ID INT IDENTITY(1, 1)
			  ,[Date] DATE
			  )
	     DECLARE @TodayList TABLE (
			  ID INT IDENTITY(1, 1)
			  ,[Date] DATE
			  )

		  SET @dt_TodayDate = GETDATE()
		  SET @str_TodayDate = CONVERT(VARCHAR(8), @dt_TodayDate, 126) + '01'
		  SET @dt_FirstDayofMonth = @str_TodayDate
		  SET @i_CurrentWeekDay = DATENAME(weekday, @dt_TodayDate)
		  --SELECT @dt_FirstDayofMonth

		  SET @dt_LastDayofMonth = DATEADD(d, - 1, DATEADD(m, 1, @str_TodayDate))

		  --SELECT @dt_LastDayofMonth			
		  WHILE @dt_FirstDayofMonth <= @dt_LastDayofMonth
		  BEGIN
			  IF DATENAME(weekday, @dt_FirstDayofMonth) = @i_CurrentWeekDay
			  BEGIN
				  INSERT INTO @TodayList
				  SELECT @dt_FirstDayofMonth
			  END
			  
			  IF DATENAME(weekday, @dt_FirstDayofMonth) = 'MONDAY'
			  BEGIN
				  INSERT INTO @FridayList
				  SELECT @dt_FirstDayofMonth
			  END

			  SET @dt_FirstDayofMonth = DATEADD(d, 1, @dt_FirstDayofMonth)
		  END


		  SELECT @dt_DateKeySwitchoverDay = [DATE]
			FROM @FridayList
			WHERE ID = 2
		  --SELECT * FROM @FridayList
		  SELECT
			  @i_Id = Id
		  FROM 
			 @TodayList
		  WHERE [DATE] = CAST(GETDATE() AS DATE)
		  --Select * from @FridayList
		  
		IF @i_Id = 2 
		   BEGIN	
				SET @i_Id = CASE WHEN @dt_TodayDate < @dt_DateKeySwitchoverDay THEN 1
								ELSE @i_Id
							END    		 
		   END
		   
		   IF @i_Id = 1
			  BEGIN
				  SET @dt_LastMonthDate = DATEADD(mm, - 2, GETDATE())
				  SET @dt_LastMonthEndDate = DATEADD(s, - 2, DATEADD(mm, DATEDIFF(m, 0, @dt_LastMonthDate) + 1, 0))
				  SET @i_LastMonthDatekey = CAST(CONVERT(VARCHAR(8), @dt_LastMonthEndDate, 112) AS INT)
				
				  IF NOT EXISTS(SELECT 1 FROM Anchordate WHERE Datekey = @i_LastMonthDatekey AND AnchorDate =CAST(@dt_LastMonthEndDate AS DATE))
				  
					INSERT INTO Anchordate
					   (DateKey,
					   AnchorDate,
					   CalendarQuarter,
					   CalendarSemester,
					   EnglishMonthName,
					   CalenderYear)
					SELECT 
					    @i_LastMonthDatekey,
					    CAST(@dt_LastMonthEndDate AS DATE),
					    CASE WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 1 AND 3 THEN 'Quarter1'
							WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 4 AND 6 THEN  'Quarter2'
							WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 7 AND 9 THEN  'Quarter3'
							WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 10 AND 12 THEN  'Quarter4'
					    END,
						CASE WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 1 AND 6 THEN 'Semister1'
							WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 7 AND 12 THEN 'Semister2'
							END,
						DATENAME(MONTH,@dt_LastMonthEndDate),
						DATENAME(YEAR,@dt_LastMonthEndDate)
					
				
			  END
			 
	      ELSE
			  BEGIN
				  SET @dt_LastMonthDate = DATEADD(mm, - 1, GETDATE())
				  SET @dt_LastMonthEndDate = DATEADD(s, - 1, DATEADD(mm, DATEDIFF(m, 0, @dt_LastMonthDate) + 1, 0))
				  SET @i_LastMonthDatekey = CAST(CONVERT(VARCHAR(8), @dt_LastMonthEndDate, 112) AS INT)
				  	
				 IF NOT EXISTS(SELECT 1 FROM Anchordate WHERE Datekey = @i_LastMonthDatekey AND AnchorDate =CAST(@dt_LastMonthEndDate AS DATE) )
					   INSERT INTO Anchordate
					   (DateKey,
					   AnchorDate,
					   CalendarQuarter,
					   CalendarSemester,
					   EnglishMonthName,
					   CalenderYear)
					   SELECT 
					      @i_LastMonthDatekey,
					       CAST(@dt_LastMonthEndDate AS DATE),
					      CASE WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 1 AND 3 THEN 'Quarter1'
							   WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 4 AND 6 THEN  'Quarter2'
							   WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 7 AND 9 THEN  'Quarter3'
							   WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 10 AND 12 THEN  'Quarter4'
					       END,
						   CASE WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 1 AND 6 THEN 'Semister1'
							    WHEN DATEPART(MONTH,@dt_LastMonthEndDate) BETWEEN 7 AND 12 THEN 'Semister2'
							 END,
						   DATENAME(MONTH,@dt_LastMonthEndDate),
						   DATENAME(YEAR,@dt_LastMonthEndDate)
				END

	
	 SELECT @i_LatestDatekey = MAX(Datekey)  FROM AnchorDate
	 -------------
	

	SELECT @d_EndDate = MAX(AnchorDate)
	FROM AnchorDate
	IF @d_EndDate IS NULL
	BEGIN
	SET @d_EndDate = CONVERT(DATE,GETDATE())
	END

	SET @d_StartDate = DATEADD(yy, - 2, @d_EndDate)

	SELECT @d_EndDate = DATEADD(day, 0 - day(dateadd(month, 1, @d_EndDate)), dateadd(month, 1, @d_EndDate))

	WHILE @d_StartDate <= @d_EndDate
	BEGIN
		SET @d_StartDate = DATEADD(day, 0 - day(dateadd(month, 1, @d_StartDate)), dateadd(month, 1, @d_StartDate))

		INSERT INTO AnchorDate (
			datekey
			,anchordate
			,calendarquarter
			,calendarsemester
			,englishmonthname
			,calenderyear
			)
		SELECT Cast(CONVERT(VARCHAR(8), convert(DATE, @d_StartDate), 112) AS INT)
			,Cast(@d_StartDate AS DATE)
			,CASE 
				WHEN Datepart(month, @d_StartDate) BETWEEN 1
						AND 3
					THEN 'Quarter1'
				WHEN Datepart(month, @d_StartDate) BETWEEN 4
						AND 6
					THEN 'Quarter2'
				WHEN Datepart(month, @d_StartDate) BETWEEN 7
						AND 9
					THEN 'Quarter3'
				WHEN Datepart(month, @d_StartDate) BETWEEN 10
						AND 12
					THEN 'Quarter4'
				END
			,CASE 
				WHEN Datepart(month, @d_StartDate) BETWEEN 1
						AND 6
					THEN 'Semister1'
				WHEN Datepart(month, @d_StartDate) BETWEEN 7
						AND 12
					THEN 'Semister2'
				END
			,Datename(month, @d_StartDate)
			,Datename(year, @d_StartDate)
		WHERE NOT EXISTS (
				SELECT 1
				FROM AnchorDate a
				WHERE a.AnchorDate = Cast(@d_StartDate AS DATE)
				)

		SET @d_StartDate = DATEADD(dd, 1, @d_StartDate)
	END 
-----------------------Report Frequency mapping with dates for all reports---------


INSERT INTO Reportfrequencydate (
		ReportFrequencyId
		,AnchorDate
		,IsETLCompleted
		)
SELECT ReportFrequencyId, AnchorDate.DateKey,0 FROM ReportFrequency
CROSS JOIN AnchorDate
where not exists (select 1 from Reportfrequencydate rfd
where rfd.ReportFrequencyId = ReportFrequency.ReportFrequencyId
and AnchorDate.DateKey = rfd.AnchorDate
)



		
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH