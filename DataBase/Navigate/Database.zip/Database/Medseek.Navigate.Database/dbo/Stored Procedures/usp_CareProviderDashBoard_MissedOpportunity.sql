﻿
/*
---------------------------------------------------------------------------
Procedure Name: [dbo].[usp_CareProviderDashBoard_MissedOpportunity] 
Description   : This procedure is to be used to get the missed oportunity data.

----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
02-Jan-2015 Nagasiva Added 2012 pagination feature and SP_EXECUTESQL instead of EXEC dynamic execution command.
30-03-2015 Rathnam modifed the proce to not to display the adhoc tasks as per 2611 impacts did not modify
26-11-2015 Yugandhar Modified the SP as per NAVI-3907 
14-03-2016 Rathnam Modified sp as per NAVI-5312
09-Sep-2016 Nagababu Modified the logic as per NAVI-6724
-----------------------------------------------------------------------------------------
*/  
CREATE PROCEDURE [dbo].[usp_CareProviderDashBoard_MissedOpportunity] 
	(
	 @i_AppUserId KEYID
	,@t_ProgramID TTYPEKEYID READONLY
	,@t_tblTaskTypeIDAndTypeID TBLTASKTYPEANDTYPEID READONLY 
	,@t_CareTeamMemberId TTYPEKEYID READONLY
	,@i_StartRowIndex KeyId
	,@i_EndRowIndex KeyId
	,@v_SortType VARCHAR(5)
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	-- Check if valid Application User ID is passed          
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END

	CREATE TABLE #TotalMissedOpprtunities (
		PatientID INT
		,FullName VARCHAR(1000)
		,DisEnrollCnt INT
		,InCompleteCnt INT
		)

	CREATE TABLE #PatientTask (
		PatientId INT
		,ProgramId INT
		,cnt INT 
		
		)

	CREATE TABLE #MissedOpprtunitiesCnt (TaskCount INT)

	CREATE TABLE #Program (ProgramID INT)

	INSERT INTO #Program
	SELECT tKeyId
	FROM @t_ProgramID

	CREATE TABLE #TaskType (
		TaskTypeID INT
		)

	INSERT INTO #TaskType
	SELECT tt.TaskTypeId
	FROM TaskType tt WHERE tt.IsTask = 1

	IF (@v_SortType IS NULL)
	BEGIN
		SET @v_SortType = ''
	END

	DECLARE @v_Select NVARCHAR(MAX) = ''
		,@v_WhereClause NVARCHAR(MAX) = ''
		,@v_JoinClause NVARCHAR(MAX) = ''
		,@v_SQL NVARCHAR(MAX) = ''
		,@v_CntSQL NVARCHAR(MAX) = ''
		,@v_ParamDefintion NVARCHAR(MAX)
		,@v_PatientTask NVARCHAR(MAX)
		,@i_Patientcnt INT
		,@v_CntParamDefintion NVARCHAR(MAX)
		,@v_TaskParamDefintion NVARCHAR(MAX)
		,@i_DisenrollStatusID INT
		,@i_IncompleteStatusID INT

	SELECT @i_DisenrollStatusID = ts.TaskStatusId
	FROM TaskStatus ts
	WHERE ts.TaskStatusText = 'DisEnroll'

	SELECT @i_IncompleteStatusID = ts.TaskStatusId
	FROM TaskStatus ts
	WHERE ts.TaskStatusText = 'Closed Incomplete'

	SET @v_ParamDefintion = '   @i_AppUserId INT  
         ,@i_StartRowIndex INT   
         ,@i_EndRowIndex INT   
		 ,@i_DisenrollStatusID INT
		 ,@i_IncompleteStatusID INT
        '
	SET @v_CntParamDefintion = ' @i_AppUserId INT '
	SET @v_TaskParamDefintion = ' @i_AppUserId INT '
	SET @v_WhereClause = ' WHERE ts.TaskStatusText IN  (''Closed Incomplete''  , ''DisEnroll'')
	   '


	SET @v_Select = ' INSERT INTO #TotalMissedOpprtunities  
          SELECT    
               t.Patientid  
			  ,COALESCE(ISNULL(P.LastName , '''') + '', '' + ISNULL(P.FirstName , '''') + ''. '' + ISNULL(P.MiddleName , '''') + '''' + ISNULL(P.NameSuffix , '''') , '''') AS Fullname
              ,SUM(CASE WHEN t.TaskStatusId = @i_DisenrollStatusID THEN 1 ELSE 0 END) DisEnrollCnt
              ,SUM(CASE WHEN t.TaskStatusId = @i_IncompleteStatusID THEN 1 ELSE 0 END) InCompleteCnt 
          FROM  
              PatientTask t WITH(NOLOCK)  
		  INNER JOIN Patient P
		      ON P.Patientid = t.patientid	  
          INNER JOIN #Program pr  
              ON t.ManagedPopulationID = pr.ProgramID   
          INNER JOIN #TaskType ty  
              ON ty.TaskTypeID = t.TaskTypeId       
          INNER JOIN TaskStatus ts WITH(NOLOCK)  
              ON ts.TaskStatusId = t.TaskStatusId   
            
    
              '
	SET @v_PatientTask = ' INSERT INTO #PatientTask  
		SELECT   
		t.Patientid,  
		pr.Programid,  
		COUNT(1) cnt 
          FROM  
              PatientTask t WITH(NOLOCK)  
       INNER JOIN #TotalMissedOpprtunities tm  
       on t.PatientID = tm.PatientID  
          INNER JOIN #Program pr  
              ON t.ManagedPopulationID = pr.ProgramID  
          INNER JOIN #TaskType ty  
              ON ty.TaskTypeID = t.TaskTypeId       
          INNER JOIN TaskStatus ts WITH(NOLOCK)  
              ON ts.TaskStatusId = t.TaskStatusId   
            
    '
	SET @v_CntSQL = 'INSERT INTO #MissedOpprtunitiesCnt  
       SELECT   
       COUNT(DISTINCT t.PatientId)  
        FROM   
         PatientTask t WITH(NOLOCK)  
        INNER JOIN #Program pr  
         ON t.ManagedPopulationID = pr.ProgramID  
        INNER JOIN #TaskType ty  
         ON ty.TaskTypeID = t.TaskTypeId       
        INNER JOIN TaskStatus ts WITH(NOLOCK)  
         ON ts.TaskStatusId = t.TaskStatusId   
         '

	IF EXISTS (
			SELECT 1
			FROM @t_tblTaskTypeIDAndTypeID
			)
	BEGIN
		SELECT ttt.TaskTypeID
			,ttt.TypeID
		INTO #tblTaskTypeIDAndTypeID
		FROM @t_tblTaskTypeIDAndTypeID ttt

		SET @v_JoinClause = @v_JoinClause + ' INNER JOIN #tblTaskTypeIDAndTypeID    
                               ON #tblTaskTypeIDAndTypeID.TaskTypeID = ty.TaskTypeID    
                               AND #tblTaskTypeIDAndTypeID.TypeID = t.TypeID    
                               '
	END

	SET @v_SQL = @v_Select + ISNULL(@v_JoinClause, '') + ISNULL(@v_WhereClause, '') + ' GROUP BY t.PatientId,COALESCE(ISNULL(P.LastName , '''') + '', '' + ISNULL(P.FirstName , '''') + ''. '' + ISNULL(P.MiddleName , '''') + '''' + ISNULL(P.NameSuffix , '''') , '''') 
	ORDER BY fullname ' + @v_SortType + ' OFFSET (@i_StartRowIndex-1) * @i_EndRowIndex  ROWS  FETCH NEXT  @i_EndRowIndex  ROWS ONLY  '
	SET @v_CntSQL = @v_CntSQL + ISNULL(@v_JoinClause, '') + ISNULL(@v_WhereClause, '')
	SET @v_PatientTask = @v_PatientTask + ISNULL(@v_JoinClause, '') + ISNULL(@v_WhereClause, '') + '  GROUP BY t.Patientid,pr.Programid '
	
	
	EXEC SP_EXECUTESQL @v_SQL
		,@v_ParamDefintion
		,@i_DisenrollStatusID = @i_DisenrollStatusID
		,@i_IncompleteStatusID = @i_IncompleteStatusID
		,@i_AppUseriD = @i_AppUseriD
		,@i_StartRowIndex = @i_StartRowIndex
		,@i_EndRowIndex = @i_EndRowIndex
	
	EXEC SP_EXECUTESQL @v_CntSQL
		,@v_CntParamDefintion
		,@i_AppUseriD = @i_AppUseriD

	EXEC SP_EXECUTESQL @v_PatientTask
		,@v_TaskParamDefintion
		,@i_AppUseriD = @i_AppUseriD

	CREATE NONCLUSTERED INDEX [IX_#PatientTask] ON #PatientTask
	(
		PatientId ,ProgramID
	)

	SELECT TPT.PatientId ,
		TPT.ProgramID ,
		COUNT(DISTINCT PP.PatientProgramID) AS EnrolledCnt
	INTO #EnrolledCnt
	FROM #PatientTask TPT
	INNER JOIN PatientProgram PP WITH(NOLOCK) 
		ON PP.PatientID = TPT.PatientId
		AND PP.ProgramID = TPT.ProgramID
	WHERE PP.StatusCode NOT IN('P','D')
	GROUP BY TPT.PatientId ,
		TPT.ProgramID


	SELECT p.FullName AS PatientName
		,ISNULL(InCompleteCnt, 0) AS MissedOpportunity
		,ISNULL(DisEnrollCnt, 0) AS DisEnroll
		,p.PatientID
		,STUFF((
				SELECT ', ' + pr.ProgramName + case when pr.StatusCode = 'I' then + ' (Inactivated) ' else '' end + '(' + CONVERT(VARCHAR(5), TEC.EnrolledCnt) + ')'
				FROM #PatientTask pt
				INNER JOIN #Program tp ON pt.ProgramID = tp.ProgramID
				INNER JOIN #EnrolledCnt TEC ON TEC.PatientId = pt.PatientId
											AND TEC.ProgramID = TP.ProgramID
				INNER JOIN Program pr ON pr.ProgramId = tp.ProgramID
				WHERE pt.Patientid = p.PatientID
				FOR XML PATH('')
				), 1, 2, '') AS ManagedPopulation
		,STUFF((
				SELECT DISTINCT ', ' + ct.CareTeamName
				FROM #PatientTask pt
				INNER JOIN ProgramCareTeam pct WITH (NOLOCK) ON pt.ProgramID = pct.ProgramId
				INNER JOIN #Program tp ON pct.ProgramID = tp.ProgramID
				INNER JOIN CareTeam ct WITH (NOLOCK) ON ct.CareTeamId = pct.CareTeamId
				WHERE pt.PatientID = p.PatientID
				FOR XML PATH('')
				), 1, 2, '') AS CareTeamName
		,(
			SELECT MAX(DateOfService) EncounterDate
			FROM vw_PatientEncounter WITH (NOLOCK)
			WHERE vw_PatientEncounter.PatientID = p.PatientID
			) AS LastPCPVisit
	FROM  #TotalMissedOpprtunities p 
	
	SELECT @i_Patientcnt = TaskCount
	FROM #MissedOpprtunitiesCnt

	SELECT @i_Patientcnt AS TotalPatients

END TRY

BEGIN CATCH
select ERROR_MESSAGE()
	----------------------------------------------------------------------------------------------------------         
	-- Handle exception  
	IF (@@TRANCOUNT > 0)
	BEGIN
	ROLLBACK TRANSACTION;
	END

		DECLARE @ErrorNumber INT = ERROR_NUMBER();
		DECLARE @ErrorLine INT = ERROR_LINE();
		DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
		DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
		DECLARE @ErrorState INT = ERROR_STATE();
		DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

		INSERT INTO Audit_Errors (
			Userid
			,Source
			,Type
			,ErrorDate
			,[Message]
			,[Procedure]
			)
		SELECT @i_AppUserId
			,'Database'
			,@ErrorSeverity
			,GETDATE()
			,@ErrorMessage
			,@ErrorProcedure
END CATCH
GO
