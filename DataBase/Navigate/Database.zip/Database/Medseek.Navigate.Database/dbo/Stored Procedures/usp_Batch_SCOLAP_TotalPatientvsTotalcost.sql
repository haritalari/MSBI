﻿
/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_SCOLAP_TotalPatientvsTotalcost]
Description   : This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Nagasiva  
Created Date  : 23-Jan-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
13-Feb-2015 Nagasiva  assigned null value to  @i_AppUserId  Parameter to remove the hardcoded userid in cube execution package
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_SCOLAP_TotalPatientvsTotalcost] (
	@i_AppUserId KEYID =NULL
	
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	SELECT @i_AppUserId=MIN(UserId) FROM Users

	IF OBJECT_ID('TEMPDB..##OLAP_SC_FactDrCost') IS NOT NULL
		DROP TABLE ##OLAP_SC_FactDrCost;

	WITH CTE
	AS (
		SELECT DISTINCT dr.DrKey AS PopulationKey
			,dr.PatientKey AS PatientKey
			,igp.InsuranceGroupId AS HealthPlanKey
			,dr.DateKey AS DateKey
			,dr.ClaimAmt AS ClaimAmt
		FROM ##OLAP_SC_BridgePatientDr dr WITH (NOLOCK)
		INNER JOIN PatientInsurance pie WITH (NOLOCK) ON pie.PatientID = dr.PatientKey
		INNER JOIN PatientInsuranceBenefit pib WITH (NOLOCK) ON pib.PatientInsuranceID = pie.PatientInsuranceID
		INNER JOIN ReportFrequencyConfiguration rfc WITH (NOLOCK) ON rfc.drid = dr.DrKey
		INNER JOIN ReportFrequency rf WITH (NOLOCK) ON rf.ReportFrequencyId = rfc.ReportFrequencyId
		INNER JOIN InsuranceGroupPlan igp WITH (NOLOCK) ON igp.InsuranceGroupPlanId = pie.InsuranceGroupPlanId
		INNER JOIN ##OLAP_SC_DimAnchordate ad WITH (NOLOCK) ON ad.DateKey = dr.DateKey
		INNER JOIN ##OLAP_SC_DimHealthPlan HP
					ON HP.HealthPlanKey = igp.InsuranceGroupId
		INNER JOIN Report r WITH (NOLOCK) ON r.ReportId = rf.ReportID
		WHERE AnchorDate BETWEEN DATEADD(dd, - (DAY(pib.DateOfEligibility) - 1), pib.DateOfEligibility)
				AND CASE 
						WHEN YEAR(pib.CoverageEndsDate) = 9999
							THEN pib.CoverageEndsDate
						ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, pib.CoverageEndsDate) + 1, 0))
						END
			AND r.ReportName = 'TotalPatient Vs Total Cost'
			AND rfc.StatusCode = 'A'
			
		)
	SELECT *
	INTO ##OLAP_SC_FactDrCost
	FROM CTE
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH