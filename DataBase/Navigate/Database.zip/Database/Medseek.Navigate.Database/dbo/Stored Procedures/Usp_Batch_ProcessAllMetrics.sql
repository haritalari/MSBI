﻿
/*   
---------------------------------------------------------------------------------------   
Procedure Name: [dbo].[Usp_Batch_ProcessAllMetrics]   
Description   : This proc is used to push all the datekeys numerators patients data at a time from tempDB
				 to improve the batch numerators process performance. 
Created By    : Nagasiva   
Created Date  : 25-June-2013 
----------------------------------------------------------------------------------------   
Log History   :    
DD-MM-YYYY  BY DESCRIPTION   
----------------------------------------------------------------------------------------   
*/ 
CREATE PROCEDURE [dbo].[Usp_Batch_ProcessAllMetrics] 
(@i_AppUserId KEYID =NULL
)
 AS 
  BEGIN TRY 
      SET nocount ON 

    SELECT @i_AppUserId = MIN(UserId) FROM Users WITH(NOLOCK)

    
	  DECLARE @i_min              INT, 
              @i_max              INT, 
              @vc_Name            VARCHAR(150), 
              @i_datekey          VARCHAR(8), 
              @vc_String          VARCHAR(max), 
              @vc_DroptableString VARCHAR(max) 
      DECLARE @tbl_NrPatients TABLE 
        ( 
           id   INT IDENTITY(1, 1), 
           NAME VARCHAR(150) 
        ) 

      INSERT INTO @tbl_NrPatients 
      SELECT NAME 
      FROM   tempdb.dbo.sysobjects 
      WHERE  NAME LIKE '%NrpatientCount_%' 
             AND type = 'U' 

      SELECT @i_min = Min(id), 
             @i_Max = Max(id) 
      FROM   @tbl_NrPatients 

      WHILE @i_min <= @i_Max 
        BEGIN 
            SELECT @vc_Name = NAME 
            FROM   @tbl_NrPatients 
            WHERE  id = @i_min 

            SELECT @i_datekey = Substring(@vc_Name, Charindex('_', @vc_Name) + 1 
                                , 
                                Len( 
                                @vc_Name)) 

            DELETE FROM nrpatientcount 
            WHERE  datekey = Cast(@i_datekey AS INT) 

            SET @vc_String = ' INSERT INTO NrpatientCount ( PatientID, MetricID, Count, IsIndicator, CreatedByUserId, CreatedDate, DateKey ) SELECT  PatientID, MetricId, Count, IsIndicator, (SELECT MIN(UserId) FROM Users), GETDATE(), DateKey FROM '+ @vc_Name 

    --PRINT(@vc_String)  
			EXEC(@vc_String) 

			SET @vc_DroptableString ='DROP TABLE ' + @vc_Name 

			EXEC(@vc_DroptableString) 

			SET @i_min = @i_min + 1 
		END 

    DELETE FROM @tbl_NrPatients 

    INSERT INTO @tbl_NrPatients 
    SELECT NAME 
    FROM   tempdb.dbo.sysobjects 
    WHERE  NAME LIKE '%NrpatientValue_%' 
           AND type = 'U' 

    SELECT @i_min = Min(id), 
           @i_Max = Max(id) 
    FROM   @tbl_NrPatients 

    WHILE @i_min <= @i_Max 
      BEGIN 
          SELECT @vc_Name = NAME 
          FROM   @tbl_NrPatients 
          WHERE  id = @i_min 

          SELECT @i_datekey = Substring(@vc_Name, Charindex('_', @vc_Name) + 1, 
                              Len( 
                              @vc_Name)) 

          DELETE FROM nrpatientvalue 
          WHERE  datekey = Cast(@i_datekey AS INT) 

          SET @vc_String = ' INSERT INTO NRPatientValue ( PatientID, MetricID, Value, ValueDate, IsIndicator, CreatedByUserId, CreatedDate, DateKey ) SELECT  PatientID, MetricId, Value, ValueDate, IsIndicator, (SELECT MIN(UserId) FROM Users), GETDATE(), DateKey FROM '+ @vc_Name 

    --PRINT(@vc_String)  
		 EXEC(@vc_String) 
		 SET @i_min = @i_min + 1 
		 SET @vc_DroptableString ='DROP TABLE ' + @vc_Name 
		 EXEC(@vc_DroptableString) 
	  END 

    EXEC [Usp_batch_metricfrequencyupdateforpopreport] 
      @i_AppUserId = 1, 
      @v_DateKey = NULL, 
      @i_MetricID = NULL 
END TRY 

  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------       
  BEGIN CATCH 
      -- Handle exception   
      DECLARE @i_ReturnedErrorID INT 

      EXECUTE @i_ReturnedErrorID = dbo.Usp_handleexception 
        @i_UserId = @i_AppUserId 
  END CATCH