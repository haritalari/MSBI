﻿CREATE PROCEDURE [dbo].[aspnet_PersonalizationAdministration_GetCountOfState]
(
 @Count INT OUT ,
 @AllUsersScope BIT ,
 @ApplicationName NVARCHAR(256) ,
 @Path NVARCHAR(256) = NULL ,
 @UserName NVARCHAR(256) = NULL ,
 @InactiveSinceDate DATETIME = NULL )
AS
SET NOCOUNT ON
BEGIN

      DECLARE @ApplicationId UNIQUEIDENTIFIER
      EXEC dbo.aspnet_Personalization_GetApplicationId @ApplicationName , @ApplicationId OUTPUT
      IF ( @ApplicationId IS NULL )
         SELECT
             @Count = 0
      ELSE
         IF ( @AllUsersScope = 1 )
            SELECT
                @Count = COUNT(*)
            FROM
                dbo.aspnet_PersonalizationAllUsers AllUsers ,
                dbo.aspnet_Paths Paths
            WHERE
                Paths.ApplicationId = @ApplicationId AND AllUsers.PathId = Paths.PathId AND ( @Path IS NULL OR Paths.LoweredPath LIKE LOWER(@Path) )
         ELSE
            SELECT
                @Count = COUNT(*)
            FROM
                dbo.aspnet_PersonalizationPerUser PerUser ,
                dbo.aspnet_Users Users ,
                dbo.aspnet_Paths Paths
            WHERE
                Paths.ApplicationId = @ApplicationId AND PerUser.UserId = Users.UserId AND PerUser.PathId = Paths.PathId AND ( @Path IS NULL OR Paths.LoweredPath LIKE LOWER(@Path) ) AND ( @UserName IS NULL OR Users.LoweredUserName LIKE LOWER(@UserName) ) AND ( @InactiveSinceDate IS NULL OR Users.LastActivityDate <= @InactiveSinceDate )
END
