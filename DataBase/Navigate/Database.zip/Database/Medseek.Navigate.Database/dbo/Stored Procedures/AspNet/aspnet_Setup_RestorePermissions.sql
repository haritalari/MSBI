﻿CREATE PROCEDURE [dbo].[aspnet_Setup_RestorePermissions] @name SYSNAME
AS
SET NOCOUNT ON
BEGIN
      DECLARE @object SYSNAME
      DECLARE @protectType CHAR(10)
      DECLARE @action VARCHAR(20)
      DECLARE @grantee SYSNAME
      DECLARE @cmd NVARCHAR(500)

CREATE TABLE #aspnet_Permissions
(
    Owner     sysname,
    Object    sysname,
    Grantee   sysname,
    Grantor   sysname,
    ProtectType char(10),
    [Action]    varchar(20),
    [Column]    sysname
)

INSERT INTO #aspnet_Permissions
EXECUTE master.dBO.sp_helprotect 
      
      DECLARE c1 CURSOR FORWARD_ONLY
              FOR SELECT
                      Object ,
                      ProtectType ,
                      [Action] ,
                      Grantee
                  FROM
                      #aspnet_Permissions
                  WHERE
                      Object = @name

      OPEN c1

      FETCH c1 INTO @object,@protectType,@action,@grantee
      WHILE ( @@fetch_status = 0 )
            BEGIN
                  SET @cmd = @protectType + ' ' + @action + ' on ' + @object + ' TO [' + @grantee + ']'
                  EXEC ( @cmd )
                  FETCH c1 INTO @object,@protectType,@action,@grantee
            END

      CLOSE c1
      DEALLOCATE c1
END
