﻿CREATE PROCEDURE [dbo].[aspnet_PersonalizationAdministration_ResetSharedState]
(
 @Count INT OUT ,
 @ApplicationName NVARCHAR(256) ,
 @Path NVARCHAR(256) )
AS
SET NOCOUNT ON
BEGIN
      DECLARE @ApplicationId UNIQUEIDENTIFIER
      EXEC dbo.aspnet_Personalization_GetApplicationId @ApplicationName , @ApplicationId OUTPUT
      IF ( @ApplicationId IS NULL )
         SELECT
             @Count = 0
      ELSE
         BEGIN
               DELETE  FROM
                       dbo.aspnet_PersonalizationAllUsers
               WHERE
                       PathId IN ( SELECT
                                       AllUsers.PathId
                                   FROM
                                       dbo.aspnet_PersonalizationAllUsers AllUsers ,
                                       dbo.aspnet_Paths Paths
                                   WHERE
                                       Paths.ApplicationId = @ApplicationId AND AllUsers.PathId = Paths.PathId AND Paths.LoweredPath = LOWER(@Path) )

               SELECT
                   @Count = @@ROWCOUNT
         END
END
