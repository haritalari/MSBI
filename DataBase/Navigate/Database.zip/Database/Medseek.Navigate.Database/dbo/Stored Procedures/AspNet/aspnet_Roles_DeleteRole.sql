﻿CREATE PROCEDURE [dbo].[aspnet_Roles_DeleteRole]
       @ApplicationName NVARCHAR(256) ,
       @RoleName NVARCHAR(256) ,
       @DeleteOnlyIfRoleIsEmpty BIT
AS
SET NOCOUNT ON
BEGIN
      DECLARE @ApplicationId UNIQUEIDENTIFIER
      SELECT
          @ApplicationId = NULL
      SELECT
          @ApplicationId = ApplicationId
      FROM
          aspnet_Applications
      WHERE
          LOWER(@ApplicationName) = LoweredApplicationName
      IF ( @ApplicationId IS NULL )
         RETURN ( 1 )

      DECLARE @ErrorCode INT
      SET @ErrorCode = 0

      DECLARE @TranStarted BIT
      SET @TranStarted = 0

      IF ( @@TRANCOUNT = 0 )
         BEGIN
               BEGIN TRANSACTION
               SET @TranStarted = 1
         END
      ELSE
         SET @TranStarted = 0

      DECLARE @RoleId UNIQUEIDENTIFIER
      SELECT
          @RoleId = NULL
      SELECT
          @RoleId = RoleId
      FROM
          dbo.aspnet_Roles
      WHERE
          LoweredRoleName = LOWER(@RoleName) AND ApplicationId = @ApplicationId

      IF ( @RoleId IS NULL )
         BEGIN
               SELECT
                   @ErrorCode = 1
               GOTO Cleanup
         END
      IF ( @DeleteOnlyIfRoleIsEmpty <> 0 )
         BEGIN
               IF ( EXISTS ( SELECT
                                 RoleId
                             FROM
                                 dbo.aspnet_UsersInRoles
                             WHERE
                                 @RoleId = RoleId ) )
                  BEGIN
                        SELECT
                            @ErrorCode = 2
                        GOTO Cleanup
                  END
         END


      DELETE  FROM
              dbo.aspnet_UsersInRoles
      WHERE
              @RoleId = RoleId

      IF ( @@ERROR <> 0 )
         BEGIN
               SET @ErrorCode = -1
               GOTO Cleanup
         END

      DELETE  FROM
              dbo.aspnet_Roles
      WHERE
              @RoleId = RoleId AND ApplicationId = @ApplicationId

      IF ( @@ERROR <> 0 )
         BEGIN
               SET @ErrorCode = -1
               GOTO Cleanup
         END

      IF ( @TranStarted = 1 )
         BEGIN
               SET @TranStarted = 0
               COMMIT TRANSACTION
         END

      RETURN ( 0 )

      Cleanup:

      IF ( @TranStarted = 1 )
         BEGIN
               SET @TranStarted = 0
               ROLLBACK TRANSACTION
         END

      RETURN @ErrorCode
END
