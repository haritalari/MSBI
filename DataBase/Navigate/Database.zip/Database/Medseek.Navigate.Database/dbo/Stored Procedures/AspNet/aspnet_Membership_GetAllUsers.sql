﻿CREATE PROCEDURE [dbo].[aspnet_Membership_GetAllUsers]
       @ApplicationName NVARCHAR(256) ,
       @PageIndex INT ,
       @PageSize INT
AS
SET NOCOUNT ON
BEGIN
      DECLARE @ApplicationId UNIQUEIDENTIFIER
      SELECT
          @ApplicationId = NULL
      SELECT
          @ApplicationId = ApplicationId
      FROM
          dbo.aspnet_Applications
      WHERE
          LOWER(@ApplicationName) = LoweredApplicationName
      IF ( @ApplicationId IS NULL )
         RETURN 0


    -- Set the page bounds
      DECLARE @PageLowerBound INT
      DECLARE @PageUpperBound INT
      DECLARE @TotalRecords INT
      SET @PageLowerBound = @PageSize * @PageIndex
      SET @PageUpperBound = @PageSize - 1 + @PageLowerBound

    -- Create a temp table TO store the select results
      CREATE TABLE #PageIndexForUsers
      (
        IndexId INT IDENTITY(0,1)
                    NOT NULL ,
        UserId UNIQUEIDENTIFIER )

    -- Insert into our temp table
      INSERT INTO
          #PageIndexForUsers
          (
            UserId )
          SELECT
              u.UserId
          FROM
              dbo.aspnet_Membership m ,
              dbo.aspnet_Users u
          WHERE
              u.ApplicationId = @ApplicationId AND u.UserId = m.UserId
          ORDER BY
              u.UserName

      SELECT
          @TotalRecords = @@ROWCOUNT

      SELECT
          u.UserName ,
          m.Email ,
          m.PasswordQuestion ,
          m.Comment ,
          m.IsApproved ,
          m.CreateDate ,
          m.LastLoginDate ,
          u.LastActivityDate ,
          m.LastPasswordChangedDate ,
          u.UserId ,
          m.IsLockedOut ,
          m.LastLockoutDate
      FROM
          dbo.aspnet_Membership m ,
          dbo.aspnet_Users u ,
          #PageIndexForUsers p
      WHERE
          u.UserId = p.UserId AND u.UserId = m.UserId AND p.IndexId >= @PageLowerBound AND p.IndexId <= @PageUpperBound
      ORDER BY
          u.UserName
      RETURN @TotalRecords
END
