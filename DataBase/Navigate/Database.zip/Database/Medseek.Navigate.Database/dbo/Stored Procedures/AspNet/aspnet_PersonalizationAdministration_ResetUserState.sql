﻿CREATE PROCEDURE [dbo].[aspnet_PersonalizationAdministration_ResetUserState]
(
 @Count INT OUT ,
 @ApplicationName NVARCHAR(256) ,
 @InactiveSinceDate DATETIME = NULL ,
 @UserName NVARCHAR(256) = NULL ,
 @Path NVARCHAR(256) = NULL )
AS
SET NOCOUNT ON
BEGIN
      DECLARE @ApplicationId UNIQUEIDENTIFIER
      EXEC dbo.aspnet_Personalization_GetApplicationId @ApplicationName , @ApplicationId OUTPUT
      IF ( @ApplicationId IS NULL )
         SELECT
             @Count = 0
      ELSE
         BEGIN
               DELETE  FROM
                       dbo.aspnet_PersonalizationPerUser
               WHERE
                       Id IN ( SELECT
                                   PerUser.Id
                               FROM
                                   dbo.aspnet_PersonalizationPerUser PerUser ,
                                   dbo.aspnet_Users Users ,
                                   dbo.aspnet_Paths Paths
                               WHERE
                                   Paths.ApplicationId = @ApplicationId AND PerUser.UserId = Users.UserId AND PerUser.PathId = Paths.PathId AND ( @InactiveSinceDate IS NULL OR Users.LastActivityDate <= @InactiveSinceDate ) AND ( @UserName IS NULL OR Users.LoweredUserName = LOWER(@UserName) ) AND ( @Path IS NULL OR Paths.LoweredPath = LOWER(@Path) ) )

               SELECT
                   @Count = @@ROWCOUNT
         END
END
