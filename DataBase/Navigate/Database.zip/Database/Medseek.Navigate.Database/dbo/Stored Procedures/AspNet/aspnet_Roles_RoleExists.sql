﻿CREATE PROCEDURE [dbo].[aspnet_Roles_RoleExists]
       @ApplicationName NVARCHAR(256) ,
       @RoleName NVARCHAR(256)
AS
SET NOCOUNT ON
BEGIN
      DECLARE @ApplicationId UNIQUEIDENTIFIER
      SELECT
          @ApplicationId = NULL
      SELECT
          @ApplicationId = ApplicationId
      FROM
          aspnet_Applications
      WHERE
          LOWER(@ApplicationName) = LoweredApplicationName
      IF ( @ApplicationId IS NULL )
         RETURN ( 0 )
      IF ( EXISTS ( SELECT
                        RoleName
                    FROM
                        dbo.aspnet_Roles
                    WHERE
                        LOWER(@RoleName) = LoweredRoleName AND ApplicationId = @ApplicationId ) )
         RETURN ( 1 )
      ELSE
         RETURN ( 0 )
END
