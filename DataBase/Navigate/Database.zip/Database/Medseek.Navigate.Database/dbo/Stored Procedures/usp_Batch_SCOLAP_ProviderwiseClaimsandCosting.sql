﻿
/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_SCOLAP_ProviderwiseClaimsandCosting]
Description   : This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Nagasiva  
Created Date  : 23-Jan-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
13-Feb-2015 Nagasiva  assigned null value to  @i_AppUserId  Parameter to remove the hardcoded userid in cube execution package
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_SCOLAP_ProviderwiseClaimsandCosting] (@i_AppUserId KEYID =NULL)
AS
BEGIN TRY
	SET NOCOUNT ON

	SELECT @i_AppUserId =MIN(UserId) FROM Users

	IF OBJECT_ID('TEMPDB..##OLAP_SC_FactProviderHealthPlanCost ') IS NOT NULL
		DROP TABLE ##OLAP_SC_FactProviderHealthPlanCost ;

	WITH CTE
	AS (
		SELECT DISTINCT igp.InsuranceGroupId AS HealthPlanKey
			,cp.ProviderID AS ProviderKey
			,ad.DateKey
			,cp.ClaimInfoID AS ClaimId
			,ci.NetPaidAmount AS ClaimAmt
		FROM PatientInsuranceBenefit pib WITH (NOLOCK)
		INNER JOIN PatientInsurance pi1 WITH (NOLOCK) ON pi1.PatientInsuranceID = pib.PatientInsuranceID
		INNER JOIN ClaimInfo ci WITH (NOLOCK)  ON ci.PatientID = pi1.PatientID
		INNER JOIN ClaimProvider cp WITH (NOLOCK) ON cp.ClaimInfoID = ci.ClaimInfoId
		INNER JOIN InsuranceGroupPlan igp WITH (NOLOCK) ON igp.InsuranceGroupPlanId = pi1.InsuranceGroupPlanId
		INNER JOIN ##OLAP_SC_DimHealthPlan HP
					ON HP.HealthPlanKey = igp.InsuranceGroupId
		INNER JOIN ##OLAP_SC_DimProvider p
		ON p.providerkey = cp.ProviderID			
		INNER JOIN ##OLAP_SC_DimAnchordate ad ON ad.AnchorDate = CASE 
				WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pib.DateOfEligibility) - 1), pib.DateOfEligibility)
						AND CASE 
								WHEN YEAR(pib.CoverageEndsDate) = 9999
									THEN pib.CoverageEndsDate
								ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, pib.CoverageEndsDate) + 1, 0))
								END
					THEN ad.AnchorDate
				ELSE NULL
				END
			AND ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(ci.DateOfAdmit) - 1), ci.DateOfAdmit)
				AND DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, ci.DateOfDischarge) + 1, 0))
		)
	SELECT *
	INTO ##OLAP_SC_FactProviderHealthPlanCost
	FROM CTE
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH