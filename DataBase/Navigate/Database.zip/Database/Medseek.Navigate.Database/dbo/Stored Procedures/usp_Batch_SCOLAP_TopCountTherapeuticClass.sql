﻿/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_SCOLAP_TopCountTherapeuticClass]
Description   : This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Nagasiva  
Created Date  : 23-Jan-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
13-Feb-2015 Nagasiva  assigned null value to  @i_AppUserId  Parameter to remove the hardcoded userid in cube execution package
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_SCOLAP_TopCountTherapeuticClass] (@i_AppUserId KEYID=NULL)
AS
BEGIN TRY
	SET NOCOUNT ON

		SELECT @i_AppUserId =MIN(UserId) FROM Users WITH (NOLOCK)

		IF OBJECT_ID('TEMPDB..##OLAP_SC_FactTherapeuticClass') IS NOT NULL
		DROP TABLE ##OLAP_SC_FactTherapeuticClass;

	WITH CTE
	AS (
		SELECT rc.DrugCodeId AS DrugCodeKey
			,ad.DateKey AS DateKey
			,rc.RxClaimID AS ClaimId
			,SUM(rcc.PaidAmount) AS ClaimAmt 
		FROM RxClaim rc WITH (NOLOCK)
		INNER JOIN RxClaimCost rcc WITH (NOLOCK)
			ON rcc.RxClaimId = rc.RxClaimID
		INNER JOIN ##OLAP_SC_DimCodesetDrug d
		   ON d.DrugCodeKey = rc.DrugCodeId
		INNER JOIN ##OLAP_SC_DimAnchordate ad WITH (NOLOCK)
			ON ad.DateKey = CASE 
					WHEN rc.DateFilled > = DATEADD(dd, - (DAY(ad.AnchorDate) - 1), ad.AnchorDate)
						AND rc.DateFilled < = ad.AnchorDate
						THEN ad.DateKey
					ELSE NULL
					END
		WHERE DrugCodeId IS NOT NULL
		GROUP BY rc.DrugCodeId
			,rc.RxClaimID
			,ad.DateKey
		)
	SELECT *
	INTO ##OLAP_SC_FactTherapeuticClass
	FROM CTE

END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH