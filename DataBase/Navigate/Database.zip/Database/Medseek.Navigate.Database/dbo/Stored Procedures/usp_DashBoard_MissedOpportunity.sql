﻿
/****** Object:  StoredProcedure [dbo].[usp_DashBoard_MissedOpportunity]    Script Date: 8/24/2015 4:18:12 PM ******/
/*  
--------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_DashBoard_MissedOpportunity] 85679, 53855,'Care Manager'
Description   : This proc is used to retrive the Patient specific missedopportunity records from task table  
Created By    : Rathnam  
Created Date  : 20-Jan-2013
---------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY   DESCRIPTION
30-12-2014 Santosh changed the code as per NAVI - 2072 
30-03-2015 Rathnam modifed the proce to not to display the adhoc tasks as per 2608 impacts did not modify
23-07-2015 Rathnam modifed the proce to not to display the Disenroll tasks as per 3330 impacts did not modify
20-Aug-2015 Santosh Modified the SP as per NAVI-3489
10-Sep-2015 Santosh Modified the SP as per NAVI-3908
26-Nov-2015 Yugandhar Modified the SP as per NAVI-3907
17-03-2016 Rathnam modifed as per new task architecture
31-03-2016 Rathnam modifed as per NAVI-5658
5-04-2016 Rathnam modifed as per NAVI-5725
20-Apr-2016 Yugandhar Modified the SP as per NAVI-5829
---------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_DashBoard_MissedOpportunity] (
	@i_AppUserId KEYID
	,@i_PatientUserID KEYID
	)
AS
SET NOCOUNT ON
BEGIN TRY
	-- Check if valid Application User ID is passed  
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END

	DECLARE @i_IncompleteTaskStatusID INT
		,@i_DisEnrollTaskStatusID INT

	SELECT @i_IncompleteTaskStatusID = ts.TaskStatusId
	FROM TaskStatus ts
	WHERE TaskStatusText = 'Closed Incomplete'

	SELECT @i_DisEnrollTaskStatusID = ts.TaskStatusId
	FROM TaskStatus ts
	WHERE TaskStatusText = 'DisEnroll'

	SELECT t.PatientTaskId TaskId
		,ty.TaskTypeName
		,dbo.ufn_GetTypeNamesByTypeId(ty.TaskTypeName, t.TypeID) TaskName
		,t.DateTaken MissedOpportunityDate
		,t.DueDate AS TaskDueDate
		,CASE WHEN t.TaskStatusId = @i_IncompleteTaskStatusID THEN 'Incomplete' ELSE 'Disenroll - ' + ISNULL(r.DisenrollReason,pm.ReasonForDisenroll) END AS Reason
		,ProgramName
		,p.StatusCode AS ProgramStatus
	FROM PatientTask t WITH (NOLOCK)
	INNER JOIN PatientProgram pm WITH(NOLOCK)
	on t.PatientProgramId = pm.PatientProgramID
	INNER JOIN TaskType ty WITH (NOLOCK) ON t.TaskTypeId = ty.TaskTypeId
	INNER JOIN Program p WITH (NOLOCK) ON p.ProgramId = t.ManagedPopulationId
	LEFT JOIN CodeSetDisenrollmentReason r
	on r.DisenrollReasonId = pm.ReasonForDisenrollId
	WHERE t.TaskStatusId IN (
			@i_IncompleteTaskStatusID
			,@i_DisEnrollTaskStatusID
			)
		AND t.PatientId = @i_PatientUserID
		AND ty.IsTask = 1
END TRY

---------------------------------------------------------------------------------------------------------------------------------  
BEGIN CATCH
	-- Handle exception                  
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH