﻿
/*    
------------------------------------------------------------------------------    
Procedure Name: [usp_Batch_TaskSchedule]
Description   : This procedure is used to schedule recurring tasks
Created By    : NagaBabu
Created Date  : 04-Mar-2016
------------------------------------------------------------------------------    
Log History   :     
DD-MM-YYYY  BY   DESCRIPTION 
28-Mar-2016 Nagababu Modified the logic as per NAVI-5547
29-Mar-2016 Nagababu Modified logic as per NAVI-5622
31-Mar-2016 Nagababu Modified the logic as per NAVI-5634
31-Mar-2016 Nagababu Modified the logic as per NAVI-5336
01-Apr-2016 Nagababu Modified the logic as per NAVI-5622
13-Apr-2016 Nagababu Modified the logic as per NAVI-5777
27-Apr-2016 Nagababu Modified the logic as per NAVI-5885
14-Jun-2016 Nagababu Modified the logic as per NAVI-6195
04-Jul-2016 Nagababu Modified the logic as per NAVI-6309
02-Aug-2016 Nagababu Modified the logic as per NAVI-6383
17-Aug-2016 Rathnam added statuscode = 'A' as per NAVI-6612
12-Sep-2016 Nagababu Modified the code for NAVI-6705
13-Oct-2016 Nagababu Modified the code as per NAVI-6862
------------------------------------------------------------------------------    
*/
CREATE PROCEDURE [dbo].[usp_Batch_TaskSchedule] 
(
	@i_AppUserId INT ,
	@t_PatientTask PatientTask READONLY
)
AS
BEGIN TRY
	SET NOCOUNT ON

	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END

	DECLARE @l_TranStarted BIT = 0

	IF (@@TRANCOUNT = 0)
	BEGIN
		BEGIN TRANSACTION

		SET @l_TranStarted = 1 -- Indicator for start of transactions
	END
	DECLARE @i_TaskStatusId INT
		,@d_TodayDate DATETIME 
		,@d_Today DATETIME 

		SELECT @d_TodayDate = DATEADD(HH,DATEPART(HH,GETDATE()),CAST(CAST(GETDATE() AS DATE) AS DATETIME))
		

	SELECT @i_TaskStatusId = TaskStatusId ,
		@d_Today = CAST(GETDATE() AS DATE)
	FROM TaskStatus
	WHERE TaskStatusText = 'Open'

	SELECT DISTINCT
		PTTS.PatientTaskTemplateId ,
		PTTS.PatientTaskTemplateScheduleId ,
		PTTS.StartScheduleType ,
		TTP.NextDueDate
	INTO #NextContact
	FROM @t_PatientTask TTP
	INNER JOIN PatientTaskTemplateSchedule PTTS
	ON TTP.PatientTaskTemplateId = PTTS.PatientTaskTemplateId
	WHERE ISNULL(TTP.NextDueDate,PTTS.StartDate) BETWEEN PTTS.StartDate AND PTTS.EndDate 
	AND ((PTTS.StartScheduleType <> 'A' AND TTP.NextDueDate IS NOT NULL) OR TTP.NextDueDate IS NULL)

	UPDATE PTTS
	SET StatusCode = 'C' ,
		LastModifiedByUserId = @i_AppUserId ,
		LastModifiedDate = GETDATE()
	FROM PatientTaskTemplateSchedule PTTS
	INNER JOIN #NextContact TNCD
	ON TNCD.PatientTaskTemplateId = PTTS.PatientTaskTemplateId
	WHERE PTTS.PatientTaskTemplateScheduleId < TNCD.PatientTaskTemplateScheduleId
	AND TNCD.NextDueDate IS NOT NULL
	AND PTTS.StatusCode = 'A'

	UPDATE PTTS
	SET StatusCode = 'C' ,
		LastModifiedByUserId = @i_AppUserId ,
		LastModifiedDate = GETDATE()
	FROM PatientTaskTemplateSchedule PTTS
	INNER JOIN #NextContact TNCD
	ON TNCD.PatientTaskTemplateId = PTTS.PatientTaskTemplateId
	WHERE TNCD.NextDueDate IS NULL
	AND PTTS.StatusCode = 'A'


	SELECT ProviderId ,
		TPT.PatientTaskTemplateId ,
		NextDueDate ,
		PTTS.PatientTaskTemplateScheduleId ,
		PTTS.AccessType
	INTO #PatientTask
	FROM @t_PatientTask TPT	
	INNER JOIN PatientTaskTemplateSchedule PTTS
	ON TPT.PatientTaskTemplateId = PTTS.PatientTaskTemplateId
	WHERE NextDueDate BETWEEN PTTS.StartDate AND PTTS.EndDate 	
	AND PTTS.StatusCode = 'A'

		SELECT 
			PatientId 
			,PatientTaskTemplateIntervalId
			,ManagedPopulationId 
			,TaskTypeId 
			,PatientTaskTemplateScheduleId 
			,StartDate 
			,EndDate 
			,Duedate
			,ToDay
			,CASE 
				WHEN @d_TodayDate BETWEEN StartDate
						AND CASE WHEN OccurrenceType IN('H','O') THEN EndDate  
								 WHEN OccurrenceType = 'D' THEN DATEADD(MI,-59,EndDate)  
								 ELSE  DATEADD(DD,-1,EndDate)
							END
					THEN @d_TodayDate
				WHEN @d_TodayDate < StartDate
					THEN StartDate
				END AS TodayDate
			,DATEADD(DD, CASE WHEN OccurrenceType = 'D' THEN Occurrence ELSE 1 END, ToDay) AS NextDate
			,DATEADD(DD, - (DATEPART(DW, ToDay)) + 1, ToDay) AS WeekStartDate
			,DATEADD(DD, 7 * CASE WHEN OccurrenceType = 'W' THEN Occurrence ELSE 1 END , DATEADD(DD, - (DATEPART(DW, ToDay)) + 1, ToDay)) AS NextWeekStartDate
			,DATEADD(DD, - DATEPART(DD, ToDay) + 1, ToDay) AS StartDateOfMonth
			,DATEADD(MM, CASE WHEN OccurrenceType = 'M' THEN Occurrence ELSE 1 END, DATEADD(DD, - DATEPART(DD, ToDay) + 1, ToDay)) AS StartOfNextMonth
			,DATEADD(MM, - DATEPART(MM, ToDay) + 1, DATEADD(DD,- DATEPART(DD, ToDay)+ 1,ToDay)) AS YearStartDate
			,DATEADD(YY, CASE WHEN OccurrenceType = 'Y' THEN Occurrence ELSE 1 END, DATEADD(MM, - DATEPART(MM, ToDay) + 1, DATEADD(DD,- DATEPART(DD, ToDay)+ 1,ToDay))) AS NextYearStartDate
			,OccurrenceType
			,Occurrence
			,Interval
			,DayOfTheMonth
			,TypeId
			,SNO
			,MissedopportunityType
			,ProviderId
			,OneTimeDueDate
			,PatientTaskTemplateId
			,DT.AccessType
		INTO #SourceForDueDates
		FROM 
			(
			SELECT PTT.PatientId
				,PTI.PatientTaskTemplateIntervalId
				,PTTS.ManagedPopulationId
				,PTT.TaskTypeId
				,PTTS.PatientTaskTemplateScheduleId
				,PTTS.StartDate
				,CAST(CAST(CASE WHEN @d_TodayDate BETWEEN StartDate AND CASE WHEN OccurrenceType IN('H','O') THEN EndDate  
																			 WHEN OccurrenceType = 'D' THEN DATEADD(MI,-59,EndDate)  
																			 ELSE  DATEADD(DD,-1,EndDate)
																		END
										THEN @d_TodayDate
									WHEN @d_TodayDate < StartDate
										THEN StartDate
									END AS DATE) AS DATETIME) AS ToDay
				,PTTS.EndDate
				,TPT.NextDueDate AS Duedate
				,PTTS.OccurrenceType
				,PTTS.Occurrence
				,PTI.Interval
				,PTI.DayOfTheMonth
				,COALESCE(AssessmentId,ProcedureId,EducationMaterialId,OtherTaskId) AS TypeId
				,DENSE_RANK() OVER (
					PARTITION BY PTTS.PatientTaskTemplateId ORDER BY PTTS.StartDate
					) AS SNO
				,PTTS.MissedopportunityType
				,TPT.ProviderId
				,PTTS.DueDate AS OneTimeDueDate
				,PTTS.PatientTaskTemplateId 
				,TPT.AccessType
			FROM PatientTaskTemplateSchedule PTTS 
			INNER JOIN PatientTaskTemplate PTT ON PTT.PatientTaskTemplateId = PTTS.PatientTaskTemplateId
			INNER JOIN #PatientTask TPT ON TPT.PatientTaskTemplateId = PTT.PatientTaskTemplateId
										AND TPT.PatientTaskTemplateScheduleId <= PTTS.PatientTaskTemplateScheduleId
			LEFT JOIN PatientTaskTemplateInterval PTI ON PTI.PatientTaskTemplateScheduleId = PTTS.PatientTaskTemplateScheduleId
			AND pti.StatusCode = 'A'
			WHERE PTT.StatusCode = 'A'
				AND PTTS.StatusCode = 'A'
			) DT
		--WHERE SNO <= 2
		WHERE ((ToDay BETWEEN StartDate AND CASE WHEN OccurrenceType IN('H','O') THEN EndDate  
												 WHEN OccurrenceType = 'D' THEN DATEADD(MI,-59,EndDate)  
												 ELSE  DATEADD(DD,-1,EndDate)
											END) OR StartDate > ToDay)
		
		SELECT DISTINCT PatientTaskTemplateIntervalId
			,TSD.PatientTaskTemplateScheduleId
			,PatientId
			,ManagedPopulationId
			,TaskTypeId
			,TypeId
			,MissedopportunityType
			,@i_TaskStatusId AS TaskStatusId
			,StartDate
			,EndDate
			,DueDate 
			,OccurrenceType 
			,Occurrence
			,Interval
			,DayOfTheMonth
			,TPT.ProviderId
			,OneTimeDueDate
			,CASE WHEN TSD.PatientTaskTemplateScheduleId = TPT.PatientTaskTemplateScheduleId THEN CASE WHEN Duedate >= @d_TodayDate AND OccurrenceType <> 'O' THEN Duedate ELSE OneTimeDueDate END
				ELSE CASE
						WHEN OccurrenceType = 'D'
							AND PatientTaskTemplateIntervalId IS NOT NULL
							THEN CASE 
									WHEN DATEADD(HH, Interval, Today) < TodayDate
										THEN DATEADD(HH, Interval, NextDate)
									ELSE DATEADD(HH, Interval, Today)
									END
						WHEN OccurrenceType = 'W'
							AND PatientTaskTemplateIntervalId IS NOT NULL
							THEN CASE 
									WHEN DATEADD(DD, Interval - 1, WeekStartDate) < CAST(TodayDate AS DATE)
										THEN DATEADD(HH, 23, DATEADD(DD, Interval - 1, NextWeekStartDate))
									ELSE DATEADD(HH, 23, DATEADD(DD, Interval - 1, WeekStartDate))
									END
						WHEN OccurrenceType = 'M'
							AND PatientTaskTemplateIntervalId IS NOT NULL
							THEN CASE 
									WHEN Interval = 0
										THEN CASE 
												WHEN EOMONTH(StartDateOfMonth) < CAST(TodayDate AS DATE)
													THEN DATEADD(HH, 23, CAST(EOMONTH(StartOfNextMonth) AS DATETIME))
												ELSE DATEADD(HH, 23, CAST(EOMONTH(StartDateOfMonth) AS DATETIME))
												END
									ELSE CASE 
											WHEN DATEADD(DD, Interval - 1, StartDateOfMonth) < CAST(TodayDate AS DATE)
												THEN DATEADD(HH, 23, DATEADD(DD, Interval - 1, StartOfNextMonth))
											ELSE DATEADD(HH, 23, DATEADD(DD, Interval - 1, StartDateOfMonth))
											END
									END
						WHEN OccurrenceType = 'Y'
							AND PatientTaskTemplateIntervalId IS NOT NULL
							THEN CASE 
									WHEN ISNULL(DayOfTheMonth, 0) = 0
										THEN CASE 
												WHEN EOMONTH(DATEADD(MM, Interval - 1, YearStartDate)) < CAST(TodayDate AS DATE)
													THEN DATEADD(HH, 23, CAST(EOMONTH(DATEADD(MM, Interval - 1, NextYearStartDate)) AS DATETIME))
												ELSE DATEADD(HH, 23, CAST(EOMONTH(DATEADD(MM, Interval - 1, YearStartDate)) AS DATETIME))
												END
									ELSE CASE 
											WHEN DATEADD(DD, DayOfTheMonth - 1, (DATEADD(MM, Interval - 1, YearStartDate))) < CAST(TodayDate AS DATE)
												THEN DATEADD(HH, 23, DATEADD(DD, DayOfTheMonth - 1, (DATEADD(MM, Interval - 1, NextYearStartDate))))
											ELSE DATEADD(HH, 23, DATEADD(DD, DayOfTheMonth - 1, (DATEADD(MM, Interval - 1, YearStartDate))))
											END
									END
						WHEN OccurrenceType = 'H' THEN CASE WHEN Duedate > TodayDate THEN Duedate
														ELSE TodayDate
														END
						ELSE CASE WHEN OneTimeDueDate IS NULL THEN CASE WHEN OccurrenceType = 'D' THEN DATEADD(DD, 1 * Occurrence, TodayDate)
																		  WHEN OccurrenceType = 'W' THEN DATEADD(WW, 1 * Occurrence, TodayDate)
																		  WHEN OccurrenceType = 'M' THEN DATEADD(MM, 1 * Occurrence, TodayDate)
																		  WHEN OccurrenceType = 'Y' THEN DATEADD(YY, 1 * Occurrence, TodayDate)
																	 END					

								ELSE CASE WHEN DueDate > OneTimeDueDate THEN '9999-12-31'
										  ELSE OneTimeDueDate
									 END
							END 
					END 
			END	AS DueDates
			,ToDay
			,DENSE_RANK() OVER (
				PARTITION BY 1 ORDER BY PatientId
					,ManagedPopulationId
					,TaskTypeId
					,TypeId
				) AS PrimarySNO
			,TSD.AccessType
		INTO #DueDates
		FROM #SourceForDueDates TSD
		INNER JOIN #PatientTask TPT
		ON TSD.PatientTaskTemplateId = TPT.PatientTaskTemplateId

		
		SELECT PatientTaskTemplateScheduleId
			,PatientTaskTemplateIntervalId
			,PatientId
			,ManagedPopulationId
			,TaskTypeId
			,TypeId
			,TaskStatusId
			,StartDate
			,EndDate
			,CASE WHEN OccurrenceType <> 'O' THEN CASE WHEN DATEPART(MI,DueDates) >= 1 AND DATEDIFF(MI,DueDates,StartDate) <= 59 
																THEN DATEADD(HH,DATEPART(HH,DATEADD(HH,1,DueDates)),CAST(CAST(DATEADD(HH,1,DueDates) AS DATE) AS DATETIME))
														ELSE DATEADD(HH,DATEPART(HH,DueDates),CAST(CAST(DueDates AS DATE) AS DATETIME))
													END
					ELSE DueDates										 
			 END AS DueDates
			,CAST(CAST(DueDates AS DATE)AS DATETIME) AS DueDatesDateFormat
			,PrimarySNO
			,MissedopportunityType
			,DueDate
			,OccurrenceType 
			,Occurrence
			,Interval
			,DayOfTheMonth
			,ProviderId
			,OneTimeDueDate
			,DENSE_RANK() OVER (
				PARTITION BY PrimarySNO ORDER BY ISNULL(DueDates,'9999-12-31'),PatientTaskTemplateScheduleId
				) AS SeqNo
			,AccessType
		INTO #TempPatientTask
		FROM #DueDates
		WHERE ((DueDates BETWEEN StartDate AND CASE WHEN OccurrenceType IN('H','O') THEN EndDate  
												  WHEN OccurrenceType = 'D' THEN DATEADD(MI,-59,EndDate)  
												  ELSE  DATEADD(DD,-1,EndDate)
											 END) OR StartDate >=DueDates)
		
		SELECT
			PatientTaskTemplateScheduleId
			,PatientTaskTemplateIntervalId
			,PatientId
			,ManagedPopulationId
			,TaskTypeId
			,TypeId
			,TaskStatusId
			,StartDate
			,EndDate
			,DueDates
			,DueDatesDateFormat
			,PrimarySNO
			,MissedopportunityType
			,DueDate
			,OccurrenceType 
			,Occurrence
			,Interval
			,DayOfTheMonth
			,SeqNo
			,ProviderId
			,OneTimeDueDate
			,DATEADD(DD, CASE WHEN OccurrenceType = 'D' THEN Occurrence ELSE 1 END, DueDatesDateFormat) AS NextDate
			,DATEADD(DD, - (DATEPART(DW, DueDates)) + 1, DueDates) AS WeekStartDate
			,DATEADD(DD, 7 * CASE WHEN OccurrenceType = 'W' THEN Occurrence ELSE 1 END , DATEADD(DD, - (DATEPART(DW, DueDates)) + 1, DueDates)) AS NextWeekStartDate
			,DATEADD(DD, - DATEPART(DD, DueDates) + 1, DueDates) AS StartDateOfMonth
			,DATEADD(MM, CASE WHEN OccurrenceType = 'M' THEN Occurrence ELSE 1 END, DATEADD(DD, - DATEPART(DD, DueDates) + 1, DueDates)) AS StartOfNextMonth
			--,DATEADD(MM, - DATEPART(MM, DueDates) + 1, DueDates) AS YearStartDate
			,DATEADD(MM, - DATEPART(MM, DueDates) + 1, DATEADD(DD,- DATEPART(DD, DueDates)+ 1,DueDates)) AS YearStartDate
			,DATEADD(YY, CASE WHEN OccurrenceType = 'Y' THEN Occurrence ELSE 1 END, DATEADD(MM, - DATEPART(MM, DueDates) + 1, DATEADD(DD,- DATEPART(DD, DueDates)+ 1,DueDates))) AS NextYearStartDate
			,AccessType
		INTO #SourceForNextContactDate
		FROM #TempPatientTask
		--WHERE SeqNo = 1

		SELECT DISTINCT
			CTEBNC.PatientTaskTemplateScheduleId
			,PTTI.PatientTaskTemplateIntervalId
			,PatientId
			,ManagedPopulationId
			,TaskTypeId
			,TypeId
			,TaskStatusId
			,StartDate
			,EndDate
			,DueDates
			,DueDatesDateFormat
			,PrimarySNO
			,MissedopportunityType
			,DueDate
			,OccurrenceType 
			,Occurrence
			,CASE 
				WHEN OccurrenceType = 'D'
					AND PTTI.PatientTaskTemplateIntervalId IS NOT NULL
					THEN CASE 
							WHEN DATEADD(HH, PTTI.Interval, DueDatesDateFormat) <= DueDates
								THEN DATEADD(HH, PTTI.Interval, NextDate)
							ELSE DATEADD(HH, PTTI.Interval, DueDatesDateFormat)
							END
				WHEN OccurrenceType = 'W'
					AND PTTI.PatientTaskTemplateIntervalId IS NOT NULL
					THEN CASE 
							WHEN DATEADD(DD, PTTI.Interval - 1, WeekStartDate) <= DueDates 
								THEN DATEADD(DD, PTTI.Interval - 1, NextWeekStartDate)
							ELSE DATEADD(DD, PTTI.Interval - 1, WeekStartDate)
							END
				WHEN OccurrenceType = 'M'
					AND PTTI.PatientTaskTemplateIntervalId IS NOT NULL
					THEN CASE 
							WHEN PTTI.Interval = 0
								THEN CASE 
										WHEN EOMONTH(CAST(StartDateOfMonth AS DATE)) <= CAST(DueDates AS DATE)
											THEN DATEADD(HH, 23, CAST(EOMONTH(StartOfNextMonth) AS DATETIME))
										ELSE DATEADD(HH, 23, CAST(EOMONTH(StartDateOfMonth) AS DATETIME))
										END
							ELSE CASE 
									WHEN DATEADD(DD, PTTI.Interval - 1, StartDateOfMonth) <= DueDates 
										THEN DATEADD(DD, PTTI.Interval - 1, StartOfNextMonth)
									ELSE DATEADD(DD, PTTI.Interval - 1, StartDateOfMonth)
									END
							END
				WHEN OccurrenceType = 'Y'
					AND PTTI.PatientTaskTemplateIntervalId IS NOT NULL
					THEN CASE 
							WHEN ISNULL(PTTI.DayOfTheMonth, 0) = 0
								THEN CASE 
										WHEN EOMONTH(DATEADD(MM, PTTI.Interval - 1, YearStartDate)) <= CAST(DueDates AS DATE)
											THEN DATEADD(HH, 23, CAST(EOMONTH(DATEADD(MM, PTTI.Interval - 1, NextYearStartDate)) AS DATETIME))
										ELSE DATEADD(HH, 23, CAST(EOMONTH(DATEADD(MM, PTTI.Interval - 1, YearStartDate)) AS DATETIME))
										END
							ELSE CASE 
									WHEN DATEADD(DD, PTTI.DayOfTheMonth - 1, (DATEADD(MM, PTTI.Interval - 1, YearStartDate))) <= DueDates 
										THEN DATEADD(DD, PTTI.DayOfTheMonth - 1, (DATEADD(MM, PTTI.Interval - 1, NextYearStartDate)))
									ELSE DATEADD(DD, PTTI.DayOfTheMonth - 1, (DATEADD(MM, PTTI.Interval - 1, YearStartDate)))
									END
							END
				WHEN OccurrenceType = 'H' THEN DATEADD(HH, Occurrence , DueDates)
				ELSE CASE WHEN OneTimeDueDate IS NULL THEN CASE WHEN OccurrenceType = 'D' THEN DATEADD(DD, 1 * Occurrence, DueDates)
														  WHEN OccurrenceType = 'W' THEN DATEADD(WW, 1 * Occurrence, DueDates)
														  WHEN OccurrenceType = 'M' THEN DATEADD(MM, 1 * Occurrence, DueDates)
														  WHEN OccurrenceType = 'Y' THEN DATEADD(YY, 1 * Occurrence, DueDates)
													 END					

						ELSE CASE WHEN DueDate > OneTimeDueDate THEN NULL
								  ELSE OneTimeDueDate
							 END
					 END 
			END AS NextDueDates 
		   ,SeqNo
		   ,ProviderId
		   ,AccessType
		INTO #NextContactDates   	
		FROM #SourceForNextContactDate CTEBNC
		LEFT JOIN PatientTaskTemplateInterval PTTI ON CTEBNC.PatientTaskTemplateIntervalId = PTTI.PatientTaskTemplateIntervalId
		--WHERE SeqNo <= 2
		
		SELECT DISTINCT
			PatientTaskTemplateScheduleId
			,PatientId
			,ManagedPopulationId
			,TaskTypeId
			,TypeId
			,TaskStatusId
			,StartDate
			,EndDate
			,DueDates
			,DueDatesDateFormat
			,PrimarySNO
			,MissedopportunityType
			,DueDate
			,OccurrenceType 
			,Occurrence
			,CASE WHEN ISNULL(NextDueDates,'1900-01-01') > EndDate THEN DATEADD(MI,1,EndDate)
				ELSE NextDueDates
			 END AS NextDueDates
			,SeqNo	
			,ProviderId
			,AccessType
		INTO #NextDates
		FROM #NextContactDates
		WHERE DueDates BETWEEN StartDate AND CASE WHEN OccurrenceType IN ('H','D','O') THEN EndDate 
												ELSE  DATEADD(DD,-1,EndDate)
											END 

		SELECT DISTINCT
			PatientTaskTemplateScheduleId
			,PatientId
			,ManagedPopulationId
			,TaskTypeId
			,TypeId
			,TaskStatusId
			,StartDate
			,EndDate
			,DueDates
			,DueDatesDateFormat
			,PrimarySNO
			,MissedopportunityType
			,DueDate
			,OccurrenceType 
			,Occurrence
			,NextDueDates 
			,SeqNo	
			,ProviderId
			,DENSE_RANK() OVER (PARTITION BY PatientId,TaskTypeId,TypeId ORDER BY ISNULL(NextDueDates,'9999-12-31')) AS SNO
			,AccessType
		INTO #NextDueDates
		FROM #NextDates
		--WHERE DueDates BETWEEN StartDate AND CASE WHEN OccurrenceType IN ('H','D') THEN EndDate 
		--										ELSE  DATEADD(DD,-1,EndDate)
		--		
									--END  
	

	INSERT INTO PatientTask (
		PatientTaskTemplateScheduleId
		,PatientId
		,ManagedPopulationId
		,TaskTypeId
		,TypeId
		,TaskStatusId
		,DueDate
		,DateTaken
		,MissedOpportunityDate
		,NextContactDate
		,NextOccurence
		,ProviderId
		,Comments
		,CreatedByUserId
		,PatientProgramId
		,AccessType
		)
	SELECT
		PatientTaskTemplateScheduleId 
	    ,PatientId 
		,ManagedPopulationId
		,TaskTypeId 
		,TypeId
		,TaskStatusId
		,DueDates
		,NULL 
		,CASE WHEN NextContactDate >= EndDate THEN EndDate
			  ELSE CASE 
						WHEN MissedopportunityType = 'L' THEN ISNULL(DATEADD(HH,DATEPART(HH,NextContactDate),CAST(CAST(NextContactDate AS DATE) AS DATETIME)),EndDate)
						WHEN MissedopportunityType = 'E' THEN EndDate
						ELSE ISNULL(DATEADD(HH, DATEDIFF(HH, DueDates, DATEADD(HH,DATEPART(HH,NextContactDate),CAST(CAST(NextContactDate AS DATE) AS DATETIME))) / 2, DueDates),EndDate)
				   END
		 END AS MissedOpportunityDate
		,CASE WHEN CSD1OccurrenceType = 'O'  OR DATEDIFF(MI,DueDates,NextContactDate) <=59 THEN DT.DueDates2
			ELSE DATEADD(HH,DATEPART(HH,NextContactDate),CAST(CAST(NextContactDate AS DATE) AS DATETIME)) 
		 END AS NextContactDate
		,NULL
		,ProviderID
		,NULL
		,@i_AppUserId
		,(SELECT MAX(PatientProgramId)
		 FROM PatientProgram PP WITH(NOLOCK)
		 WHERE PP.PatientID = DT.PatientId
		 AND PP.ProgramID = DT.ManagedPopulationId
		)
		,AccessType
	FROM (
			SELECT DISTINCT CSD1.PatientTaskTemplateScheduleId
				,CSD1.PatientId
				,CSD1.ManagedPopulationId
				,CSD1.TaskTypeId
				,CSD1.TypeId
				,CSD1.TaskStatusId
				,CSD1.DueDates
				,CSD2.DueDates AS DueDates2
				,CSD1.EndDate
				,CASE WHEN NDD.NextDueDates BETWEEN NDD.StartDate AND NDD.EndDate AND NDD.NextDueDates > CSD1.DueDates AND CSD1.OccurrenceType <> 'O' THEN NextDueDates
					  ELSE CSD2.DueDates 
				 END AS NextContactDate
				,CSD1.ProviderID
				,CSD1.MissedopportunityType
				,CSD1.OccurrenceType AS CSD1OccurrenceType 
				,CSD2.OccurrenceType AS CSD2OccurrenceType
				,CSD1.AccessType
			FROM #TempPatientTask CSD1
			INNER JOIN #NextDueDates NDD ON CSD1.PatientTaskTemplateScheduleId = NDD.PatientTaskTemplateScheduleId
											AND CSD1.SeqNo = NDD.SeqNo
											AND CSD1.DueDates = NDD.DueDates
			LEFT JOIN #TempPatientTask CSD2 ON CSD1.PrimarySNO = CSD2.PrimarySNO
				AND CSD1.SeqNo + 1 = CSD2.SeqNo
				
			WHERE CSD1.SeqNo = 1
			AND NDD.SNO = 1
			AND CSD1.DueDates BETWEEN CSD1.StartDate AND CASE WHEN CSD1.OccurrenceType IN('H','O') THEN CSD1.EndDate  
															  WHEN CSD1.OccurrenceType = 'D' THEN DATEADD(MI,-59,CSD1.EndDate)  
															  ELSE  DATEADD(DD,-1,CSD1.EndDate)
														 END 
		) DT
		WHERE NOT EXISTS (SELECT 1
						  FROM PatientTask PT WITH(NOLOCK)
						  WHERE PT.PatientTaskTemplateScheduleId = DT.PatientTaskTemplateScheduleId
						  AND PT.DueDate = DT.DueDates)


	INSERT INTO PatientEducationMaterialDocument
	(
		PatientTaskId
		,PatientTaskTemplateDocumentId
		,CreatedByUserId
	)
	SELECT DISTINCT
		PT.PatientTaskId 
		,PTD.PatientTaskTemplateDocumentId
		,@i_AppUserId
	FROM PatientTaskTemplateDocument PTD WITH(NOLOCK)
	INNER JOIN #TempPatientTask TTPT
	ON PTD.PatientTaskTemplateScheduleId = TTPT.PatientTaskTemplateScheduleId
	INNER JOIN PatientTask PT WITH(NOLOCK) 
	ON TTPT.PatientTaskTemplateScheduleId = PT.PatientTaskTemplateScheduleId
	WHERE PT.TaskStatusId = @i_TaskStatusId 
	AND NOT EXISTS (SELECT 1
					FROM PatientEducationMaterialDocument PEMD WITH(NOLOCK)
					WHERE PEMD.PatientTaskId = PT.PatientTaskId
					AND PEMD.PatientTaskTemplateDocumentId = PTD.PatientTaskTemplateDocumentId)
		
			
	IF (@l_TranStarted = 1) -- If transactions are there, then commit
	BEGIN
		SET @l_TranStarted = 0

		COMMIT TRANSACTION
	END
END TRY

--------------------------------------------------------     
BEGIN CATCH
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH