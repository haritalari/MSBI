﻿/*                  
------------------------------------------------------------------------------                  
Procedure Name: usp_CareProviderDashBoard_ClosedCompleteByPatient  87163,12,'V',23      
Description   : This procedure is used to get the open tasks select by patientID             
Created By    : Wasim Ahmed
Created Date  : 29-Jun-2014
10-Sep-2015 Santosh Modified the SP as per NAVI-3908,3807
18-Mar-2016 Rathnam modified as per new task architecture
29-Mar-2016 Rathnam modified the SP as per NAVI-5618
27-09-2016 Rathnam NAVI-5589 Define Rejected Reasons on Patient Submitted Tasks
------------------------------------------------------------------------------   
*/
CREATE PROCEDURE [dbo].[usp_CareProviderDashBoard_ClosedCompleteByPatient] (
	@i_AppUserId INT
	,@i_PatientUserID INT
	,@i_StartIndex INT = 1
	,@i_EndIndex INT = 20
	,@tblTaskStatus TypeIDAndName READONLY
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	SELECT ty.TaskTypeName TaskTypeName
		,t.DueDate DateDue
		,t.TypeID
		,dbo.ufn_GetTypeNamesByTypeId(ty.TaskTypeName, t.TypeID) TypeName
		,t.DateTaken LastTaskCompletedDate
		,t.PatientTaskID Taskid
		,ProgramName
		,pr.StatusCode as ProgramStatus
	FROM PatientTask t WITH (NOLOCK)
	INNER JOIN Program Pr ON Pr.ProgramId = t.ManagedPopulationId
	INNER JOIN @tblTaskStatus ts ON ts.TypeId = t.TaskStatusId
	INNER JOIN TaskType ty WITH (NOLOCK) ON t.TaskTypeId = ty.TaskTypeId
	WHERE t.PatientId = @i_PatientUserID
	ORDER BY t.DateTaken DESC OFFSET(@i_StartIndex - 1) * @i_EndIndex ROWS

	FETCH NEXT @i_EndIndex ROWS ONLY;

	IF (@i_StartIndex = 1)
	BEGIN
		SELECT count(1) ClosedCompleteCount
		FROM PatientTask t1 WITH (NOLOCK)
		INNER JOIN @tblTaskStatus ts ON ts.TypeId = t1.TaskStatusId
		WHERE t1.PatientId = @i_PatientUserID
	END
END TRY

--------------------------------------------------------                   
BEGIN CATCH
	-- Handle exception                  
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH
GO

