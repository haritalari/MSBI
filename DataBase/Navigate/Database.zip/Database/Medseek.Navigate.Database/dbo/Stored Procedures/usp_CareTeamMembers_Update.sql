﻿/*      
------------------------------------------------------------------------------      
Procedure Name: usp_CareTeamMembers_Update  
Description   : This procedure is used to update record in CareTeamMembers table.  
Created By    : Aditya      
Created Date  : 15-Mar-2010      
------------------------------------------------------------------------------      
Log History   :       
DD-MM-YYYY  BY   DESCRIPTION      
27-Sep-2010 NagaBabu Modified return statement by returning 0     
26-Nov-2015 Nagababu Added logic to insert and delete data into ProgramProvider as per the NAVI-4347
13-04-2016 Rathnam modified as per NAVI-5796
------------------------------------------------------------------------------      
*/    
CREATE PROCEDURE [dbo].[usp_CareTeamMembers_Update]  
(    
  @i_AppUserId KeyID ,  
  @i_UserId KeyID,  
  @i_CareTeamId KeyID,  
  @i_IsCareTeamManager KeyID,  
  @vc_StatusCode StatusCode    
)    
AS    
BEGIN TRY  
  
      SET NOCOUNT ON
	  DECLARE @l_numberOfRecordsUpdated INT 
	  -- Check if valid Application User ID is passed      
	  IF ( @i_AppUserId IS NULL ) OR ( @i_AppUserId <= 0 )    
	  BEGIN    
		  RAISERROR   
		  ( N'Invalid Application User ID %d passed.' ,    
		    17 ,    
		    1 ,    
		    @i_AppUserId  
		  )    
	  END  
 
    
---------Update operation into CareTeamMembers table-----    

   
	  UPDATE
			CareTeamMembers  
		 SET 
			IsCareTeamManager = @i_IsCareTeamManager,  
			StatusCode = @vc_StatusCode,  
			LastModifiedByUserId = @i_AppUserId,  
			LastModifiedDate = GETDATE()  
	   WHERE 
			CareTeamId = @i_CareTeamId  
			AND ProviderID = @i_UserId
			
		IF @vc_StatusCode = 'A'
			BEGIN
				INSERT INTO ProgramProvider
				(
					ProgramID
					,ProviderID
					,CreatedByUserID
				)
				SELECT DISTINCT 
					PCT.ProgramId
					,CTM.ProviderID
					,@i_AppUserId
				FROM ProgramCareTeam PCT
				INNER JOIN CareTeamMembers CTM ON PCT.CareTeamId = CTM.CareTeamId
				WHERE CTM.ProviderID = @i_UserId
				AND CTM.CareTeamId = @i_CareTeamId
				AND NOT EXISTS (SELECT 1
								FROM ProgramProvider PP WITH(NOLOCK)
								WHERE PP.ProgramId = PCT.ProgramId
								AND PP.ProviderId = @i_UserId)
			
			END	
		ELSE 
			BEGIN

				SELECT pp.ProgramID, pp.ProviderID INTO #prg FROM ProgramProvider  pp
				INNER JOIN CareTeamMembers ctm	
				on pp.ProviderID = ctm.ProviderID
				WHERE ctm.CareTeamId = @i_CareTeamId
				AND ctm.ProviderID = @i_UserId

				DELETE FROM ProgramProvider WHERE EXISTS (SELECT 1 FROM #prg p WHERE P.ProgramID = ProgramProvider.ProgramID
				and P.ProviderID = ProgramProvider.ProviderID
				)
				
			END			   
        
		SELECT @l_numberOfRecordsUpdated = @@ROWCOUNT

        RETURN 0
        
END TRY      
--------------------------------------------------------       
BEGIN CATCH      
    -- Handle exception      
      DECLARE @i_ReturnedErrorID INT    
      EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException   
     @i_UserId = @i_AppUserId    
    
      RETURN @i_ReturnedErrorID    
END CATCH