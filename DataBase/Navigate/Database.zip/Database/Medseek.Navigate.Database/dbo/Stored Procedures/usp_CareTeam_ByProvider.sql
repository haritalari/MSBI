﻿/*
--------------------------------------------------------------------------------------------------------------            
Procedure Name: [usp_CareTeam_ByProvider] 88071
Description   : This is used to select the careteams for given provider
Created By    : Nagababu S
Created Date  : 24-Nov-2015
---------------------------------------------------------------------------------------------------------------            
Log History   :
DD-Mon-YYYY  BY  DESCRIPTION
----------------------------------------------------------------------------------------------------------------        
 */
CREATE PROCEDURE [dbo].[usp_CareTeam_ByProvider] (@i_ProviderId KeyId)
AS
BEGIN TRY
	SET NOCOUNT ON

	-- Check if valid Application User ID is passed
	IF (@i_ProviderId IS NULL)
		OR (@i_ProviderId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_ProviderId
				)
	END

	;WITH CtmCTE
	AS (
		SELECT COUNT(DISTINCT ctm.ProviderID) Cntprovider
			,ctm.CareTeamId
		FROM CareTeamMembers ctm
		INNER JOIN (
			SELECT DISTINCT CareTeamId
			FROM CareTeamMembers
			WHERE ProviderID = @i_ProviderId AND StatusCode = 'A'
			) T ON T.CareTeamId = ctm.CareTeamId
			AND ctm.StatusCode = 'A'
		INNER JOIN Provider pr ON pr.ProviderID = ctm.ProviderID
		GROUP BY ctm.CareTeamId
		)
	SELECT DISTINCT DT.ProgramName
	INTO #careteams
	FROM CareTeamMembers CTM
	LEFT JOIN (
		SELECT CareTeamName AS ProgramName
			,C.CareTeamId
		FROM CtmCTE C
		INNER JOIN CareTeam CT ON C.CareTeamId = CT.CareTeamId
		WHERE Cntprovider = 1
		) DT ON CTM.CareTeamId = DT.CareTeamId
	WHERE Providerid = @i_ProviderId

	IF (
			(
				SELECT COUNT(1)
				FROM #careteams
				WHERE ProgramName IS NOT NULL
				) > 0
			)
	BEGIN
		SELECT DISTINCT (
				SELECT TOP 1 dbo.ufn_GetProviderName(Providerid)
				FROM PatientProgram
				WHERE ProviderID = @i_ProviderId
					AND StatusCode = 'E'
				) AS CareLeadName
			,ProgramName
		FROM #careteams
		WHERE ProgramName IS NOT NULL
		ORDER BY ProgramName
	END
	ELSE
	BEGIN
		SELECT DISTINCT  (
				SELECT TOP 1 dbo.ufn_GetProviderName(Providerid)
				FROM PatientProgram
				WHERE ProviderID = @i_ProviderId
					AND StatusCode= 'E'
				)AS CareLeadName
			,null AS ProgramName
	END
END TRY

BEGIN CATCH
	----------------------------------------------------------------------------------------------------------           
	-- Handle exception
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_ProviderId

	RETURN @i_ReturnedErrorID
END CATCH
