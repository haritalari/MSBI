﻿/*---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_HEDIS-L_HealthPlans_CDC_GetNumerator_LDL-C_Test_Count_2012]
Description   : This proc is used to populating the configuerd numerator patient count
Created By    :   
Created Date  : 
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY	DESCRIPTION  
26/09/2015  NagaSiva Added parameter @ECTTableName and modified code to optimize performance Navi-4455
08/12/2015  Srinivas  Added parameter Sniffing to avoid unnecessary compilations, and reducing the number of ad-hoc queries in the plan cache
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_HEDIS-L_HealthPlans_CDC_GetNumerator_LDL-C_Test_Count_2012] (
	@PopulationDefinitionID INT
	,@MetricID INT
	,@Num_Months_Prior INT = 12
	,@Num_Months_After INT = 0
	,@ECTCodeVersion_Year INT = 2012
	,@ECTCodeStatus VARCHAR(1) = 'A'
	,@AnchorDate_Year INT = 2012
	,@AnchorDate_Month VARCHAR(2) = 12
	,@AnchorDate_Day VARCHAR(2) = 31
	,@ReportType CHAR(1)='P'--S For Strategic Companion,P for Population
	,@ECTTableName VARCHAR(20)='CDC-H'
	)
AS
BEGIN
SET NOCOUNT ON
/************************************************************ INPUT PARAMETERS ************************************************************  
  
  @PopulationDefinitionID = Handle to the selected Population of Patients from which the Eligible Population of Patients of the Numerator  
          are to be constructed.  
  
  @Num_Months_Prior = Number of Months Before the Anchor Date from which Eligible Population of Patients with desired Encounter Claims  
       is to be constructed.  
  
  @Num_Months_After = Number of Months After the Anchor Date from which Eligible Population of Patients with desired Encounter Claims  
       is to be constructed.  
  
  @ECTCodeVersion_Year = Code Version Year from which valid HEDIS-associated ECT and Drug Codes during the Measurement Period that are  
          retrieved to identify Patients for inclusion in the Eligible Population of Patients.  
  
  @ECTCodeStatus = Status of valid HEDIS-associated ECT and Drug Codes during the Measurement Period that are retrieved to identify Patients  
       for inclusion in the Eligible Population of Patients during the Measurement Period.  
       Examples = 1 (for 'Enabled') or 0 (for 'No').  
  
  *********************************************************************************************************************************************/
/* Retrieves Count of Patients with Performed Procedures with Procedure Codes during the Measurement Period. */
DECLARE @v_DenominatorType VARCHAR(1)
	,@i_ManagedPopulationID INT
	,@DateKey VARCHAR(10),
	@vc_tableName VARCHAR(50)='##NrPatientCount',
	@vc_Sql VARCHAR(MAX)
	,@param_PopulationDefinitionID INT
	,@param_MetricID INT
	,@param_Num_Months_Prior INT 
	,@param_Num_Months_After INT
	,@param_ECTCodeVersion_Year INT 
	,@param_ECTCodeStatus VARCHAR(1) 
	,@param_AnchorDate_Year INT
	,@param_AnchorDate_Month VARCHAR(2)
	,@param_AnchorDate_Day VARCHAR(2)
	,@param_ReportType CHAR(1)
	,@param_ECTTableName VARCHAR(20)

	SET @param_PopulationDefinitionID  =@PopulationDefinitionID 
	SET @param_MetricID =@MetricID
	SET @param_Num_Months_Prior =@Num_Months_Prior
	SET @param_Num_Months_After =@Num_Months_After
	SET @param_ECTCodeVersion_Year =@ECTCodeVersion_Year
	SET @param_ECTCodeStatus =@ECTCodeStatus
	SET @param_AnchorDate_Year =@AnchorDate_Year
	SET @param_AnchorDate_Month =@AnchorDate_Month
	SET @param_AnchorDate_Day =@AnchorDate_Day
	SET @param_ReportType  =@ReportType
	SET @param_ECTTableName =@ECTTableName


SELECT @v_DenominatorType = m.DenominatorType
	,@i_ManagedPopulationID = m.ManagedPopulationID
FROM Metric m
WHERE m.MetricId = @param_MetricID


CREATE TABLE #PDNR (
	PatientID INT
	,[Count] INT
	,IsIndicator BIT
	)
SET @DateKey = CONVERT(VARCHAR(10), @param_AnchorDate_Year) + CONVERT(VARCHAR(10),@param_AnchorDate_Month) + CONVERT(VARCHAR(10),@param_AnchorDate_Day)


SELECT [ECTCode] INTO #cpt
	FROM dbo.ufn_HEDIS_GetECTCodeInfo_ByTableName(@param_ECTTableName, @param_ECTCodeVersion_Year, @param_ECTCodeStatus)
	WHERE [ECTHedisCodeTypeCode] IN (
			'CPT'
			,'CPT-CAT-II'
			,'HCPCS'
			)
	SELECT [ECTCode] INTO #icd
			FROM dbo.ufn_HEDIS_GetECTCodeInfo_ByTableName(@param_ECTTableName, @param_ECTCodeVersion_Year, @param_ECTCodeStatus)
			WHERE [ECTHedisCodeTypeCode] IN (
					'ICD9-Proc'
					,'ICD10-Proc')

IF @v_DenominatorType = 'M'
	AND @i_ManagedPopulationID IS NOT NULL
BEGIN
	INSERT INTO #PDNR
	SELECT  pat.[PatientID]
		,COUNT(*) AS 'Count'
		,0 AS 'IsIndicator'
	FROM (
		SELECT DISTINCT  ci.[PatientID]
			,cl.BeginServiceDate
		FROM [dbo].[ClaimLine] cl WITH (NOLOCK)
		INNER JOIN [dbo].[ClaimInfo] ci WITH (NOLOCK) ON ci.[ClaimInfoID] = cl.[ClaimInfoID]
		INNER JOIN [dbo].[PopulationDefinitionPatients] p WITH (NOLOCK) ON p.[PatientID] = ci.[PatientID]
		INNER JOIN PopulationDefinitionPatientAnchorDate pdpad
		   ON pdpad.PopulationDefinitionPatientID = p.PopulationDefinitionPatientID	
		INNER JOIN PatientProgram pp WITH (NOLOCK) ON pp.PatientID = p.PatientID
		INNER JOIN [dbo].[CodeSetProcedure] cod_proc WITH (NOLOCK) ON (cod_proc.[ProcedureCodeID] = cl.[ProcedureCodeID])
		INNER JOIN #cpt cpt
			ON cpt.ECTCode = cod_proc.ProcedureCode
		WHERE (
				cl.[BeginServiceDate] BETWEEN (DATEADD(MM, - @param_Num_Months_Prior, DATEADD(YYYY, 0, pdpad.OutPutAnchorDate)))
					AND (DATEADD(MM, @param_Num_Months_After, DATEADD(YYYY, 0, pdpad.OutPutAnchorDate)))
				)
			AND PopulationDefinitionID = @param_PopulationDefinitionID
			AND pp.ProgramID = @i_ManagedPopulationID
			AND pdpad.DateKey = @DateKey
			AND pdpad.OutPutAnchorDate  = CASE 
						WHEN pdpad.OutPutAnchorDate BETWEEN DATEADD(dd, - (DAY(PP.EnrollmentStartDate) - 1), PP.EnrollmentStartDate)
								AND CASE 
										WHEN YEAR(ISNULL(PP.EnrollmentEndDate, '9999-12-31')) = 9999
											THEN ISNULL(PP.EnrollmentEndDate, '9999-12-31')
										ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, PP.EnrollmentEndDate) + 1, 0))
										END
							THEN pdpad.OutPutAnchorDate
						ELSE NULL
						END
		
		UNION
		
		SELECT  ci.[PatientID]
			 ,ci.DateOfAdmit AS BeginServiceDate
		FROM [dbo].[ClaimInfo] ci WITH (NOLOCK)
		INNER JOIN [dbo].[PopulationDefinitionPatients] p ON p.[PatientID] = ci.[PatientID]
		INNER JOIN PatientProgram pp WITH (NOLOCK) ON pp.PatientID = p.PatientID
		INNER JOIN PopulationDefinitionPatientAnchorDate pdpad WITH (NOLOCK) 
		ON pdpad.PopulationDefinitionPatientID = P.PopulationDefinitionPatientID
		INNER JOIN [dbo].[ClaimProcedure] cp WITH (NOLOCK) ON cp.[ClaimInfoID] = ci.[ClaimInfoID]
		INNER JOIN [dbo].[CodeSetICDProcedure] cod_iproc WITH (NOLOCK) ON (cod_iproc.[ProcedureCodeID] = cp.[ProcedureCodeID])
		INNER JOIN #icd icdproc
		    ON icdproc.ECTCode = cod_iproc.ProcedureCode
		WHERE (
				ci.[DateOfAdmit] BETWEEN (DATEADD(MM, - @param_Num_Months_Prior, DATEADD(YYYY, 0, pdpad.OutPutAnchorDate)))
					AND (DATEADD(MM, @param_Num_Months_After, DATEADD(YYYY, 0, pdpad.OutPutAnchorDate)))
				)
			AND PopulationDefinitionID = @param_PopulationDefinitionID
			AND pp.ProgramID = @i_ManagedPopulationID
			AND pdpad.DateKey = @DateKey
			AND pdpad.OutPutAnchorDate  = CASE 
						WHEN pdpad.OutPutAnchorDate BETWEEN DATEADD(dd, - (DAY(PP.EnrollmentStartDate) - 1), PP.EnrollmentStartDate)
								AND CASE 
										WHEN YEAR(ISNULL(PP.EnrollmentEndDate, '9999-12-31')) = 9999
											THEN ISNULL(PP.EnrollmentEndDate, '9999-12-31')
										ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, PP.EnrollmentEndDate) + 1, 0))
										END
							THEN pdpad.OutPutAnchorDate
						ELSE NULL
						END
		) AS pat
	GROUP BY pat.[PatientID]
END
ELSE
BEGIN
	INSERT INTO #PDNR
	SELECT  pat.[PatientID]
		,COUNT(*) AS 'Count'
		,0 AS 'IsIndicator'
	FROM (
		SELECT  ci.[PatientID]
			,cl.BeginServiceDate
	FROM [dbo].[ClaimLine] cl WITH(NOLOCK)
	INNER JOIN [dbo].[ClaimInfo] ci WITH(NOLOCK)
		ON ci.[ClaimInfoID] = cl.[ClaimInfoID]
	INNER JOIN [dbo].PopulationDefinitionPatients pdp WITH(NOLOCK)
		ON pdp.[PatientID] = ci.[PatientID]
	INNER JOIN PopulationDefinitionPatientAnchorDate pdpad
		ON pdpad.PopulationDefinitionPatientID = pdp.PopulationDefinitionPatientID	
		INNER JOIN [dbo].[CodeSetProcedure] cod_proc WITH(NOLOCK)
		ON (cod_proc.[ProcedureCodeID] = cl.[ProcedureCodeID])
	INNER JOIN #cpt cpt
		ON cpt.ECTCode = cod_proc.ProcedureCode
		
	WHERE (
			cl.[BeginServiceDate] BETWEEN (DATEADD(MM, - @param_Num_Months_Prior, DATEADD(YYYY, 0, pdpad.OutPutAnchorDate )))
				AND (DATEADD(MM, @param_Num_Months_After, DATEADD(YYYY, 0, pdpad.OutPutAnchorDate)))
			)
		AND pdp.PopulationDefinitionID = @param_PopulationDefinitionID
		AND pdpad.DateKey = @DateKey
			
	 UNION
	SELECT   ci.[PatientID]
			,ci.DateOfAdmit AS BeginServiceDate
	FROM [dbo].[ClaimInfo] ci WITH(NOLOCK)
	INNER JOIN [dbo].PopulationDefinitionPatients pdp WITH(NOLOCK)
		ON pdp.[PatientID] = ci.[PatientID]
	INNER JOIN PopulationDefinitionPatientAnchorDate pdpad
		ON pdpad.PopulationDefinitionPatientID = pdp.PopulationDefinitionPatientID
	INNER JOIN [dbo].[ClaimProcedure] cp WITH(NOLOCK)
		ON cp.[ClaimInfoID] = ci.[ClaimInfoID]
	INNER JOIN [dbo].[CodeSetICDProcedure] cod_iproc WITH(NOLOCK)
		ON (cod_iproc.[ProcedureCodeID] = cp.[ProcedureCodeID])
	INNER JOIN  #icd icdproc
		ON icdproc.ECTCode = cod_iproc.ProcedureCode
		
	WHERE (
			ci.[DateOfAdmit] BETWEEN (DATEADD(MM, - @param_Num_Months_Prior, DATEADD(YYYY, 0, pdpad.OutPutAnchorDate)))
				AND (DATEADD(MM, @param_Num_Months_After, DATEADD(YYYY, 0, pdpad.OutPutAnchorDate)))
			)
		AND pdp.PopulationDefinitionID = @param_PopulationDefinitionID
			AND pdpad.DateKey = @DateKey
		) AS pat
	GROUP BY pat.[PatientID]
END

	IF EXISTS(SELECT 1 FROM Tempdb.dbo.sysobjects WHERE Name =@vc_tableName+'_'+@datekey)
	BEGIN 
	    
		SET @vc_Sql =' DELETE FROM ' +@vc_tableName+'_'+@datekey+ ' WHERE Datekey ='+@datekey+' AND MetricId ='+CAST(@param_MetricID AS VARCHAR)
			EXEC(@vc_Sql)		
		SET	@vc_Sql= 'INSERT INTO '+@vc_tableName+'_'+@datekey+'(MetricID,PatientID,[Count],IsIndicator,DateKey)
					  SELECT '+CAST(@param_MetricID AS VARCHAR)+' ,'+'PatientID,[Count],IsIndicator,'+@DateKey +' FROM #PDNR'
		--PRINT(@vc_SQL)
		EXEC(@vc_Sql)
	END
	ELSE
	BEGIN
		SET @vc_Sql ='SELECT '+CAST(@param_MetricID AS VARCHAR)+' AS MetricId,PatientID,[Count],IsIndicator,'+@DateKey + 'AS DateKey INTO '+@vc_tableName+'_'+@datekey+' FROM #PDNR'
	
		--PRINT(@vc_Sql)
		EXEC(@vc_Sql)
	END


	DROP TABLE #PDNR
	DROP TABLE #cpt
	DROP TABLE #icd
END
