﻿
/*  
---------------------------------------------------------------------------------------  
Procedure Name: dbo].[usp_Batch_SCOLAP_Dim] 1
Description   : This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Nagasiva  
Created Date  : 22-Jan-2014
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
13-Feb-2015 Nagasiva  assigned null value to  @i_AppUserId  Parameter to remove the hardcoded userid in cube execution package
25-Feb-2016 Yugandhar Modified the sp as per NAVI- 5338
11-Apr-2016 Nagababu Modified the logic as per NAVI-5691
29-Sep-2016 Rathnam Modified the logic as per NAVI-6815
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_SCOLAP_Dim] (@i_AppUserId INT = NULL)
AS
BEGIN TRY
	SET NOCOUNT ON

	SELECT @i_AppUserId = MIN(UserId)
	FROM Users WITH (NOLOCK)

	  DECLARE @d_StartDate DATE
	      DECLARE @d_EndDate DATE

	
	SET @d_EndDate = CONVERT(DATE,GETDATE())

	SET @d_StartDate = DATEADD(yy, - 1, @d_EndDate)

	SELECT @d_EndDate = DATEADD(day, 0 - day(dateadd(month, 1, @d_EndDate)), dateadd(month, 1, @d_EndDate))

	WHILE @d_StartDate <= @d_EndDate
	BEGIN
		SET @d_StartDate = DATEADD(day, 0 - day(dateadd(month, 1, @d_StartDate)), dateadd(month, 1, @d_StartDate))

		INSERT INTO AnchorDate (
			datekey
			,anchordate
			,calendarquarter
			,calendarsemester
			,englishmonthname
			,calenderyear
			)
		SELECT CAST(CONVERT(VARCHAR(8), CONVERT(DATE, @d_StartDate), 112) AS INT)
			,CAST(@d_StartDate AS DATE)
			,CASE 
				WHEN Datepart(month, @d_StartDate) BETWEEN 1
						AND 3
					THEN 'Quarter1'
				WHEN Datepart(month, @d_StartDate) BETWEEN 4
						AND 6
					THEN 'Quarter2'
				WHEN Datepart(month, @d_StartDate) BETWEEN 7
						AND 9
					THEN 'Quarter3'
				WHEN Datepart(month, @d_StartDate) BETWEEN 10
						AND 12
					THEN 'Quarter4'
				END
			,CASE 
				WHEN Datepart(month, @d_StartDate) BETWEEN 1
						AND 6
					THEN 'Semister1'
				WHEN Datepart(month, @d_StartDate) BETWEEN 7
						AND 12
					THEN 'Semister2'
				END
			,Datename(month, @d_StartDate)
			,Datename(year, @d_StartDate)
		WHERE NOT EXISTS (
				SELECT 1
				FROM AnchorDate a
				WHERE a.AnchorDate = Cast(@d_StartDate AS DATE)
				)

		SET @d_StartDate = DATEADD(dd, 1, @d_StartDate)
	END 

	
	IF OBJECT_ID('TEMPDB..##OLAP_SC_DimAnchordate') IS NOT NULL
		DROP TABLE ##OLAP_SC_DimAnchordate

	SELECT DateKey
		,AnchorDate
		,CalendarQuarter
		,CalendarSemester
		,EnglishMonthName
		,CalenderYear
	INTO ##OLAP_SC_DimAnchordate
	FROM AnchorDate WITH (NOLOCK)

	IF OBJECT_ID('TEMPDB..##OLAP_SC_DimLkUpCodeType') IS NOT NULL
		DROP TABLE ##OLAP_SC_DimLkUpCodeType

	SELECT CodeTypeID AS CodeTypeKey
		,CodeTypeCode AS Description
	INTO ##OLAP_SC_DimLkUpCodeType
	FROM LkUpCodeType WITH (NOLOCK)

	IF OBJECT_ID('TEMPDB..##OLAP_SC_DimUtilization') IS NOT NULL
		DROP TABLE ##OLAP_SC_DimUtilization

	SELECT CodeGroupingID AS UtilizationKey
		,CodeGroupingDescription AS [Description]
	INTO ##OLAP_SC_DimUtilization
	FROM CodeGrouping cg WITH (NOLOCK)
	INNER JOIN CodeTypeGroupers ctg WITH (NOLOCK) ON cg.CodeTypeGroupersID = ctg.CodeTypeGroupersID
	WHERE CodeTypeGroupersName = 'Encounter Types(Internal)'

	IF OBJECT_ID('TEMPDB..##OLAP_SC_DimPatient') IS NOT NULL
		DROP TABLE ##OLAP_SC_DimPatient

	SELECT DISTINCT PatientID AS PatientKey
		,ISNULL(FirstName + ' ', '') + '' + ISNULL(LastName, '') AS FullName
		,ISNULL(MedicalRecordNumber, MemberID) MedicalRecordNumber
		,convert(date,DateOfBirth) DateOfBirth
		,dbo.ufn_GetAgeByDOB(DateOfBirth) AS Age
		,Gender
		,PrimaryPhoneNumber AS PhoneNo
	INTO ##OLAP_SC_DimPatient
	FROM Patient WITH (NOLOCK)

	IF OBJECT_ID('TEMPDB..##OLAP_SC_DimHealthPlan') IS NOT NULL
		DROP TABLE ##OLAP_SC_DimHealthPlan

	SELECT InsuranceGroupID AS HealthPlanKey
		,GroupName AS NAME
	INTO ##OLAP_SC_DimHealthPlan
	FROM InsuranceGroup WITH (NOLOCK)
	WHERE GroupName IS NOT NULL

	DECLARE @i_NoInsuranceGroupId INT
	SELECT @i_NoInsuranceGroupId = IG.InsuranceGroupId
	FROM InsuranceGroup IG
	WHERE IG.InternalID = '000'

	IF OBJECT_ID('TEMPDB..##OLAP_SC_DimProduct') IS NOT NULL
		DROP TABLE ##OLAP_SC_DimProduct

	CREATE TABLE ##OLAP_SC_DimProduct (
		ProductKey INT IDENTITY(1, 1)
		,[Description] VARCHAR(50)
		,ProductCode CHAR(1)
		,
		)

	INSERT INTO ##OLAP_SC_DimProduct (
		[Description]
		,ProductCode
		)
	SELECT DISTINCT CASE
			WHEN h.InsuranceGroupId = @i_NoInsuranceGroupId AND ProductType = 'N' 
				THEN 'No insurance info'
			WHEN ProductType = 'C'
				THEN 'Commercial'
			WHEN ProductType = 'M'
				THEN 'Medicare'
			WHEN ProductType = 'H'
				THEN 'HMO'
			WHEN ProductType = 'P'
				THEN 'PPO'
			END [Description]
		,ProductType AS ProductCode
	FROM InsuranceGroupplan h WITH (NOLOCK)
	WHERE ProductType IS NOT NULL
	ORDER BY ProductType

	IF OBJECT_ID('TEMPDB..##OLAP_SC_DimProviderType') IS NOT NULL
		DROP TABLE ##OLAP_SC_DimProviderType

	SELECT ProviderTypeCodeID AS TypeKey
		,Description
	INTO ##OLAP_SC_DimProviderType
	FROM CodeSetProviderType WITH (NOLOCK)

	IF OBJECT_ID('TEMPDB..##OLAP_SC_DimProvider') IS NOT NULL
		DROP TABLE ##OLAP_SC_DimProvider

	SELECT ProviderID AS ProviderKey
		,LTRIM(DBO.[ufn_GetProviderName](ProviderID)) FullName
		,ProviderTypeID AS TypeKey
		,NPINumber
		,TaxID_EIN_SSN AS TaxIDNumber
	INTO ##OLAP_SC_DimProvider
	FROM [Provider] p WITH (NOLOCK)
	LEFT JOIN CodeSetProviderType pt WITH (NOLOCK) ON p.ProviderTypeID = pt.ProviderTypeCodeID
	--WHERE Description <> 'Administrator'
	--	AND LTRIM(DBO.[ufn_GetProviderName](ProviderID)) <> ''

	IF OBJECT_ID('TEMPDB..##OLAP_SC_DimCodeGroup') IS NOT NULL
		DROP TABLE ##OLAP_SC_DimCodeGroup

	SELECT DISTINCT CG.CodeGroupingID AS CodeGroupKey
		,CG.CodeGroupingName AS CodeDescription
		,cgt.CodeGroupType AS CodeGroupingType
		,ctg.CodeTypeGroupersName AS SourceType
	INTO ##OLAP_SC_DimCodeGroup
	FROM CodeGrouping CG WITH (NOLOCK)
	INNER JOIN CodeTypeGroupers ctg WITH (NOLOCK) ON CG.CodeTypeGroupersID = CTG.CodeTypeGroupersID
	INNER JOIN CodeGroupingType cgt WITH (NOLOCK) ON ctg.CodeGroupingTypeID = cgt.CodeGroupingTypeID

	IF OBJECT_ID('TEMPDB..##DimManagerPopulation') IS NOT NULL
		DROP TABLE ##DimManagerPopulation

	SELECT [ProgramId]
		,replace(ProgramName,'All Patients Managed population','Not a member of Managed population') ProgramName
	INTO ##DimManagerPopulation
	FROM [Program]

	IF OBJECT_ID('TEMPDB..##answer') IS NOT NULL
		DROP TABLE ##answer

	CREATE TABLE ##answer (
		ID INT IDENTITY(1, 1)
		,QuestionId INT
		,AnswerId INT
		,AnswerDescription VARCHAR(5000)
		,IsFreeText BIT
		);

	WITH patanswer
	AS (
		SELECT a.QuestionId
			,a.AnswerId
			,a.AnswerDescription
			,0 IsFreeText
		FROM Answer a
		INNER JOIN Question q ON a.QuestionId = q.QuestionId
		INNER JOIN AnswerType at ON at.AnswerTypeId = q.AnswerTypeId
		WHERE AnswerTypeCode NOT IN (
				'Text'
				,'DateTime'
				,'NumberText'
				)
				
		
		UNION
		
		SELECT q.QuestionId
			,a.AnswerId
			,ISNULL(CASE 
					WHEN a.AnswerDescription = ''
						THEN NULL
					ELSE a.AnswerDescription
					END, uqa.AnswerString)
			,1
		FROM PatientAssessmentAnswer uqa
		INNER JOIN Answer a ON a.AnswerID = uqa.Answerid
		INNER JOIN Question q ON q.QuestionId = a.QuestionId
		INNER JOIN AnswerType at ON at.AnswerTypeId = q.AnswerTypeId
		WHERE AnswerTypeCode IN (
				'Text'
				,'DateTime'
				,'NumberText'
				)
		)
	INSERT INTO ##answer
	SELECT *
	FROM patanswer

	IF OBJECT_ID('TEMPDB..##DimAssessment') IS NOT NULL
		DROP TABLE ##DimAssessment

	CREATE TABLE #SC_DimAssessment (
		[DimAssessmentKey] [int] NOT NULL IDENTITY(1, 1)
		,[AssessmentKey] [int] NOT NULL
		,[QuestionKey] [int] NULL
		,[AnswerKey] [int] NULL
		,[AssessmentText] [varchar](5000) NULL
		,[QuestionText] [varchar](500) NULL
		,[AnswerText] [varchar](5000) NULL
		,[ScoreRange] [varchar](30) NULL
		,ScoreRangeKey INT
		)

	INSERT INTO #SC_DimAssessment
	SELECT DISTINCT qr.QuestionaireId
		,q.QuestionId
		,a.ID AnswerId
		,qr.QuestionaireName
		,q.QuestionText
		,a.AnswerDescription
		,convert(VARCHAR(10), qs.RangeStartScore) + ' - ' + convert(VARCHAR(10), qs.RangeEndScore) ScoreRange
		,qs.QuestionnaireScoringID
	FROM Questionaire qr
	INNER JOIN QuestionaireQuestionSet qqs ON qqs.QuestionaireId = qr.QuestionaireId
	INNER JOIN QuestionSetQuestion qsq ON qsq.QuestionSetId = qqs.QuestionSetId
	INNER JOIN Question q ON q.QuestionId = qsq.QuestionId
	INNER JOIN ##answer a ON a.QuestionId = q.QuestionId
	LEFT JOIN QuestionnaireScoring qs ON qs.QuestionaireId = qr.QuestionaireId

	SELECT [DimAssessmentKey]
		,[AssessmentKey]
		,[QuestionKey]
		,[AnswerKey]
		,[AssessmentText]
		,[QuestionText]
		,[AnswerText]
		,[ScoreRange]
		,ScoreRangeKey
	INTO ##DimAssessment
	FROM #SC_DimAssessment

	IF OBJECT_ID('TEMPDB..##DimCareTeam') IS NOT NULL
		DROP TABLE ##DimCareTeam

	CREATE TABLE #DimCareTeam (
		[DimCareTeamKey] [int] NOT NULL IDENTITY(1, 1)
		,[CareTeamKey] [int] NULL
		,[CareTeamMemberKey] [int] NULL
		,[CareTeamName] [varchar](500) NULL
		,[CareTeamMemberName] [varchar](500) NULL
		)

	INSERT INTO #DimCareTeam
	SELECT DISTINCT ct.CareTeamId
		,ctm.ProviderID
		,ct.CareTeamName
		,dbo.[ufn_GetProviderName](ctm.ProviderID) ProviderName
	FROM CareTeamMembers ctm
	INNER JOIN CareTeam ct ON ct.CareTeamId = ctm.CareTeamId
	WHERE ctm.StatusCode = 'A'

	SELECT *
	INTO ##DimCareTeam
	FROM #DimCareTeam

	IF OBJECT_ID('TEMPDB..##DimPopulation') IS NOT NULL
		DROP TABLE ##DimPopulation

	SELECT PopulationDefinitionID
		,PopulationDefinitionName
	INTO ##DimPopulation
	FROM PopulationDefinition
	WHERE DefinitionType IN (
			'C'
			,'P'
			)

	IF OBJECT_ID('TEMPDB..##Metric') IS NOT NULL
		DROP TABLE ##Metric

	SELECT DISTINCT m.MetricId
		,m.NAME
	INTO ##Metric
	FROM Metric m


	IF OBJECT_ID('TEMPDB..##DimManagedCareTeam') IS NOT NULL
		DROP TABLE ##DimManagedCareTeam
	

	SELECT DISTINCT
		PCT.ProgramId AS ManagedPopulationKey ,
		TDCT.DimCareTeamKey 
	INTO ##DimManagedCareTeam
	FROM ProgramCareTeam PCT
	INNER JOIN ##DimCareTeam TDCT
	ON PCT.CareTeamId = TDCT.CareTeamKey

	-------------------------------------------
	IF OBJECT_ID('TEMPDB..##SC_DimCondition') IS NOT NULL
	DROP TABLE ##SC_DimCondition

	SELECT DISTINCT CG.CodeGroupingID AS CodeGroupKey
		,CG.CodeGroupingName AS CodeGroupName
	INTO ##SC_DimCondition
	FROM CodeGrouping CG WITH (NOLOCK)
	INNER JOIN CodeTypeGroupers CTG WITH (NOLOCK) ON CG.CodeTypeGroupersID = CTG.CodeTypeGroupersID
	INNER JOIN CodeGroupingType CGT WITH (NOLOCK) ON CTG.CodeGroupingTypeID = CGT.CodeGroupingTypeID
	WHERE CTG.CodeTypeGroupersName IN (
				'AHRQ Procedure Groupers'
				,'AHRQ Diagnosis Groupers'
					)
	AND CG.StatusCode = 'A'
	
	UNION 
	
	SELECT 0, 'NA'


END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH