﻿
/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_SCOLAP_FinancialReport] 1
Description   : This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Nagasiva  
Created Date  : 23-Jan-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
13-Feb-2015 Nagasiva  assigned null value to  @i_AppUserId  Parameter to remove the hardcoded userid in cube execution package
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_SCOLAP_FinancialReport] (
	@i_AppUserId KEYID =NULL
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	SELECT @i_AppUserId =MIN(UserId) FROM Users
	

	IF OBJECT_ID('TEMPDB..##OLAP_SC_FactFinancialReport') IS NOT NULL
		DROP TABLE ##OLAP_SC_FactFinancialReport;

	WITH CTE
	AS (
		SELECT DISTINCT Dr.DrKey AS PopulationKey
			,nr.MetricKey
			,igp.InsuranceGroupId AS HealthPlanKey
			,dr.DateKey
			,dr.PatientKey
			,dr.ClaimAmt
		FROM ##OLAP_SC_BridgePatientDr dr WITH (NOLOCK)
		INNER JOIN ##OLAP_SC_BridgePatientNr nr WITH (NOLOCK) ON dr.PatientKey = nr.PatientKey
			AND dr.DrKey = nr.Drkey
		INNER JOIN PatientInsurance pie WITH (NOLOCK) ON pie.PatientID = dr.PatientKey
		INNER JOIN PatientInsuranceBenefit pib WITH (NOLOCK) ON pib.PatientInsuranceID = pie.PatientInsuranceID
		INNER JOIN ReportFrequencyConfiguration rfc WITH (NOLOCK) ON rfc.MetricId = nr.MetricKey
			AND RFC.DrID = DR.DrKey
		INNER JOIN ReportFrequency rf WITH (NOLOCK) ON rf.ReportFrequencyId = rfc.ReportFrequencyId
		INNER JOIN InsuranceGroupPlan igp WITH (NOLOCK) ON igp.InsuranceGroupPlanId = pie.InsuranceGroupPlanId
		INNER JOIN ##OLAP_SC_DimHealthPlan HP
					ON HP.HealthPlanKey = igp.InsuranceGroupId
		INNER JOIN ##OLAP_SC_DimAnchordate ad WITH (NOLOCK) ON ad.DateKey = dr.DateKey
		INNER JOIN Report r WITH (NOLOCK) ON r.ReportId = rf.ReportID
		WHERE nr.DateKey = dr.DateKey
			AND ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pib.DateOfEligibility) - 1), pib.DateOfEligibility)
				AND CASE 
						WHEN YEAR(pib.CoverageEndsDate) = 9999
							THEN pib.CoverageEndsDate
						ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, pib.CoverageEndsDate) + 1, 0))
						END
			AND r.ReportName = 'Financial Report'
			AND rfc.StatusCode = 'A'
		)
	SELECT *
	INTO ##OLAP_SC_FactFinancialReport
	FROM CTE
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH