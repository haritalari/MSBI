﻿/*
-----------------------------------------------------------------------------------
Procedure Name: usp_CareProviderDashBoard_CareManagement @i_AppUserId=2,@v_TabName='ALL'
Description   : This procedure is going to be used for displaying data related to 
				Care management (Analytics 3 report)
Created By    : Rathnam
Created Date  : 18-Jan-2013
-----------------------------------------------------------------------------------     
Log History   :
DD-MM-YYYY  BY   DESCRIPTION
09/07/2013:Santosh Changed the name 'Program Enrollment' to 'Managed Population Enrollment'
31/7/2013:Santosh added the column Isenrollment in the resultset
05-Aug-2013 NagaBabu Modified percentages to show the taskstatus and taskattempts
22/08/2013:Santosh added the filter isenrollment
19-02-2014 Rathnam commented the assigned careprovider functionality as we need to get the tasks based on tasktypes
10-10-2014 Rathnam commented @t_TaskTypeID, @t_PrimaryCarePhysician
02-01-2015 Rathnam modified the code as per NAVI-2006 -- Missed Opportunity report
29-Sep-2015 NagaBabu Modified the code as part of NAVI-3998 (performance tuning) and removed unused columns.
30-Sep-2015 NagaBabu Modified the code to filter data properly as per DueDate NAVI-3982
13-Apr-2016 Rathnam Modified as per NAVI-5791
-----------------------------------------------------------------------------------        
*/
CREATE PROCEDURE [dbo].[usp_CareProviderDashBoard_CareManagement] (
	@i_AppUserId KEYID
	,@t_ProgramID TTYPEKEYID READONLY
	,@v_TabName VARCHAR(350)
	,@t_CareTeamMembers TTYPEKEYID READONLY
	,@t_tblTaskTypeIDAndTypeID TBLTASKTYPEANDTYPEID READONLY
	,@v_DueDate KEYID = NULL
	)
AS
SET NOCOUNT ON
BEGIN TRY
	-- Check if valid Application User ID is passed        
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END
	
	CREATE TABLE #Program (ProgramID INT)

	INSERT INTO #Program
	SELECT DISTINCT tKeyId
	FROM @t_ProgramID

	CREATE TABLE #TaskType (TaskTypeID INT)

	
	CREATE TABLE #tblTask (
		TaskID INT
		,PatientUserID INT
		,TaskStatusText VARCHAR(50)
		,AttemptStatus INT
		,TypeID INT
		,TaskTypeID INT
		,TaskCompletedDate datetime
		)

	DECLARE @v_Select VARCHAR(MAX)
		,@v_WhereClause VARCHAR(MAX) = ''
		,@v_JoinClause VARCHAR(MAX) = ''
		,@v_SQL VARCHAR(MAX) = ''
		,@v_TabName1 VARCHAR(500) 
		,@v_DueDateValue INT = NULL
		,@v_DueDateStatus VARCHAR(1) = NULL 

	SET @v_TabName1 = @v_TabName
	
	DECLARE @i_TaskTypeId INT = NULL
		
		IF @v_TabName = 'All'
		BEGIN
			SET @v_TabName = @v_TabName --+ ISNULL(' ',0)  
		END
		ELSE
		BEGIN
			SELECT @i_TaskTypeId = TaskTypeId FROM TaskType WHERE TaskTypeName = @v_TabName
			IF @i_TaskTypeId IS NULL
				SET @i_TaskTypeId = 0
			SET @v_WhereClause = ' WHERE t.TaskTypeId = ' + CAST(@i_TaskTypeId AS VARCHAR(10))
		END
	
	
	SET @v_Select = '
			INSERT INTO #tblTask  (TaskID 
		,PatientUserID 
		,TaskStatusText 
		,TypeID 
		,TaskTypeID 
		,TaskCompletedDate 
		 )
            SELECT DISTINCT
                t.PatientTaskID
               ,t.PatientID
               ,ts.TaskStatusText
               ,t.TypeID
               ,t.TaskTypeID
			   ,t.DateTaken
            FROM
                PatientTask t WITH(NOLOCK)
            INNER JOIN #Program pr
                ON pr.ProgramID = t.ManagedPopulationID
            INNER JOIN TaskStatus ts WITH(NOLOCK)
                ON ts.TaskStatusId = t.TaskStatusId '

			
	IF EXISTS (
			SELECT 1
			FROM @t_tblTaskTypeIDAndTypeID
			)
	BEGIN
		SELECT ttt.TaskTypeID
			,ttt.TypeID
		INTO #tblTaskTypeIDAndTypeID
		FROM @t_tblTaskTypeIDAndTypeID ttt

		SET @v_JoinClause = @v_JoinClause + ' INNER JOIN #tblTaskTypeIDAndTypeID  
                               ON #tblTaskTypeIDAndTypeID.TaskTypeID = t.TaskTypeID  
                               AND #tblTaskTypeIDAndTypeID.TypeID = t.TypeID  
                               '
	END

	
	IF @v_DueDate IS NOT NULL
	BEGIN
		SELECT 
			@v_DueDateValue = Value ,
			@v_DueDateStatus = TaskStatus
		FROM TaskDueDates 
		WHERE TaskDueDateId = @v_DueDate

		SET @v_WhereClause = @v_WhereClause + ' AND (
					( ts.TaskStatusText = ''Open'' AND 
					  DATEDIFF(DAY , t.DueDate , getdate()) BETWEEN ' + CASE WHEN @v_DueDateValue = 0 AND @v_DueDateStatus = 'C' THEN '1' ELSE CONVERT(VARCHAR(10), @v_DueDateValue) END + 
			' AND 0 
                    )  
                    OR
                    (
						ts.TaskStatusText = ''Closed complete'' AND 
						DATEDIFF(DAY , t.DateTaken , getdate()) BETWEEN 0 AND ' + CONVERT(VARCHAR(10), REPLACE(@v_DueDateValue, '-', '')) + ' 
                    
                    ) 
                    
                    OR
                    (
						ts.TaskStatusText IN  (''Closed Incomplete''  , ''DisEnroll'') AND 
						DATEDIFF(DD,  DateTaken ,GETDATE()) BETWEEN 0 AND ' + CONVERT(VARCHAR(10), REPLACE(@v_DueDateValue, '-', '')) + '
                    )

                   )'
	END

	SET @v_SQL = @v_Select + ISNULL(@v_JoinClause, '') + ISNULL(@v_WhereClause, '') 
	EXEC (@v_SQL)


	CREATE TABLE #tblTotal (
		NAME VARCHAR(200)
		,PatientCount VARCHAR(10)
		,Scheduled VARCHAR(10)
		,[Open] VARCHAR(10)
		,ClosedComplete VARCHAR(10)
		,ClosedIncomplete VARCHAR(10)
		,DisEnroll VARCHAR(10)
		,TabRowId VARCHAR(10)
		,TaskTypeName VARCHAR(200)
		
		)


	INSERT INTO #tblTotal
	SELECT
	 CASE 
			WHEN @v_TabName1 = 'Managed Population Enrollment'
				THEN x.TaskTypeName + ' - ' + dbo.ufn_GetTypeNamesByTypeId(x.TaskTypeName, x.TypeID)
			ELSE dbo.ufn_GetTypeNamesByTypeId(x.TaskTypeName, x.TypeID)
			END NAME
		,(
			SELECT COUNT(DISTINCT PatientUserID)
			FROM #tblTask t
			WHERE t.TypeID = x.TypeID
			AND t.TaskTypeID = x.TaskTypeID
			
			) AS PatientCount
		,(
			SELECT COUNT(1)
			FROM #tblTask t
			WHERE t.TypeID = x.TypeID
				AND t.TaskStatusText = 'Scheduled'
				AND t.TaskTypeID = x.TaskTypeID
				
			) AS Scheduled
		,(
			SELECT COUNT(1)
			FROM #tblTask t
			WHERE t.TypeID = x.TypeID
				AND t.TaskStatusText = 'Open'
				AND t.TaskTypeID = x.TaskTypeID
				
			) AS "Open"
		,(
			SELECT COUNT(1)
			FROM #tblTask t
			WHERE t.TypeID = x.TypeID
				AND t.TaskStatusText = 'Closed Complete'
				AND t.TaskTypeID = x.TaskTypeID
				
			) AS ClosedComplete
		,(
			SELECT COUNT(1)
			FROM #tblTask t
			INNER JOIN TaskType ty
			ON ty.TaskTypeId = t.TaskTypeID
			WHERE t.TypeID = x.TypeID
				AND t.TaskStatusText = 'Closed Incomplete'
				AND t.TaskTypeID = x.TaskTypeID
				AND ty.IsTask = 1
				
			) AS ClosedIncomplete
         ,(SELECT COUNT(1)
			FROM #tblTask t
			WHERE t.TypeID = x.TypeID
				AND t.TaskStatusText = 'DisEnroll'
				AND t.TaskTypeID = x.TaskTypeID
		  ) AS DisEnroll
		,x.TypeID TabRowId
		,x.TaskTypeName
		
	FROM (
		SELECT DISTINCT TypeID
			,TTY.TaskTypeName
			,TTY.TaskTypeID
		FROM #tblTask TT
		INNER JOIN TaskType TTY
		ON TT.TaskTypeID = TTY.TaskTypeId
		) x

	;WITH cteCareManagement
	
	AS (
		SELECT NAME
			,PatientCount
			,Scheduled
			,"Open" AS [Open]
			,ClosedComplete
			,ClosedIncomplete
			,DisEnroll
			,TabRowId
			,TaskTypeName
			,'' ISenrollment
		FROM #tblTotal
		UNION
		
		SELECT 'ZZGrandTotal'
			,CONVERT(VARCHAR(10), SUM(CONVERT(INT, PatientCount)))
			,CONVERT(VARCHAR(10), SUM(CONVERT(INT, Scheduled)))
			,CONVERT(VARCHAR(10), SUM(CONVERT(INT, "open")))
			,CONVERT(VARCHAR(10), SUM(CONVERT(INT, ClosedComplete)))
			,CONVERT(VARCHAR(10), SUM(CONVERT(INT, ClosedIncomplete)))
			,CONVERT(VARCHAR(10), SUM(CONVERT(INT, DisEnroll)))
			,''
			,'' AS TaskTypeName
			,'' AS ISenrollment
		FROM #tblTotal
		
		UNION
		
		SELECT 'ZZZGrandPercentage'
			,' '
			,CAST(CAST(CAST(SUM(CAST(Scheduled AS INT)) AS DECIMAL(10, 2)) * 100 / CAST(NULLIF(SUM(CAST(Scheduled AS INT)) + SUM(CAST([Open] AS INT)) + SUM(CAST(ClosedComplete AS INT)) + SUM(CAST(ClosedIncomplete AS INT)), 0) AS DECIMAL(10, 2)) AS DECIMAL(10, 2)) AS VARCHAR)
			,CAST(CAST(CAST(SUM(CAST([Open] AS INT)) AS DECIMAL(10, 2)) * 100 / CAST(NULLIF(SUM(CAST([Open] AS INT)) + SUM(CAST(Scheduled AS INT)) + SUM(CAST(ClosedComplete AS INT)) + SUM(CAST(ClosedIncomplete AS INT)), 0) AS DECIMAL(10, 2)) AS DECIMAL(10, 2)) AS VARCHAR)
			,CAST(CAST(CAST(SUM(CAST(ClosedComplete AS INT)) AS DECIMAL(10, 2)) * 100 / CAST(NULLIF(SUM(CAST(ClosedComplete AS INT)) + SUM(CAST([Open] AS INT)) + SUM(CAST(Scheduled AS INT)) + SUM(CAST(ClosedIncomplete AS INT)) , 0) AS DECIMAL(10, 2)) AS DECIMAL(10, 2)) AS VARCHAR)
			,CAST(CAST(CAST(SUM(CAST(ClosedIncomplete AS INT)) AS DECIMAL(10, 2)) * 100 / CAST(NULLIF(SUM(CAST(ClosedIncomplete AS INT)) + SUM(CAST([Open] AS INT)) + SUM(CAST(ClosedComplete AS INT)) + SUM(CAST(Scheduled AS INT)) , 0) AS DECIMAL(10, 2)) AS DECIMAL(10, 2)) AS VARCHAR)
			,CAST(CAST(CAST(SUM(CAST(DisEnroll AS INT)) AS DECIMAL(10, 2)) * 100 / CAST(NULLIF(SUM(CAST(ClosedIncomplete AS INT)) + SUM(CAST([Open] AS INT)) + SUM(CAST(ClosedComplete AS INT)) + SUM(CAST(Scheduled AS INT)) , 0) AS DECIMAL(10, 2)) AS DECIMAL(10, 2)) AS VARCHAR)
			,' '
			,'' AS TaskTypeName
			,'' AS ISenrollment
		FROM #tblTotal
		)
	SELECT *
	FROM cteCareManagement
	ORDER BY NAME
		
	SELECT COUNT(DISTINCT PatientUserID) PatientCount
	FROM #tblTask
END TRY

------------------------------------------------------------------------------------------------------
BEGIN CATCH
	-- Handle exception  
	IF (@@TRANCOUNT > 0)
	BEGIN
	ROLLBACK TRANSACTION;
	END
		DECLARE @ErrorNumber INT = ERROR_NUMBER();
		DECLARE @ErrorLine INT = ERROR_LINE();
		DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
		DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
		DECLARE @ErrorState INT = ERROR_STATE();
		DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

		INSERT INTO Audit_Errors (
			Userid
			,Source
			,Type
			,ErrorDate
			,[Message]
			,[Procedure]
			)
		SELECT @i_AppUserId
			,'Database'
			,@ErrorSeverity
			,GETDATE()
			,@ErrorMessage
			,@ErrorProcedure
END CATCH