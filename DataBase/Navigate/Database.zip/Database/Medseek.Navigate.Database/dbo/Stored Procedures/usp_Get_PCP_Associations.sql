﻿
/*
--------------------------------------------------------------------------------
Procedure Name: [dbo].[usp_Get_PCP_Associations]
Description	  : This procedure is used to select the Primary Care Physician Associations.
Created By    :	Prashanth Kumar as part of NAVI-4477
Created Date  : 02-Dec-2015
---------------------------------------------------------------------------------
Log History   : 
DD-MM-YYYY		BY			DESCRIPTION
10-May-2016 Nagababu Modified the code as per NAVI-5956
05-Jul-2016 Yugandhar modified the sp as per NAVI-6363 (Performance)
---------------------------------------------------------------------------------
*/
CREATE PROCEDURE [dbo].[usp_Get_PCP_Associations] (
	@i_ProviderId KEYID
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @i_ProgramID INT

	SELECT @i_ProgramID = ProgramId
	FROM Program
	WHERE ProgramName = 'All Patients Managed population'

	SELECT DISTINCT ProgramId
	INTO #prog
	FROM ProgramProvider PP
	WHERE ProviderId = @i_ProviderId
		AND ProgramID != @i_ProgramID

	SELECT DISTINCT ppcp.ProviderId INTO #pcp
		FROM PatientPCP ppcp 
		INNER JOIN PatientProgram pp WITH (NOLOCK) ON pp.patientid = ppcp.PatientId
		INNER JOIN #prog p ON p.ProgramID = pp.ProgramID
		WHERE ISNULL(ppcp.IslatestPCP, 0) = 1

	;with prcte
	as
	(
	SELECT pr.ProviderId,
		 CONCAT(LastName, CASE WHEN LastName IS NULL THEN '' ELSE ', ' END, FirstName) AS Name
	FROM Provider pr
	INNER JOIN #pcp pcp ON pcp.ProviderID = pr.ProviderID
	)
		select ProviderId,
		 case when Name = 'No PCP Assigned'
		 then ' No PCP Assigned'else Name end
		 AS Name
		 from prcte order by Name Asc
END TRY

BEGIN CATCH
	----------------------------------------------------------------------------------------------------------           
	-- Handle exception  
	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_ProviderId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH
GO

