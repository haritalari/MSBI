﻿/*            
--------------------------------------------------------------------------------------------------------------            
Procedure Name: [dbo].[usp_CareProviderDashBoard_MyTasks_ByCareProvider]23,11,20    
Description   : This procedure is to get the recent tasks by patientid to the respective careteammembers       
Created By    : Rathnam         
Created Date  : 14-Nov-2012    
---------------------------------------------------------------------------------------------------------------            
Log History   :             
DD-Mon-YYYY  BY  DESCRIPTION     
24-March-2016 Deleted all the previous log and modified as per task new architecture NAVI-5401
04-April-2016 Rathnam modified as per NAVI-5627
10-May-2016 Nagababu Modified code as per NAVI-5952
25-May-2016 Yugandhar Modified code as per NAVI-6098  
14-Jul-2016 Yugandhar modified the logic as per NAVI-6471
----------------------------------------------------------------------------------------------------------------        
 */
CREATE PROCEDURE [dbo].[usp_CareProviderDashBoard_MyTasks_ByCareProvider] (
	@i_AppUserId KEYID
	,@i_StartRowIndex INT = 1 --> RowStart Index    
	,@i_EndRowIndex INT = 10 --> End Row Index    
	,@i_RemainderCount INT --> It is For only Open Tasks counts like PastDue, ToDays and Future Tasks circles in the appllication    
	,@t_ProgramList TTYPEKEYID READONLY --> Managed Population which are mapped from the managed population screen to the particular careteam    
	,@t_TaskTypeID TTYPEKEYID READONLY --> Displays the list of Task types based on login user task rights    
	,@t_PCPID TTYPEKEYID READONLY --> PCP information     
	,@t_tblTaskTypeIDAndTypeID TBLTASKTYPEANDTYPEID READONLY --> it will vary the data based on tasktype 
	,@t_tProvider TTYPEKEYID READONLY --> CareLead Information
	,@t_tCareTeams TTYPEKEYID READONLY --> CareTeam Information
	,@t_tCareTeamMembers TTYPEKEYID READONLY --> CareTeamMember Information
	,@v_SortBy VARCHAR(50) = 'duedate'
	,@v_SortType VARCHAR(5) = NULL
	)
AS
BEGIN TRY
	SET NOCOUNT ON


	DECLARE @i_ProviderTotalTasks INT
	DECLARE @V_ParamDefintion NVARCHAR(MAX)
		,@i_PrvCnt INT
	DECLARE @d_StartDatetime datetime = CAST(getdate() AS DATE)
	DECLARE @d_EndDatetime datetime = DATEADD(dd,1,@d_StartDatetime)
	SET @V_ParamDefintion = '@i_AppUserId KEYID
							,@i_StartRowIndex INT   
							,@i_EndRowIndex INT 
							,@i_RemainderCount INT 
							,@v_Operator VARCHAR(5)
							,@i_TaskStatusID INT
							,@v_Aliasname VARCHAR(20)
							,@d_StartDatetime DATETIME
							,@d_EndDatetime DATETIME
							,@i_ProviderTotalTasks int OUTPUT

							'

	SELECT @i_PrvCnt = COUNT(1)
	FROM @t_tProvider

	IF @i_PrvCnt > 0
	BEGIN
		SELECT tKeyId ProviderID
		INTO #Provider
		FROM @t_tProvider
	END

	SELECT tkeyId AS ProgramId
	INTO #ProgramList
	FROM @t_ProgramList
					

	DECLARE @i_CareteamCnt INT
		,@i_CareManagerCnt INT

	SELECT @i_CareteamCnt = COUNT(1)
	FROM @t_tCareTeams
	
	SELECT tkeyId AS CareTeamId
	INTO #tCareTeams
	FROM @t_tCareTeams

	SELECT @i_CareManagerCnt = COUNT(1)
	FROM @t_tCareTeamMembers

	SELECT tkeyId AS ProviderId
	INTO #tCareTeamMembers
	FROM @t_tCareTeamMembers 

	CREATE TABLE #PreProgram (
		ProgramID INT
		,ProgramName VARCHAR(200)
		,ADTtype VARCHAR(1)
		,StatusCode VARCHAR(1)
		,CareTeamId INT
		)

	CREATE TABLE #Program (
		ProgramID INT
		,ProgramName VARCHAR(200)
		,ADTtype VARCHAR(1)
		,StatusCode VARCHAR(1)
		)

	INSERT INTO #PreProgram
	SELECT DISTINCT p.ProgramId
		,p.ProgramName
		,pd.ADTtype
		,P.StatusCode 
		,C.CareTeamId
	FROM ProgramCareTeam pct WITH (NOLOCK)
	INNER JOIN CareTeam c WITH (NOLOCK) ON c.CareTeamId = pct.CareTeamId
	INNER JOIN CareTeamMembers ctm WITH (NOLOCK) ON ctm.CareTeamId = c.CareTeamId
	INNER JOIN Program p WITH (NOLOCK) ON P.ProgramId = pct.ProgramId
	INNER JOIN PopulationDefinition pd WITH (NOLOCK) ON pd.PopulationDefinitionID = p.PopulationDefinitionID
	WHERE  c.StatusCode = 'A'
		AND ctm.StatusCode = 'A'
		AND ctm.ProviderID = @i_AppUserId
		AND p.ProductionStatus = 'F'
		AND P.ProgramName <> 'All Patients Managed population'
	
	DECLARE @vc_MPSQL NVARCHAR(MAX)

	SELECT @vc_MPSQL = ' INSERT INTO #Program
						  SELECT DISTINCT TPP.ProgramId
							,ProgramName
							,ADTtype
							,TPP.StatusCode
						  FROM #PreProgram TPP '
	
	IF EXISTS ( SELECT 1
				FROM @t_ProgramList )
		BEGIN 	

			SET  @vc_MPSQL =  @vc_MPSQL + SPACE(1) + ' INNER JOIN #ProgramList tp 
													ON TP.ProgramId = TPP.ProgramId '
		END

	IF @i_CareteamCnt > 0 
		BEGIN
			
			SET  @vc_MPSQL =  @vc_MPSQL + SPACE(1) + ' INNER JOIN #tCareTeams TCT 
														ON TCT.CareTeamId = TPP.CareTeamId '
		END
	
	IF @i_CareManagerCnt > 0
		BEGIN
			
			SET  @vc_MPSQL =  @vc_MPSQL + SPACE(1) + ' INNER JOIN CareTeamMembers CTM
														ON CTM.CareTeamId = TPP.CareTeamId 
													   INNER JOIN #tCareTeamMembers TCTM
														ON CTM.ProviderId = TCTM.ProviderId '
		END

	EXEC (@vc_MPSQL)

	DECLARE @v_GroupByColumn VARCHAR(500)

	IF @v_SortBy IS NOT NULL
	BEGIN
		SET @v_GroupByColumn = CASE 
				WHEN @v_SortBy = 'patientName'
					THEN ' COALESCE(ISNULL(pts.LastName , '''') + '', '' + ISNULL(pts.FirstName , '''') + ''. '' + ISNULL(pts.MiddleName , '''') + '''' + ISNULL(pts.NameSuffix , '''') , '''') '
				WHEN @v_SortBy = 'gender'
					THEN ' pts.Gender '
				WHEN @v_SortBy = 'age'
					THEN ' dbo.ufn_GetAgeByDOB(pts.DateOfBirth) '
				WHEN @v_SortBy = 'duedate'
					THEN ' t.DueDate '
				END
	END

	CREATE TABLE #tblTaskTypeID (TaskTypeID INT)

	DECLARE @i_Tasktypecnt INT

	SELECT @i_Tasktypecnt = COUNT(1)
	FROM @t_TaskTypeID

	IF @i_Tasktypecnt > 0
	BEGIN
		INSERT INTO #tblTaskTypeID
		SELECT tKeyId TaskTypeID
		FROM @t_TaskTypeID
	END
	ELSE
	BEGIN
		INSERT INTO #tblTaskTypeID
		SELECT TaskTypeId
		FROM TaskType
	END

	CREATE TABLE #tblTask (
		ID INT IDENTITY(1, 1)
		,PatientTaskID INT
		,PatientID INT
		,Groupcolumn VARCHAR(500)
		)

	DECLARE @v_Operator NVARCHAR(1000)
		,@i_TaskStatusID INT

	SELECT @i_TaskStatusID = ts.TaskStatusId
	FROM TaskStatus ts
	WHERE ts.TaskStatusText = 'Open'


	SET @v_Operator = CASE 
			WHEN @i_RemainderCount = 3 --Today
				THEN ' AND CAST(DueDate AS DATE) = @d_StartDatetime'
			WHEN @i_RemainderCount = 2 --PastDue
				THEN ' AND CAST(DueDate AS DATE) < @d_StartDatetime'
			WHEN @i_RemainderCount = 1 -- Future
				THEN ' AND CAST(DueDate AS DATE) > @d_StartDatetime'
			END
			
	DECLARE @v_SQL NVARCHAR(MAX)
		,@v_WhereClause NVARCHAR(MAX) = ' WHERE t.TaskStatusId =  @i_TaskStatusID ' + @v_Operator
											
		,@v_JoinClause NVARCHAR(MAX) = ''
		,@v_GroupByClause NVARCHAR(MAX) = ' Group by t.PatientID, ' + @v_GroupByColumn
		,@v_DueDateSQL NVARCHAR(MAX) = ''
	DECLARE @i_PCPCnt INT
		,@v_Aliasname VARCHAR(20) = CASE 
			WHEN @i_RemainderCount = 3 --Today
				THEN 'TodayTasks'
			WHEN @i_RemainderCount = 2 --PastDue
				THEN 'PastDueTasks'
			WHEN @i_RemainderCount = 1 -- Future
				THEN 'FutureTasks'
			END

	SELECT @i_PCPCnt = 1
	FROM @t_PCPID

	SET @v_SQL = '    
    
	    SELECT     
        max(t.PatientTaskID) TaskID    
        ,t.PatientID ' + CASE WHEN  @v_SortBy != 'duedate' THEN ', '+  @v_GroupByColumn ELSE '' END + '
       FROM     
        PatientTask t WITH(NOLOCK)
	  INNER JOIN Patient pts WITH(NOLOCK)
		ON t.PatientId = pts.PatientId	     
      INNER JOIN #Program pm    
        ON pm.ProgramID = t.ManagedPopulationID         
      '
	IF @v_SortBy = 'duedate'
	BEGIN
	SET @v_DueDateSQL = ' SELECT pt.PatientTaskId, pt.PatientId, 1 FROM PatientTask pt INNER JOIN ('
	END

	IF @i_Tasktypecnt > 0
	BEGIN
		SET @v_JoinClause = @v_JoinClause + ' INNER JOIN #tblTaskTypeID ty1    
        ON ty1.TaskTypeID = t.TaskTypeId   '
	END

	IF @i_PrvCnt > 0
	BEGIN
		SET @v_JoinClause = @v_JoinClause + ' INNER JOIN #Provider pr ON pr.ProviderID = t.ProviderID  '
	END

	IF @i_PCPCnt IS NOT NULL
	BEGIN
		SELECT tKeyId PCPID
		INTO #PCPID
		FROM @t_PCPID pcp

		SET @v_JoinClause = @v_JoinClause + '      
                          INNER JOIN PatientPCP pcp  WITH(NOLOCK)
                          ON pcp.PatientID = pts.PatientID
                          INNER JOIN #PCPID    
                          ON #PCPID.PCPID = pcp.ProviderID  '
	END

	IF EXISTS (
			SELECT 1
			FROM @t_tblTaskTypeIDAndTypeID
			)
	BEGIN
		SELECT ttt.TaskTypeID
			,ttt.TypeID
		INTO #tblTaskTypeIDAndTypeID
		FROM @t_tblTaskTypeIDAndTypeID ttt

		SET @v_JoinClause = @v_JoinClause + ' INNER JOIN #tblTaskTypeIDAndTypeID    
                               ON #tblTaskTypeIDAndTypeID.TaskTypeID = t.TaskTypeID    
                               AND #tblTaskTypeIDAndTypeID.TypeID = t.TypeID    
                               '
	END

	DECLARE @v_OrderByClause VARCHAR(4000) = ''

	SET @v_OrderByClause = ' ORDER BY 3 ' + ISNULL(@v_SortType, ' ASC')
	SET @v_SQL = CASE WHEN @v_SortBy = 'duedate' then @v_DueDateSQL else '' end +
				 @v_SQL + 
				 ISNULL(@v_JoinClause, '') + 
				 ISNULL(@v_WhereClause, '') + 
				 CASE WHEN @v_SortBy = 'duedate' THEN ' Group by t.PatientID) t1 ON pt.PatientTaskID = t1.TaskID ' ELSE ISNULL(@v_GroupByClause, '') END  + 
				 CASE WHEN @v_SortBy = 'duedate' THEN ' ORDER BY pt.DueDate ' + ISNULL(@v_SortType, ' ASC') ELSE @v_OrderByClause END + 
				 '  OFFSET (@i_StartRowIndex-1) * @i_EndRowIndex  ROWS  FETCH NEXT  @i_EndRowIndex   ROWS ONLY '

	INSERT INTO #tblTask
	EXEC SP_EXECUTESQL @v_SQL
		,@V_ParamDefintion
		,@i_AppUserId = @i_AppUserId
		,@i_StartRowIndex = @i_StartRowIndex
		,@i_EndRowIndex = @i_EndRowIndex
		,@i_RemainderCount = @i_RemainderCount
		,@v_Operator = @v_Operator
		,@i_TaskStatusID = @i_TaskStatusID
		,@v_Aliasname = @v_Aliasname
		,@d_StartDatetime = @d_StartDatetime
		,@d_EndDatetime = @d_EndDatetime
		,@i_ProviderTotalTasks = @i_ProviderTotalTasks OUTPUT
	;WITH CTE_Result AS (
	SELECT DISTINCT t1.ID
		,t.PatientTaskId TaskID
		,t.PatientId UserId
		,(
			SELECT COUNT(DISTINCT pt.PatientTaskId)
			FROM PatientTask pt WITH (NOLOCK)
			WHERE pt.PatientId = t.PatientId
				AND pt.TaskStatusId = @i_TaskStatusID
			) AS TaskCount
		,p.MedicalRecordNumber MemberNum
		,COALESCE(ISNULL(p.LastName, '') + ', ' + ISNULL(p.FirstName, '') + '. ' + ISNULL(p.MiddleName, '') + ' ' + ISNULL(p.NameSuffix, ''), '') AS FullName
		,dbo.ufn_GetAgeByDOB(p.DateOfBirth) AS Age
		,p.Gender
		,t.DueDate TaskDueDate
		,dbo.ufn_GetPCPName(T.PatientId) PCPName
		,pg.ProgramName AssignmentName
		,CASE 
			WHEN pg.ADTtype = 'A'
				THEN 'Admit'
			WHEN pg.ADTtype = 'D'
				THEN 'Discharge'
			WHEN pg.ADTtype = 'E'
				THEN 'ER Visit'
			ELSE NULL
			END AS ADTStatus
		,pg.StatusCode as ProgramStatus
	FROM #tblTask t1
	INNER JOIN PatientTask t WITH (NOLOCK) ON t1.PatientTaskId = t.PatientTaskId
	INNER JOIN Patient p WITH (NOLOCK) ON p.PatientID = t.PatientId
	INNER JOIN TaskType ty WITH (NOLOCK) ON ty.TaskTypeId = t.TaskTypeId
	INNER JOIN #Program pg ON pg.ProgramId = t.ManagedPopulationId )
	--ORDER BY t1.ID

	SELECT 
		TaskID ,
		UserId ,
		TaskCount ,
		MemberNum ,
		FullName ,
		Age ,
		Gender ,
		TaskDueDate ,
		PCPName ,
		AssignmentName ,
		ADTStatus,
		ProgramStatus
	FROM CTE_Result
	ORDER BY ID
	IF @i_RemainderCount = 2
	BEGIN
		DECLARE @v_TodayCntSQL NVARCHAR(MAX)
			,@v_TodayCntWhereClause NVARCHAR(MAX)
			,@v_FutureCntSQL NVARCHAR(MAX)
			,@v_FutureCntWhereClause NVARCHAR(MAX)
			,@v_PastdueCntSQL NVARCHAR(MAX)
			,@v_PastDueCntWhereClause NVARCHAR(MAX)
			,@v_FromClause NVARCHAR(MAX)
			,@v_CntWhereClause NVARCHAR(MAX)

		SET @v_FromClause = ' FROM     
        PatientTask t WITH(NOLOCK)    
      INNER JOIN #Program pm    
        ON pm.ProgramID = t.ManagedPopulationid   '

		SET @v_CntWhereClause = ' WHERE t.TaskStatusId =  @i_TaskStatusID '
											


		SET @v_PastdueCntSQL = '  SELECT COUNT(1) AS PastDueTasks, Count(Distinct t.PatientID) as PatientCnt ' + @v_FromClause
		SET @v_PastDueCntWhereClause = @v_CntWhereClause + ' AND CAST(DueDate AS DATE) < @d_StartDatetime'
		SET @v_TodayCntSQL = ' SELECT COUNT(1) AS TodayTasks, Count(Distinct t.PatientID) as PatientCnt ' + @v_FromClause
		SET @v_TodayCntWhereClause = @v_CntWhereClause + ' AND CAST(DueDate AS DATE) = @d_StartDatetime '
		SET @v_FutureCntSQL = '  SELECT COUNT(1) AS FutureTasks, Count(Distinct t.PatientID) as PatientCnt ' + @v_FromClause
		SET @v_FutureCntWhereClause = @v_CntWhereClause + ' AND CAST(DueDate AS DATE) >  @d_StartDatetime '
		SET @v_TodayCntSQL = @v_TodayCntSQL + ISNULL(REPLACE(@v_JoinClause,'pts.patientid','t.patientid'), '') + ISNULL(@v_TodayCntWhereClause, '')
		SET @v_FutureCntSQL = @v_FutureCntSQL + ISNULL(REPLACE(@v_JoinClause,'pts.patientid','t.patientid'), '') + ISNULL(@v_FutureCntWhereClause, '')
		SET @v_PastdueCntSQL = @v_PastdueCntSQL + ISNULL(REPLACE(@v_JoinClause,'pts.patientid','t.patientid'), '') + ISNULL(@v_PastDueCntWhereClause, '')
		
		EXEC SP_EXECUTESQL @v_PastdueCntSQL
			,@V_ParamDefintion
			,@i_AppUserId = @i_AppUserId
			,@i_StartRowIndex = @i_StartRowIndex
			,@i_EndRowIndex = @i_EndRowIndex
			,@i_RemainderCount = @i_RemainderCount
			,@v_Operator = @v_Operator
			,@i_TaskStatusID = @i_TaskStatusID
			,@v_Aliasname = @v_Aliasname
			,@d_StartDatetime = @d_StartDatetime
		    ,@d_EndDatetime = @d_EndDatetime
			,@i_ProviderTotalTasks = @i_ProviderTotalTasks OUTPUT

		EXEC SP_EXECUTESQL @v_TodayCntSQL
			,@V_ParamDefintion
			,@i_AppUserId = @i_AppUserId
			,@i_StartRowIndex = @i_StartRowIndex
			,@i_EndRowIndex = @i_EndRowIndex
			,@i_RemainderCount = @i_RemainderCount
			,@v_Operator = @v_Operator
			,@i_TaskStatusID = @i_TaskStatusID
			,@v_Aliasname = @v_Aliasname
			,@d_StartDatetime = @d_StartDatetime
			,@d_EndDatetime = @d_EndDatetime
			,@i_ProviderTotalTasks = @i_ProviderTotalTasks OUTPUT

		EXEC SP_EXECUTESQL @v_FutureCntSQL
			,@V_ParamDefintion
			,@i_AppUserId = @i_AppUserId
			,@i_StartRowIndex = @i_StartRowIndex
			,@i_EndRowIndex = @i_EndRowIndex
			,@i_RemainderCount = @i_RemainderCount
			,@v_Operator = @v_Operator
			,@i_TaskStatusID = @i_TaskStatusID
			,@v_Aliasname = @v_Aliasname
			,@d_StartDatetime = @d_StartDatetime
			,@d_EndDatetime = @d_EndDatetime
			,@i_ProviderTotalTasks = @i_ProviderTotalTasks OUTPUT
	END
	ELSE
	BEGIN
		SELECT 0 AS 'PastDueTasks'
			,0 AS PatientCnt

		SELECT 0 AS 'TodayTasks'
			,0 AS PatientCnt

		SELECT 0 AS 'Futuretasks'
			,0 AS PatientCnt
	END
END TRY

BEGIN CATCH
	----------------------------------------------------------------------------------------------------------           
	-- Handle exception  
	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH