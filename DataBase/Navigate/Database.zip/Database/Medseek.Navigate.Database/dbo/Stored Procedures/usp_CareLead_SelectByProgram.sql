﻿
/*            
--------------------------------------------------------------------------------------------------------------            
Procedure Name: [usp_CareLead_SelectByProgram]
Description   : This is used to select the careleads for given Program
Created By    : Nagababu S
Created Date  : 24-Nov-2015
---------------------------------------------------------------------------------------------------------------            
Log History   :             
DD-Mon-YYYY  BY  DESCRIPTION     
----------------------------------------------------------------------------------------------------------------        
 */
CREATE PROCEDURE [dbo].[usp_CareLead_SelectByProgram] (
	@i_AppUserId KeyId
	,@i_ProgramId KeyId
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	-- Check if valid Application User ID is passed            
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END

	SELECT COUNT(1) AS PatientsCount
		,pp.ProviderID
	INTO #prg
	FROM PatientProgram PP
	WHERE PP.StatusCode = 'E'
		AND PP.ProgramID = @i_ProgramId
	GROUP BY pp.ProviderID

	SELECT DISTINCT PatientsCount
		,ctm.ProviderID
		,dbo.ufn_GetProviderName(ctm.Providerid) ProviderName
	FROM ProgramCareTeam pct WITH (NOLOCK)
	INNER JOIN CareTeamMembers ctm WITH (NOLOCK) ON pct.CareTeamId = ctm.CareTeamId
	INNER JOIN CareTeam c WITH (NOLOCK) ON c.CareTeamId = ctm.CareTeamId
	LEFT JOIN #prg p ON p.ProviderID = ctm.ProviderID
	WHERE c.StatusCode = 'A'
		AND ctm.StatusCode = 'A'
		AND pct.ProgramId = @i_ProgramId
END TRY

BEGIN CATCH
	----------------------------------------------------------------------------------------------------------           
	-- Handle exception            
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId

	RETURN @i_ReturnedErrorID
END CATCH