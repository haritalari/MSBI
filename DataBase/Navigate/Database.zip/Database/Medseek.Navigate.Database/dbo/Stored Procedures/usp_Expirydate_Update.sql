﻿--select * from aspnet_Membership where Email ='venugopalrao.gone@symphonycorp.com'  
  
  
CREATE procedure [dbo].[usp_Expirydate_Update]  
(  
@PasswordExpiryDate datetime,  
@PrimaryEmailid varchar(100)  
)  
as 
SET NOCOUNT ON
begin  
update aspnet_Membership set [passwordExpireDate] = convert(date,@PasswordExpiryDate) where [Email] = @PrimaryEmailid  
END
