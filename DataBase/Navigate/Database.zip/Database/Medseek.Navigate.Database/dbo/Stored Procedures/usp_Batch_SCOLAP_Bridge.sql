﻿/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_SCOLAP_Bridge] 1
Description   :  This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Nagasiva  
Created Date  : 22-Jan-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
05-02-2015   Nagasiva Optimized ##OLAP_SC_BridgePatientcodeGroup table data inserting statement 
13-Feb-2015 Nagasiva  assigned null value to  @i_AppUserId  Parameter to remove the hardcoded userid in cube execution package
13-Feb-2015 Nagasiva  removed @i_Datekey parameter to clean up the code
18-Dec-2015 Nagasiva Modified the SP as per NAVI-4781
19-Jan-2015 Rathnam Modified the SP as per NAVI-4824
25-Feb-2016 NagaBabu Modified the logic for readmission qualified patients as per NAVI-5153
23-Aug-2016 Rathnam modified the conditions logic as per NAVI-6524 
29-Sep-2016 Rathnam Modified the logic as per NAVI-6815
------------------------------------------------------------------------------------------------------------
*/
CREATE PROCEDURE [dbo].[usp_Batch_SCOLAP_Bridge] (
	@i_AppUserId KEYID = NULL
	,@b_IsExecute BIT = 0
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	SELECT @i_AppUserId = MIN(UserId)
	FROM Users WITH (NOLOCK)


	DECLARE @i_ProgramID INT
	SELECT @i_ProgramID = ProgramID FROM program WHERE ProgramName = 'All Patients Managed population'


	CREATE TABLE #PRG
		(
		ManagedPopulationKey INT ,
		PatientKey INT,
		DateKey INT
		)
		
		INSERT INTO #PRG
		SELECT DISTINCT pp.ProgramID
			,pp.PatientID PatientKey
			,ad.DateKey
		FROM PatientProgram pp WITH (NOLOCK)
		INNER JOIN AnchorDate ad ON ad.AnchorDate = CASE 
				WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pp.EnrollmentStartDate) - 1), pp.EnrollmentStartDate)
						AND CASE 
								WHEN YEAR(ISNULL(pp.EnrollmentEndDate, '9999-12-31')) = 9999
									THEN ISNULL(pp.EnrollmentEndDate, '9999-12-31')
								ELSE EOMONTH(pp.EnrollmentEndDate)
								END
					THEN ad.AnchorDate
				ELSE NULL
				END
				where  PP.ProgramID != @i_ProgramID
				AND pp.StatusCode in ('E','I')

		INSERT INTO #PRG
		SELECT DISTINCT pp.ProgramID
			,pp.PatientID PatientKey
			,ad.DateKey
		FROM PatientProgram pp WITH (NOLOCK)
		INNER JOIN AnchorDate ad ON ad.AnchorDate = CASE 
				WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pp.EnrollmentStartDate) - 1), pp.EnrollmentStartDate)
						AND CASE 
								WHEN YEAR(ISNULL(pp.EnrollmentEndDate, '9999-12-31')) = 9999
									THEN ISNULL(pp.EnrollmentEndDate, '9999-12-31')
								ELSE EOMONTH(pp.EnrollmentEndDate)
								END
					THEN ad.AnchorDate
				ELSE NULL
				END
				where PP.ProgramID = @i_ProgramID
				and not exists (select 1 from #prg p where p.PatientKey = pp.PatientID)



	CREATE TABLE #CodeGroup (CodeGroupingID INT);

	INSERT INTO #CodeGroup
	SELECT cg.CodeGroupingID
	FROM CodeGrouping AS cg WITH (NOLOCK)
	INNER JOIN CodeTypeGroupers AS ctg WITH (NOLOCK) ON CG.CodeTypeGroupersID = CTG.CodeTypeGroupersID
	WHERE ctg.CodeTypeGroupersName IN (
			'Encounter Types(Internal)'
			,'AHRQ Diagnosis Groupers'
			,'Encounter Type (Internal) by Code Type'
			);

	DECLARE @i_EDIClaimTypeId INT

	SELECT @i_EDIClaimTypeId = EDIClaimTypeId
	FROM dbo.LkUpEDIClaimType WITH (NOLOCK)
	WHERE EDIClaimTypeName = 'Institutional'

	IF OBJECT_ID('TEMPDB..##OLAP_SC_BridgePatientCodeGroup') IS NOT NULL
		DROP TABLE ##OLAP_SC_BridgePatientCodeGroup

	SELECT ClaiminFoId
		,PatientID
		,DateOfAdmit
		,DateOfDischarge
	INTO #Claims
	FROM ClaimInfo ci WITH (NOLOCK)

	SELECT DISTINCT ccg.CodeGroupingID AS CodeGroupKey
		,cc.PatientID AS PatientKey
		,dad.DateKey AS Datekey
		,cc.DateOfAdmit AS DateOfService
		,CASE 
			WHEN DATEDIFF(DAY, cc.DateOfAdmit, MAX(cc.DateOfDischarge)) = 0
				THEN 1
			ELSE DATEDIFF(DAY, cc.DateOfAdmit, MAX(cc.DateOfDischarge))
			END AS NoOfDays
		,(
			SELECT SUM(NetPaidAMount)
			FROM ClaimInfo ci WITH (NOLOCK)
			INNER JOIN ClaimCodeGroup cg WITH (NOLOCK) ON cg.ClaimInfoID = ci.ClaimInfoId
			WHERE cg.CodeGroupingID = ccg.CodeGroupingID
				AND ci.PatientId = cc.PatientID
				AND ci.DateOfAdmit = cc.DateOfAdmit
			) AS ClaimAmount
		,MAX(DateOfDischarge) AS DateOfDischarge
		,NULL AS ReadmitGap
	INTO ##OLAP_SC_BridgePatientCodeGroup
	FROM ClaimCodeGroup ccg
	INNER JOIN #Claims cc ON cc.ClaimInfoId = ccg.ClaimInfoID
	INNER JOIN #CodeGroup os ON os.CodeGroupingID = ccg.CodeGroupingID
	INNER JOIN ##OLAP_SC_DimCodeGroup dc ON dc.CodeGroupKey = os.CodeGroupingID
	INNER JOIN ##OLAP_SC_DimAnchordate AS dad ON dad.AnchorDate = CASE 
			WHEN AnchorDate BETWEEN DATEADD(dd, - (DAY(cc.DateOfAdmit) - 1), cc.DateOfAdmit)
					AND EOMONTH(cc.DateOfAdmit) 
				THEN dad.AnchorDate
			ELSE NULL
			END
	GROUP BY ccg.CodeGroupingID
		,cc.PatientID
		,dad.DateKey
		,cc.DateOfAdmit

	IF OBJECT_ID('TEMPDB..##OLAP_SC_BridgePatientCodeGroupProvider') IS NOT NULL
		DROP TABLE ##OLAP_SC_BridgePatientCodeGroupProvider

	SELECT DISTINCT cga.CodeGroupingID AS CodeGroupKey
		,ci.PatientID AS PatientKey
		,dad.DateKey AS Datekey
		,cp.ProviderId AS ProviderKey
	INTO ##OLAP_SC_BridgePatientCodeGroupProvider
	FROM ClaimCodeGroup AS cga WITH (NOLOCK)
	INNER JOIN ClaimInfo ci WITH (NOLOCK) ON ci.ClaimInfoID = cga.ClaimInfoID
	INNER JOIN ClaimProvider cp WITH (NOLOCK) ON cp.ClaimInfoId = ci.ClaimInfoId
	INNER JOIN ##OLAP_SC_DimCodeGroup AS cg ON cga.CodeGroupingID = cg.CodeGroupKey
	INNER JOIN ##OLAP_SC_DimAnchordate AS dad ON dad.AnchorDate = CASE 
			WHEN AnchorDate BETWEEN DATEADD(dd, - (DAY(ci.DateOfAdmit) - 1), ci.DateOfAdmit)
					AND EOMONTH(ci.DateOfAdmit) 
				THEN dad.AnchorDate
			ELSE NULL
			END
	WHERE cg.sourcetype IN ('Encounter Types(Internal)')
		AND cg.CodeDescription IN ('Outpatient')

	IF OBJECT_ID('TEMPDB..##OLAP_SC_BridgeHealthPlan') IS NOT NULL
		DROP TABLE ##OLAP_SC_BridgeHealthPlan

	SELECT DISTINCT dhp.HealthPlanKey
		,pi1.PatientID AS patientKey
		,ad.DateKey
	INTO ##OLAP_SC_BridgeHealthPlan
	FROM PatientInsuranceBenefit AS pib WITH (NOLOCK)
	INNER JOIN PatientInsurance AS pi1 WITH (NOLOCK) ON pi1.PatientInsuranceID = pib.PatientInsuranceID
	INNER JOIN InsuranceGroupPlan AS igp WITH (NOLOCK) ON igp.InsuranceGroupPlanId = pi1.InsuranceGroupPlanId
	INNER JOIN ##OLAP_SC_DimPatient AS dp1 ON dp1.PatientKey = pi1.PatientID
	INNER JOIN ##OLAP_SC_DimProduct AS dp ON dp.ProductCode = igp.ProductType
	INNER JOIN ##OLAP_SC_DimHealthPlan AS dhp ON dhp.HealthPlanKey = igp.InsuranceGroupId
	INNER JOIN ##OLAP_SC_DimAnchordate AS ad ON ad.AnchorDate = CASE 
			WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pib.DateOfEligibility) - 1), pib.DateOfEligibility)
					AND CASE 
							WHEN YEAR(pib.CoverageEndsDate) = 9999
								THEN pib.CoverageEndsDate
							ELSE   EOMONTH(pib.CoverageEndsDate) 
							END
				THEN ad.AnchorDate
			ELSE NULL
			END

	IF OBJECT_ID('TEMPDB..##OLAP_SC_BridgeProduct') IS NOT NULL
		DROP TABLE ##OLAP_SC_BridgeProduct

	SELECT DISTINCT dp.ProductKey
		,pi1.PatientID AS PatientKey
		,ad.DateKey
	INTO ##OLAP_SC_BridgeProduct
	FROM PatientInsuranceBenefit AS pib WITH (NOLOCK)
	INNER JOIN PatientInsurance AS pi1 WITH (NOLOCK) ON pi1.PatientInsuranceID = pib.PatientInsuranceID
	INNER JOIN InsuranceGroupPlan AS igp WITH (NOLOCK) ON igp.InsuranceGroupPlanId = pi1.InsuranceGroupPlanId
	INNER JOIN ##OLAP_SC_DimPatient AS dp1 ON dp1.PatientKey = pi1.PatientID
	INNER JOIN ##OLAP_SC_DimProduct AS dp ON dp.ProductCode = igp.ProductType
	INNER JOIN ##OLAP_SC_DimAnchordate AS ad ON ad.AnchorDate = CASE 
			WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pib.DateOfEligibility) - 1), pib.DateOfEligibility)
					AND CASE 
							WHEN YEAR(pib.CoverageEndsDate) = 9999
								THEN pib.CoverageEndsDate
							ELSE  EOMONTH(pib.CoverageEndsDate)
							END
				THEN ad.AnchorDate
			ELSE NULL
			END;

	WITH cte
	AS (
		SELECT DISTINCT C.CodeGroupKey
			,C.PatientKey
			,C.Datekey
			,DateOfService
			,DateOfDischarge
			,ROW_NUMBER() OVER (
				PARTITION BY C.PatientKey ORDER BY DateOfService
					,DateOfDischarge
				) AS row_num
		FROM ##OLAP_SC_BridgePatientCodeGroup C
		INNER JOIN ##OLAP_SC_DimCodeGroup dcg ON C.CodeGroupKey = dcg.CodeGroupKey
		WHERE DCG.CodeDescription = 'Acute Inpatient - Revenue Code'
		)
		,CTE_RES
	AS (
		SELECT a.CodeGroupKey
			,a.PatientKey
			,b.Datekey
			,b.DateOfService AS CurAdmitDate
			,b.DateOfDischarge AS CurDischargeDate
			,a.DateOfService AS PreviousAdmitDate
			,a.DateOfDischarge AS PreviousDischargeDate
			,CASE 
				WHEN Datediff(d, a.DateOfService, b.DateOfDischarge) = 0
					THEN 1
				ELSE Datediff(d, a.DateOfService, b.DateOfDischarge)
				END AS totaldays
		FROM cte AS a
		INNER JOIN cte AS b ON a.PatientKey = b.PatientKey
			AND a.row_num = b.row_num - 1
		)
	UPDATE C
	SET ReadmitGap = CR.totaldays
	FROM ##OLAP_SC_BridgePatientCodeGroup C
	INNER JOIN CTE_RES CR ON CR.CodeGroupKey = C.CodeGroupKey
		AND CR.PatientKey = C.PatientKey
		AND CR.Datekey = C.Datekey
		AND CR.CurAdmitDate = C.DateOfService
		AND CR.totaldays <= 60

	
	DECLARE @i_AssessmentTasktypeID INT, @i_TaskStatusID INT
	SELECT @i_TaskStatusID = TaskStatusId FROM TaskStatus WHERE TaskStatusText = 'Closed Complete'
	SELECT @i_AssessmentTasktypeID = TaskTypeId FROM TaskType	WHERE TaskTypeName = 'Assessment'

	IF OBJECT_ID('TEMPDB..##FactPatientAssessment') IS NOT NULL
		DROP TABLE ##FactPatientAssessment

	SELECT ppm.ManagedPopulationKey
		,ppm.PatientKey
		,ppm.DateKey
		,f.DimAssessmentKey
	INTO ##FactPatientAssessment
	FROM #PRG ppm
	INNER JOIN (
		SELECT DISTINCT ast.DimAssessmentKey
			,ptast.ProgramId ManagedPopulationKey
			,ptast.PatientId PatientKey
			,ad.DateKey
		FROM ##DimAssessment ast
		INNER JOIN (
			SELECT DISTINCT pq.ManagedPopulationId ProgramId
				,pq.PatientId
				,pq.TypeId QuestionaireId
				,a.QuestionId
				,aa.ID AnswerId
				,pq.DateTaken
				,(
					SELECT MAX(qsg.QuestionnaireScoringID)
					FROM QuestionnaireScoring qsg WITH (NOLOCK)
					WHERE qsg.QuestionaireId = pq.TypeId
						AND pq.AssessmentScore BETWEEN qsg.RangeStartScore
							AND qsg.RangeEndScore
					) QuestionnaireScoringID
			FROM PatientTask pq WITH (NOLOCK)
			INNER JOIN PatientAssessmentAnswer uqa WITH (NOLOCK) ON pq.PatientTaskId = uqa.PatientTaskId
			INNER JOIN Answer a WITH (NOLOCK) ON a.AnswerId = uqa.AnswerID
			INNER JOIN ##answer aa ON aa.AnswerId = a.AnswerId
				AND aa.QuestionId = a.QuestionId
				AND (
					aa.AnswerDescription = CASE 
						WHEN aa.IsFreeText = 1
							THEN uqa.AnswerString
						ELSE a.AnswerDescription
						END
					)
			WHERE pq.TaskTypeId = @i_AssessmentTasktypeID
			AND pq.TaskStatusId = @i_TaskStatusID
			) ptast ON ast.AssessmentKey = ptast.QuestionaireId
			AND ast.QuestionKey = ptast.QuestionId
			AND ast.AnswerKey = ptast.AnswerId
			AND (
				ast.ScoreRangeKey = ptast.QuestionnaireScoringID
				OR ptast.QuestionnaireScoringID IS NULL
				)
		INNER JOIN AnchorDate ad ON ad.AnchorDate = CASE 
				WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(ptast.DateTaken) - 1), ptast.DateTaken)
						AND EOMONTH(ptast.DateTaken) 
					THEN ad.AnchorDate
				ELSE NULL
				END
		) f ON ppm.ManagedPopulationKey = f.ManagedPopulationKey
		AND ppm.PatientKey = f.PatientKey
		AND ppm.datekey = f.datekey

	

	IF OBJECT_ID('TEMPDB..##FactPatientEnrollment') IS NOT NULL
		DROP TABLE ##FactPatientEnrollment;

	WITH prgcte
	AS (
		SELECT ROW_NUMBER() OVER (
				PARTITION BY pp.ProgramID
				,pp.PatientID ORDER BY patientprogramid DESC
				) sno
			,pp.ProgramID
			,pp.PatientID
			,CASE 
				WHEN pp.StatusCode = 'E'
					THEN 'E'
				ELSE 'D'
				END EnrollStatus
		FROM PatientProgram pp
		WHERE pp.ProgramID != @i_ProgramID
		AND pp.StatusCode in ('E','I')
		)
		,quecte
	AS (
		SELECT ROW_NUMBER() OVER (
				PARTITION BY pqe.PatientID
				,pqe.typeid ORDER BY pqe.DateTaken DESC
				) sno
			,pqe.PatientTaskId PatientQuestionaireid
			,pqe.PatientId
			,pqe.TypeId QuestionaireId
			,pqe.AssessmentScore TotalScore
			,pqe.DateTaken
		FROM PatientTask pqe WITH (NOLOCK)
		INNER JOIN Questionaire q WITH (NOLOCK) ON pqe.TypeId = q.QuestionaireId
		WHERE  pqe.TaskTypeId = @i_AssessmentTasktypeID
			AND pqe.TaskStatusId = @i_TaskStatusID
		)
	SELECT ppm.ProgramID ManagedPopulationKey
		,ppm.PatientID PatientKey
		,f.DimAssessmentKey
		,ppm.EnrollStatus
		,f.DateTaken
		,f.PatientQuestionaireId AS PatientAssessmentKey
	INTO ##FactPatientEnrollment
	FROM (
		SELECT PatientID
			,ProgramID
			,EnrollStatus
		FROM prgcte
		WHERE sno = 1
		) ppm
	LEFT JOIN (
		SELECT DISTINCT ast.DimAssessmentKey
			,ptast.PatientId PatientKey
			,ptast.DateTaken
			,ptast.PatientQuestionaireId
		FROM ##DimAssessment ast
		INNER JOIN (
			SELECT DISTINCT pq.PatientQuestionaireId
				,pq.PatientId
				,pq.QuestionaireId
				,a.QuestionId
				,aa.ID AnswerId
				,pq.DateTaken
				,(
					SELECT MAX(qsg.QuestionnaireScoringID)
					FROM QuestionnaireScoring qsg WITH (NOLOCK)
					WHERE qsg.QuestionaireId = pq.QuestionaireId
						AND pq.TotalScore BETWEEN qsg.RangeStartScore
							AND qsg.RangeEndScore
					) QuestionnaireScoringID
			FROM quecte pq WITH (NOLOCK)
			INNER JOIN PatientAssessmentAnswer uqa WITH (NOLOCK) ON pq.PatientQuestionaireid = uqa.PatientTaskId
			INNER JOIN Answer a WITH (NOLOCK) ON a.AnswerId = uqa.AnswerID
			INNER JOIN ##answer aa ON aa.AnswerId = a.AnswerId
				AND aa.QuestionId = a.QuestionId
				AND (
					aa.AnswerDescription = CASE 
						WHEN aa.IsFreeText = 1
							THEN uqa.AnswerString
						ELSE a.AnswerDescription
						END
					)
			WHERE pq.sno = 1
			) ptast ON ast.AssessmentKey = ptast.QuestionaireId
			AND ast.QuestionKey = ptast.QuestionId
			AND ast.AnswerKey = ptast.AnswerId
			AND (
				ast.ScoreRangeKey = ptast.QuestionnaireScoringID
				OR ptast.QuestionnaireScoringID IS NULL
				)
		) f ON ppm.PatientID = f.PatientKey

	IF @b_IsExecute = 1
	BEGIN
		SELECT ClaimInfoId
			,PatientID
			,DateKey
			,NetPaidAmount
		INTO #claim
		FROM ClaimInfo ci
		INNER JOIN Anchordate ad ON ad.AnchorDate = CASE 
				WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(ci.DateOfAdmit) - 1), ci.DateOfAdmit)
						AND CASE 
								WHEN YEAR(ci.DateOfDischarge) = 9999
									THEN ci.DateOfDischarge
								ELSE EOMONTH(ci.DateOfDischarge) 
								END
					THEN ad.AnchorDate
				ELSE NULL
				END

		SELECT DISTINCT pi1.PatientID
			,igp.InsuranceGroupId
			,ad.DateKey
		INTO #insurance
		FROM PatientInsuranceBenefit pib WITH (NOLOCK)
		INNER JOIN PatientInsurance pi1 WITH (NOLOCK) ON pi1.PatientInsuranceID = pib.PatientInsuranceID
		INNER JOIN InsuranceGroupPlan igp WITH (NOLOCK) ON igp.InsuranceGroupPlanId = pi1.InsuranceGroupPlanId
		INNER JOIN Patient p ON P.PatientID = PI1.PatientID
		INNER JOIN InsuranceGroup HP ON HP.InsuranceGroupID = igp.InsuranceGroupId
		INNER JOIN Anchordate ad ON ad.AnchorDate = CASE 
				WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pib.DateOfEligibility) - 1), pib.DateOfEligibility)
						AND CASE 
								WHEN YEAR(pib.CoverageEndsDate) = 9999
									THEN pib.CoverageEndsDate
								ELSE EOMONTH(pib.CoverageEndsDate)   
								END
					THEN ad.AnchorDate
				ELSE NULL
				END

		IF OBJECT_ID('TEMPDB..##FactHealthPlanTrend') IS NOT NULL
			DROP TABLE ##FactHealthPlanTrend;

		SELECT i.InsuranceGroupId
			,i.PatientID
			,i.DateKey
			,c.ClaimInfoId
			,c.NetPaidAmount
		INTO ##FactHealthPlanTrend
		FROM #claim c
		RIGHT JOIN #insurance i ON c.PatientID = i.PatientID
			AND c.DateKey = i.DateKey

		IF OBJECT_ID('TEMPDB..##FactHealthPlanClaimCost') IS NOT NULL
			DROP TABLE ##FactHealthPlanClaimCost

		SELECT DISTINCT i.InsuranceGroupId
			,i.PatientID
			,i.DateKey
			,pdp.PopulationDefinitionID
			,c.NetPaidAmount
		INTO ##FactHealthPlanClaimCost
		FROM (
			SELECT PatientID
				,DateKey
				,sum(NetPaidAmount) NetPaidAmount
			FROM #claim c
			GROUP BY PatientID
				,DateKey
			) c
		INNER JOIN #insurance i ON c.PatientID = i.PatientID
			AND c.DateKey = i.DateKey
		INNER JOIN PopulationDefinitionPatients pdp ON pdp.PatientID = c.PatientID
			AND pdp.StatusCode = 'A'

		IF OBJECT_ID('TEMPDB..##FactProviderClaimCost') IS NOT NULL
			DROP TABLE ##FactProviderClaimCost

		SELECT DISTINCT i.InsuranceGroupId
			,i.PatientID
			,i.DateKey
			,pdp.ProviderID
			,c.ClaimInfoId
			,c.NetPaidAmount
		INTO ##FactProviderClaimCost
		FROM #claim c
		INNER JOIN #insurance i ON c.PatientID = i.PatientID
			AND c.DateKey = i.DateKey
		INNER JOIN ClaimProvider pdp ON c.ClaimInfoId = pdp.ClaimInfoID

		SELECT DISTINCT pdp.PopulationDefinitionID DrKey
			,pdp.PatientID PatientKey
			,pdpad.DateKey DateKey
			,pdpad.ClaimAmt ClaimAmt
		INTO #BridgePatientDr
		FROM PopulationDefinitionPatients AS pdp
		INNER JOIN PopulationDefinitionPatientAnchorDate AS pdpad ON pdp.PopulationDefinitionPatientID = pdpad.PopulationDefinitionPatientID
		INNER JOIN ##dimpopulation dp ON dp.PopulationDefinitionID = pdp.PopulationDefinitionID
		INNER JOIN ##OLAP_SC_DimAnchordate ad ON ad.Datekey = pdpad.DateKey;

		WITH CTE
		AS (
			SELECT Sno = ROW_NUMBER() OVER (
					PARTITION BY MetricId
					,PatientID
					,DateKey ORDER BY ValueDate DESC
					)
				,MetricID
				,PatientID
				,DateKey
				,FrequencyID
			FROM NRPatientValue
			WHERE Value IS NOT NULL
			)
		SELECT m.MetricId MetricKey
			,OMR.PatientID PatientKey
			,OMR.DateKey DateKey
			,m.DenominatorID Drkey
			,OMR.FrequencyID FrequencyKey
		INTO #BridgePatientNr
		FROM Metric AS m
		INNER JOIN (
			SELECT nc.MetricID
				,nc.PatientID
				,nc.DateKey
				,nc.FrequencyID
			FROM NRPatientCount AS nc
			
			UNION ALL
			
			SELECT MetricID
				,PatientID
				,DateKey
				,FrequencyID
			FROM CTE
			WHERE Sno = 1
			) AS OMR ON m.MetricId = OMR.MetricID

		IF OBJECT_ID('TEMPDB..##FactFinancialReport') IS NOT NULL
			DROP TABLE ##OLAP_SC_FactFinancialReport;

		SELECT DISTINCT Dr.DrKey AS PopulationKey
			,nr.MetricKey
			,igp.InsuranceGroupId AS HealthPlanKey
			,dr.DateKey
			,dr.PatientKey
			,dr.ClaimAmt
		INTO ##FactFinancialReport
		FROM #BridgePatientDr dr WITH (NOLOCK)
		INNER JOIN #BridgePatientNr nr WITH (NOLOCK) ON dr.PatientKey = nr.PatientKey
			AND dr.DrKey = nr.Drkey
		INNER JOIN PatientInsurance pie WITH (NOLOCK) ON pie.PatientID = dr.PatientKey
		INNER JOIN PatientInsuranceBenefit pib WITH (NOLOCK) ON pib.PatientInsuranceID = pie.PatientInsuranceID
		INNER JOIN ReportFrequencyConfiguration rfc WITH (NOLOCK) ON rfc.MetricId = nr.MetricKey
			AND RFC.DrID = DR.DrKey
		INNER JOIN ReportFrequency rf WITH (NOLOCK) ON rf.ReportFrequencyId = rfc.ReportFrequencyId
		INNER JOIN InsuranceGroupPlan igp WITH (NOLOCK) ON igp.InsuranceGroupPlanId = pie.InsuranceGroupPlanId
		INNER JOIN ##OLAP_SC_DimHealthPlan HP ON HP.HealthPlanKey = igp.InsuranceGroupId
		INNER JOIN ##OLAP_SC_DimAnchordate ad WITH (NOLOCK) ON ad.DateKey = dr.DateKey
		INNER JOIN Report r WITH (NOLOCK) ON r.ReportId = rf.ReportID
		WHERE nr.DateKey = dr.DateKey
			AND ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pib.DateOfEligibility) - 1), pib.DateOfEligibility)
				AND CASE 
						WHEN YEAR(pib.CoverageEndsDate) = 9999
							THEN pib.CoverageEndsDate
						ELSE EOMONTH(pib.CoverageEndsDate)  
						END
			AND r.ReportName = 'Financial Report'
			AND rfc.StatusCode = 'A'
	END

	/* CCM Report */
	IF OBJECT_ID('TEMPDB..##OLAP_SC_CCMReport') IS NOT NULL
		DROP TABLE ##OLAP_SC_CCMReport
		
	SELECT DISTINCT pp.PatientKey
		,pp.ManagedPopulationKey ProgramID
		,pp.DateKey
	INTO #prog
	FROM #PRG pp WITH (NOLOCK)

	SELECT DISTINCT Q.PatientId
		,Q.DateKey
		,Mints
	INTO #Seg
	FROM (
		SELECT PQ.PatientId
			,AD.DateKey
			,SUM(CONVERT(DECIMAL(20, 6), case when UQA.AnswerString = '.' then '0' else UQA.AnswerString end )) Mints
		FROM PatientTask PQ WITH (NOLOCK)
		INNER JOIN (
			SELECT DISTINCT QU.QuestionaireId
				,A.AnswerId
			FROM Questionaire QU WITH (NOLOCK)
			INNER JOIN QuestionaireQuestionSet QQS WITH (NOLOCK) ON QU.QuestionaireId = QQS.QuestionaireId
			INNER JOIN QuestionSetQuestion QSQ WITH (NOLOCK) ON QSQ.QuestionSetId = QQS.QuestionSetId
			INNER JOIN Question Q WITH (NOLOCK) ON QSQ.QuestionId = Q.QuestionId
			INNER JOIN Answer A WITH (NOLOCK) ON A.QuestionId = Q.QuestionId
			WHERE Q.IsCCMReport = 1
			) DT ON DT.QuestionaireId = pq.TypeId
		INNER JOIN PatientAssessmentAnswer UQA WITH (NOLOCK) ON UQA.PatientTaskId = PQ.PatientTaskId
			AND UQA.AnswerID = DT.AnswerId
		INNER JOIN AnchorDate AD WITH (NOLOCK) ON AD.AnchorDate = EOMONTH(PQ.DateTaken) 
		WHERE PQ.TaskTypeId = @i_AssessmentTasktypeID
		AND pq.TaskStatusId = @i_TaskStatusID
			AND ISNUMERIC(UQA.AnswerString) = 1
		GROUP BY PQ.PatientId
			,AD.DateKey
		) Q

	SELECT p.PatientKey AS PatientKey
		,p.ProgramID AS ManagedPopulationKey
		,p.DateKey
		,isnull(s.Mints, 0) AS NumOfMinutes
	INTO ##OLAP_SC_CCMReport
	FROM #prog p
	LEFT JOIN #Seg s ON p.PatientKey = s.PatientId
		AND p.DateKey = s.DateKey

	SELECT DISTINCT PCP.PatientId
		,AD.DateKey
		,CP.ProviderID AS ClinicId
		,PP.ProviderID AS PCPId
	INTO #PCP
	FROM ProviderHierarchyDetail PHD WITH (NOLOCK)
	INNER JOIN Provider CP WITH (NOLOCK) ON PHD.ParentProviderID = CP.ProviderID
	INNER JOIN Provider PP WITH (NOLOCK) ON PHD.ChildProviderID = PP.ProviderID
	INNER JOIN PatientPCP PCP WITH (NOLOCK) ON PCP.ProviderID = PP.ProviderID
	INNER JOIN AnchorDate AD WITH (NOLOCK) ON AD.AnchorDate = CASE 
			WHEN AD.AnchorDate BETWEEN DATEADD(dd, - (DAY(PHD.BeginDate) - 1), PHD.BeginDate)
					AND CASE 
							WHEN YEAR(ISNULL(PHD.EndDate, '9999-12-31')) = 9999
								THEN ISNULL(PHD.EndDate, '9999-12-31')
							ELSE EOMONTH(PHD.EndDate) 
							END
				THEN AD.AnchorDate
			ELSE NULL
			END
		AND AD.AnchorDate = CASE 
			WHEN AD.AnchorDate BETWEEN DATEADD(dd, - (DAY(PCP.CareBeginDate) - 1), PCP.CareBeginDate)
					AND CASE 
							WHEN YEAR(ISNULL(PCP.CareEndDate, '9999-12-31')) = 9999
								THEN ISNULL(PCP.CareEndDate, '9999-12-31')
							ELSE EOMONTH(PCP.CareEndDate) 
							END
				THEN AD.AnchorDate
			ELSE NULL
			END
		

	SELECT DISTINCT DP.ProductKey
		,AD.DateKey
		,PIN.PatientID
	INTO #Product
	FROM ##OLAP_SC_DimProduct DP
	INNER JOIN InsuranceGroupPlan IGP ON IGP.ProductType = DP.ProductCode
	INNER JOIN PatientInsurance PIN ON IGP.InsuranceGroupPlanId = PIN.InsuranceGroupPlanId
	INNER JOIN PatientInsuranceBenefit PIB ON PIN.PatientInsuranceID = PIB.PatientInsuranceID
	INNER JOIN AnchorDate AD ON AD.AnchorDate = CASE 
			WHEN AD.AnchorDate BETWEEN DATEADD(dd, - (DAY(PIB.DateOfEligibility) - 1), PIB.DateOfEligibility)
					AND CASE 
							WHEN YEAR(ISNULL(PIB.CoverageEndsDate, '9999-12-31')) = 9999
								THEN ISNULL(PIB.CoverageEndsDate, '9999-12-31')
							ELSE EOMONTH(PIB.CoverageEndsDate) 
							END
				THEN AD.AnchorDate
			ELSE NULL
			END

	SELECT DISTINCT PDP.PatientID
		,PDP.PopulationDefinitionID
		,REPLACE(CAST(PDPA.OutPutAnchorDate AS VARCHAR), '-', '') DateKey
	INTO #DrPatient
	FROM PopulationDefinitionPatientAnchorDate PDPA
	INNER JOIN PopulationDefinitionPatients PDP ON PDPA.PopulationDefinitionPatientID = PDP.PopulationDefinitionPatientID

	IF OBJECT_ID('TEMPDB..##OLAP_SC_PatientAttribute') IS NOT NULL
		DROP TABLE ##OLAP_SC_PatientAttribute

	SELECT DISTINCT P.PatientKey
		,P.DateKey
		,PCP.ClinicId AS ClinicKey
		,PCP.PCPId AS PCPKey
		,tp.ProductKey
		,DRP.PopulationDefinitionID AS PopulationKey
	INTO ##OLAP_SC_PatientAttribute
	FROM #prog P
	LEFT JOIN #PCP PCP ON PCP.DateKey = P.DateKey
		AND PCP.PatientId = P.PatientKey
	LEFT JOIN #Product TP ON P.DateKey = TP.DateKey
		AND P.PatientKey = TP.PatientID
	LEFT JOIN #DrPatient DRP ON DRP.DateKey = P.DateKey
		AND DRP.PatientID = P.PatientKey

	IF OBJECT_ID('TEMPDB..##OLAP_SC_FactPatientAttributes') IS NOT NULL
		DROP TABLE ##OLAP_SC_FactPatientAttributes
		
		SELECT  prg.PatientKey PatientKey ,  prg.datekey DateKey, prg.ManagedPopulationKey, pcp.ClinicID ClinicKey, pcp.PCPId PCPKey 
		into ##OLAP_SC_FactPatientAttributes
		FROM #PRG Prg
		left JOIN #PCP pcp
		on pcp.PatientID = prg.PatientKey
		and pcp.DateKey = prg.DateKey
		

IF OBJECT_ID('TEMPDB..##FactPatientReAdmission') IS NOT NULL
		DROP TABLE ##FactPatientReAdmission;

	DECLARE @i_Questionaireid INT
	
	CREATE TABLE #Program
	(
		ProgramId INT
	)

	INSERT INTO #Program
	(
		ProgramId
	)
	SELECT ProgramId
	FROM Program 
	WHERE ProgramName IN ('TC Tammy Brown Care Team','TC Hanna Hensel Care Team','TC Kelley Pruet Care Team','TC Julia Collins Care Team','TC Teressa Williams Care Team',
							'TC Myreta Killen Care Team','TC Donna Tinkle Care Team')
	AND StatusCode = 'A'

	SELECT @i_Questionaireid = QuestionaireId FROM Questionaire WHERE QuestionaireName = 'Final Program Assessment'

	;WITH ReadmitCTE
	AS (
		SELECT PatientEventNotificationID
			,Patientid
			,VisitDischargedate
			,VisitAdmitdate
			,row_number() OVER (
				PARTITION BY Patientid ORDER BY VisitAdmitdate
				) AS r
		FROM patientevent e WITH(NOLOCK)
		INNER JOIN patienteventnotification n WITH(NOLOCK) ON e.Patienteventid = n.patienteventid
		INNER JOIN eventtype t WITH(NOLOCK) ON t.EventTypeID = n.EventTypeID
		WHERE t.EventCode IN ('A01','A06')
		)
	SELECT DISTINCT readmit.PatientID
		,AdmittedToNextVisit
		,ReadmitDays
		,DischargedFromLastVisit
	INTO #readmit
	FROM PatientProgram PP WITH(NOLOCK)
	INNER JOIN #Program TP
		ON PP.ProgramID = TP.ProgramId
	INNER JOIN (
		SELECT c1.Patientid
			,c1.VisitDischargedate AS DischargedFromLastVisit
			,c2.VisitAdmitdate AS AdmittedToNextVisit
			,DATEDIFF(DD, c1.VisitDischargedate, c2.VisitAdmitdate) ReadmitDays
		FROM ReadmitCTE c1
		INNER JOIN ReadmitCTE c2 ON c1.Patientid = c2.Patientid
		WHERE c1.PatientEventNotificationID <> c2.PatientEventNotificationID
			AND c1.r + 1 = c2.r
			AND c1.VisitDischargedate IS NOT NULL
		) readmit
		ON PP.PatientID = readmit.PatientId
	WHERE ReadmitDays BETWEEN 1 AND 90
	AND readmit.AdmittedToNextVisit BETWEEN PP.EnrollmentStartDate AND ISNULL(PP.EnrollmentEndDate,'9999-12-31')
	AND EXISTS (SELECT 1
				FROM PatientTask PQ WITH(NOLOCK)
				INNER JOIN PatientAssessmentAnswer UQA WITH(NOLOCK) ON PQ.PatientTaskId = UQA.PatientTaskId
				INNER JOIN QuestionSetQuestion QSQ WITH(NOLOCK) ON UQA.QuestionSetQuestionId = QSQ.QuestionSetQuestionId
				INNER JOIN  Question QS WITH(NOLOCK) ON QS.QuestionId = QSQ.QuestionId
				INNER JOIN Answer A WITH(NOLOCK) ON UQA.AnswerID = A.AnswerID
													AND QS.QuestionId = A.QuestionId	
				WHERE pq.TypeId = @i_Questionaireid 
				AND pq.TaskTypeId = @i_AssessmentTasktypeID
				AND pq.TaskStatusId = @i_TaskStatusID
				AND QS.[Description] = 'Did this patient complete the Transitions Program?'
				AND ISNULL(NULLIF(UQA.AnswerString,''),A.AnswerDescription) = 'Yes'
				AND PP.PatientId = PQ.PatientId
				AND PQ.DateTaken BETWEEN readmit.DischargedFromLastVisit AND DATEADD(DAY,45,readmit.DischargedFromLastVisit))

	SELECT pe1.PatientId PatientKey
		,ad1.DateKey
		,1 AS EventTypeKey
		,ReadmitDays
		,pe1.AdmittedToNextVisit as ReadmitDate
	INTO ##FactPatientReAdmission
	FROM #readmit pe1
	INNER JOIN AnchorDate ad1 ON ad1.AnchorDate = EOMONTH(pe1.DischargedFromLastVisit)

	---------------------
		IF OBJECT_ID('TEMPDB..##SC_FactPatientCondition') IS NOT NULL
		DROP TABLE ##SC_FactPatientCondition

	SELECT DISTINCT cgt.CodeGroupingID CodeGroupKey
		,ci.PatientID PatientKey
		,CAST(ci.DateOfAdmit AS DATE) DateIdentified
	INTO ##SC_FactPatientCondition
	FROM ClaimCodeGroup ccg WITH (NOLOCK)
	INNER JOIN ClaimInfo ci WITH (NOLOCK) ON ccg.ClaimInfoID = ci.ClaimInfoId
	INNER JOIN (
		SELECT CG.CodeGroupingID
			,CG.CodeGroupingName
		FROM CodeGrouping CG WITH (NOLOCK)
		INNER JOIN CodeTypeGroupers CTG WITH (NOLOCK) ON CG.CodeTypeGroupersID = CTG.CodeTypeGroupersID
		WHERE CTG.CodeTypeGroupersName IN (
			'AHRQ Procedure Groupers'
			,'AHRQ Diagnosis Groupers'
				)
			AND CG.StatusCode = 'A'
		) cgt ON ccg.CodeGroupingID = cgt.CodeGroupingID
		
	INSERT INTO ##SC_FactPatientCondition (
		CodeGroupKey
		,PatientKey
		,DateIdentified
		)
	SELECT DISTINCT 0
		,PatientKey
		,'9999-01-01'
	FROM ##OLAP_SC_CCMReport r
	WHERE NOT EXISTS (
			SELECT 1
			FROM ##SC_FactPatientCondition c
			WHERE c.PatientKey = r.PatientKey
			)



END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH