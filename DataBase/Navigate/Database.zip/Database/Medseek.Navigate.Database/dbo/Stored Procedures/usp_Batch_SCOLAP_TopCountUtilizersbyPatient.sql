﻿
/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_SCOLAP_TopCountUtilizersbyPatient]
Description   :This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Nagasiva  
Created Date  : 23-Jan-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
13-Feb-2015 Nagasiva  assigned null value to  @i_AppUserId  Parameter to remove the hardcoded userid in cube execution package
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_SCOLAP_TopCountUtilizersbyPatient] (@i_AppUserId KEYID =NULL)
AS
BEGIN TRY
	SET NOCOUNT ON

	SELECT @i_AppUserId =MIN(UserId) FROM Users

	SELECT cg.CodeGroupingID
	INTO #CodeGroup
	FROM dbo.CodeGrouping cg WITH (NOLOCK)
	INNER JOIN dbo.CodeTypeGroupers ctg WITH (NOLOCK) ON ctg.CodeTypeGroupersID = cg.CodeTypeGroupersID
	WHERE ctg.CodeTypeGroupersName = 'Encounter Types(Internal)'

	CREATE TABLE #PatientCodegroup (
		CodeGroupingID INT
		,PatientID INT
		,ClaimInfoId INT
		,DateKey INT
		,Amt MONEY
		)

	INSERT INTO #PatientCodegroup (
		CodeGroupingID
		,PatientID
		,ClaimInfoId
		,DateKey
		)
	SELECT DISTINCT CCG.CodeGroupingID
		,CI.PatientID
		,CI.ClaimInfoId
		,AD.DateKey
	FROM ClaimCodeGroup CCG WITH (NOLOCK)
	INNER JOIN #CodeGroup TCG  ON CCG.CodeGroupingID = TCG.CodeGroupingID
	INNER JOIN ClaimInfo CI WITH (NOLOCK) ON CCG.ClaimInfoID = CI.ClaimInfoId
	INNER JOIN ##OLAP_SC_DimAnchordate AD WITH (NOLOCK) ON ad.DateKey = CASE 
			WHEN CI.DateOfAdmit > = DATEADD(dd, - (DAY(ad.AnchorDate) - 1), ad.AnchorDate)
				AND CI.DateOfAdmit < = ad.AnchorDate
				THEN ad.DateKey
			ELSE NULL
			END

	UPDATE #PatientCodegroup
	SET Amt = ci.ChargeAmount
	FROM ClaimInfo ci WITH (NOLOCK)
	WHERE CI.ClaimInfoId = #PatientCodegroup.ClaimInfoId
	
	IF OBJECT_ID('TEMPDB..##OLAP_SC_FactUtilizersByPatient') IS NOT NULL
		DROP TABLE ##OLAP_SC_FactUtilizersByPatient;

	SELECT CodeGroupingID AS UtilizationKey
		,PatientID AS PatientKey
		,DateKey AS DateKey
		,ClaimInfoId AS ClaimId
		,Amt AS ClaimAmt
	INTO ##OLAP_SC_FactUtilizersByPatient
	FROM #PatientCodegroup
	WHERE Amt IS NOT NULL
	
	DROP TABLE #CodeGroup
	DROP TABLE #PatientCodegroup
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH