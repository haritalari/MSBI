/*    
----------------------------------------------------------------------------------    
Procedure Name: [usp_CareManager_Search]
Description   : 
Created By    : 
Created Date  : 
----------------------------------------------------------------------------------    
Log History   :     
DD-MM-YYYY  BY   DESCRIPTION    
----------------------------------------------------------------------------------    
*/  
CREATE PROCEDURE [dbo].[usp_CareManager_Search] 
(
	@i_AppUserId KEYID ,
	@v_UserLoginName VARCHAR(256) = NULL ,
	@v_LastName LASTNAME = NULL ,
	@v_FirstName LASTNAME = NULL ,
	@v_City VARCHAR(50) = NULL ,
	@v_State VARCHAR(50) = NULL ,
	@v_ZipCode VARCHAR(10) = NULL ,
	@v_EmailIdPrimary EMAILID = NULL ,
	@v_PhoneNumberPrimary PHONE = NULL ,
	@i_StartIndex INT = 1 ,
	@i_EndIndex INT = 10
)
AS
	BEGIN TRY
		SET NOCOUNT ON

		----- Check if valid Application User ID is passed--------------    
		IF (@i_AppUserId IS NULL)
			OR (@i_AppUserId <= 0)
		BEGIN
			RAISERROR (
					N'Invalid Application User ID %d passed.'
					,17
					,1
					,@i_AppUserId
					)
		END 

		SELECT
			PR.ProviderId AS UserId,
			U.UserLoginName ,
			U.FirstName ,
			U.LastName ,
			'' AS PCPName ,
			'' AS AgeGender ,
			CAST(NULL AS DATETIME) AS DateOfBirth ,
			'' AS MemberNum ,
			PR.PrimaryPhoneNumber ,
			PR.PrimaryPhoneNumberExtension ,
			PR.PrimaryAddressLine1 AS AddressLine1 ,
			PR.PrimaryAddressLine2 AS AddressLine2 ,
			PR.PrimaryAddressCity AS City ,
			PR.PrimaryAddressPostalCode AS ZipCode ,
			NULL AS IsPatient ,
			COALESCE(ISNULL((U.LastName + ' '),'') + '' + ISNULL((U.FirstName + ' '),''),'') AS Fullname ,
			U.AccountStatusCode AS UserStatus ,
			SR.RoleName AS SecurityName ,
			U.PrimaryEmailAddress AS EmailIdPrimary ,
			CASE 
				WHEN U.AccountStatusCode = 'A' THEN 'Active' 
				WHEN U.AccountStatusCode = 'I' THEN 'Inactive' 
				WHEN U.AccountStatusCode = 'L' THEN 'Locked'
			END AS [Description]
		FROM Users U
		INNER JOIN UserGroup UG
			ON U.UserId = UG.UserID
		INNER JOIN SecurityRole SR
			ON UG.SecurityRoleId = SR.SecurityRoleId
		INNER JOIN Provider PR
			ON UG.ProviderID = PR.ProviderID
		LEFT JOIN CodeSetState CSS
			ON CSS.StateID = PR.PrimaryAddressStateCodeID
		WHERE SR.RoleName = 'Care Manager'
			AND U.AccountStatusCode = 'A'
			AND UG.StatusCode = 'A'
			AND (U.UserLoginName LIKE + '%' + @v_UserLoginName + '%' OR @v_UserLoginName IS NULL)
			AND (U.FirstName LIKE + '%' + @v_FirstName + '%' OR @v_FirstName IS NULL)
			AND (U.LastName LIKE + '%' + @v_LastName + '%' OR @v_LastName IS NULL)
			AND (PR.PrimaryAddressCity LIKE + '%' + @v_City + '%' OR @v_City IS NULL )
			AND (PR.PrimaryAddressPostalCode LIKE + '%' + @v_ZipCode + '%' OR @v_ZipCode IS NULL )
			AND (PR.PrimaryPhoneNumber LIKE + '%' + @v_PhoneNumberPrimary + '%' OR @v_PhoneNumberPrimary IS NULL )
			AND (CSS.StateName LIKE + '%' + @v_State + '%' OR @v_State IS NULL )
			AND (U.PrimaryEmailAddress = @v_EmailIdPrimary OR @v_EmailIdPrimary IS NULL)
		ORDER BY U.UserLoginName
		OFFSET (@i_StartIndex - 1) * @i_EndIndex ROWS
		FETCH NEXT @i_EndIndex ROWS ONLY
		
		SELECT COUNT(1) AS Cnt
		FROM Users U
		INNER JOIN UserGroup UG
			ON U.UserId = UG.UserID
		INNER JOIN SecurityRole SR
			ON UG.SecurityRoleId = SR.SecurityRoleId
		INNER JOIN Provider PR
			ON UG.ProviderID = PR.ProviderID
		LEFT JOIN CodeSetState CSS
			ON CSS.StateID = PR.PrimaryAddressStateCodeID
		WHERE SR.RoleName = 'Care Manager'
			AND U.AccountStatusCode = 'A'
			AND UG.StatusCode = 'A'
			AND (U.UserLoginName LIKE + '%' + @v_UserLoginName + '%' OR @v_UserLoginName IS NULL)
			AND (U.FirstName LIKE + '%' + @v_FirstName + '%' OR @v_FirstName IS NULL)
			AND (U.LastName LIKE + '%' + @v_LastName + '%' OR @v_LastName IS NULL)
			AND (PR.PrimaryAddressCity LIKE + '%' + @v_City + '%' OR @v_City IS NULL )
			AND (PR.PrimaryAddressPostalCode LIKE + '%' + @v_ZipCode + '%' OR @v_ZipCode IS NULL )
			AND (PR.PrimaryPhoneNumber LIKE + '%' + @v_PhoneNumberPrimary + '%' OR @v_PhoneNumberPrimary IS NULL )
			AND (CSS.StateName LIKE + '%' + @v_State + '%' OR @v_State IS NULL )
			AND (U.PrimaryEmailAddress = @v_EmailIdPrimary OR @v_EmailIdPrimary IS NULL)  			

END TRY
--------------------------------------------------------     
BEGIN CATCH
	-- Handle exception    
	DECLARE @i_ReturnedErrorID INT
	EXECUTE @i_ReturnedErrorID = usp_HandleException @i_UserId = @i_AppUserId
	RETURN @i_ReturnedErrorID
END CATCH



