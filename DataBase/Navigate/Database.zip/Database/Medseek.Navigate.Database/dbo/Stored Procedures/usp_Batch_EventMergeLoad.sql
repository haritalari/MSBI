﻿
/*          
-----------------------------------------------------------------------------------------------------------------                 
Procedure Name: [usp_Batch_EventMergeLoad]
Description   : This StoredProcedure used to load ADT data into Transaction database for the event A40
Created By    : NagaBabu
Created Date  : 08-Jun-2015
-----------------------------------------------------------------------------------------------------------------                 
Log History   :           
DD-MM-YYYY  BY   DESCRIPTION
24-Jun-2015 NagaBabu Deleted the functionality to insert inactive patient data into PatientMerge table as well as updations of Active patients in dependent tables 
26-Jun-2015 NagaBabu Added comment for update statements to update the reason for 'H','F' of respective event  
14-Jul-2015 Nagababu Added the logic to insert data into ProviderEventNotification table
05-Aug-2015 Nagababu Modified logic to allow active patient for merge event with multiple inactive patients as per NAVI-3430
14-Sep-2015 Nagababu Added new parameter @i_CreatedByUserId
05-Jan-2016 Nagababu Modified the logic as per NAVI-4864
05-Feb-2016 NagaBabu Modified the logic as per NAVI-4848
15-Feb-2016 NagaBabu Modified the logic as per NAVI-5147
29-Feb-2016 NagaBabu Added logic to make status 'F' for Active patient not available in Navigate as per NAVI-2591 
11-Mar-2016 NagaBabu Modified logic as per NAVI-5485 and NAVI-5426
23-May-2016 Nagababu Modified the code as per NAVI-6025
01-Jun-2016 Rathnam  Added functionality for Admin notifications as per NAVI- 5972
-----------------------------------------------------------------------------------------------------------------                
*/
CREATE PROCEDURE [dbo].[usp_Batch_EventMergeLoad]
AS
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @i_CreatedByUserId INT

	SELECT @i_CreatedByUserId = ProviderId
	FROM Provider P
	INNER JOIN CodeSetProviderType CSP ON P.ProviderTypeID = CSP.ProviderTypeCodeID
	WHERE CSP.[Description] = 'Administrator'
		AND P.FirstName = 'User'
		AND P.LastName = 'HL7'

	UPDATE TM
	SET MergePatientId = PRI.PatientId
	FROM ##Event_Merge TM
	INNER JOIN Patient PRI ON TM.MergeMid = PRI.PatientPrimaryId

	UPDATE TM
	SET CurrentPatientId = CUR.PatientId
	FROM ##Event_Merge TM
	INNER JOIN Patient CUR ON TM.Mid = CUR.PatientPrimaryId

	UPDATE ##Event_Merge
	SET [Status] = 'F'
		,[Comments] = 'MergePatient does not exist'
	WHERE MergePatientId IS NULL
		AND IsIdentifierMove = 'False'

	UPDATE ##Event_Merge
	SET [Status] = 'H'
		,[Comments] = 'Active Patient does not exist'
	WHERE MergePatientId IS NOT NULL
		AND CurrentPatientId IS NULL
		AND IsIdentifierMove = 'False'

	UPDATE AM
	SET [Status] = 'F'
		,[Comments] = 'Inactive patient has come with multiple active patients for merge event'
	FROM ##Event_Merge AM
	INNER JOIN (
		SELECT MergePatientId
		FROM (
			SELECT DISTINCT MergePatientId
				,CurrentPatientId
			FROM ##Event_Merge
			WHERE [Status] = 'P'
			) DTP
		GROUP BY MergePatientId
		HAVING COUNT(*) > 1
		) DT1 ON AM.MergePatientId = DT1.MergePatientId
	WHERE IsIdentifierMove = 'False'

	UPDATE AM
	SET [Status] = 'F'
		,[Comments] = 'This is a duplicate request, already merge event is processed between these patients'
	FROM ##Event_Merge AM
	WHERE EXISTS (
			SELECT 1
			FROM PatientEvent PE
			WHERE PE.MergePatientId = AM.MergePatientId
				AND PE.PatientId = AM.CurrentPatientId
			)
		AND AM.[Status] = 'P'
		AND IsIdentifierMove = 'False'

	UPDATE AM
	SET [Status] = 'F'
		,[Comments] = 'Merge event is already processed for This Inactive patient with other active patient'
	FROM ##Event_Merge AM
	WHERE EXISTS (
			SELECT 1
			FROM PatientEvent PE
			WHERE PE.MergePatientId = AM.MergePatientId
				AND PE.PatientId <> AM.CurrentPatientId
			)
		AND AM.[Status] = 'P'
		AND IsIdentifierMove = 'False'

	DECLARE @i_EventTypeId INT

	SELECT @i_EventTypeId = EventTypeId
	FROM EventType
	WHERE EventCode = 'A40'

	DECLARE @l_TranStarted BIT = 0

	IF (@@TRANCOUNT = 0)
	BEGIN
		BEGIN TRANSACTION

		SET @l_TranStarted = 1 -- Indicator for start of transactions
	END

	INSERT INTO PatientEvent (
		PatientId
		,MergePatientId
		,CreatedByUserId
		)
	SELECT DISTINCT AM.CurrentPatientId
		,AM.MergePatientId
		,@i_CreatedByUserId AS CreatedByUserId
	FROM ##Event_Merge AM
	WHERE [Status] IN ('P','H')
		AND NOT EXISTS (
			SELECT 1
			FROM PatientEvent PE
			WHERE (
					PE.PatientId = AM.CurrentPatientId
					AND PE.MergePatientId = AM.MergePatientId
					)
				AND PE.MergePatientId IS NOT NULL
			)
		AND AM.CurrentPatientId IS NOT NULL
		AND IsIdentifierMove = 'False'

	INSERT INTO PatientEventNotification (
		PatientEventId
		,EventTypeId
		,EventDate
		,CreatedByUserId
		,SourceId
		)
	SELECT DISTINCT PE.PatientEventId
		,@i_EventTypeId
		,GETDATE()
		,@i_CreatedByUserId AS CreatedByUserId
		,AM.GeneralId
	FROM ##Event_Merge AM
	INNER JOIN PatientEvent PE ON AM.CurrentPatientId = PE.PatientId
		AND AM.MergePatientId = PE.MergePatientId
	WHERE [Status] IN ('P','H')
		AND NOT EXISTS (
			SELECT 1
			FROM PatientEventNotification PEN
			WHERE PEN.PatientEventId = PE.PatientEventId
			)
		AND AM.CurrentPatientId IS NOT NULL
		AND IsIdentifierMove = 'False'

	UPDATE AM
	SET [Status] = 'C'
		,Comments = NULL
	FROM ##Event_Merge AM
	INNER JOIN PatientEventNotification PEN ON AM.GeneralId = PEN.SourceId

	UPDATE AM
	SET [Status] = 'F'
		,Comments = '60 calendar days expired; surviving patient not yet created'
	FROM ##Event_Merge AM
	WHERE DATEDIFF(DD, AM.CreatedDate, GETDATE()) > 60
		AND [Status] = 'H'

	DECLARE @i_ProgramID INT

	SELECT @i_ProgramID = ProgramId
	FROM Program
	WHERE ProgramName = 'All Patients Managed Population'

	/*Managed Population CTM notifications*/
	SELECT PatientID
		,GeneralId
	INTO #pat
	FROM (
		SELECT CurrentPatientId AS PatientID
			,GeneralId
		FROM ##Event_Merge
		WHERE [Status] = 'C'
		
		UNION
		
		SELECT MergePatientId
			,GeneralId
		FROM ##Event_Merge
		WHERE [Status] = 'C'
		) P

	SELECT DISTINCT pm.ProgramID
		,s.GeneralId
	INTO #prg
	FROM PatientProgram pm
	INNER JOIN #pat s ON pm.PatientID = s.PatientID
	WHERE pm.StatusCode = 'E'
		AND pm.ProgramID <> @i_ProgramID

	SELECT DISTINCT pp.ProviderID
		,p.GeneralId
	INTO #prov
	FROM ProgramProvider PP
	INNER JOIN #prg p ON pp.ProgramID = p.ProgramID

	INSERT INTO ProviderEventNotification (
		PatientEventNotificationID
		,ProviderID
		)
	SELECT pen.PatientEventNotificationId
		,p.ProviderID
	FROM PatientEventNotification pen
	INNER JOIN #prov p ON p.GeneralId = pen.SourceId
	WHERE NOT EXISTS (
			SELECT 1
			FROM ProviderEventNotification PREN
			WHERE PREN.PatientEventNotificationID = PEN.PatientEventNotificationID
				AND PREN.ProviderID = P.ProviderID
			)

	/*Admin notifications*/
	SELECT pen.PatientEventNotificationId
	INTO #adminevent
	FROM PatientEventNotification pen
	INNER JOIN (
		SELECT DISTINCT p.GeneralId
		FROM #pat p
		WHERE NOT EXISTS (
				SELECT 1
				FROM #prg g
				WHERE g.GeneralId = p.GeneralId
				)
		) g ON pen.SourceId = g.GeneralId

	IF EXISTS (SELECT 1 FROM #adminevent)
	BEGIN
	;WITH prv
	AS (
		SELECT ug.ProviderID
		FROM UserGroup ug
		INNER JOIN SecurityRole sr ON ug.SecurityRoleId = sr.SecurityRoleId
		WHERE RoleName = 'Administrator'
			AND ug.StatusCode = 'A'
		)
	INSERT INTO ProviderEventNotification (
		PatientEventNotificationID
		,ProviderID
		)
	SELECT A.PatientEventNotificationId
		,prv.ProviderID
	FROM #adminevent A
	CROSS JOIN prv
	END
	-------------------------------------------------------------------------------------------------------------------------------------------
	UPDATE P
	SET MedicalRecordNumber = TM.PatientIdentifier
		,LastModifiedByUserID = @i_CreatedByUserId
		,LastModifiedDate = GETDATE()
	FROM Patient P
	INNER JOIN ##Event_Merge TM ON P.PatientID = ISNULL(TM.CurrentPatientId, TM.MergePatientId)
	WHERE TM.IsIdentifierMove = 'True'
		AND TM.IdentifierStatus = 'True'

	UPDATE TM
	SET [Status] = 'C'
	FROM ##Event_Merge TM
	WHERE EXISTS (
			SELECT 1
			FROM Patient P
			WHERE P.PatientPrimaryId = ISNULL(NULLIF(Mid, '00000000-0000-0000-0000-000000000000'), NULLIF(MergeMID, '00000000-0000-0000-0000-000000000000'))
			)
		AND ISNULL(NULLIF(Mid, '00000000-0000-0000-0000-000000000000'), NULLIF(MergeMID, '00000000-0000-0000-0000-000000000000')) IS NOT NULL
		AND TM.IsIdentifierMove = 'True'
		AND TM.IdentifierStatus = 'True'

	UPDATE TM
	SET [Status] = 'F'
	FROM ##Event_Merge TM
	WHERE NOT EXISTS (
			SELECT 1
			FROM Patient P
			WHERE P.PatientPrimaryId = ISNULL(NULLIF(Mid, '00000000-0000-0000-0000-000000000000'), NULLIF(MergeMID, '00000000-0000-0000-0000-000000000000'))
			)
		AND ISNULL(NULLIF(Mid, '00000000-0000-0000-0000-000000000000'), NULLIF(MergeMID, '00000000-0000-0000-0000-000000000000')) IS NOT NULL
		AND TM.IsIdentifierMove = 'True'

	IF (@l_TranStarted = 1) -- If transactions are there, then commit
	BEGIN
		SET @l_TranStarted = 0

		COMMIT TRANSACTION
	END
END TRY

-----------------------------------------------------------------------------------------------------------------       
BEGIN CATCH
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_CreatedByUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH