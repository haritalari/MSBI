﻿
/*              
------------------------------------------------------------------------------              
Procedure Name: usp_CareTeamMembers_Select             
Description   : This procedure is used to get the CareTeamMembers Details based on the           
    CareTeamID or get all the CareTeamMembers when passed NULL            
Created By    : Aditya              
Created Date  : 15-Mar-2010              
------------------------------------------------------------------------------              
Log History   :               
DD-MM-YYYY  BY   DESCRIPTION              
22-Jun-10 Pramod Replaced the inner join with ProfessionalType with outer join    
27-Sep-2010 NagaBabu Added CreatedDate,LastModifiedByUserId,LastModifiedDate Fields    
25-Nov-2011 NagaBabu Changed LastName field by Taking fullname script 
31-Aug-2016 Rathnam modified as per NAVI-6692   
------------------------------------------------------------------------------              
*/
CREATE PROCEDURE [dbo].[usp_CareTeamMembers_Select] (
	@i_AppUserId KEYID
	,@i_CareTeamId KEYID = NULL
	,@v_StatusCode StatusCode = NULL
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	-- Check if valid Application User ID is passed              
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END
	
	----------- Select CareTeamMembers details -------------------        
	SELECT ug.ProviderID AS UserID
		,ctm.CareTeamId
		,ctm.IsCareTeamManager
		,ISNULL(u.LastName, '') + ', ' + ISNULL(u.FirstName, '')  AS LastName
		,u.FirstName
		,null as ProfessionalTypeID
		,null AS NAME
		,u.PrimaryEmailAddress AS EmailIdPrimary
		,ctm.CreatedByUserId
		,CASE ctm.StatusCode
			WHEN 'A'
				THEN 'Active'
			WHEN 'I'
				THEN 'InActive'
			END AS STATUS
		,ctm.CreatedDate
		,ctm.LastModifiedByUserId
		,ctm.LastModifiedDate
		,CASE ctm.IsCareTeamManager
			WHEN '0'
				THEN 'No'
			WHEN '1'
				THEN 'Yes'
			END AS IsCareManager
	FROM CareTeamMembers ctm WITH (NOLOCK)
	INNER JOIN UserGroup ug WITH (NOLOCK) ON ug.ProviderID = ctm.ProviderID
	INNER JOIN Users u WITH(NOLOCK)
	ON u.UserId = ug.UserID
	WHERE (
			ctm.CareTeamId = @i_CareTeamId
			OR @i_CareTeamId IS NULL
			)
		AND (
			@v_StatusCode IS NULL
			OR ctm.StatusCode = @v_StatusCode
			)
	ORDER BY LastName
END TRY

BEGIN CATCH
	-- Handle exception              
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId

	RETURN @i_ReturnedErrorID
END CATCH
