﻿/****** Object:  StoredProcedure [dbo].[usp_CareTeamMembers_Insert]    Script Date: 09/22/2014 09:37:51 ******/
/*          
------------------------------------------------------------------------------          
Procedure Name: usp_CareTeamMembers_Insert          
Description   : This procedure is used to insert record into CareTeamMembers table      
Created By    : Aditya          
Created Date  : 15-Mar-2010          
------------------------------------------------------------------------------          
Log History   :           
DD-MM-YYYY  BY   DESCRIPTION          
27-Sep-2010 NagaBabu Added @l_numberOfRecordsInserted condition for Error message
12-Oct-10 Pramod Removed the duplicate check condition
22-Sep-2014 Rathnam As requested by Naresh & Praween. we dont have page for assinging 
		  the taskrights in V3.0, so every provider autometcially have rights to all tasktypes
21-May-2015 Rathnam modified the SP as per BugID:2950
24-Nov-2015 Nagababu Added new table ProgramProvider to this script as per the NAVI-4347 
12-Apr-2016 Rathnam modified SP as per the NAVI-5771
------------------------------------------------------------------------------          
*/
CREATE PROCEDURE [dbo].[usp_CareTeamMembers_Insert] (
	@i_AppUserId KEYID
	,@i_UserId KEYID
	,@i_CareTeamId KEYID
	,@i_IsCareTeamManager KEYID
	,@vc_StatusCode STATUSCODE
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @l_numberOfRecordsInserted INT

	-- Check if valid Application User ID is passed          
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END

	------------------insert operation into CareTeamMembers table-----        
	IF EXISTS (
			SELECT 1
			FROM CareTeamMembers
			WHERE CareTeamId = @i_CareTeamId
				AND ProviderID = @i_UserId
			)
	BEGIN
		UPDATE CareTeamMembers
		SET StatusCode = 'A'
		WHERE CareTeamId = @i_CareTeamId
			AND ProviderID = @i_UserId
	END
	ELSE
	BEGIN
		INSERT INTO CareTeamMembers (
			ProviderID
			,StatusCode
			,CareTeamId
			,IsCareTeamManager
			,CreatedByUserId
			)
		VALUES (
			@i_UserId
			,@vc_StatusCode
			,@i_CareTeamId
			,@i_IsCareTeamManager
			,@i_AppUserId
			)
	END

	INSERT INTO ProgramProvider
	(
		ProgramID
		,ProviderID
		,CreatedByUserID
	)
	SELECT DISTINCT
		PCT.ProgramId 
		,CTM.ProviderID
		,@i_AppUserId
	FROM ProgramCareTeam PCT
	INNER JOIN CareTeamMembers CTM ON PCT.CareTeamId = CTM.CareTeamId
	WHERE CTM.ProviderID = @i_UserId
	AND CTM.CareTeamId = @i_CareTeamId
	AND NOT EXISTS (SELECT 1
					FROM ProgramProvider PP WITH(NOLOCK)
					WHERE PP.ProgramId = PCT.ProgramId
					AND PP.ProviderId = @i_UserId)

		/* we dont have page for assinging the taskrights in V3.0, so every provider autometcially have rights to all tasktypes*/
	INSERT INTO CareTeamTaskRights (
		ProviderID
		,TaskTypeId
		,CareTeamId
		,StatusCode
		,CreatedByUserId
		,CreatedDate
		)
	SELECT @i_UserId
		,TaskTypeId
		,@i_CareTeamId
		,'A'
		,@i_AppUserId
		,GETDATE()
	FROM TaskType
	WHERE NOT EXISTS (
			SELECT 1
			FROM CareTeamTaskRights ct
			WHERE ct.ProviderID = @i_UserId
				AND ct.TaskTypeId = TaskType.TaskTypeId
				AND ct.CareTeamId = @i_CareTeamId
			)

	RETURN 0
END TRY

--------------------------------------------------------           
BEGIN CATCH
	-- Handle exception          
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId

	RETURN @i_ReturnedErrorID
END CATCH
GO

