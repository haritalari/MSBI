﻿/*          
------------------------------------------------------------------------------          
Procedure Name: [usp_Batch_EventORULoad]
Description   : This StoredProcedure is used to load the data into patientevent & Notification table
Created By    : Rathnam
Created Date  : 20-Feb-2015
------------------------------------------------------------------------------          
Log History   :           
DD-MM-YYYY  BY   DESCRIPTION
07-APR-2015 Nagababu Modified the querry to laod facilityId into PatientEvent table for the bugid 'NAVI 2658'
08-Apr-2015 Nagababu Modified the Answer identification querry with respcet to Assessment and Question for the bugid 'NAVI 2662' and 'NAVI 2664'
20-Apr-2015 Nagababu Removed the column SourceId from PatientEvent table part of NAVI-2470
26-Jun-2015 Nagababu Added the functionality to update the Hail,Hold comments to the staging tables
14-Jul-2015 Nagababu Added the logic to insert data into ProviderEventNotification table
14-Sep-2015 Nagababu Added new parameter @i_CreatedByUserId
15-Sep-2015 Nagababu Modified the script for considering Datetime of assessment instead of date as per NAVI-3879.
29-Oct-2015 NagaBabu Modified the script as per the NAVI-4264
02-Nov-2015 NagaBabu Modified the stored procedure for updating datetime answertypes data.
13-Nov-2015 NagaBabu Modified the querry to load data into UserQuestionaireAnswers table as string conversion into date format 
10-Dec-2015 NagaBabu Modified the querry for genrating Decesed notification as per NAVI-4569
15-Dec-2015 NagaBabu Modified the script as per NAVI-4730
06-Jan-2016 Nagababu Added the logic for NAVI-4789
06-Jan-2016 Nagasiva Added condition to validate providers in Providereventnotification table.
22-Mar-2016 Nagababu Changes applied as per the new architecture of task for the NAVI-5538.
25-May-2016 Nagababu Modified the logic as per NAVI-5290
26-May-2016 Nagababu Modified the logic as per NAVI-6167
01-Jun-2016 Nagababu Modified as per NAVI-6167 review comments
11-Aug-2016 Nagababu Modified the logic as per NAVI-6582 
16-Aug-2016 Nagababu Added IsRequiredQuestion to the table ##Event_Assessment as per NAVI-6539 
25-Oct-2016 Yugandhar modified the sp as per NAVI-6912
------------------------------------------------------------------------------                
*/
CREATE PROCEDURE [dbo].[usp_Batch_EventORULoad]
AS
BEGIN TRY
	DECLARE @i_ProgramID INT
			,@i_CreatedByUserId INT
			,@i_DataSourceID INT 
			,@i_CareTeamId INT

	SELECT @i_ProgramID = ProgramID
	FROM Program WITH (NOLOCK)
	WHERE ProgramName = 'All Patients Managed population'

	SELECT @i_CareTeamId = CareTeamId
	FROM CareTeam
	WHERE CareTeamName = 'All Patients Care Team'

	SELECT @i_CreatedByUserId = ProviderId
	FROM Provider P
	INNER JOIN CodeSetProviderType CSP
		ON P.ProviderTypeID = CSP.ProviderTypeCodeID
	WHERE CSP.[Description] = 'Administrator'
	AND P.FirstName = 'User'
	AND P.LastName = 'HL7'

	SELECT @i_DataSourceID = DataSourceId
	FROM CodeSetDataSource
	WHERE SourceName = 'HL7'

	DECLARE @l_TranStarted BIT = 0

	IF (@@TRANCOUNT = 0)
	BEGIN
		BEGIN TRANSACTION

		SET @l_TranStarted = 1 -- Indicator for start of transactions
	END

	IF @i_ProgramID IS NOT NULL
		AND (
			(
				SELECT COUNT(1)
				FROM PatientProgram WITH (NOLOCK)
				WHERE ProgramID = @i_ProgramID
					AND EnrollmentEndDate IS NULL
				) > 0
			)
	BEGIN
		
		DECLARE @i_SourceTypeId INT

		SELECT @i_SourceTypeId = FileSourceID
		FROM LkUpFileSource WITH (NOLOCK)
		WHERE FileSourceName = 'HL7'

		UPDATE P
		SET PatientPrimaryId = DT.PrimaryIdId ,
			LastModifiedByUserID = @i_CreatedByUserId ,
			LastModifiedDate = GETDATE() ,
			SourceTypeId = @i_SourceTypeId 
		FROM (SELECT DISTINCT TP.IdentifiersId,TP.PrimaryIdId
			  FROM ##Event_Patient TP)DT
		INNER JOIN Patient P WITH (NOLOCK) ON DT.IdentifiersId = P.MedicalRecordNumber
		WHERE NULLIF(DT.PrimaryIdId, '') IS NOT NULL
		AND P.PatientPrimaryId IS NULL
		AND NOT EXISTS (SELECT 1
						FROM Patient PA
						WHERE PA.PatientPrimaryId = DT.PrimaryIdId)

		UPDATE ##Event_Assessment
		SET ##Event_Assessment.PatientID = p.PatientID
		FROM Patient p WITH (NOLOCK)
		INNER JOIN ##Event_Patient ep
			ON ep.PrimaryIdId = p.PatientPrimaryId
		WHERE ##Event_Assessment.GeneralID = ep.GeneralId

		INSERT INTO Patient (
			FirstName
			,LastName
			,NamePrefix
			,NameSuffix
			,SSN
			,DateOfBirth
			,IsDeceased
			,DateDeceased
			,Gender
			,MedicalRecordNumber
			,PrimaryAddressLine1
			,PrimaryAddressLine2
			,PrimaryAddressCity
			,PrimaryAddressStateCodeID
			,PrimaryAddressCountyID
			,PrimaryAddressPostalCode
			,PrimaryAddressCountryCodeID
			,PrimaryPhoneNumber
			,PrimaryEmailAddress
			,AccountStatusCode
			,CreatedByUserID
			,CreatedDate
			,PatientPrimaryId
			,SourceTypeId
			,SecondaryIdentifier
			)
		SELECT DISTINCT TP1.NameGivenName
			,TP1.NameFamilyName
			,TP1.NamePrefix
			,TP1.NameSuffix
			,TP1.PatientSSN
		
			,CAST(SUBSTRING(TP1.DateOfBirth, 1, 4) + '-' + SUBSTRING(TP1.DateOfBirth, 5, 2) + '-' + SUBSTRING(TP1.DateOfBirth, 7, 2) AS DATE) AS DateOfBirth
			,CASE 
				WHEN TP1.PatientDeathIndicator = 'False'
					THEN 0
				WHEN TP1.PatientDeathIndicator = 'True'
					THEN 1
				ELSE NULL
				END AS PatientDeathIndicator
			,CASE 
				WHEN NULLIF(TP1.PatientDeathDateTime, '') IS NOT NULL
					THEN CAST(SUBSTRING(TP1.PatientDeathDateTime, 1, 4) + '-' + SUBSTRING(TP1.PatientDeathDateTime, 5, 2) + '-' + SUBSTRING(TP1.PatientDeathDateTime, 7, 2) AS DATE)
				ELSE NULL
				END
			,CASE WHEN TP1.PatientSex = 'Female' THEN 'F'
				WHEN TP1.PatientSex = 'Male' THEN 'M'
				ELSE NULL
			 END 
			,ISNULL(TP1.IdentifiersId, '')
			,TP1.AddressesStreetAddress
			,TP1.AddressesOtherDesignation
			,TP1.AddressesCity
			,CSS.StateID AS PrimaryAddressStateCodeID
			,NULL AS PrimaryAddressCountyID
			,TP1.AddressesZipOrPostalCode
			,CSC.CountryID AS PrimaryAddressCountryCodeID
			,TP1.HomePhoneNumbersLocalNumber
			,ISNULL(TP1.PatientEmailAddress, '') AS PatientEmailAddress
			,CASE 
				WHEN NULLIF(TP1.PatientDeathDateTime, '') IS NOT NULL
					THEN 'I'
				ELSE 'A'
				END AS AccountStatusCode
			,@i_CreatedByUserId AS CreatedByUserID
			,GETDATE()
			,TP1.PrimaryIdId
			,@i_SourceTypeId
			,STUFF(( SELECT ', ' + IdentifiersId + ISNULL(' (' + NULLIF(IdentifiersAssigningFacility,'') + ')','')
					 FROM ##Event_Patient EP
					 WHERE EP.GeneralId = TP1.GeneralId
					 AND NULLIF(EP.PrimaryIdId,'') IS NULL
					 FOR XML PATH('')),1,2,'')
		FROM (
			SELECT  
				ROW_NUMBER() OVER (PARTITION BY TP.PrimaryIdId  ORDER BY (SELECT NULL)) AS RNO
				,TP.NameGivenName
				,TP.NameFamilyName
				,TP.NamePrefix
				,TP.NameSuffix
				,TP.PatientSSN
				,TP.DateOfBirth
				,TP.PatientDeathIndicator
				,TP.PatientDeathDateTime
				,TP.PatientSex
				,TP.IdentifiersId
				,TP.AddressesStreetAddress
				,TP.AddressesOtherDesignation
				,TP.AddressesCity
				,TP.AddressesStateOrProvince
				,TP.AddressesZipOrPostalCode
				,TP.AddressesCountry
				,(ISNULL(TP.HomePhoneNumbersAreaCode,'') +TP.HomePhoneNumbersLocalNumber) AS HomePhoneNumbersLocalNumber
				,ISNULL(NULLIF(TP.HomePhoneNumbersCommAddress, ''), TP.BusinessPhoneNumbersCommAddress) PatientEmailAddress
				,TP.PrimaryIdId
				,TA.PatientId
				,TP.GeneralId
			FROM ##Event_Patient TP
			INNER JOIN ##Event_General TG ON TP.GeneralId = TG.GeneralId
			INNER JOIN ##Event_Assessment TA ON TA.GeneralId = TG.GeneralId
			WHERE TA.PatientId IS NULL
			AND TG.GeneralMessageControlId NOT LIKE '%ORU%'
			) TP1
		LEFT JOIN CodeSetState CSS WITH (NOLOCK) ON TP1.AddressesStateOrProvince = CSS.StateCode
		LEFT JOIN CodeSetCountry CSC WITH (NOLOCK) ON TP1.AddressesCountry = CSC.CountryName
		WHERE NULLIF(TP1.PrimaryIdId, '') IS NOT NULL
		  AND TP1.RNO = 1

		UPDATE ##Event_Assessment
		SET ##Event_Assessment.PatientID = p.PatientID
		FROM Patient p WITH (NOLOCK)
		INNER JOIN ##Event_Patient ep
			ON ep.PrimaryIdId = p.PatientPrimaryId
		WHERE ##Event_Assessment.GeneralID = ep.GeneralId
		AND ##Event_Assessment.PatientId IS NULL

		
		IF @i_ProgramID IS NOT NULL
		BEGIN
			EXEC dbo.[usp_AllPatientsManagedpopulation_Enrollment] 
			@i_ProgramID = @i_ProgramID
		END
	
		UPDATE ##Event_Assessment
		SET ##Event_Assessment.QuestionaireID = Questionaire.QuestionaireID
		FROM Questionaire WITH (NOLOCK)
		WHERE Questionaire.uniqueID = ##Event_Assessment.AssessmentsAssessmentId
			AND ISNUMERIC(AssessmentsAssessmentId) = 1

		UPDATE ##Event_Assessment
		SET ##Event_Assessment.QuestionaireID = s.QuestionaireID
		FROM (
			SELECT GeneralId
				,QuestionaireID
			FROM ##Event_Assessment
			WHERE QuestionaireID IS NOT NULL
			) s
		WHERE ##Event_Assessment.GeneralId = s.GeneralId

		UPDATE ##Event_Assessment
		SET ##Event_Assessment.QuestionID = Q.QuestionID ,
			##Event_Assessment.IsRequiredQuestion = qs.IsRequiredQuestion
		FROM Question Q WITH (NOLOCK)
		INNER JOIN QuestionSetQuestion qs WITH (NOLOCK)
			ON q.QuestionId = qs.QuestionId
		INNER JOIN QuestionaireQuestionSet qq WITH (NOLOCK)
			ON qq.QuestionSetId = qs.QuestionSetId
		WHERE Q.uniqueID = ##Event_Assessment.AssessmentQuestionId
			AND ISNUMERIC(AssessmentQuestionId) = 1
			AND qq.QuestionaireId = ##Event_Assessment.QuestionaireID

		UPDATE ##Event_Assessment
		SET ##Event_Assessment.AnswerID = A.AnswerID
		FROM Answer a WITH (NOLOCK)
		INNER JOIN Question Q WITH (NOLOCK)
			ON q.QuestionId = a.questionid
		INNER JOIN QuestionSetQuestion qs WITH (NOLOCK)
			ON q.QuestionId = qs.QuestionId
		INNER JOIN QuestionaireQuestionSet qq WITH (NOLOCK)
			ON qq.QuestionSetId = qs.QuestionSetId
		WHERE a.uniqueID = ##Event_Assessment.AssessmentAnswerId
			AND Q.QuestionId = ##Event_Assessment.QuestionID
			AND qq.QuestionaireId = ##Event_Assessment.QuestionaireId
			AND ISNUMERIC(AssessmentAnswerId) = 1
			AND ##Event_Assessment.questionid IS NOT NULL

		UPDATE ##Event_Assessment
		SET ##Event_Assessment.RefQuestionCnt = t.cnt
		FROM (
			SELECT qqs.QuestionaireId
				,count(qsa.QuestionId) cnt
			FROM QuestionaireQuestionSet qqs WITH (NOLOCK)
			INNER JOIN QuestionSetQuestion qsa WITH (NOLOCK)
				ON qsa.QuestionSetId = qqs.QuestionSetId
			WHERE qsa.IsRequiredQuestion = 1
			GROUP BY qqs.QuestionaireId
			) t
		WHERE t.QuestionaireId = ##Event_Assessment.QuestionaireId

		UPDATE ##Event_Assessment
		SET ##Event_Assessment.SourceQuestionCnt = t.cnt
		FROM (
			SELECT GeneralID
				,COUNT(DISTINCT QuestionID) cnt
			FROM ##Event_Assessment
			WHERE AssessmentQuestionId IS NOT NULL
				AND QuestionID IS NOT NULL
				AND IsRequiredQuestion = 1
			GROUP BY GeneralID
			) t
		WHERE t.GeneralID = ##Event_Assessment.GeneralID

		UPDATE ##Event_Assessment
		SET ##Event_Assessment.QuestionaireID = s.QuestionaireID
			,##Event_Assessment.RefQuestionCnt = s.RefQuestionCnt
		FROM (
			SELECT QuestionaireID
				,GeneralID
				,RefQuestionCnt
			FROM ##Event_Assessment
			WHERE QuestionaireID IS NOT NULL
			) s
		WHERE s.GeneralId = ##Event_Assessment.GeneralId
			AND ##Event_Assessment.QuestionaireID IS NULL
			AND ##Event_Assessment.RefQuestionCnt IS NULL

		UPDATE ##Event_Assessment
		SET IsInComplete = 1
		FROM (
			SELECT DISTINCT Generalid
			FROM ##Event_Assessment
			WHERE QuestionaireID IS NULL
				OR (IsRequiredQuestion = 1 AND answerid IS NULL)
				OR ISNULL(SourceQuestionCnt, 0) != ISNULL(RefQuestionCnt, 0)
			) T
		WHERE t.Generalid = ##Event_Assessment.Generalid

		UPDATE TEA
		SET InCompleteAssessment = 1
		FROM ##Event_Assessment TEA
		WHERE EXISTS (SELECT 1
					  FROM ##Event_Assessment TA
					  WHERE TA.GeneralId = TEA.GeneralId
					  AND TA.IsRequiredQuestion = 1 AND AnswerID IS NULL)

		UPDATE TEA
		SET Inaccurate = 1
		FROM ##Event_Assessment TEA
		WHERE EXISTS (SELECT 1
					  FROM ##Event_Assessment TA
					  WHERE TA.GeneralId = TEA.GeneralId
					  AND TA.IsInComplete = 1 	)


		DECLARE @i_ProviderTypeID INT

		SELECT @i_ProviderTypeID = ProviderTypeCodeID
		FROM CodeSetProviderType WITH (NOLOCK)
		WHERE [Description] = 'Clinic'

		DECLARE @i_ProviderId INT

		SELECT @i_ProviderId = ProviderId
		FROM Provider P WITH (NOLOCK)
		WHERE P.OrganizationName = 'No Facility'
			AND ProviderTypeID = @i_ProviderTypeID

		IF @i_ProviderId IS NULL
		BEGIN
			INSERT INTO Provider (
				IsIndividual
				,OrganizationName
				,IsCareProvider
				,IsExternalProvider
				,ProviderTypeID
				,TaxID_EIN_SSN
				,SecondaryAlternativeProviderID
				,AccountStatusCode
				,CreatedByUserID
				,CreatedDate
				)
			VALUES (
				0
				,'No Facility'
				,1
				,0
				,@i_ProviderTypeID
				,'000000000'
				,NULL
				,'A'
				,@i_CreatedByUserId
				,GETDATE()
				)

			SET @i_ProviderId = SCOPE_IDENTITY()
		END


		INSERT INTO PatientEvent (
			PatientId
			,IsReadmit
			,FacilityId
			,VisitAdmitdate
			,VisitDischargedate
			,CreatedByUserId
			,IsAssessmentComplete
			,AssessmentID
			)
		SELECT DISTINCT q.PatientID
			,0
			,ISNULL(p.ProviderID,@i_ProviderId)
			,CAST(CONVERT(VARCHAR(19),TRY_CONVERT(DATETIME,STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(Ltrim(Rtrim(q.AssessmentsAssessmentStartDate)) + '00000000000000', 14),5,0,'-'),8,0,'-'),11,0,' '),14,0,':'),17,0,':'),19,0,'')),121) AS DATETIME)AS StartDate
			,CASE WHEN LEFT( Ltrim(RTRIM(COALESCE(q.AssessmentsAssessmentEndDate, q.AssessmentsAssessmentStartDate,''))) + '00000000000000', 14) = '00000000000000' THEN GETDATE()
					ELSE CAST(CONVERT(VARCHAR(19),TRY_CONVERT(DATETIME,STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(COALESCE(q.AssessmentsAssessmentEndDate, q.AssessmentsAssessmentStartDate,''))) + '00000000000000', 14),5,0,'-'),8,0,'-'),11,0,' '),14,0,':'),17,0,':'),19,0,'')),121) AS DATETIME) 
			 END	
			,@i_CreatedByUserId
			,CASE 
				WHEN IsInComplete = 1
					THEN 0
				ELSE 1
				END
			,Q.QuestionaireID
		FROM ##Event_Assessment q
		INNER JOIN ##Event_General g
			ON g.GeneralID = q.GeneralID
		LEFT JOIN provider p 
		ON p.TaxID_EIN_SSN = g.GeneralEventFacility
		WHERE q.PatientID IS NOT NULL
			AND q.AssessmentsAssessmentStartDate IS NOT NULL
			AND Q.QuestionaireID IS NOT NULL
			AND NOT EXISTS (
				SELECT 1
				FROM PatientEvent pe WITH (NOLOCK)
				WHERE pe.PatientID = q.PatientID
					AND pe.AssessmentID = q.QuestionaireID
					AND VisitAdmitdate = CAST(CONVERT(VARCHAR(19),TRY_CONVERT(DATETIME,STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(q.AssessmentsAssessmentStartDate)) + '00000000000000', 14),5,0,'-'),8,0,'-'),11,0,' '),14,0,':'),17,0,':'),19,0,'')),121)AS DATETIME))
				

		DECLARE @i_EventID INT

		SELECT @i_EventID = EventTypeID
		FROM Eventtype WITH (NOLOCK)
		WHERE EventCode = 'R01'

		INSERT INTO PatientEventNotification (
			PatientEventId
			,EventTypeId
			,EventDate
			,CreatedByUserId
			,CreatedDate
			,SourceId
			)
		SELECT DISTINCT pe.PatientEventId 
			,@i_EventID
			,CAST(CONVERT(VARCHAR(19),TRY_CONVERT(DATETIME,STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(COALESCE(g.GeneralEventDateTime, g.GeneralMsgDateTime,''))) + '00000000000000', 14),5,0,'-'),8,0,'-'),11,0,' '),14,0,':'),17,0,':'),19,0,'')),121)AS DATETIME)
			,@i_CreatedByUserId
			,getdate()
			,g.GeneralID
		FROM PatientEvent pe WITH (NOLOCK)
		INNER JOIN ##Event_Assessment pt
			ON pt.PatientID = pe.PatientId
				AND pt.QuestionaireID = pe.AssessmentID
				AND CAST(CONVERT(VARCHAR(19),TRY_CONVERT(DATETIME,STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(pt.AssessmentsAssessmentStartDate)) + '00000000000000', 14),5,0,'-'),8,0,'-'),11,0,' '),14,0,':'),17,0,':'),19,0,'')),121)AS DATETIME)= pe.VisitAdmitdate
		INNER JOIN ##Event_General g
			ON g.GeneralID = pt.GeneralID
		WHERE NOT EXISTS (
				SELECT 1
				FROM PatientEventNotification pe1 WITH (NOLOCK)
				WHERE pe1.PatientEventId = pe.PatientEventId
				)

		DECLARE @i_DeceasedEventId INT 
		SELECT @i_DeceasedEventId = EventTypeId 
		FROM EventType
		WHERE EventDescription = 'Deceased'		
		
		INSERT INTO PatientEvent
		(
			PatientId
			,IsReadmit
			,FacilityId
			,VisitAdmitdate
			,VisitDischargedate
			,CreatedByUserId
			,IsInternal
		)
		SELECT DISTINCT TA.PatientId ,
			NULL ,
			NULL ,
			NULL ,
			NULL ,
			@i_CreatedByUserId ,
			1
		FROM ##Event_Assessment TA 
		INNER JOIN ##Event_Patient TP ON TA.GeneralId = TP.GeneralId
		INNER JOIN ##Event_General TG ON TG.GeneralId = TP.GeneralId
		WHERE tp.PatientDeathIndicator = 'True'
		AND NOT EXISTS (SELECT 1
						FROM Patient P
						WHERE TA.PatientID = P.PatientID	
						AND ISNULL(P.IsDeceased,0) = 1)

		INSERT INTO PatientEventNotification
		(
			PatientEventId
			,EventTypeId
			,EventDate
			,CreatedByUserId
			,VisitType
			,SourceId
		)
	
		SELECT DISTINCT
			PE.PatientEventId ,
			@i_DeceasedEventId ,
			GETDATE() AS EventDate ,
			@i_CreatedByUserId ,
			NULL ,
			TA.GeneralId
		FROM PatientEvent PE
		INNER JOIN ##Event_Assessment TA ON TA.PatientId = PE.PatientId 
		INNER JOIN ##Event_Patient TP ON TA.GeneralId = TP.GeneralId
		INNER JOIN ##Event_General g ON g.GeneralID = TP.GeneralID 
		WHERE tp.PatientDeathIndicator = 'True'
		AND PE.IsInternal = 1
		AND NOT EXISTS (SELECT 1
						FROM PatientEventNotification PEN
						WHERE PEN.PatientEventId = PE.PatientEventId)

		UPDATE P
		SET IsDeceased = 1 ,
			DateDeceased = CASE WHEN NULLIF(TP.PatientDeathDateTime, '') IS NOT NULL
									THEN CAST(CONVERT(VARCHAR(19),TRY_CONVERT(DATETIME,STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LTRIM(RTRIM(TP.PatientDeathDateTime)),5,0,'-'),8,0,'-'),11,0,' '),14,0,':'),17,0,':'),19,0,'')),121)AS DATE) 
								ELSE NULL
						   END ,	
			LastModifiedByUserID = @i_CreatedByUserId ,
			LastModifiedDate = GETDATE() ,
			SourceTypeId = @i_SourceTypeId
		FROM Patient P
		INNER JOIN ##Event_Patient TP ON P.PatientPrimaryId = TP.PrimaryIdId
		WHERE TP.PatientDeathIndicator = 'True'
		AND NOT EXISTS (SELECT 1
						FROM Patient PA
						WHERE PA.PatientID = P.PatientID
						AND PA.IsDeceased = 1)

		INSERT INTO PatientEvent
		(
			PatientId
			,IsReadmit
			,FacilityId
			,VisitAdmitdate
			,VisitDischargedate
			,CreatedByUserId
			,IsInternal
		)
		SELECT DISTINCT TA.PatientId ,
			NULL ,
			NULL ,
			NULL ,
			NULL ,
			@i_CreatedByUserId ,
			1
		FROM ##Event_Assessment TA 
		INNER JOIN ##Event_Patient TP ON TA.GeneralId = TP.GeneralId
		INNER JOIN ##Event_General TG ON TG.GeneralId = TP.GeneralId
		WHERE tp.PatientDeathIndicator = 'False'
		AND EXISTS (SELECT 1
					FROM Patient P
					WHERE P.PatientId = TA.PatientId
					AND P.IsDeceased = 1 )
		
		SELECT @i_DeceasedEventId = EventTypeId 
		FROM EventType
		WHERE EventDescription = 'Not Deceased'	

		INSERT INTO PatientEventNotification
		(
			PatientEventId
			,EventTypeId
			,EventDate
			,CreatedByUserId
			,VisitType
			,SourceId
		)
	
		SELECT DISTINCT
			PE.PatientEventId ,
			@i_DeceasedEventId ,
			GETDATE() AS EventDate ,
			@i_CreatedByUserId ,
			NULL ,
			TA.GeneralId
		FROM PatientEvent PE
		INNER JOIN ##Event_Assessment TA ON TA.PatientId = PE.PatientId 
		INNER JOIN ##Event_Patient TP ON TA.GeneralId = TP.GeneralId
		INNER JOIN ##Event_General g ON g.GeneralID = TP.GeneralID 
		WHERE tp.PatientDeathIndicator = 'False'
		AND PE.IsInternal = 1
		AND NOT EXISTS (SELECT 1
						FROM PatientEventNotification PEN
						WHERE PE.PatientEventId = PEN.PatientEventId)
		AND EXISTS (SELECT 1
					FROM Patient PA
					WHERE PA.PatientID = PE.PatientID
					AND PA.IsDeceased = 1)

		UPDATE P
		SET IsDeceased = 0 ,
			DateDeceased = NULL ,	
			LastModifiedByUserID = @i_CreatedByUserId ,
			LastModifiedDate = GETDATE() ,
			SourceTypeId = @i_SourceTypeId
		FROM Patient P
		INNER JOIN ##Event_Patient TP ON P.PatientPrimaryId = TP.PrimaryIdId
		WHERE TP.PatientDeathIndicator = 'False'
		AND EXISTS (SELECT 1
					FROM Patient PA
					WHERE PA.PatientID = P.PatientID
					AND ISNULL(PA.IsDeceased,0) = 1)
	
		DECLARE @i_TaskTypeId INT ,
				@i_OpenTaskStatusId INT ,
				@i_CompletedTaskStatusId INT ,
				@i_InvalidatedTaskStatusId INT ,
				@i_InaccuReasonId INT ,
				@i_InCompleteReasonId INT ,
				@i_ReasonId INT


		SELECT @i_TaskTypeId = TaskTypeId
		FROM TaskType 
		WHERE TaskTypeName = 'Assessment'

		SELECT @i_OpenTaskStatusId = TaskStatusId
		FROM TaskStatus 
		WHERE TaskStatusText = 'Open'

		SELECT @i_CompletedTaskStatusId = TaskStatusId
		FROM TaskStatus 
		WHERE TaskStatusText = 'Closed Complete'

		SELECT @i_InvalidatedTaskStatusId = TaskStatusId
		FROM TaskStatus 
		WHERE TaskStatusText = 'Invalidated'

		SELECT @i_InaccuReasonId = InvalidReasonId
		FROM LkupInvalidReason 
		WHERE InvalidReason = 'Inaccurate data (Source: ORU)'

		SELECT @i_InCompleteReasonId = InvalidReasonId
		FROM LkupInvalidReason 
		WHERE InvalidReason = 'Incomplete assessment (Source: ORU)'

		SELECT @i_ReasonId = InvalidReasonId
		FROM LkupInvalidReason 
		WHERE InvalidReason = 'Incomplete assessment and Inaccurate data (Source: ORU)'

		INSERT INTO PatientTask
		(
			PatientTaskTemplateScheduleId
			,PatientId
			,ManagedPopulationId
			,TaskTypeId
			,TypeId
			,TaskStatusId
			,DueDate
			,DateTaken
			,MissedOpportunityDate
			,NextContactDate
			,Comments
			,CreatedByUserId
			,IsBatchProcess
			,ProviderId
			,InvalidatedReasonId
		)
		SELECT DISTINCT
			NULL
			,pg.PatientID 
			,@i_ProgramID 
			,@i_TaskTypeId
			,a.QuestionaireId
			,CASE WHEN IsInComplete = 1 THEN @i_InvalidatedTaskStatusId
				 ELSE @i_CompletedTaskStatusId
			 END	 								   
			,CASE WHEN LEFT( LTRIM(RTRIM(COALESCE(a.AssessmentsAssessmentStartDate, a.AssessmentsAssessmentEndDate,''))) + '00000000000000', 14) = '00000000000000' THEN GETDATE()
					ELSE CAST(CONVERT(VARCHAR(19),TRY_CONVERT(DATETIME,STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(COALESCE(a.AssessmentsAssessmentStartDate, a.AssessmentsAssessmentEndDate,''))) + '00000000000000', 14),5,0,'-'),8,0,'-'),11,0,' '),14,0,':'),17,0,':'),19,0,'')),121)AS DATETIME) 
			 END
			,CASE WHEN a.IsInComplete = 1 THEN NULL
				  ELSE	
					CASE WHEN LEFT(LTRIM(RTRIM(COALESCE(a.AssessmentsAssessmentEndDate, a.AssessmentsAssessmentStartDate,''))) + '00000000000000', 14) = '00000000000000' THEN GETDATE()
							ELSE CAST(CONVERT(VARCHAR(19),TRY_CONVERT(DATETIME,STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(COALESCE(a.AssessmentsAssessmentEndDate, a.AssessmentsAssessmentStartDate,''))) + '00000000000000', 14),5,0,'-'),8,0,'-'),11,0,' '),14,0,':'),17,0,':'),19,0,'')),121)AS DATETIME) 
					END 
			 END
			,NULL 
			,NULL
			,'ORU Event'
			,@i_CreatedByUserId
			,1
			,@i_CreatedByUserId
			,CASE WHEN ISNULL(InCompleteAssessment,0) = 1 AND ISNULL(Inaccurate,0) = 0 THEN @i_InCompleteReasonId
				  WHEN ISNULL(InCompleteAssessment,0) = 0 AND ISNULL(Inaccurate,0) = 1 THEN @i_InaccuReasonId
				  WHEN ISNULL(InCompleteAssessment,0) = 1 AND ISNULL(Inaccurate,0) = 1 THEN @i_ReasonId 
				 ELSE NULL
			 END	 	
		FROM ##Event_Assessment a
		INNER JOIN PatientProgram pg WITH (NOLOCK)
			ON pg.PatientID = a.PatientID
		WHERE ProgramID = @i_ProgramID
			AND pg.EnrollmentEndDate IS NULL
			AND a.QuestionaireId IS NOT NULL
			AND a.AssessmentsAssessmentId IS NOT NULL --> To restrict the limited set of records
			AND NOT EXISTS (
				SELECT 1
				FROM PatientTask pqe WITH (NOLOCK)
				WHERE pqe.PatientId = pg.PatientID
					AND pqe.TypeId = a.QuestionaireId
					AND pqe.ManagedPopulationId = @i_ProgramID
					AND pqe.DueDate = CASE WHEN LEFT( LTRIM(RTRIM(COALESCE(a.AssessmentsAssessmentStartDate, a.AssessmentsAssessmentEndDate,''))) + '00000000000000', 14) = '00000000000000' THEN GETDATE()
															ELSE CAST(CONVERT(VARCHAR(19),TRY_CONVERT(DATETIME,STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(COALESCE(a.AssessmentsAssessmentStartDate, a.AssessmentsAssessmentEndDate,''))) + '00000000000000', 14),5,0,'-'),8,0,'-'),11,0,' '),14,0,':'),17,0,':'),19,0,'')),121)AS DATETIME)  
													 END)

		INSERT INTO PatientAssessmentAnswer (
			PatientTaskId
			,QuestionSetQuestionId
			,AnswerID
			,AnswerComments
			,AnswerString
			,CreatedByUserId
			)
		SELECT DISTINCT pq.PatientTaskId
			,qsq.QuestionSetQuestionId
			,a.AnswerID
			,'Complete'
			,CASE WHEN AnswerTypeCode = 'DateTime' AND NULLIF(a.AssessmentAnswerText,'') IS NOT NULL THEN SUBSTRING(a.AssessmentAnswerText,5,2) + '/' + SUBSTRING(a.AssessmentAnswerText,7,2) + '/' + SUBSTRING(a.AssessmentAnswerText,1,4) + ' ' + SUBSTRING(a.AssessmentAnswerText,9,2) + ':' + SUBSTRING(a.AssessmentAnswerText,11,2)  
				 ELSE a.AssessmentAnswerText
			 END AS AssessmentAnswerText	 							
			,@i_CreatedByUserId
		FROM PatientTask pq WITH (NOLOCK)
		INNER JOIN ##Event_Assessment a
			ON a.PatientID = pq.PatientId
		INNER JOIN QuestionaireQuestionSet qqs WITH (NOLOCK)
			ON qqs.QuestionaireId = pq.TypeId
		INNER JOIN QuestionSetQuestion qsq WITH (NOLOCK)
			ON qsq.QuestionSetId = qqs.QuestionSetId
		INNER JOIN Question Q
			ON Q.QuestionId = qsq.QuestionId
		INNER JOIN AnswerType AN
			ON AN.AnswerTypeId = Q.AnswerTypeId				
		WHERE pq.ManagedPopulationId = @i_ProgramID
			AND PQ.TaskTypeId = @i_TaskTypeId
			AND pq.IsBatchProcess = 1
			AND a.AnswerID IS NOT NULL
			AND a.QuestionaireId = pq.TypeId
			AND qsq.QuestionId = a.QuestionId

		UPDATE PatientTask
		SET IsBatchProcess = NULL 
			,LastModifiedByUserId = @i_CreatedByUserId
			,LastModifiedDate = GETDATE()
			,AssessmentScore = dbo.GetMaxScoreByUserQuestionaireID(PatientTaskId)
		WHERE IsBatchProcess = 1
		

		UPDATE ##Event_Assessment
		SET [Status] = CASE 
				WHEN PatientID IS NULL
					THEN 'H'
				WHEN PatientID IS NOT NULL
					AND QuestionaireID IS NULL
					THEN 'F'
				WHEN PatientID IS NOT NULL
					AND QuestionaireID IS NOT NULL
					THEN 'C'
				END
			,Comments = CASE 
				WHEN PatientID IS NULL
					THEN 'Patient does not exist'
				WHEN PatientID IS NOT NULL
					AND QuestionaireID IS NULL
					THEN 'Assessment does not exist'
				WHEN PatientID IS NOT NULL
					AND QuestionaireID IS NOT NULL
					THEN NULL
				END

		INSERT INTO ProviderEventNotification
		(
			PatientEventNotificationID ,
			ProviderID 
		)
		SELECT DISTINCT PEN.PatientEventNotificationID ,
			ctm.ProviderID	
		FROM PatientProgram pp WITH (NOLOCK)
		INNER JOIN ##Event_Assessment TA
			ON TA.PatientId = pp.PatientId
		INNER JOIN ProgramCareTeam pct WITH (NOLOCK)
			ON pct.ProgramID = pp.ProgramID
		INNER JOIN CareTeamMembers ctm WITH (NOLOCK)
			ON ctm.CareTeamID = pct.CareTeamID
		INNER JOIN UserGroup UG WITH (NOLOCK)
			ON UG.ProviderID = ctm.ProviderID
		INNER JOIN PatientEventNotification PEN 
			ON PEN.SourceId = TA.GeneralId
		WHERE pp.EnrollmentEndDate IS NULL
			AND ctm.StatusCode = 'A'
			AND TA.[Status] = 'C'
			AND TA.IsInComplete = 1
			AND NOT EXISTS (SELECT 1
							FROM ProviderEventNotification PREN
							WHERE PREN.PatientEventNotificationID = PEN.PatientEventNotificationID
							AND PREN.ProviderID = ctm.ProviderID)

		INSERT INTO ProviderEventNotification
		(
			PatientEventNotificationID ,
			ProviderID 
		)
		SELECT DISTINCT DT.PatientEventNotificationID ,
			DCT.ProviderId
		FROM
		(SELECT DISTINCT PEN.PatientEventNotificationID 
		FROM ##Event_Assessment TA
		INNER JOIN PatientEventNotification PEN 
			ON PEN.SourceId = TA.GeneralId
		WHERE TA.[Status] = 'C'
			AND TA.IsInComplete = 1) DT
		CROSS JOIN (SELECT ProviderId
					FROM CareTeamMembers
					WHERE CareTeamId = @i_CareTeamId
					AND IsCareTeamManager = 1) DCT
		WHERE NOT EXISTS (SELECT 1
						FROM ProviderEventNotification PREN
						WHERE PREN.PatientEventNotificationID = DT.PatientEventNotificationID
						AND PREN.ProviderID = DCT.ProviderID)	

		INSERT INTO ProviderEventNotification
		(
			PatientEventNotificationID ,
			ProviderID 
		)
		SELECT DISTINCT PEN.PatientEventNotificationID ,
			pp.ProviderID	
		FROM PatientProgram pp WITH (NOLOCK)
		INNER JOIN ##Event_Assessment TA
			ON TA.PatientId = pp.PatientId
		INNER JOIN ProgramCareTeam pct WITH (NOLOCK)
			ON pct.ProgramID = pp.ProgramID
		INNER JOIN CareTeamMembers ctm WITH (NOLOCK)
			ON ctm.CareTeamID = pct.CareTeamID
		INNER JOIN UserGroup UG WITH (NOLOCK)
			ON UG.ProviderID = ctm.ProviderID
		INNER JOIN PatientEventNotification PEN 
			ON PEN.SourceId = TA.GeneralId
		WHERE PEN.EventTypeId = @i_DeceasedEventId
			AND TA.[Status] = 'C'
			AND TA.IsInComplete = 1
			AND NOT EXISTS (SELECT 1
							FROM ProviderEventNotification PREN
							WHERE PREN.PatientEventNotificationID = PEN.PatientEventNotificationID)
		
		AND pp.ProviderID IS NOT NULL

		CREATE TABLE #PatAssessment
		(
			ID INT IDENTITY(1,1) ,
			PatientId INT ,
			AssessmentId INT
		)

		INSERT INTO #PatAssessment
		(
			PatientId ,
			AssessmentId
		)
		SELECT DISTINCT PatientId ,QuestionaireID
		FROM ##Event_Assessment
		WHERE [Status] = 'C'
		AND ISNULL(IsInComplete,0) = 0
		AND EXISTS (SELECT 1
					FROM PatientEventNotification PEN WITH(NOLOCK)
					WHERE PEN.SourceId = ##Event_Assessment.GeneralId)

		IF EXISTS (SELECT 1 FROM #PatAssessment)
			BEGIN
				DECLARE @i_MinId INT ,
						@i_MaxId INT ,
						@i_PatientId INT ,
						@i_AssessmentId INT 
				
				SELECT @i_MinId = MIN(ID) ,
				       @i_MaxId = MAX(ID)
				FROM #PatAssessment
					   		
				WHILE @i_MinId <= @i_MaxId
				BEGIN
					SELECT @i_PatientId = PatientId ,
						   @i_AssessmentId = AssessmentId
					FROM #PatAssessment
					WHERE ID = @i_MinId

					EXEC [dbo].[usp_PatientAutoEnroll_ByAseessment]  
						@i_AppUserId = @i_CreatedByUserId ,
						@i_PatientId = @i_PatientId ,
						@i_AssessmentId = @i_AssessmentId ,
						@v_Source = 'ADT'

					SET @i_MinId = @i_MinId + 1
				
				END	
			END

			IF (@l_TranStarted = 1) -- If transactions are there, then commit
			BEGIN
				SET @l_TranStarted = 0

				COMMIT TRANSACTION
			END
	END
END TRY

----------------------------------------------
BEGIN CATCH
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_CreatedByUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH
