﻿
/*  
-------------------------------------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Assignment_PopulationDefinition]1,210,453
Description   : This procedure is used to get the details of population definition
Created By    : Rathnam
Created Date  : 27.09.2012  
--------------------------------------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY   DESCRIPTION  
14-Nov-2012 P.V.P.Mohan changes the name of Procedure and changed parameters and added PopulationDefinitionID in 
            the place of CohortListID 
14-Mar-2013 P.V.P.Mohan  changed parameters and added PatientProgram table in place of UserProgram 
21-Jan-2014 P.V.P.Mohan  changed PatientProgam to PatientProgram
09-Jan-2015 Santosh modified the Sp as per the bug NAVI 2114
27-Mar-2015 Nagababu Modified the query for fetching EnrollmentStartDate data as deleted 'AND pa.VisitDischargedate IS NULL'
14-April-2015 Rathnam modified the code as per NAVI-2668 Managed Population Configuration>Draft Managed Population:Population Definition 
				count is not reflecting immidiately when new Population Definition mapped in Edit mode.
06-Jan-2016 Rathnam modified as per NAVI-4618
21-Jan-2016 Rathnam Modified as per 5047 to restrict not to dispaly all managed population patients
23-Jun-2016 Rathnam Modified as per 6309 & 6142 to for auto enrollment functionality
17-Jul-2016 davidm  Added optional job tracking.
02-Aug-2016 Rathnam	Worked as per NAVI-6383 for task reconciliation impacts
--------------------------------------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Assignment_PopulationDefinition] (
	@i_AppUserId INT
	,@i_PopulationDefinitionID INT = NULL
	,@i_ProgramID INT
	,@i_JobId INT = NULL
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @l_TranStarted BIT = 0

	IF (@@TRANCOUNT = 0)
	BEGIN
		BEGIN TRANSACTION

		SET @l_TranStarted = 1 -- Indicator for start of transactions
	END

	IF @i_PopulationDefinitionID IS NOT NULL
		AND @i_ProgramID IS NOT NULL
	BEGIN
		DECLARE @dt_date DATETIME = GETDATE()
		DECLARE @i_DataSourceID INT
		/*Conflicted patients*/
		DECLARE @tblPatient ttypeKeyID

		INSERT INTO @tblPatient
		SELECT DISTINCT clu.PatientID AS UserID
		FROM PopulationDefinitionPatients clu WITH (NOLOCK)
		INNER JOIN Program p WITH (NOLOCK) ON clu.PopulationDefinitionID = P.PopulationDefinitionID
		INNER JOIN PopulationDefinition pd WITH (NOLOCK) ON pd.PopulationDefinitionID = p.PopulationDefinitionID
		WHERE ProgramId = @i_ProgramId
			AND clu.StatusCode = 'A'
			AND NOT EXISTS (
				SELECT 1
				FROM PatientProgram ups
				WHERE ups.ProgramId = p.ProgramId
					AND ups.PatientID = clu.PatientID
					AND ups.EnrollmentEndDate IS NULL
				)

		CREATE TABLE #ConflictPatients (PatientId INT)

		INSERT INTO #ConflictPatients
		EXEC usp_PatientTaskTemplate_Conflict 
			 @i_AppUserId = @i_AppUserId
			,@i_ManagedPopulationid = @i_ProgramID
			,@tblPatientID = @tblPatient

		SELECT @i_DataSourceID = DataSourceId
		FROM CodeSetDataSource
		WHERE SourceName = 'Managed Population Creation'

		IF @i_JobId IS NOT NULL
		BEGIN
			UPDATE ManagedPopulationEnrollmentJob
			SET PercentComplete = IIF(PercentComplete + 10 > 100, PercentComplete, PercentComplete + 10)
			WHERE JobId = @i_JobId
		END

		INSERT INTO PatientProgram (
			ProgramId
			,PatientID
			,EnrollmentStartDate
			,CreatedByUserId
			,StatusCode
			,IsAutoEnrollment
			,IdentificationDate
			,IsAdhoc
			,DataSourceID
			)
		SELECT @i_ProgramId
			,clu.tKeyId AS UserID
			,CASE 
				WHEN pt.PatientId IS NULL
					THEN @dt_date
				ELSE NULL
				END
			,@i_AppUserId
			,CASE 
				WHEN pt.PatientId IS NULL
					THEN 'E'
				ELSE 'P'
				END
			,1
			,@dt_date
			,0
			,@i_DataSourceID
		FROM @tblPatient clu
		LEFT JOIN #ConflictPatients pt ON pt.PatientId = clu.tKeyId
		WHERE NOT EXISTS (
				SELECT 1
				FROM PatientProgram ups
				WHERE ups.ProgramId = @i_ProgramId
					AND ups.PatientID = clu.tKeyId
					AND ups.EnrollmentEndDate IS NULL
				)

		EXEC [usp_PatientManagedPopulation_CareLead] 
		     @i_AppUserId = @i_AppUserId
			,@i_ProgramID = @i_ProgramId
	END
	ELSE
	BEGIN
		IF @i_PopulationDefinitionID IS NULL
		BEGIN
			SELECT @i_PopulationDefinitionID = PopulationDefinitionID
			FROM Program
			WHERE ProgramId = @i_ProgramID
		END

		SELECT PopulationDefinitionID
			,PopulationDefinitionName
		FROM PopulationDefinition
		WHERE PopulationDefinitionID = @i_PopulationDefinitionID
	END

	IF @i_JobId IS NOT NULL
	BEGIN
		UPDATE ManagedPopulationEnrollmentJob
		SET PercentComplete = IIF(PercentComplete + 40 > 100, PercentComplete, PercentComplete + 40)
		WHERE JobId = @i_JobId
	END

	IF (@l_TranStarted = 1) -- If transactions are there, then commit
	BEGIN
		SET @l_TranStarted = 0

		COMMIT TRANSACTION
	END
END TRY

BEGIN CATCH
	---------------------------------------------------------------------------------------------------------------------------  
	-- Handle exception  
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH
