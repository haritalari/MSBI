﻿
/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_SCOLAP_TrendChart]1
Description   :This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Nagasiva  
Created Date  : 23-Jan-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
13-Feb-2015 Nagasiva  assigned null value to  @i_AppUserId  Parameter to remove the hardcoded userid in cube execution package
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_SCOLAP_TrendChart] (@i_AppUserId KEYID =NULL)
AS
BEGIN TRY
	SET NOCOUNT ON

	SELECT @i_AppUserId=MIN(UserId) FROM Users WITH (NOLOCK)

	IF OBJECT_ID('TEMPDB..##OLAP_SC_FactHealthPlanCost') IS NOT NULL
		DROP TABLE ##OLAP_SC_FactHealthPlanCost;

	WITH CTE
	AS (
		SELECT PatientID AS PatientKey
			,InsuranceGroupId AS HealthPlanKey
			,DateKey AS DateKey
			,Amt AS ClaimAmt
		FROM (
			SELECT *
				,(
					SELECT SUM(NetPaidAmount)
					FROM ClaimInfo ci WITH (NOLOCK)
					WHERE t.AnchorDate BETWEEN DATEADD(dd, - (DAY(ci.DateOfAdmit) - 1), ci.DateOfAdmit)
							AND DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, ci.DateOfDischarge) + 1, 0))
						AND ci.PatientID = t.PatientID
					) Amt
			FROM (
				SELECT DISTINCT pi1.PatientID
					,igp.InsuranceGroupId
					,ad.DateKey
					,ad.AnchorDate
				FROM PatientInsuranceBenefit pib WITH (NOLOCK)
				INNER JOIN PatientInsurance pi1 WITH (NOLOCK)
					ON pi1.PatientInsuranceID = pib.PatientInsuranceID
				INNER JOIN InsuranceGroupPlan igp WITH (NOLOCK)
					ON igp.InsuranceGroupPlanId = pi1.InsuranceGroupPlanId
				INNER JOIN ##OLAP_SC_DimPatient p
					ON P.PatientKey = PI1.PatientID
				INNER JOIN ##OLAP_SC_DimHealthPlan HP
					ON HP.HealthPlanKey = igp.InsuranceGroupId
				INNER JOIN ##OLAP_SC_DimAnchordate ad
					ON ad.AnchorDate = CASE 
							WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(pib.DateOfEligibility) - 1), pib.DateOfEligibility)
									AND CASE 
											WHEN YEAR(pib.CoverageEndsDate) = 9999
												THEN pib.CoverageEndsDate
											ELSE DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, pib.CoverageEndsDate) + 1, 0))
											END
								THEN ad.AnchorDate
							ELSE NULL
							END
				) t
			) t1
		WHERE Amt IS NOT NULL
		)
	SELECT *
	INTO ##OLAP_SC_FactHealthPlanCost
	FROM CTE
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH