﻿
/*    
------------------------------------------------------------------------------    
Procedure Name: usp_EnrollDashboard_ByPatient 
Description   : This procedure is used to get demographic details of a patient
Created By    : Rathnam
Created Date  : 11-Jan-2016    
------------------------------------------------------------------------------    
Log History   :     
DD-MM-YYYY  BY         DESCRIPTION   
23-Aug-2016 Rathnam modified the conditions logic as per NAVI-6524 
------------------------------------------------------------------------------    
*/
CREATE PROCEDURE [dbo].[usp_EnrollDashboard_ByPatient] (
	@i_AppUserId INT
	,@i_PatientID INT
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	SELECT DISTINCT CG.CodeGroupingName AS NAME
	INTO #Condition
	FROM ClaimCodeGroup CCG WITH (NOLOCK)
	INNER JOIN (
		SELECT CG.CodeGroupingID
			,CG.CodeGroupingName
		FROM CodeGrouping CG WITH (NOLOCK)
		INNER JOIN CodeTypeGroupers CTG WITH (NOLOCK) ON CG.CodeTypeGroupersID = CTG.CodeTypeGroupersID
		WHERE CTG.CodeTypeGroupersName IN ('AHRQ Procedure Groupers','AHRQ Diagnosis Groupers')
			AND CG.StatusCode = 'A'
		) CG ON CG.CodeGroupingId = CCG.CodeGroupingID
	INNER JOIN ClaimInfo CI WITH (NOLOCK) ON CCG.ClaimInfoID = ci.ClaimInfoId
	WHERE ci.PatientID = @i_PatientID

	SELECT p.Patientid
		,p.FirstName
		,p.LastName
		,p.MiddleName
		,p.MedicalRecordNumber AS MemberNumber
		,p.DateOfBirth
		,p.Gender
		,p.PrimaryPhoneNumber
		,p.PrimaryEmailAddress
		,[dbo].[ufn_GetPCPName](p.PatientID) PCP
		,STUFF((
				SELECT DISTINCT ', ' + COALESCE(ISNULL(pr.LastName, '') + ' ' + ISNULL(pr.FirstName, '') + ' ' + ISNULL(pr.MiddleName, ''), '')
				FROM PatientProgram PP WITH (NOLOCK)
				INNER JOIN Provider pr WITH (NOLOCK) ON pr.ProviderID = pp.ProviderID
				WHERE PP.Patientid = p.PatientID
					AND PP.StatusCode = 'E'
				FOR XML PATH('')
				), 1, 1, '') AS CareLeads
		,STUFF((
				SELECT DISTINCT ', ' + pr.ProgramName
				FROM PatientProgram PP WITH (NOLOCK)
				INNER JOIN Program pr WITH (NOLOCK) ON pr.ProgramId = pp.ProgramID
				WHERE PP.Patientid = p.PatientID
					AND PP.StatusCode = 'E'
					AND pr.ProgramName != 'All Patients Managed population'
				FOR XML PATH('')
				), 1, 1, '') AS Programs
		,STUFF((
				SELECT DISTINCT ', ' + c.CareTeamName
				FROM PatientProgram PP WITH (NOLOCK)
				INNER JOIN ProgramCareTeam pr WITH (NOLOCK) ON pp.ProgramID = pr.ProgramId
				INNER JOIN CareTeam c ON c.CareTeamId = pr.CareTeamId
				WHERE PP.Patientid = p.PatientID
					AND PP.StatusCode = 'E'
					AND C.CareTeamName != 'All Patients Care Team'
				FOR XML PATH('')
				), 1, 1, '') AS CareTeams
		,STUFF((
				SELECT DISTINCT ', ' + isnull(pd.NAME, '')
				FROM #Condition pd WITH (NOLOCK)
				FOR XML PATH('')
				), 1, 1, '') AS Conditions
	FROM Patient p
	WHERE P.PatientID = @i_PatientID
END TRY

--------------------------------------------------------     
BEGIN CATCH
	-- Handle exception  
	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,2627
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH