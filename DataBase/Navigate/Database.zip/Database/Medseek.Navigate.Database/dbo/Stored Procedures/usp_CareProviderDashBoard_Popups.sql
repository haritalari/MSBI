﻿/*     
------------------------------------------------------------------------------          
Procedure Name: usp_CareProviderDashBoard_Popups  10941,4010,'Encounters',null      
Description   : This Procedure is used for getting popupdata by patientuseid in careprovider dashboard tabs      
Created By    : Rathnam      
Created Date  : 22-Dec-2010          
------------------------------------------------------------------------------          
Log History   :           
DD-MM-YYYY  BY   DESCRIPTION          
20-Jan-2011 Rathnam changed the conditions for Healthrisk score       
15-Feb-2011 Rathnam Modified the Healthrisk score conditions         
09-May-2011 Rathnam added @v_PopUpType = 'ICDCode' tab.      
26-May-2011 Rathnam added @v_PopUpType = 'CPTCode' tab.      
09-Aug-2011 NagaBabu Added @v_PopUpType = 'DiseaseMarker' tab      
11-Aug-2011 NagaBabu Added 'AND UserDisease.DiseaseMarkerStatus = 'N'' for 'DiseaseMarker' Tab      
17-Aug-2011 NagaBabu Modified ICDMarker,MeasureMarker Fields      
12-Sep-2011 NagaBabu Replaced MeasureMarker,ICDMarker fields by SelectedCriteria      
08-Nov-2012 sivakrishna Added YtdUtilization,CareGaps,RxUtilization,ERVisits If Clauses to give the popup details.      
08/07/2013 Santosh Commented the Column Comments    
19-08-2014 Santosh removed the condition IsPatientDeclinedEnrollment
30-12-2014 Santosh changed the code as per NAVI - 2072
01/04/2015 : Rathnam modified the code as per NAVI-2630 # changes are ISNULL(t.IsProgramTask,0) = 1 instead of AND ((ty.IsTask = 0 AND t.TaskCompletedDate IS NOT NULL) OR ty.IsTask = 1)
06-01-2015: Santosh modified Sp as per NAVI-3096
24/07/2015 : Chaitanya teja modified the code as per NAVI-3332 to get Missed Opportunities count same in patients tasks and mypatients
22-Sep-2015 NagaBabu Added a new input parameter for the NAVI-3934 for fetching caregaps for all users
24-Mar-2016 Nagababu Modified the logic for caregaps as per new task architecture as per NAVI-5539
11-Apr-2016 Rathnam Modified as per NAVI-5738
13-Apr-2016 Rathnam Modified as per NAVI-5791
------------------------------------------------------------------------------          
*/
CREATE PROCEDURE [dbo].[usp_CareProviderDashBoard_Popups] -- 10,820,'Encounters',null    
	(
	@i_AppUserId KEYID
	,@i_PatientUserId KEYID
	,@v_PopUpType VARCHAR(15)
	,@d_LastOfficeVisist DATETIME = NULL
	,@t_tDiseaseID ttypekeyid READONLY
	,@t_tProgramID ttypekeyid READONLY
	,@vc_RoleName VARCHAR(50) = NULL
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	-- Check if valid Application User ID is passed        
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END

	CREATE TABLE #TEMP (DiseaseID INT)

	INSERT INTO #TEMP
	SELECT *
	FROM @t_tDiseaseID

	CREATE TABLE #TEST (ProgramID INT)

	INSERT INTO #TEST
	SELECT *
	FROM @t_tProgramID

	DECLARE @vc_SQL VARCHAR(MAX)
		,@v_SQL VARCHAR(MAX)

	------------------ Diseases that have been diagnosed for the patient ------------------------      
	IF @v_PopUpType = 'Diseases'
		SET @vc_SQL = 'SELECT  ISNULL(PopulationDefinition.PopulationDefinitionName, '''') AS Conditions    
  FROM PopulationDefinitionPatients ConditionDefinitionUser WITH (NOLOCK)    
  INNER JOIN PopulationDefinition WITH (NOLOCK)    
   ON ConditionDefinitionUser.PopulationDefinitionID = PopulationDefinition.PopulationDefinitionID   '

	IF EXISTS (
			SELECT 1
			FROM #TEMP
			)
	BEGIN
		SET @vc_SQL = @vc_SQL + ' INNER JOIN #TEMP
                                ON DiseaseID =  ConditionDefinitionUser.PopulationDefinitionID '
	END

	SET @vc_SQL = @vc_SQL + ' WHERE ConditionDefinitionUser.PatientID = ' + CAST(@i_PatientUserId AS VARCHAR) + '
   AND PopulationDefinition.StatusCode = ''A''    
   AND ConditionDefinitionUser.StatusCode = ''A''    
   AND PopulationDefinition.DefinitionType = ''C'''

	PRINT (@vc_SQL)

	EXEC (@vc_SQL)

	--ORDER BY StartDate DESC    
	------------------ Active programs the patient is enrolled in ------------------------       
	IF @v_PopUpType = 'programs'
		SET @v_SQL = 'SELECT ISNULL(CONVERT(VARCHAR, PatientProgram.EnrollmentStartDate, 101), '''') + '' - '' + ISNULL(Program.ProgramName, '''') AS ManagedPopulation    
  FROM PatientProgram WITH (NOLOCK)    
  INNER JOIN Program WITH (NOLOCK)    
   ON PatientProgram.ProgramId = Program.ProgramId    
    AND Program.StatusCode = ''A''    
    AND PatientProgram.StatusCode = ''A'''

	IF EXISTS (
			SELECT 1
			FROM #TEST
			)
	BEGIN
		SET @v_SQL = @v_SQL + 'INNER JOIN #TEST
                               ON #TEST.ProgramID = PatientProgram.ProgramID '
	END

	SET @v_SQL = @v_SQL + 'WHERE PatientProgram.PatientID = ' + CAST(@i_PatientUserId AS VARCHAR) + '   
   AND PatientProgram.EnrollmentStartDate IS NOT NULL    
   AND PatientProgram.EnrollmentEndDate IS NULL    
  --  ORDER BY PatientProgram.EnrollmentStartDate DESC '

	PRINT (@v_SQL)

	EXEC (@v_SQL)

	IF @v_PopUpType = 'Encounters'
	BEGIN
		DECLARE @i_UserId INT = @i_patientUserid
			,@b_ispopup ISINDICATOR = 1
			,@b_isLV ISINDICATOR = 0

		EXEC [usp_DashBoard_PatientHomePage_ProgramEncounters] @i_AppUserId
			,@i_UserId
			,@b_isLV
			,@b_ispopup
			

		-----------------------Future Encounters-------------------------   
		SELECT '' AS 'Scheduled Date'
			,'' AS 'Encounter Type'
			,'' AS 'Care Provider'
			,'' AS Comments
		WHERE 1 = 0
	END

	----------------------------Risk Score for each type-------------------------      
	IF @v_PopUpType = 'Risk'
		SELECT CONVERT(VARCHAR, UHS.DateDetermined, 101) AS 'Date'
			,HealthRisk.[Risk Score Type] AS 'Risk Score Type'
			,CASE 
				WHEN UHS.Score IS NOT NULL
					THEN CONVERT(VARCHAR, UHS.Score) + '%'
				ELSE UHS.ScoreText
				END AS Score
		FROM PatientHealthStatusScore UHS WITH (NOLOCK)
		INNER JOIN HealthStatusScoreType UST WITH (NOLOCK) ON UST.HealthStatusScoreId = UHS.HealthStatusScoreId
		INNER JOIN (
			SELECT DISTINCT MAX(PatientHealthStatusId) AS UserHealthStatusId
				,HealthStatusScoreOrganization.NAME + ' - ' + HealthStatusScoreType.NAME AS 'Risk Score Type'
			FROM PatientHealthStatusScore WITH (NOLOCK)
			INNER JOIN HealthStatusScoreType WITH (NOLOCK) ON HealthStatusScoreType.HealthStatusScoreId = PatientHealthStatusScore.HealthStatusScoreId
			INNER JOIN HealthStatusScoreOrganization WITH (NOLOCK) ON HealthStatusScoreOrganization.HealthStatusScoreOrgId = HealthStatusScoreType.HealthStatusScoreOrgId
			WHERE PatientHealthStatusScore.PatientID = @i_PatientUserId
				AND PatientHealthStatusScore.StatusCode = 'A'
				AND HealthStatusScoreType.StatusCode = 'A'
			GROUP BY HealthStatusScoreOrganization.NAME + ' - ' + HealthStatusScoreType.NAME
			) HealthRisk ON HealthRisk.UserHealthStatusId = UHS.PatientHealthStatusId
		WHERE UHS.PatientID = @i_PatientUserId
			AND UHS.StatusCode = 'A'
			AND UST.StatusCode = 'A'
		ORDER BY UHS.DateDetermined DESC

	IF @v_PopUpType = 'ICDCode'
		AND @d_LastOfficeVisist IS NOT NULL
		SELECT DISTINCT TOP 50 cg.DiagnosisCode AS ICDCode
			,cg.DiagnosisLongDescription AS ICDCodeDescription
		FROM ClaimLineDiagnosis pdc WITH (NOLOCK)
		INNER JOIN ClaimLine pdg WITH (NOLOCK) ON pdg.ClaimLineID = pdc.ClaimLineID
		INNER JOIN ClaimInfo ci WITH (NOLOCK) ON ci.ClaimInfoId = pdg.ClaimInfoID
		INNER JOIN CodeSetICDDiagnosis cg ON cg.DiagnosisCodeID = pdc.DiagnosisCodeID
		WHERE ci.PatientID = @i_PatientUserId
			AND CAST(ci.DateOfAdmit AS DATE) = CAST(@d_LastOfficeVisist AS DATE)

	IF @v_PopUpType = 'CPTCode'
		AND @d_LastOfficeVisist IS NOT NULL
		SELECT DISTINCT TOP 50 cg.ProcedureCode CPTCode
			,cg.ProcedureName CPTCodeDescription
		FROM ClaimLine ppc WITH (NOLOCK)
		INNER JOIN ClaimInfo ppcg WITH (NOLOCK) ON ppc.ClaimInfoID = ppcg.ClaimInfoID
		INNER JOIN CodeSetProcedure cg ON cg.ProcedureCodeID = ppc.ProcedureCodeID
		WHERE ppcg.PatientID = @i_PatientUserId
			AND CAST(ppcg.DateOfAdmit AS DATE) = CAST(@d_LastOfficeVisist AS DATE)

	---------------------          
	IF @v_PopUpType = 'YTDUtilization'
		SELECT DATEPART(YY, CI.PaidDate) AS Year
			,CAST(SUM(CASE 
						WHEN CI.ClaimInfoId IS NULL
							THEN 0
						ELSE 1
						END) AS VARCHAR) AS TotalNumberOfClaims
			,'$' + CAST(SUM(CASE 
						WHEN CI.NetPaidAmount IS NULL
							THEN 0
						ELSE CI.NetPaidAmount
						END) AS VARCHAR) TotalAmountPaid
		FROM ClaimInfo CI WITH (NOLOCK)
		WHERE CI.PatientID = @i_PatientUserId
			AND CAST(CI.PaidDate AS DATE) BETWEEN CAST(DATEADD(YY, - 3, GETDATE()) AS DATE)
				AND CAST(GETDATE() AS DATE)
		GROUP BY DATEPART(YY, CI.PaidDate)
		ORDER BY DATEPART(YY, CI.PaidDate) DESC

	--------------------------------------         
	IF @v_PopUpType = 'ERVisits'
		SELECT DATEPART(YY, CI.PaidDate) AS Year
			,CAST(SUM(CASE 
						WHEN CL.ClaimLineID IS NULL
							THEN 0
						ELSE 1
						END) AS VARCHAR) AS TotalNoOfVisists
			,'$' + CAST(SUM(CASE 
						WHEN CI.NetPaidAmount IS NULL
							THEN 0
						ELSE CI.NetPaidAmount
						END) AS VARCHAR) AS TotalAmountPaid
		FROM ClaimInfo CI WITH (NOLOCK)
		INNER JOIN ClaimLine CL WITH (NOLOCK) ON CI.ClaimInfoId = CL.ClaimInfoID
		INNER JOIN vw_PatientEncounter PE ON PE.ClaimInfoId = CI.ClaimInfoId
		WHERE PE.CodeGroupingName = 'ED'
			AND CI.PatientID = @i_PatientUserId
			AND CAST(CI.PaidDate AS DATE) BETWEEN CAST(DATEADD(YY, - 3, GETDATE()) AS DATE)
				AND CAST(GETDATE() AS DATE)
		GROUP BY DATEPART(YY, CI.PaidDate)
		ORDER BY DATEPART(YY, CI.PaidDate) DESC

	-----------------------------------------------      
	IF @v_PopUpType = 'RxUtilization'
		SELECT Rx.RxClaimNumber AS RxClaimNum
			,CSD.DrugCode
			,CSD.DrugName
			,CONVERT(VARCHAR(12), Rx.DateFilled, 101) AS DateOfTaken
			,SUM(CASE 
					WHEN Rx.QuantityDispensed IS NULL
						THEN 0
					ELSE Rx.QuantityDispensed
					END)
		FROM RxClaim Rx WITH (NOLOCK)
		INNER JOIN PatientDrugCodes Ud WITH (NOLOCK) ON Rx.RxClaimId = ud.RxClaimId
		INNER JOIN CodeSetDrug CSD WITH (NOLOCK) ON UD.DrugCodeId = CSD.DrugCodeId
		WHERE Ud.PatientID = @i_PatientUserId
			AND CAST(Rx.DateFilled AS DATE) BETWEEN CAST(DATEADD(YY, - 3, GETDATE()) AS DATE)
				AND CAST(GETDATE() AS DATE)
		GROUP BY Rx.RxClaimNumber
			,CSD.DrugCode
			,CSD.DrugName
			,Rx.DateFilled

	--------------------------------------            
	IF @v_PopUpType = 'CareGaps'
	BEGIN
	DECLARE @i_IncompleteTaskStatusID INT, @i_DisEnrollTaskStatusID int

	SELECT @i_IncompleteTaskStatusID = ts.TaskStatusId
	FROM TaskStatus ts
	WHERE TaskStatusText = 'Closed Incomplete'

	SELECT @i_DisEnrollTaskStatusID = ts.TaskStatusId
	FROM TaskStatus ts
	WHERE TaskStatusText = 'DisEnroll'

	CREATE TABLE #tProgram
	(
		ProgramID INT
	)

	IF @vc_RoleName IN ('Care Manager','Care Team Member')
		INSERT INTO #tProgram
		SELECT DISTINCT p.ProgramID
		FROM ProgramCareTeam pct
		INNER JOIN CareTeamMembers ctm ON ctm.CareTeamId = pct.CareTeamId
		INNER JOIN Program p ON p.ProgramId = pct.ProgramId
		WHERE 
			ctm.StatusCode = 'A'
			AND ctm.ProviderID = @i_AppUserId 
	ELSE 
		INSERT INTO #tProgram
		SELECT p.ProgramID
		FROM Program p

		SELECT Dbo.ufn_GetTypeNamesByTypeId(ty.TaskTypeName, t.TypeID) AS TaskName
			,t.MissedOpportunityDate
		FROM PatientTask t WITH (NOLOCK)
		INNER JOIN #tProgram pt ON t.ManagedPopulationId = pt.ProgramID
		INNER JOIN TaskType ty WITH (NOLOCK) 
		ON ty.TaskTypeId = t.TaskTypeId
		WHERE 
			t.PatientId = @i_PatientUserId
			and ((t.TaskStatusId IN (@i_IncompleteTaskStatusID,@i_DisEnrollTaskStatusID) AND IsTask = 1)
				OR (t.TaskStatusId = @i_DisEnrollTaskStatusID AND IsTask = 0))

			END
				
END TRY

---------------------------------------------------------------           
BEGIN CATCH
		-- Handle exception  
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH