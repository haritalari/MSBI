﻿/*                  
------------------------------------------------------------------------------                  
Procedure Name: usp_CareProviderDashBoard_MyTasksByPatientID  87163,12,'D',1      
Description   : This procedure is used to get the open tasks select by patientID             
Created By    : Rathnam                  
Created Date  : 28-Oct-2010                  
------------------------------------------------------------------------------                  
Log History   :                   
DD-MM-YYYY  BY   DESCRIPTION       
07-Jan-2013 NagaBabu Modified derivation for IsAdhoc Field in resultset       
02-Feb-2013 Praveen Added parameter @i_IsShortList to get top 5 records based on condition      
25-July-2013 Rathnam added PatientTaskID GeneralizedID  
20-02-2014 Rathnam commented the assigned careprovider functionality as we need to get the tasks based on tasktypes 
26-09-2014 Rathnam modifed the SP as per the Bug 1529     
24-11-2014 Rathnam modifed the SP as per 3.1 Sprint 2 Document
05-08-2015 Nagababu Added logic for ER vist type functionality
19-08-2015 Prashanth Added support for Role
05-10-2015 Santosh Modified the SP as per NAVI-3807,3908
26-11-2015 Yugandhar Modified the SP as per NAVI-3907
30-11-2015   Removed t.TotalRemainderCount IS NOT NULL comdition to get the adhoc tasks.
17-03-2016 Rathnam modifed as per new task architecture
01-04-2016 Chaitanya modifed dateTaken column name as per defect NAVI-5679
29-Aug-2016 Rathnam Modified the logic as per NAVI-6597 (Patient Task access rights)
09-09-2016 Rathnam modified the logic as per NAVI-6683 (Last completed date display)
27-09-2016 Rathnam NAVI-5589 Define Rejected Reasons on Patient Submitted Tasks
17-Oct-2016 Nagababu Modified the logic as per NAVI-6868
03-Nov-2016 Nagababu Modified the code as per NAVI-6808
------------------------------------------------------------------------------       
*/
CREATE PROCEDURE [dbo].[usp_CareProviderDashBoard_MyTasksByPatientID] (
	@i_AppUserId INT
	,@i_PatientUserID INT
	,@v_PageType CHAR(1) = 'D' --> D -- DashBoard, V -- VisitPlan
	,@tblTaskStatus TypeIDAndName READONLY ---> Navigate(submit, Open & Reject) , External(Open & Reject)
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @i_OpenTaskStatusID INT
		,@i_ClosedCompleteStatusID INT

	SELECT @i_OpenTaskStatusID = TaskStatusId
	FROM TaskStatus
	WHERE TaskStatusText = 'Open'

	SELECT @i_ClosedCompleteStatusID = TaskStatusId
	FROM TaskStatus
	WHERE TaskStatusText = 'Closed Complete'

	IF @v_PageType = 'V'
	BEGIN
		SELECT t.PatientTaskId
			,ty.IsTask
			,t.TaskTypeId
			,ty.TaskTypeName TaskTypeName
			,t.DueDate DateDue
			,t.TypeID
			,dbo.ufn_GetTypeNamesByTypeId(ty.TaskTypeName, t.TypeID) TypeName
			,t.DateTaken AS TaskCompletedDate
			,pr.ProgramName
			,pr.StatusCode AS ProgramStatus
			,t.AccessType
		FROM PatientTask t WITH (NOLOCK)
		INNER JOIN Program Pr WITH (NOLOCK) ON T.ManagedPopulationId = pr.ProgramId
		INNER JOIN TaskType ty WITH (NOLOCK) ON t.TaskTypeId = ty.TaskTypeId
		WHERE t.TaskStatusId = @i_OpenTaskStatusID
			AND t.PatientId = @i_PatientUserID
			AND ty.IsTask = 1
		
		UNION
		
		SELECT t.PatientTaskId
			,ty.IsTask
			,t.TaskTypeId
			,ty.TaskTypeName TaskTypeName
			,t.DueDate DateDue
			,t.TypeID
			,dbo.ufn_GetTypeNamesByTypeId(ty.TaskTypeName, t.TypeID) TypeName
			,t.DateTaken AS TaskCompletedDate
			,pr.ProgramName
			,pr.StatusCode AS ProgramStatus
			,t.AccessType
		FROM PatientTask t WITH (NOLOCK)
		INNER JOIN Program Pr ON t.ManagedPopulationId = Pr.ProgramId
		INNER JOIN TaskType ty WITH (NOLOCK) ON t.TaskTypeId = ty.TaskTypeId
		WHERE t.TaskStatusId = @i_ClosedCompleteStatusID
			AND CONVERT(DATE, t.DateTaken) >= DATEADD(YY, - 1, GETDATE())
			AND t.PatientId = @i_PatientUserID
			AND ty.IsTask = 1
	END
	ELSE IF @v_PageType = 'D'
	BEGIN
		SELECT DISTINCT t.PatientTaskId Taskid
			,ty.IsTask
			,t.TaskTypeId
			,ty.TaskTypeName TaskTypeName
			,t.DueDate DateDue
			,t.TypeID
			,Pr.ProgramName
			,pr.StatusCode AS ProgramStatus
			,t.AccessType
			,ts.TypeId TaskStatusID
			,ts.Name TaskStatus
			,t.InvalidatedReasonId
			,t.LastModifiedByUserId
			,t.LastModifiedDate
			,t.Comments
		INTO #PatientTask
		FROM PatientTask t WITH (NOLOCK)
		INNER JOIN @tblTaskStatus ts ON ts.TypeId = t.TaskStatusId
		INNER JOIN Program Pr WITH (NOLOCK) ON T.ManagedPopulationId = pr.ProgramId
		INNER JOIN TaskType ty WITH (NOLOCK) ON t.TaskTypeId = ty.TaskTypeId
		WHERE t.PatientId = @i_PatientUserID
		
		SELECT ptss.PatientTaskSubmitStatusId
			,t.TaskId AS PatientTaskId
			,SubmitDate
			,SubmitBy
			,RejectBy
			,RejectDate
			,DENSE_RANK() OVER (
				PARTITION BY PatientTaskId ORDER BY PatientTaskSubmitStatusId DESC
				) Sno
		INTO #Submit
		FROM PatientTaskSubmitStatus ptss WITH (NOLOCK)
		RIGHT JOIN #PatientTask t ON ptss.PatientTaskId = t.Taskid

		SELECT t.Taskid
			,t.IsTask
			,t.TaskTypeId
			,t.TaskTypeName TaskTypeName
			,t.DateDue
			,t.TypeID
			,dbo.ufn_GetTypeNamesByTypeId(t.TaskTypeName, t.TypeID) TypeName
			,DBO.[ufn_GetTaskLastcompletedDate](@i_PatientUserID, t.TaskTypeId, t.TypeId, @i_ClosedCompleteStatusID, 0) AS LastTaskCompletedDate
			,CASE 
				WHEN t.TaskTypeName = 'Assessment'
					THEN DBO.[ufn_GetTaskLastcompletedDate](@i_PatientUserID, t.TaskTypeId, t.TypeId, @i_ClosedCompleteStatusID, 1)
				ELSE NULL
				END AS LastCompletedTaskID
			,NULL AS ADTStatus
			,NULL AS AdmitDate
			,NULL AS FacilityName
			,NULL AS LastDischargedate
			,NULL AS LastFacilityName
			,NULL AS NumberOfDays
			,NULL AS DischargeDate
			,NULL AS DisChargeFacilityName
			,NULL AS DischargedTo
			,NULL AS DisChargeAdmitDate
			,NULL AS InpatientDays
			,t.ProgramName
			,t.ProgramStatus
			,t.AccessType
			,t.TaskStatusID
			,t.TaskStatus
			,s.PatientTaskSubmitStatusId
			,s.SubmitDate
			,s.RejectDate
			,eu.UserName SubmitBy
			,dbo.ufn_GetProviderName(p.ProviderID) RejectBy
			,CASE WHEN LIR.InvalidReason = 'Other' THEN 'Other-'+ t.Comments
				  ELSE LIR.InvalidReason
			 END AS Reason
			,dbo.ufn_GetProviderName(t.LastModifiedByUserId) AS InvalidatedBy
			,t.LastModifiedDate AS InvalidationDate
		FROM #PatientTask t
		INNER JOIN #Submit s ON t.Taskid = s.PatientTaskId
		LEFT JOIN ExternalUser eu on eu.ExternalUserID = s.SubmitBy
		LEFT JOIN Provider p ON p.ProviderID = s.RejectBy
		LEFT JOIN LkupInvalidReason LIR ON LIR.InvalidReasonId = T.InvalidatedReasonId
		WHERE s.Sno = 1
	END
END TRY

--------------------------------------------------------                   
BEGIN CATCH
	-- Handle exception                  
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH
