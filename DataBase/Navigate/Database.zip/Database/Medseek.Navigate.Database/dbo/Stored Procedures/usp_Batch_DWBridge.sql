﻿

/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_DWBridge]
Description   :  This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Rathnam  
Created Date  : 10-Oct-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
http://www.purplefrogsystems.com/blog/2013/04/mdx-between-start-date-and-end-date/
------------------------------------------------------------------------------------------------------------
*/
CREATE PROCEDURE [dbo].[usp_Batch_DWBridge]
AS
BEGIN TRY
	SET NOCOUNT ON

	EXEC usp_Batch_DWCareManagement
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH