﻿/*  
---------------------------------------------------------------------------------------  
Procedure Name: dbo].[usp_Batch_DWDim] 
Description   : This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Rathnam  
Created Date  : 10-Oct-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
06-Jan-2016 Rathnam added goal table as per 4706 senario to maintain unique goals
16-March-2016 Rathnam modified the logic as per NAVI-5316.
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_DWDim] (
	@d_StartDate DATE = NULL
	,@d_EndDate DATE = NULL
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	IF @d_EndDate IS NULL
	BEGIN
		SET @d_EndDate = EOMONTH(GETDATE())
	END

	IF @d_StartDate IS NULL
	BEGIN
		SET @d_StartDate = CONVERT(DATE, DATEADD(YEAR, DATEDIFF(YEAR, 0, DATEADD(yy, - 5, @d_EndDate)), 0))
	END

	IF OBJECT_ID('DW_DimDate') IS NOT NULL
	BEGIN
		DROP TABLE [DW_DimDate]
	END

	CREATE TABLE [dbo].[DW_DimDate] (
		[DateKey] [int] NOT NULL
		,[FullDateAlternateKey] [date] NOT NULL
		,[WeekNumberOfYear] [tinyint] NOT NULL
		,[CalendarQuarter] [tinyint] NOT NULL
		,[CalendarYear] [smallint] NOT NULL
		,[CalendarSemester] [tinyint] NOT NULL
		,CONSTRAINT [PK_DW_DimDate_DateKey] PRIMARY KEY CLUSTERED ([DateKey] ASC)
		)

	WHILE @d_StartDate <= @d_EndDate
	BEGIN
		INSERT INTO DW_DimDate (
			[DateKey]
			,FullDateAlternateKey
			,[WeekNumberOfYear]
			,[CalendarQuarter]
			,[CalendarYear]
			,[CalendarSemester]
			)
		SELECT CAST(CONVERT(VARCHAR(8), CONVERT(DATE, @d_StartDate), 112) AS INT)
			,CAST(@d_StartDate AS DATE)
			,DATEPART(wk, @d_StartDate)
			,Datepart(QQ, @d_StartDate)
			,DATEPART(Year, @d_StartDate)
			,CASE 
				WHEN Datepart(month, @d_StartDate) BETWEEN 1
						AND 6
					THEN 1
				WHEN Datepart(month, @d_StartDate) BETWEEN 7
						AND 12
					THEN 1
				END

		SET @d_StartDate = DATEADD(dd, 1, @d_StartDate)
	END

	IF OBJECT_ID('TEMPDB..##DW_DimDate') IS NOT NULL
		DROP TABLE ##DW_DimDate

	SELECT DateKey
		,FullDateAlternateKey
		,WeekNumberOfYear
		,CalendarQuarter
		,CalendarYear
		,CalendarSemester
	INTO ##DW_DimDate
	FROM DW_DimDate WITH (NOLOCK)

	IF OBJECT_ID('TEMPDB..##DW_DimManagedPopulation') IS NOT NULL
		DROP TABLE ##DW_DimManagedPopulation

	BEGIN
		SELECT p.ProgramId ManagedPopulationKey
			,p.ProgramName ManagedPopulationName
			,p.StatusCode ManagedPopulationStatus
			,cp.CodeSetProgramID ProgramKey
			,cp.ProgramName ProgramName
			,cr.CodeSetRegionID RegionKey
			,cr.RegionName RegionName
			,ca.CodeSetAcuityID AcuityKey
			,ca.AcuityName
		INTO ##DW_DimManagedPopulation
		FROM Program p with(nolock)
		LEFT JOIN ProgramGroup pg with(nolock) ON pg.ProgramGroupID = p.ProgramGroupID
		LEFT JOIN CodeSetProgram cp with(nolock) ON cp.CodeSetProgramID = pg.CodeSetProgramID
		LEFT JOIN CodeSetRegion cr with(nolock) ON cr.CodeSetRegionID = pg.CodeSetRegionID
		LEFT JOIN CodeSetAcuity ca with(nolock) ON ca.CodeSetAcuityID = pg.CodeSetAcuityID
	END

	IF OBJECT_ID('TEMPDB..##DW_DimProvider') IS NOT NULL
		DROP TABLE ##DW_DimProvider

	SELECT ProviderID AS ProviderKey
		,LTRIM(DBO.[ufn_GetProviderName](ProviderID)) FullName
		,NPINumber NPINumber
		,TaxID_EIN_SSN AS TaxIDNumber
		,PrimaryAddressCity City
		,PrimaryAddressPostalCode PostalCode
		,PrimaryPhoneNumber PhoneNumber
	INTO ##DW_DimProvider
	FROM [Provider] p WITH (NOLOCK)
	LEFT JOIN CodeSetProviderType pt WITH (NOLOCK) ON p.ProviderTypeID = pt.ProviderTypeCodeID

	--WHERE Description <> 'Administrator'
	IF OBJECT_ID('TEMPDB..##DW_DimCareTeam') IS NOT NULL
		DROP TABLE ##DW_DimCareTeam

	SELECT CareTeamId
		,CareTeamName
		,StatusCode
	INTO ##DW_DimCareTeam
	FROM CareTeam with(nolock)

	IF OBJECT_ID('TEMPDB..##DW_DimPatient') IS NOT NULL
		DROP TABLE ##DW_DimPatient

	SELECT PatientID AS PatientKey
		,ISNULL(MedicalRecordNumber, MemberID) [UniqueIdentifier]
		,ISNULL(FirstName + ' ', '') + '' + ISNULL(LastName, '') AS FullName
		,DateOfBirth
		,dbo.ufn_GetAgeByDOB(DateOfBirth) AS Age
		,Gender
		,SSN
		,PrimaryEmailAddress Email
		,PrimaryPhoneNumber AS PhoneNo
		,PrimaryAddressCity City
		,cs.StateName
		,PrimaryAddressPostalCode PostalCode
		,DateDeceased
	INTO ##DW_DimPatient
	FROM Patient WITH (NOLOCK)
	LEFT JOIN codesetstate cs ON cs.StateID = Patient.PrimaryAddressStateCodeID

	IF OBJECT_ID('TEMPDB..##DW_DimDisenrollReason') IS NOT NULL
		DROP TABLE ##DW_DimDisenrollReason

	SELECT DisenrollReasonId DisEnrollReasonKey
		,DisenrollReason
	INTO ##DW_DimDisenrollReason
	FROM CodeSetDisenrollmentReason with(nolock)

	IF OBJECT_ID('TEMPDB..##DW_DimTaskType') IS NOT NULL
		DROP TABLE ##DW_DimTaskType

	SELECT TaskTypeId TaskTypeKey
		,TaskTypeName TaskTypeName
		,StatusCode TaskTypeStatus
	INTO ##DW_DimTaskType
	FROM TaskType with(nolock)

	IF OBJECT_ID('TEMPDB..##DW_DimTaskStatus') IS NOT NULL
		DROP TABLE ##DW_DimTaskStatus

	CREATE TABLE ##DW_DimTaskStatus (
		TaskStatusId INT IDENTITY(1, 1)
		,TaskStatusText VARCHAR(100)
		)

	SET IDENTITY_INSERT ##DW_DimTaskStatus ON

	INSERT INTO ##DW_DimTaskStatus (
		TaskStatusId
		,TaskStatusText
		)
	SELECT TaskStatusId
		,TaskStatusText
	FROM TaskStatus with(nolock)

	--WHERE TaskStatusText != 'Open'
	SET IDENTITY_INSERT ##DW_DimTaskStatus OFF

	INSERT INTO ##DW_DimTaskStatus
	SELECT 'Past Due'
	
	UNION
	
	SELECT 'Future'
	
	UNION
	
	SELECT 'Today'

	IF OBJECT_ID('TEMPDB..##DW_DimTaskTypeTask') IS NOT NULL
		DROP TABLE ##DW_DimTaskTypeTask

	CREATE TABLE ##DW_DimTaskTypeTask (
		DimTaskTypeTaskKey INT NOT NULL IDENTITY(1, 1)
		,TaskTypeKey INT NOT NULL
		,TaskTypeTaskKey INT NOT NULL
		,TaskTypeTaskName VARCHAR(4000)
		)

	INSERT INTO ##DW_DimTaskTypeTask
	SELECT t1.TaskTypeID TaskTypeKey
		,t1.TypeID TaskTypeTaskKey
		,CONVERT(VARCHAR, Dbo.ufn_GetTypeNamesByTypeId(TaskTypeName, TypeID)) TaskTypeTaskName
	FROM (
		SELECT DISTINCT t.TypeId
			,t.TaskTypeId
		FROM PatientTask t with(nolock)
		) t1
	INNER JOIN TaskType ty ON t1.Tasktypeid = ty.tasktypeid


	IF OBJECT_ID('TEMPDB..##Questionaire') IS NOT NULL
		DROP TABLE ##Questionaire

		SELECT QuestionaireId AssessmentKey, QuestionaireName AssessmentName into ##Questionaire FROM Questionaire
	

	IF OBJECT_ID('TEMPDB..##Assessment') IS NOT NULL
		DROP TABLE ##Assessment
DECLARE @i_AssessmentTasktypeID INT, @i_TaskStatusID INT
	SELECT @i_TaskStatusID = TaskStatusId FROM TaskStatus WHERE TaskStatusText = 'Closed Complete'
	SELECT @i_AssessmentTasktypeID = TaskTypeId FROM TaskType	WHERE TaskTypeName = 'Assessment'
	SELECT *
	INTO ##Assessment
	FROM (
		SELECT DISTINCT qr.QuestionaireId
			,qr.QuestionaireName
			,q.QuestionId
			,q.QuestionText
			,a.AnswerId
			,a.AnswerDescription
			,0 as IsFreetext
		FROM Questionaire qr with(nolock)
		INNER JOIN QuestionaireQuestionSet qqs with(nolock) ON qqs.QuestionaireId = qr.QuestionaireId
		INNER JOIN QuestionSetQuestion qsq with(nolock) ON qsq.QuestionSetId = qqs.QuestionSetId
		INNER JOIN Question q with(nolock) ON q.QuestionId = qsq.QuestionId
		INNER JOIN Answer a with(nolock) ON a.QuestionId = q.QuestionId
		INNER JOIN AnswerType ty with(nolock) ON ty.AnswerTypeId = q.AnswerTypeId
		WHERE AnswerTypeCode NOT IN (
				'Text'
				,'DateTime'
				,'NumberText'
				)
		
		UNION ALL
		
		SELECT DISTINCT qr.QuestionaireId
			,qr.QuestionaireName
			,q.QuestionId
			,q.QuestionText
			,a.AnswerID
			,CASE 
				WHEN AT.AnswerTypeCode = 'DateTime'
					AND NULLIF(uqa.AnswerString, '') IS NOT NULL
					THEN LEFT(uqa.AnswerString, 10)
				ELSE uqa.AnswerString
				END
			,1 as IsFreetext
		FROM PatientAssessmentAnswer uqa WITH (NOLOCK)
		INNER JOIN PatientTask pq WITH (NOLOCK) ON uqa.PatientTaskId = pq.PatientTaskId
		INNER JOIN Questionaire qr with(nolock) ON qr.Questionaireid = pq.TypeId
		INNER JOIN Answer a with(nolock) ON uqa.AnswerID = a.AnswerId
		INNER JOIN Question q with(nolock) ON q.QuestionId = a.QuestionId
		INNER JOIN AnswerType at with(nolock) ON at.AnswerTypeId = q.AnswerTypeId
		WHERE 
		pq.TaskTypeId =  @i_AssessmentTasktypeID
		AND pq.TaskStatusId = @i_TaskStatusID
		AND AnswerTypeCode IN (
				'Text'
				,'DateTime'
				,'NumberText'
				)
			AND uqa.AnswerString <> ''
		) x

	IF OBJECT_ID('TEMPDB..#NQuestion') IS NOT NULL
		DROP TABLE #NQuestion

	CREATE TABLE #NQuestion (
		NQuestionid INT IDENTITY(1, 1)
		,QuestionText VARCHAR(5000)
		)

	IF OBJECT_ID('TEMPDB..#NAnswer') IS NOT NULL
		DROP TABLE #NAnswer

	CREATE TABLE #NAnswer (
		NAnswerID INT IDENTITY(1, 1)
		,AnswerText VARCHAR(6000)
		)

	INSERT INTO #NQuestion
	SELECT DISTINCT QuestionText
	FROM ##Assessment

	INSERT INTO #NAnswer
	SELECT DISTINCT AnswerDescription
	FROM ##Assessment

	ALTER TABLE ##Assessment ADD NQuestionid INT

	ALTER TABLE ##Assessment ADD NAnswerID INT

	UPDATE ##Assessment
	SET NQuestionid = n.NQuestionid
	FROM #NQuestion n
	WHERE n.QuestionText = ##Assessment.QuestionText

	UPDATE ##Assessment
	SET NAnswerID = n.NAnswerID
	FROM #NAnswer n
	WHERE n.AnswerText = ##Assessment.AnswerDescription

	IF OBJECT_ID('TEMPDB..##DW_DimAssessment') IS NOT NULL
		DROP TABLE ##DW_DimAssessment

	CREATE TABLE ##DW_DimAssessment (
		[DimAssessmentKey] [int] NOT NULL IDENTITY(1, 1)
		,[AssessmentKey] [int] NOT NULL
		,[QuestionKey] [int] NULL
		,[AnswerKey] [int] NULL
		,[AssessmentText] [varchar](5000) NULL
		,[QuestionText] [varchar](500) NULL
		,[AnswerText] [varchar](5000) NULL
		)

	INSERT INTO ##DW_DimAssessment
	SELECT DISTINCT QuestionaireId
		,NQuestionid
		,NAnswerID
		,QuestionaireName
		,QuestionText
		,AnswerDescription
	FROM ##Assessment

	IF OBJECT_ID('TEMPDB..##DW_DimGoal') IS NOT NULL
		DROP TABLE ##DW_DimGoal

	CREATE TABLE ##DW_DimGoal (
		GoalID INT 
		,GoalName VARCHAR(1000)
		)

	INSERT INTO ##DW_DimGoal
	SELECT GoalId, GoalName
	FROM Goal

	IF OBJECT_ID('TEMPDB..##DW_DimActivity') IS NOT NULL
		DROP TABLE ##DW_DimActivity

	SELECT ActivityId
		,NAME
	INTO ##DW_DimActivity
	FROM Activity with(nolock)

	IF OBJECT_ID('TEMPDB..##DW_DimMPHierarchie') IS NOT NULL
		DROP TABLE ##DW_DimMPHierarchie

	SELECT DISTINCT ctm.CareTeamId
		,pct.ProgramId
		,ctm.ProviderID
	INTO ##DW_DimMPHierarchie
	FROM ProgramCareTeam pct with(nolock)
	INNER JOIN CareTeamMembers ctm ON pct.CareTeamId = ctm.CareTeamId
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH