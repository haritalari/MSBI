﻿
/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_DWCareManagement]
Description   :  This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Rathnam  
Created Date  : 10-Oct-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
http://www.purplefrogsystems.com/blog/2013/04/mdx-between-start-date-and-end-date/
06-Jan-2016 Rathnam added goal table as per 4706 senario to maintain unique goals
16-March-2016 Rathnam modified the logic as per NAVI-5316.
------------------------------------------------------------------------------------------------------------
*/
CREATE PROCEDURE [dbo].[usp_Batch_DWCareManagement]
AS
BEGIN TRY
	SET NOCOUNT ON

	IF OBJECT_ID('TEMPDB..##DW_FactCareTeamProvider') IS NOT NULL
		DROP TABLE ##DW_FactCareTeamProvider

	SELECT ctm.CareTeamId CareTeamKey
		,ctm.ProviderID CareProviderKey
		,ctm.CareStartDate StartDate
		,ctm.CareEndDate EndDate
		,cp.ProviderID InitiatedBy
		,mp.ProviderID CompletedBy
	INTO ##DW_FactCareTeamProvider
	FROM CareTeamMembers_History ctm
	LEFT JOIN Provider cp WITH (NOLOCK) ON cp.ProviderID = ctm.CreatedByUserId
	LEFT JOIN Provider mp WITH (NOLOCK) ON mp.ProviderID = ctm.LastModifiedByUserId

	IF OBJECT_ID('TEMPDB..##DW_FactCareTeamMP') IS NOT NULL
		DROP TABLE ##DW_FactCareTeamMP

	SELECT CareTeamId CareTeamKey
		,pch.ProgramId ManagedPopulationKey
		,CareStartDate StartDate
		,CareEndDate EndDatae
		,cp.ProviderID InitiatedBy
		,mp.ProviderID CompletedBy
	INTO ##DW_FactCareTeamMP
	FROM ProgramCareTeam_History pch
	INNER JOIN Program p
	on p.ProgramId = pch.ProgramId
	LEFT JOIN Provider cp WITH (NOLOCK) ON cp.ProviderID = pch.CreatedByUserId
	LEFT JOIN Provider mp WITH (NOLOCK) ON mp.ProviderID = pch.LastModifiedByUserId order by 2

	IF OBJECT_ID('TEMPDB..##DW_factPatientManagedPopulation') IS NOT NULL
		DROP TABLE ##DW_factPatientManagedPopulation

	DECLARE @i_ProgramID INT

	SELECT @i_ProgramID = ProgramId
	FROM Program
	WHERE ProgramName = 'All Patients Managed population'

	SELECT PatientManagedPopulationKey
		,ManagedPopulationKey
		,PatientKey
		,EnrollDate
		,DisenrollDate
		,DisEnrollReasonKey
		,EnrollProviderKey
		,DisenrollProviderKey
	INTO ##DW_factPatientManagedPopulation
	FROM (
		SELECT PatientProgramID PatientManagedPopulationKey
			,ProgramID ManagedPopulationKey
			,PatientID PatientKey
			,EnrollmentStartDate EnrollDate
			,EnrollmentEndDate DisenrollDate
			,ReasonForDisenrollId DisEnrollReasonKey
			,cp.ProviderID EnrollProviderKey
			,mp.ProviderID DisenrollProviderKey
			,ROW_NUMBER() OVER (
				PARTITION BY ProgramID
				,PatientID
				,CONVERT(DATE, EnrollmentStartDate) ORDER BY PatientProgramID DESC
				) sno
		FROM PatientProgram pp
		LEFT JOIN Provider cp WITH (NOLOCK) ON cp.ProviderID = pp.CreatedByUserId
		LEFT JOIN Provider mp WITH (NOLOCK) ON mp.ProviderID = pp.LastModifiedByUserId
		WHERE ProgramID != @i_ProgramID
			AND pp.StatusCode IN (
				'E'
				,'I'
				)
		) t
	WHERE sno = 1

	
	IF OBJECT_ID('TEMPDB..##DW_FactTask') IS NOT NULL
		DROP TABLE ##DW_FactTask

	SELECT PatientTaskId TaskKey
		,t.TaskStatusID TaskStatusKey
		,TypeID
		,TaskTypeID
		,PatientID PatientKey
		,ManagedPopulationId ManagedPopulationKey
		,DueDate DateKey
		,DueDate DueDate
		,DateTaken CompletedDate
		,Comments Comments
		,cp.ProviderID InitiatedProviderKey
		,mp.ProviderID CompletedProviderKey
	INTO #task
	FROM PatientTask t
	INNER JOIN TaskStatus ts ON t.TaskStatusID = ts.TaskStatusID
	LEFT JOIN Provider cp WITH (NOLOCK) ON cp.ProviderID = t.CreatedByUserId
	LEFT JOIN Provider mp WITH (NOLOCK) ON mp.ProviderID = t.LastModifiedByUserId

	
	SELECT TaskKey
		,TaskStatusKey
		,DimTaskTypeTaskKey
		,PatientKey
		,ManagedPopulationKey
		,d.DateKey
		,DueDate
		,CompletedDate
		,Comments
		,InitiatedProviderKey
		,CompletedProviderKey
	INTO ##DW_FactTask
	FROM #Task t
	INNER JOIN DW_Dimdate d WITH (NOLOCK) ON d.FullDateAlternateKey = CONVERT(DATE, t.DateKey)
	INNER JOIN ##DW_DimTaskTypeTask ty ON ty.TaskTypeTaskKey = t.TypeID
		AND ty.TaskTypeKey = t.TaskTypeID

	DECLARE @i_AssessmentTasktypeID INT, @i_TaskStatusID INT
	SELECT @i_TaskStatusID = TaskStatusId FROM TaskStatus WHERE TaskStatusText = 'Closed Complete'
	SELECT @i_AssessmentTasktypeID = TaskTypeId FROM TaskType	WHERE TaskTypeName = 'Assessment'
	IF OBJECT_ID('TEMPDB..##DW_FactPatientAssessment') IS NOT NULL
		DROP TABLE ##DW_FactPatientAssessment
		
	SELECT *
	INTO #PatAnswer
	FROM (
		SELECT DISTINCT uqa.PatientTaskId PatientQuestionaireID
			,at.NQuestionId
			,at.NAnswerId
		FROM PatientAssessmentAnswer uqa WITH (NOLOCK)
		INNER JOIN Answer a WITH (NOLOCK) ON uqa.AnswerID = a.AnswerId
		INNER JOIN ##Assessment at ON at.QuestionId = a.QuestionId
			AND at.AnswerId = a.AnswerId
		WHERE at.IsFreetext = 0
		
		UNION
		
		SELECT DISTINCT uqa.PatientTaskId PatientQuestionaireID
			,at.NQuestionId
			,at.NAnswerId
		FROM PatientAssessmentAnswer uqa WITH (NOLOCK)
		INNER JOIN Answer a WITH (NOLOCK) ON uqa.AnswerID = a.AnswerId
		INNER JOIN Question q WITH (NOLOCK) ON q.QuestionId = a.QuestionId
		INNER JOIN AnswerType ty WITH (NOLOCK) ON ty.AnswerTypeId = q.AnswerTypeId
		INNER JOIN ##Assessment at ON at.QuestionId = a.QuestionId
			AND at.AnswerDescription = CASE 
				WHEN ty.AnswerTypeCode = 'DateTime'
					AND NULLIF(uqa.AnswerString, '') IS NOT NULL
					THEN LEFT(uqa.AnswerString, 10)
				ELSE uqa.AnswerString
				END
		WHERE at.IsFreetext = 1
		) a

	SELECT *
	INTO #patque
	FROM (
		SELECT pq.PatientTaskId PatientQuestionaireId
			,(
				SELECT SUM(CONVERT(DECIMAL(20, 6), CASE 
								WHEN UQA.AnswerString = '.'
									THEN '0'
								ELSE UQA.AnswerString
								END))
				FROM PatientAssessmentAnswer UQA WITH (NOLOCK)
				INNER JOIN QuestionSetQuestion QSQ WITH (NOLOCK) ON UQA.QuestionSetQuestionId = QSQ.QuestionSetQuestionId
				INNER JOIN Question Q WITH (NOLOCK) ON QSQ.QuestionId = Q.QuestionId
				INNER JOIN AnswerType AT WITH (NOLOCK) ON AT.AnswerTypeID = Q.AnswerTypeId
				WHERE AT.AnswerTypeCode = 'NumberText'
					AND UQA.PatientTaskId = PQ.PatientTaskId
					AND ISNUMERIC(UQA.AnswerString) = 1
				GROUP BY UQA.PatientTaskId 
				) TotalTime
		FROM PatientTask pq WITH (NOLOCK)
		WHERE TaskTypeId = @i_AssessmentTasktypeID

		) p
	WHERE p.TotalTime IS NOT NULL

	SELECT *
	INTO #PatEnroll
	FROM (
		SELECT PQ.PatientTaskId PatientQuestionaireId
			,PP.EnrollmentStartDate
			,PP.EnrollmentEndDate
			,ISNULL(PP.EnrollmentEndDate, '9999-12-31') AS DisenrollDate
			,ROW_NUMBER() OVER (
				PARTITION BY PQ.PatientTaskId ORDER BY ISNULL(PP.EnrollmentEndDate, '9999-12-31') DESC
				) AS SNO
		FROM PatientTask PQ WITH (NOLOCK)
		INNER JOIN PatientProgram PP WITH (NOLOCK) ON PQ.PatientId = PP.PatientID
			AND PQ.ManagedPopulationId = PP.ProgramID
			AND pp.StatusCode IN (
				'E'
				,'I'
				)
			AND PQ.DateTaken BETWEEN PP.EnrollmentStartDate
				AND ISNULL(PP.EnrollmentEndDate, '9999-12-31')
		WHERE PQ.TaskStatusId = @i_TaskStatusID
		AND TaskTypeId = @i_AssessmentTasktypeID
		) DT
	WHERE SNO = 1

	SELECT pq.PatientTaskId PatientAssessmentKey
		,pq.ManagedPopulationId ManagedPopulationKey
		,pq.PatientId PatientKey
		,ad.DateKey
		,pq.TypeId AssessmentKey
		,pq.DueDate DateDue
		,pq.DateTaken CompletedDate
		,pq.AssessmentScore TotalScore
		,patq.TotalTime
		,cp.ProviderID InitiatedBy
		,mp.ProviderID CompletedBy
		,tpe.EnrollmentStartDate EnrollDate
		,tpe.EnrollmentEndDate DisenrollDate
	INTO ##DW_FactPatientAssessment
	FROM PatientTask pq
	INNER JOIN DW_Dimdate ad ON ad.FullDateAlternateKey = CONVERT(DATE, pq.DateTaken)
	LEFT JOIN #patque patq ON patq.PatientQuestionaireId = pq.PatientTaskId
	LEFT JOIN #PatEnroll tpe ON tpe.PatientQuestionaireId = pq.PatientTaskId
	LEFT JOIN Provider cp WITH (NOLOCK) ON cp.ProviderID = PQ.CreatedByUserId
	LEFT JOIN Provider mp WITH (NOLOCK) ON mp.ProviderID = PQ.LastModifiedByUserId
	WHERE PQ.TaskStatusId = @i_TaskStatusID
		AND TaskTypeId = @i_AssessmentTasktypeID

	IF OBJECT_ID('TEMPDB..##DW_FactPatientAssessmentAnswers') IS NOT NULL
		DROP TABLE ##DW_FactPatientAssessmentAnswers

	SELECT pqr.PatientAssessmentKey
		,ast.DimAssessmentKey
	INTO ##DW_FactPatientAssessmentAnswers
	FROM ##DW_DimAssessment ast
	INNER JOIN (
		SELECT pq.PatientAssessmentKey
			,pq.AssessmentKey
			,uqa.NQuestionId QuestionId
			,uqa.NAnswerId AnswerId
		FROM ##DW_FactPatientAssessment pq WITH (NOLOCK)
		INNER JOIN #PatAnswer uqa WITH (NOLOCK) ON pq.PatientAssessmentKey = uqa.PatientQuestionaireId
		) pqr ON ast.AssessmentKey = pqr.AssessmentKey
		AND ast.QuestionKey = pqr.QuestionId
		AND ast.AnswerKey = pqr.AnswerId

	
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH