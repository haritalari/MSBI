﻿/*          
------------------------------------------------------------------------------          
Procedure Name: [usp_Batch_EventADTLoad]
Description   : This StoredProcedure used to load ADT data into Transaction database
Created By    : NagaBabu
Created Date  : 09-Feb-2015
------------------------------------------------------------------------------          
Log History   :           
DD-MM-YYYY  BY   DESCRIPTION
19-Feb-2015 Nagababu Removed the functionality of maintaing the ADT event 'A08' in PatientEventNotification table 
25-Feb-2014 Nagababu Modified all the PatientEventNotification insert scripts 
17-Mar-2015 Nagababu ''No Facility'' is mapping for ADT facility as we are not getting sufficient information from EventFacility/SendingFacility
24-Mar-2015 Nagababu Modified the functionality for updating discharge data for the event 'A03'
26-Mar-2015 Nagababu Modified the script to load data into InsuranceGroup
15-April-2015 Santosh modified the SP as per NAVI - 2665
20-Apr-2015 Nagababu Implemented NAV-2470 functionality    
29-Apr-2015 Nagababu Modified the querry to load into PatientEventNotification for the event A03 as per NAVI-2798,NAVI-2802
15-May-2015 Nagababu Fix the issue for readmit flag as per NAVI-2896 
19-May-2015 Nagababu Added the script for all the new patients for assigning the managed population 'All Patients Managed population' as per NAVI-2919 
15-Jun-2015 Nagababu Modified the procedure as per the impact analysis on 'A40'
25-Jun-2015 Nagababu Added the condition for restricting the patientid is NULL for processing LiveADT tasks
26-Jun-2015 Nagababu Added the functionality to update the Hail,Hold comments to the staging tables 
14-Jul-2015 Nagababu Added the logic to insert data into ProviderEventNotification table
27-Jul-2015 Nagababu Modified script for changing the status for 'A08' after event process
11-Aug-2015 Nagababu Modified the script for assigning eventnotification with respective users as per the NAVI-3476
17-Aug-2015 Nagababu Modified the logic for process the event A06 as per the NAVI-3566
03-Sep-2015 Nagababu Modified the functionality for process the A04 events when we have multipe A04s for eah patient as per the scenario NAVI-3649
11-Sep-2015 Nagababu Modified the code as per the issues NAVI-3835,3841,3839
14-Sep-2015 Nagababu Added new parameter @i_CreatedByUserId
09-Oct-2015 Nagababu Added the logic to map new Patient with 'No PCP Assigned'
03-NOV-2015 Nagasiva To restrict duplicate patients Removed existing logic to create patient and added new logic to patient creation  .
09-Nov-2015 Nagababu Modified as per the NAVI-3622
10-Dec-2015 NagaBabu Modified the querry for genrating Decesed notification as per NAVI-4569
05-Jan-2016 Nagababu Modified the logic as per NAVI-4864
06-Jan-2016 Nagababu Added the logic for NAVI-4789
7-Jan-2016 Prashanth Modified the query for inserting primary dx for ADT events NAVI-4561
06-Jan-2016 Nagasiva Added condition to validate providers in Providereventnotification table.
21-Jan-2016 Nagababu Modified code as per the issue NAVI-5002
11-Apr-2016 Nagababu Modified the logic as per NAVI-5690 
24-May-2016 Nagababu Modified the logic as per NAVI-5290
31-May-2016 Sunil Modified the Date Conversion 
02-Jun-2016 Rathnam Developed ADT Event Notifications should be sent to users as per NAVI-5919
09-Aug-2016 Nagababu Modified the logic as per NAVI-6574
11-Aug-2016 Nagababu Modified the logic as per NAVI-6582 
18-Aug-2016 Nagababu Modified the logic as per NAVI-5256
16-Sep-2016 Nagababu Modified the logic as per NAVI-6759
------------------------------------------------------------------------------                
*/
CREATE PROCEDURE [dbo].[usp_Batch_EventADTLoad]
AS
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @l_TranStarted BIT = 0

	IF (@@TRANCOUNT = 0)
	BEGIN
		BEGIN TRANSACTION

		SET @l_TranStarted = 1 -- Indicator for start of transactions
	END

	DECLARE @i_SourceTypeId INT
		,@i_ProviderTypeID INT
		,@i_CreatedByUserId INT

	SELECT @i_SourceTypeId = FileSourceID
	FROM LkUpFileSource WITH (NOLOCK)
	WHERE FileSourceName = 'HL7'

	SELECT @i_CreatedByUserId = ProviderId
	FROM Provider P
	INNER JOIN CodeSetProviderType CSP ON P.ProviderTypeID = CSP.ProviderTypeCodeID
	WHERE CSP.[Description] = 'Administrator'
		AND P.FirstName = 'User'
		AND P.LastName = 'HL7'

	CREATE NONCLUSTERED INDEX [IX_##Event_ADTInsurance_GeneralId] ON ##Event_ADTInsurance (GeneralId ASC)

	CREATE NONCLUSTERED INDEX [IX_##Event_ADTVisit_GeneralId] ON ##Event_ADTVisit (GeneralId ASC)

	CREATE NONCLUSTERED INDEX [IX_##Event_ADTDiagnosis_GeneralId] ON ##Event_ADTDiagnosis (GeneralId ASC)

	CREATE NONCLUSTERED INDEX [IX_##Event_ADTGeneral_MessageTypeEvent] ON [dbo].[##Event_ADTGeneral] ([MessageTypeEvent]) INCLUDE ([GeneralId])

	-- Convert the diagnosis code to relavent ICD9 or ICD10 code ------------------------------------------------------------------------------
	DECLARE @9MinimumNumDigits TINYINT
		,@9MaximumNumDigits TINYINT
		,@9RemoveALLBlanks BIT
		,@9RemoveLeadingZeros BIT
		,@9RemoveTrailingZeros BIT
		,@9PadWithLeadingZeros BIT
		,@9PadWithTrailingZeros BIT
		,@10MinimumNumDigits TINYINT
		,@10MaximumNumDigits TINYINT
		,@10RemoveALLBlanks BIT
		,@10RemoveLeadingZeros BIT
		,@10RemoveTrailingZeros BIT
		,@10PadWithLeadingZeros BIT
		,@10PadWithTrailingZeros BIT
		,@i_TypeCodeId INT
		,@i9_TypeCodeId INT
		,@i10_TypeCodeId INT

	SELECT @i9_TypeCodeId = CodeTypeId
	FROM LkUpCodeType
	WHERE CodeTypeCode = 'ICD-9-CM-Diag'

	SELECT @i10_TypeCodeId = CodeTypeId
	FROM LkUpCodeType
	WHERE CodeTypeCode = 'ICD-10-CM-Diag'

	SELECT @9MinimumNumDigits = [MinimumNumDigits]
		,@9MaximumNumDigits = [MaximumNumDigits]
		,@9RemoveALLBlanks = [RemoveALLBlanks]
		,@9RemoveLeadingZeros = [RemoveLeadingZeros]
		,@9RemoveTrailingZeros = [RemoveTrailingZeros]
		,@9PadWithLeadingZeros = [PadWithLeadingZeros]
		,@9PadWithTrailingZeros = [PadWithTrailingZeros]
	FROM LkUpCodeType
	WHERE [CodeTypeCode] = 'ICD-9-CM-Diag'

	SELECT @10MinimumNumDigits = [MinimumNumDigits]
		,@10MaximumNumDigits = [MaximumNumDigits]
		,@10RemoveALLBlanks = [RemoveALLBlanks]
		,@10RemoveLeadingZeros = [RemoveLeadingZeros]
		,@10RemoveTrailingZeros = [RemoveTrailingZeros]
		,@10PadWithLeadingZeros = [PadWithLeadingZeros]
		,@10PadWithTrailingZeros = [PadWithTrailingZeros]
	FROM LkUpCodeType
	WHERE [CodeTypeCode] = 'ICD-10-CM-Diag';

	WITH CTE_ICD10
	AS (
		SELECT DBO.[ufn_FormatMasterCode_ICD10Diag](rtrim(ltrim(DiagnosisCode)), @10MinimumNumDigits, @10MaximumNumDigits, @10RemoveALLBlanks, @10RemoveLeadingZeros, @10RemoveTrailingZeros, @10PadWithLeadingZeros, @10PadWithTrailingZeros) AS ActualCode
			,DiagnosisCode
			,Ed.GeneralId
		FROM ##Event_ADTDiagnosis ED
		INNER JOIN ##Event_ADTGeneral AG ON ED.GeneralId = AG.GeneralId
		WHERE ED.EventDate >= '2015-10-01'
		)
	UPDATE ##Event_ADTDiagnosis
	SET DiagnosisCode = C10.ActualCode ,
		CodeTypeId = @i10_TypeCodeId
	FROM CTE_ICD10 C10
	INNER JOIN ##Event_ADTDiagnosis ED ON C10.DiagnosisCode = ED.DiagnosisCode
		AND C10.GeneralId = ED.GeneralId
	WHERE C10.ActualCode IS NOT NULL
	

	;WITH CTE_ICD9
	AS (
		SELECT DBO.[ufn_FormatMasterCode_ICD9Diag](rtrim(ltrim(DiagnosisCode)), @9MinimumNumDigits, @9MaximumNumDigits, @9RemoveALLBlanks, @9RemoveLeadingZeros, @9RemoveTrailingZeros, @9PadWithLeadingZeros, @9PadWithTrailingZeros) AS ActualCode
			,DiagnosisCode
			,Ed.GeneralId
		FROM ##Event_ADTDiagnosis ED
		INNER JOIN ##Event_ADTGeneral AG ON ED.GeneralId = AG.GeneralId
		WHERE ED.EventDate < '2015-10-01'
		)
	UPDATE ##Event_ADTDiagnosis
	SET DiagnosisCode = C9.ActualCode ,
		CodeTypeId = @i9_TypeCodeId
	FROM CTE_ICD9 C9
	INNER JOIN ##Event_ADTDiagnosis ED ON C9.DiagnosisCode = ED.DiagnosisCode
		AND C9.GeneralId = ED.GeneralId
	WHERE C9.ActualCode IS NOT NULL

	--Update DiagnosisCodeId	
	UPDATE AD
	SET AD.DiagnosisCodeId = CSD.DiagnosisCodeID
	FROM ##Event_ADTDiagnosis AD
	INNER JOIN CodeSetICDDiagnosis CSD ON CSD.DiagnosisCode = AD.DiagnosisCode
									   AND CSD.CodeTypeID = AD.CodeTypeId

	-------------------------------------------------------------------------------------------------------------------------------------------
	UPDATE P
	SET PatientPrimaryId = DT.PrimaryIdId
		,LastModifiedByUserID = @i_CreatedByUserId
		,LastModifiedDate = GETDATE()
		,SourceTypeId = @i_SourceTypeId
	FROM (
		SELECT DISTINCT TP.IdentifiersId
			,TP.PrimaryIdId
		FROM ##Event_ADTPatient TP
		INNER JOIN ##Event_ADTGeneral TG ON TG.GeneralId = TP.GeneralId
		) DT
	INNER JOIN Patient P WITH (NOLOCK) ON DT.IdentifiersId = P.MedicalRecordNumber
	WHERE NULLIF(DT.PrimaryIdId, '') IS NOT NULL
		AND P.PatientPrimaryId IS NULL
		AND NOT EXISTS (
			SELECT 1
			FROM Patient PA
			WHERE PA.PatientPrimaryId = DT.PrimaryIdId
			)

	UPDATE TP
	SET PatientId = P.PatientId
	FROM ##Event_ADTPatient TP
	INNER JOIN Patient P WITH (NOLOCK) ON TP.PrimaryIdId = P.PatientPrimaryId
	WHERE NULLIF(TP.PrimaryIdId, '') IS NOT NULL

	INSERT INTO Patient (
		FirstName
		,LastName
		,NamePrefix
		,NameSuffix
		,SSN
		,DateOfBirth
		,IsDeceased
		,DateDeceased
		,Gender
		,MedicalRecordNumber
		,PrimaryAddressLine1
		,PrimaryAddressLine2
		,PrimaryAddressCity
		,PrimaryAddressStateCodeID
		,PrimaryAddressCountyID
		,PrimaryAddressPostalCode
		,PrimaryAddressCountryCodeID
		,PrimaryPhoneNumber
		,PrimaryEmailAddress
		,AccountStatusCode
		,CreatedByUserID
		,CreatedDate
		,PatientPrimaryId
		,SourceTypeId
		,SecondaryIdentifier
		)
	SELECT DISTINCT TP1.NameGivenName
		,TP1.NameFamilyName
		,TP1.NamePrefix
		,TP1.NameSuffix
		,TP1.PatientSSN
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(TP1.DateOfBirth)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATE) AS DateOfBirth
		,CASE 
			WHEN TP1.PatientDeathIndicator = 'False'
				THEN 0
			WHEN TP1.PatientDeathIndicator = 'True'
				THEN 1
			ELSE NULL
			END AS PatientDeathIndicator
		,CASE 
			WHEN NULLIF(TP1.PatientDeathDateTime, '') IS NOT NULL
				THEN CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(TP1.PatientDeathDateTime)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATE)
			ELSE NULL
			END
		,TP1.PatientSex
		,ISNULL(TP1.IdentifiersId, '')
		,TP1.AddressesStreetAddress
		,TP1.AddressesOtherDesignation
		,TP1.AddressesCity
		,CSS.StateID AS PrimaryAddressStateCodeID
		,NULL AS PrimaryAddressCountyID
		,TP1.AddressesZipOrPostalCode
		,CSC.CountryID AS PrimaryAddressCountryCodeID
		,TP1.HomePhoneNumbersLocalNumber
		,ISNULL(TP1.PatientEmailAddress, '') AS PatientEmailAddress
		,CASE 
			WHEN NULLIF(TP1.PatientDeathDateTime, '') IS NOT NULL
				THEN 'I'
			ELSE 'A'
			END AS AccountStatusCode
		,@i_CreatedByUserId AS CreatedByUserID
		,GETDATE()
		,TP1.PrimaryIdId
		,@i_SourceTypeId
		,STUFF((
				SELECT ', ' + IdentifiersId + ISNULL(' (' + NULLIF(IdentifiersAssigningFacility, '') + ')', '')
				FROM ##Event_ADTPatient EP
				WHERE EP.GeneralId = TP1.GeneralId
					AND NULLIF(EP.PrimaryIdId, '') IS NULL
				FOR XML PATH('')
				), 1, 2, '')
	FROM (
		SELECT ROW_NUMBER() OVER (
				PARTITION BY TP.PrimaryIdId ORDER BY (
						SELECT NULL
						)
				) AS RNO
			,TP.NameGivenName
			,TP.NameFamilyName
			,TP.NamePrefix
			,TP.NameSuffix
			,TP.PatientSSN
			,TP.DateOfBirth
			,TP.PatientDeathIndicator
			,TP.PatientDeathDateTime
			,TP.PatientSex
			,TP.IdentifiersId
			,TP.AddressesStreetAddress
			,TP.AddressesOtherDesignation
			,TP.AddressesCity
			,TP.AddressesStateOrProvince
			,TP.AddressesZipOrPostalCode
			,TP.AddressesCountry
			,(ISNULL(TP.HomePhoneNumbersAreaCode, '') + TP.HomePhoneNumbersLocalNumber) AS HomePhoneNumbersLocalNumber
			,ISNULL(NULLIF(TP.HomePhoneNumbersCommAddress, ''), TP.BusinessPhoneNumbersCommAddress) PatientEmailAddress
			,TP.PrimaryIdId
			,TP.PatientId
			,TP.GeneralId
		FROM ##Event_ADTPatient TP
		INNER JOIN ##Event_ADTGeneral TG ON TP.GeneralId = TG.GeneralId
		WHERE TP.PatientId IS NULL
		) TP1
	LEFT JOIN CodeSetState CSS WITH (NOLOCK) ON TP1.AddressesStateOrProvince = CSS.StateCode
	LEFT JOIN CodeSetCountry CSC WITH (NOLOCK) ON TP1.AddressesCountry = CSC.CountryName
	WHERE NULLIF(TP1.PrimaryIdId, '') IS NOT NULL
		AND TP1.RNO = 1

	UPDATE TP
	SET PatientId = P.PatientId
	FROM ##Event_ADTPatient TP
	INNER JOIN Patient P WITH (NOLOCK) ON TP.PrimaryIdId = P.PatientPrimaryId
	WHERE NULLIF(TP.PrimaryIdId, '') IS NOT NULL

	CREATE NONCLUSTERED INDEX [<Name of Missing Index, sysname,>] ON [dbo].[##Event_ADTPatient] ([PatientId] ASC) INCLUDE ([GeneralId])

	UPDATE IG
	SET InternalID = TI.InsuranceCompanyIdId
		,LastModifiedByUserId = @i_CreatedByUserId
		,LastModifiedDate = GETDATE()
	FROM InsuranceGroup IG WITH (NOLOCK)
	INNER JOIN (
		SELECT DISTINCT InsuranceCompanyIdId
			,InsuranceCompanyNameOrganizationName1
		FROM ##Event_ADTInsurance
		) TI ON IG.GroupName = TI.InsuranceCompanyNameOrganizationName1
	WHERE IG.InternalID <> TI.InsuranceCompanyIdId

	DECLARE @i_ProgramID INT
		,@i_PopulationDefinitionId INT

	SELECT @i_ProgramID = ProgramID
		,@i_PopulationDefinitionId = PopulationDefinitionId
	FROM Program WITH (NOLOCK)
	WHERE ProgramName = 'All Patients Managed population'

	IF @i_ProgramID IS NOT NULL
	BEGIN
		EXEC dbo.[usp_AllPatientsManagedpopulation_Enrollment] 
		@i_ProgramID = @i_ProgramID
	END

	IF NOT EXISTS (
			SELECT 1
			FROM InsuranceGroup
			WHERE GroupName = 'No insurance info'
			)
	BEGIN
		INSERT INTO InsuranceGroup (
			GroupName
			,CreatedByUserId
			)
		VALUES (
			'No insurance info'
			,1
			)

		INSERT INTO InsuranceGroupPlan (
			InsuranceGroupId
			,PlanName
			,ProductType
			,IsMedicaid
			,CreatedByUserId
			)
		SELECT InsuranceGroupID
			,'No insurance info'
			,'N'
			,0
			,@i_CreatedByUserId
		FROM InsuranceGroup
		WHERE GroupName = 'No insurance info'

		SELECT @i_ProviderTypeID = ProviderTypeCodeID
		FROM CodeSetProviderType WITH (NOLOCK)
		WHERE [Description] = 'Insurance'

		INSERT INTO Provider (
			IsIndividual
			,OrganizationName
			,IsCareProvider
			,IsExternalProvider
			,ProviderTypeID
			,SecondaryAlternativeProviderID
			,AccountStatusCode
			,CreatedByUserID
			,CreatedDate
			,InsuranceGroupID
			)
		SELECT 0
			,IG.GroupName
			,0
			,0
			,@i_ProviderTypeID
			,NULL
			,'A'
			,@i_CreatedByUserId
			,GETDATE()
			,IG.InsuranceGroupID
		FROM InsuranceGroup IG WITH (NOLOCK)
		WHERE GroupName = 'No insurance info'
	END

	INSERT INTO PatientInsurance (
		PatientID
		,InsuranceGroupPlanId
		,PolicyNumber
		,MemberID
		,CreatedByUserId
		)
	SELECT DISTINCT TP.PatientId
		,IGP.InsuranceGroupPlanId
		,TI.InsuranceDetailsPolicyNumber
		,TP.PatientId
		,@i_CreatedByUserId
	FROM ##Event_ADTPatient TP
	INNER JOIN ##Event_ADTInsurance TI ON TP.GeneralId = TI.GeneralId
	INNER JOIN InsuranceGroup IG WITH (NOLOCK) ON IG.GroupName = 'No insurance info'
	INNER JOIN InsuranceGroupPlan IGP WITH (NOLOCK) ON IGP.InsuranceGroupId = IG.InsuranceGroupID
	WHERE NOT EXISTS (
			SELECT 1
			FROM PatientInsurance PIN WITH (NOLOCK)
			WHERE PIN.PatientID = TP.PatientId
			)
		AND TP.PatientId IS NOT NULL

	DECLARE @i_InsuranceBenefitTypeID INT

	SELECT @i_InsuranceBenefitTypeID = InsuranceBenefitTypeID
	FROM LkUpInsuranceBenefitType WITH (NOLOCK)
	WHERE BenefitTypeName = 'Major Medical (MM)'

	INSERT INTO PatientInsuranceBenefit (
		PatientInsuranceID
		,InsuranceBenefitTypeID
		,IsPrimary
		,DateOfEligibility
		,CoverageEndsDate
		,CreatedByUserId
		)
	SELECT DISTINCT PIN.PatientInsuranceID
		,@i_InsuranceBenefitTypeID
		,1
		,'1900-01-01' AS DateOfEligibility
		,'9999-12-31' AS CoverageEndsDate
		,@i_CreatedByUserId
	FROM ##Event_ADTPatient TP
	INNER JOIN ##Event_ADTInsurance TI ON TP.GeneralId = TI.GeneralId
	INNER JOIN InsuranceGroup IG WITH (NOLOCK) ON IG.GroupName = 'No insurance info'
	INNER JOIN InsuranceGroupPlan IGP WITH (NOLOCK) ON IGP.InsuranceGroupId = IG.InsuranceGroupID
		AND IGP.PlanName = 'No insurance info'
	INNER JOIN PatientInsurance PIN WITH (NOLOCK) ON PIN.InsuranceGroupPlanId = IGP.InsuranceGroupPlanId
		AND PIN.PatientID = TP.PatientId
		AND PIN.PolicyNumber = TI.InsuranceDetailsPolicyNumber
	WHERE NOT EXISTS (
			SELECT 1
			FROM PatientInsuranceBenefit PIB WITH (NOLOCK)
			WHERE PIB.PatientInsuranceID = PIN.PatientInsuranceID
			)

	DECLARE @i_ProviderId INT

	SELECT @i_ProviderId = ProviderId
	FROM Provider
	WHERE OrganizationName = 'No Facility'

	DECLARE @i_NoPCPId INT

	SELECT @i_NoPCPId = ProviderID
	FROM Provider
	WHERE FirstName = 'No PCP Assigned'

	INSERT INTO PatientPCP (
		PatientId
		,ProviderID
		,PCPSystem
		,CareBeginDate
		,CareEndDate
		,CreatedByUserId
		,CreatedDate
		,IslatestPCP
		)
	SELECT DISTINCT TP.PatientID
		,@i_NoPCPId
		,''
		,'2011-01-01'
		,'9999-12-31'
		,@i_CreatedByUserId
		,GETDATE()
		,1
	FROM ##Event_ADTPatient TP
	WHERE NOT EXISTS (
			SELECT 1
			FROM PatientPCP PCP
			WHERE PCP.PatientId = TP.PatientID
			)
		AND TP.PatientID IS NOT NULL

	-------------------------------------------------------------------------------------------------------------------------------------------
	UPDATE ##Event_ADTGeneral
	SET [STATUS] = 'D'
	WHERE EXISTS (
			SELECT 1
			FROM ##Event_ADTPatient TP
			WHERE TP.GeneralId = ##Event_ADTGeneral.GeneralId
				AND TP.PatientId IS NULL
			)
		AND ##Event_ADTGeneral.MessageTypeEvent = 'A08'

	UPDATE ##Event_ADTGeneral
	SET [Status] = 'F'
		,[Comments] = 'For this event in xml data visit information does not exist'
	WHERE NOT EXISTS (
			SELECT 1
			FROM ##Event_ADTVisit EV
			WHERE EV.GeneralId = ##Event_ADTGeneral.GeneralId
			)
		AND [Status] IN (
			'P'
			,'H'
			)
		AND MessageTypeEvent IN (
			'A01'
			,'A04'
			,'A06'
			,'A03'
			)

	UPDATE TG
	SET [Status] = 'F'
		,[Comments] = 'Admit date is less than last discharge date'
	FROM ##Event_ADTGeneral TG
	INNER JOIN (
		SELECT DISTINCT COALESCE(NULLIF(TV.VisitAdmitDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitAdmitDate
			,COALESCE(NULLIF(TV.VisitDischargeDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitDischargeDate
			,TP.PatientId
			,TP.GeneralId
		FROM ##Event_ADTPatient TP
		INNER JOIN ##Event_ADTVisit TV ON TP.GeneralId = TV.GeneralId
		INNER JOIN ##Event_ADTGeneral TG ON TP.GeneralId = TG.GeneralId
		WHERE TG.MessageTypeEvent = 'A04'
		) DT ON DT.GeneralId = TG.GeneralId
	WHERE EXISTS (
			SELECT 1
			FROM PatientEvent PE
			INNER JOIN PatientEventNotification PEN ON PE.PatientEventId = PEN.PatientEventId
			INNER JOIN EventType ET ON ET.EventTypeID = PEN.EventTypeId
			WHERE DT.PatientId = PE.PatientId
				AND PE.AssessmentID IS NULL
				AND PE.MergePatientId IS NULL
				AND ISNULL(PE.IsInternal, 0) = 0
			HAVING CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.VisitAdmitdate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) <= MAX(PE.VisitDischargedate)
			)
		AND [Status] IN (
			'P'
			,'H'
			)

	SELECT DENSE_RANK() OVER (
			PARTITION BY P.PatientId ORDER BY G.GeneralMsgDateTime DESC
				,G.GeneralId DESC
			) SNO
		,P.PatientId
		,G.*
	INTO #ADTA04
	FROM ##Event_ADTPatient P
	INNER JOIN ##Event_ADTGeneral G ON G.GeneralId = P.GeneralId
	WHERE G.MessageTypeEvent = 'A04'
		AND P.PatientId IS NOT NULL
		AND G.[Status] IN (
			'P'
			,'H'
			)

	INSERT INTO PatientEvent (
		PatientId
		,IsReadmit
		,FacilityId
		,VisitAdmitdate
		,VisitDischargedate
		,CreatedByUserId
		,HospitalServiceId
		)
	SELECT DISTINCT DT.PatientId
		,NULL IsReadmit
		,ISNULL(Pr.ProviderID, @i_ProviderId)
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(VisitAdmitdate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS VisitAdmitdate
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(VisitAdmitdate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS VisitDischargedate
		,@i_CreatedByUserId
		,LHS.HospitalServiceId
	FROM (
		SELECT TGP.PatientId
			,ISNULL(NULLIF(TGP.GeneralEventFacility, ''), TV.FacilityIdentifier) AS FacilityAlternateIdentifier
			,COALESCE(NULLIF(TV.VisitAdmitDateTime, ''), NULLIF(TGP.GeneralEventDateTime, ''), NULLIF(TGP.GeneralMsgDateTime, '')) AS VisitAdmitdate
			,[dbo].[ufn_GetLatestADTEventNotificationId](TGP.PatientId, 1) AS PatientEventNotificationId
			,TGP.GeneralId
			,TGP.MessageTypeEvent
			,TV.HospitalServiceIdentifier
		FROM ##Event_ADTVisit TV
		INNER JOIN (
			SELECT GeneralId
				,PatientId
				,MessageTypeEvent
				,GeneralEventDateTime
				,GeneralMsgDateTime
				,GeneralEventFacility
			FROM #ADTA04
			WHERE SNO = 1
			) TGP ON TV.GeneralId = TGP.GeneralId
		) DT
	LEFT JOIN Provider Pr ON Pr.TaxID_EIN_SSN = DT.FacilityAlternateIdentifier
	LEFT JOIN LkUpHospitalService LHS ON LHS.HospitalService = DT.HospitalServiceIdentifier
	WHERE NOT EXISTS (
			SELECT 1
			FROM PatientEvent PE WITH (NOLOCK)
			INNER JOIN PatientEventNotification PEN WITH (NOLOCK) ON PE.PatientEventId = PEN.PatientEventId
			INNER JOIN EventType ET WITH (NOLOCK) ON PEN.EventTypeId = ET.EventTypeID
			WHERE PEN.PatientEventNotificationId = DT.PatientEventNotificationId
				AND PE.VisitDischargedate IS NULL
				AND PE.MergePatientId IS NULL
				AND PE.PatientId = DT.PatientId
				AND ET.EventCode NOT IN (
					'A11'
					,'A07'
					)
			)
		AND EXISTS (
			SELECT 1
			FROM PatientEvent PE
			WHERE PE.PatientId = DT.PatientId
				AND PE.AssessmentID IS NULL
				AND PE.MergePatientId IS NULL
				AND ISNULL(PE.IsInternal, 0) = 0
			HAVING CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.VisitAdmitdate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) > ISNULL(MAX(PE.VisitDischargedate), '1900-01-01')
			)

	INSERT INTO PatientEventNotification (
		PatientEventId
		,EventTypeId
		,EventDate
		,CreatedByUserId
		--,VisitType
		,SourceId
		,GeneralMessageControlId
		,DiagnosisCodeId
		,VisitTypeId
		)
	SELECT DISTINCT DT.PatientEventId
		,SE.EventTypeId
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.EventDate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS EventDate
		,@i_CreatedByUserId AS CreatedByUserId
		--,CASE 
		--	WHEN DT.VisitPatientClass = 'Inpatient'
		--		THEN 'I'
		--	WHEN DT.VisitPatientClass = 'Outpatient'
		--		THEN 'O'
		--	WHEN DT.VisitPatientClass = 'Emergency'
		--		THEN 'E'
		--	ELSE NULL
		--	END AS VisitType
		,DT.GeneralId
		,AG.GeneralMessageControlId
		,AD.DiagnosisCodeId
		,LVT.VisitTypeId
	FROM (
		SELECT TA04.MessageTypeEvent
			,COALESCE(NULLIF(TA04.GeneralEventDateTime, ''), NULLIF(TA04.GeneralMsgDateTime, '')) AS EventDate
			,TV.VisitPatientClass
			,TA04.PatientId
			,TA04.GeneralId
			,PE.PatientEventId
		FROM #ADTA04 TA04
		INNER JOIN ##Event_ADTVisit TV ON TV.GeneralId = TA04.GeneralId
		INNER JOIN PatientEvent PE WITH (NOLOCK) ON TA04.PatientId = PE.PatientId
		WHERE TA04.SNO = 1
			AND PE.VisitDischargedate IS NOT NULL
			AND PE.AssessmentID IS NULL
			AND PE.MergePatientId IS NULL
			AND ISNULL(PE.IsInternal, 0) = 0
			AND PE.VisitAdmitdate = PE.VisitDischargedate
		) DT
	INNER JOIN EventType SE WITH (NOLOCK) ON DT.MessageTypeEvent = SE.EventCode
	LEFT OUTER JOIN ##Event_ADTGeneral AG ON AG.GeneralId = DT.GeneralId
	LEFT OUTER JOIN ##Event_ADTDiagnosis AD ON AD.GeneralId = DT.GeneralId
	LEFT OUTER JOIN LkUpVisitType LVT ON LVT.[Description] = DT.VisitPatientClass 
	WHERE NOT EXISTS (
			SELECT 1
			FROM PatientEventNotification PEE WITH (NOLOCK)
			WHERE PEE.PatientEventId = DT.PatientEventId
			)

	SELECT DENSE_RANK() OVER (
			PARTITION BY P.PatientId ORDER BY G.GeneralMsgDateTime DESC
				,G.GeneralId DESC
			) SNO
		,P.PatientId
		,G.*
	INTO #ADTA01
	FROM ##Event_ADTPatient P
	INNER JOIN ##Event_ADTGeneral G ON G.GeneralId = P.GeneralId
	WHERE G.MessageTypeEvent = 'A01'
		AND P.PatientId IS NOT NULL
		AND G.[Status] IN (
			'P'
			,'H'
			)

	INSERT INTO PatientEvent (
		PatientId
		,IsReadmit
		,FacilityId
		,VisitAdmitdate
		,VisitDischargedate
		,CreatedByUserId
		,HospitalServiceId
		)
	SELECT DISTINCT DT.PatientId
		,NULL IsReadmit
		,ISNULL(Pr.ProviderID, @i_ProviderId)
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(VisitAdmitdate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS VisitAdmitdate
		,NULL AS VisitDischargedate
		,@i_CreatedByUserId
		,LHS.HospitalServiceId
	FROM (
		SELECT DTG.PatientId
			,ISNULL(NULLIF(DTG.GeneralEventFacility, ''), TV.FacilityIdentifier) AS FacilityAlternateIdentifier
			,COALESCE(NULLIF(TV.VisitAdmitDateTime, ''), NULLIF(DTG.GeneralEventDateTime, ''), NULLIF(DTG.GeneralMsgDateTime, '')) AS VisitAdmitdate
			,[dbo].[ufn_GetLatestADTEventNotificationId](DTG.PatientId, 1) AS PatientEventNotificationId
			,DTG.GeneralId
			,DTG.MessageTypeEvent
			,TV.HospitalServiceIdentifier
		FROM ##Event_ADTVisit TV
		INNER JOIN (
			SELECT PatientId
				,GeneralEventFacility
				,GeneralEventDateTime
				,GeneralMsgDateTime
				,GeneralId
				,MessageTypeEvent
			FROM #ADTA01
			WHERE SNO = 1
			) DTG ON DTG.GeneralId = TV.GeneralId
		) DT
	LEFT JOIN Provider Pr ON Pr.TaxID_EIN_SSN = DT.FacilityAlternateIdentifier
	LEFT JOIN LkUpHospitalService LHS ON LHS.HospitalService = DT.HospitalServiceIdentifier
	WHERE DT.MessageTypeEvent = 'A01'
		AND NOT EXISTS (
			SELECT 1
			FROM PatientEvent PE WITH (NOLOCK)
			INNER JOIN PatientEventNotification PEN WITH (NOLOCK) ON PE.PatientEventId = PEN.PatientEventId
			INNER JOIN EventType ET WITH (NOLOCK) ON PEN.EventTypeId = ET.EventTypeID
			WHERE PEN.PatientEventNotificationId = DT.PatientEventNotificationId
				AND PE.VisitDischargedate IS NULL
				AND PE.MergePatientId IS NULL
				AND PE.PatientId = DT.PatientId
				AND ET.EventCode NOT IN (
					'A11'
					,'A07'
					)
			)
		AND EXISTS (
			SELECT 1
			FROM PatientEvent PE
			INNER JOIN PatientEventNotification PEN WITH (NOLOCK) ON PE.PatientEventId = PEN.PatientEventId
			INNER JOIN EventType ET WITH (NOLOCK) ON PEN.EventTypeId = ET.EventTypeID
			WHERE PE.PatientId = DT.PatientId
				AND PE.AssessmentID IS NULL
				AND PE.MergePatientId IS NULL
				AND ISNULL(PE.IsInternal, 0) = 0
			HAVING CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.VisitAdmitdate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) > ISNULL(MAX(PE.VisitDischargedate), '1900-01-01')
			)

	INSERT INTO PatientEventNotification (
		PatientEventId
		,EventTypeId
		,EventDate
		,CreatedByUserId
		--,VisitType
		,SourceId
		,GeneralMessageControlId
		,DiagnosisCodeId
		,VisitTypeId
		)
	SELECT DISTINCT DT.PatientEventId
		,SE.EventTypeId
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.EventDate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS EventDate
		,@i_CreatedByUserId AS CreatedByUserId
		--,NULL AS VisitType
		,DT.GeneralId
		,AG.GeneralMessageControlId
		,AD.DiagnosisCodeId
		,LVT.VisitTypeId
	FROM (
		SELECT TA01.MessageTypeEvent
			,COALESCE(NULLIF(TA01.GeneralEventDateTime, ''), NULLIF(TA01.GeneralMsgDateTime, '')) AS EventDate
			,TV.VisitPatientClass
			,TA01.PatientId
			,TA01.GeneralId
			,[dbo].[ufn_GetLatestADTEventNotificationId](TA01.PatientId, 0) AS PatientEventId
		FROM #ADTA01 TA01
		INNER JOIN ##Event_ADTVisit TV ON TV.GeneralId = TA01.GeneralId
		WHERE TA01.MessageTypeEvent = 'A01'
			AND TA01.SNO = 1
		) DT
	INNER JOIN EventType SE WITH (NOLOCK) ON DT.MessageTypeEvent = SE.EventCode
	LEFT OUTER JOIN ##Event_ADTGeneral AG ON AG.GeneralId = DT.GeneralId
	LEFT OUTER JOIN ##Event_ADTDiagnosis AD ON AD.GeneralId = DT.GeneralId
	LEFT OUTER JOIN LkUpVisitType LVT ON LVT.[Description] = DT.VisitPatientClass 
	WHERE NOT EXISTS (
			SELECT 1
			FROM PatientEventNotification PEE WITH (NOLOCK)
			WHERE PEE.PatientEventId = DT.PatientEventId
			)

	UPDATE TG
	SET [Status] = 'F'
		,[Comments] = 'Discharge date is less than admit date'
	FROM ##Event_ADTGeneral TG
	INNER JOIN (
		SELECT DISTINCT COALESCE(NULLIF(TV.VisitAdmitDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitAdmitDate
			,COALESCE(NULLIF(TV.VisitDischargeDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitDischargeDate
			,TP.PatientId
			,TP.GeneralId
		FROM ##Event_ADTPatient TP
		INNER JOIN ##Event_ADTVisit TV ON TP.GeneralId = TV.GeneralId
		INNER JOIN ##Event_ADTGeneral TG ON TP.GeneralId = TG.GeneralId
		WHERE TG.MessageTypeEvent = 'A03'
		) DT ON DT.GeneralId = TG.GeneralId
	WHERE EXISTS (
			SELECT 1
			FROM PatientEvent PE
			INNER JOIN PatientEventNotification PEN ON PE.PatientEventId = PEN.PatientEventId
			INNER JOIN EventType ET ON ET.EventTypeID = PEN.EventTypeId
			WHERE DT.PatientId = PE.PatientId
				AND PE.AssessmentID IS NULL
				AND PE.MergePatientId IS NULL
				AND ISNULL(PE.IsInternal, 0) = 0
			HAVING CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.VisitDischargeDate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) <= MAX(PE.VisitAdmitdate)
			)
		AND [Status] IN (
			'P'
			,'H'
			)

	-----------------------------------------------------------------------------------------------------------------------------------------------------------------
	INSERT INTO PatientEventNotification (
		PatientEventId
		,EventTypeId
		,EventDate
		,CreatedByUserId
		--,VisitType
		,SourceId
		,GeneralMessageControlId
		,DiagnosisCodeId
		)
	SELECT DISTINCT DT.MAXPatientEventId
		,DT.EventTypeId
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.EventDate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS EventDate
		,@i_CreatedByUserId AS CreatedByUserId
		--,NULL AS VisitType
		,DT.GeneralId
		,DT.GeneralMessageControlId
		,AD.DiagnosisCodeId
	FROM (
		SELECT COALESCE(NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS EventDate
			,[dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 0) AS MAXPatientEventId
			,[dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 1) AS PatientEventNotificationId
			,TP.PatientId
			,SE.EventTypeID
			,TG.GeneralId
			,TG.GeneralMessageControlId
		FROM ##Event_ADTGeneral TG
		INNER JOIN ##Event_ADTPatient TP ON TG.GeneralId = TP.GeneralId
		INNER JOIN EventType SE WITH (NOLOCK) ON TG.MessageTypeEvent = SE.EventCode
		WHERE TG.MessageTypeEvent IN (
				'A07'
				,'A11'
				)
			AND TP.PatientId IS NOT NULL
		) DT
	LEFT OUTER JOIN ##Event_ADTDiagnosis AD ON AD.GeneralId = DT.GeneralId
	WHERE DT.PatientEventNotificationId IS NOT NULL
		AND EXISTS (
			SELECT 1
			FROM PatientEventNotification PEN1 WITH (NOLOCK)
			INNER JOIN EventType ET WITH (NOLOCK) ON ET.EventTypeID = PEN1.EventTypeId
			WHERE DT.PatientEventNotificationId = PEN1.PatientEventNotificationId
				AND ET.EventCode IN (
					'A01'
					,'A06'
					)
			)

	---------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	CREATE TABLE #PatientVistitDischargeDate (
		VisitDischargeDateTime VARCHAR(20)
		,MaxPatientEventId INT
		,HospitalServiceIdentifier VARCHAR(20)
		)

	INSERT INTO #PatientVistitDischargeDate
	SELECT VisitDischargeDateTime
		,MaxPatientEventId
		,HospitalServiceIdentifier
	FROM (
		SELECT COALESCE(NULLIF(TV.VisitDischargeDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitDischargeDateTime
			,[dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 0) AS MaxPatientEventId
			,[dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 1) AS PatientEventNotificationId
			,TP.PatientId
			,TV.HospitalServiceIdentifier
		FROM ##Event_ADTGeneral TG
		INNER JOIN ##Event_ADTPatient TP ON TG.GeneralId = TP.GeneralId
		INNER JOIN ##Event_ADTVisit TV ON TV.GeneralId = TP.GeneralId
		WHERE TG.MessageTypeEvent = 'A03'
			AND TP.PatientId IS NOT NULL
			AND TG.[Status] IN (
				'P'
				,'H'
				)
		) DT
	WHERE DT.PatientEventNotificationId IS NOT NULL
		AND EXISTS (
			SELECT 1
			FROM PatientEventNotification PEN1 WITH (NOLOCK)
			INNER JOIN PatientEvent PE WITH (NOLOCK) ON PE.PatientEventId = PEN1.PatientEventId
			INNER JOIN EventType ET ON ET.EventTypeID = PEN1.EventTypeId
			WHERE PEN1.PatientEventNotificationId = DT.PatientEventNotificationId
				AND ET.EventCode IN (
					'A01'
					,'A06'
					,'A13'
					)
				AND PE.VisitAdmitdate < CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.VisitDischargeDateTime)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME)
			)

	CREATE INDEX IX_#PatientVistitDischargeDate ON #PatientVistitDischargeDate (MaxPatientEventId)

	UPDATE PE
	SET VisitDischargedate = CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(VisitDischargeDateTime)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME)
		,LastModifiedUserId = @i_CreatedByUserId
		,LastModifiedDate = GETDATE()
		,HospitalServiceId = ISNULL(PE.HospitalServiceId,LHS.HospitalServiceId)
	FROM PatientEvent PE WITH (NOLOCK)
	INNER JOIN #PatientVistitDischargeDate ST ON PE.PatientEventId = ST.MaxPatientEventId
	LEFT JOIN LkUpHospitalService LHS ON LHS.HospitalService = ST.HospitalServiceIdentifier

	INSERT INTO PatientEventNotification (
		PatientEventId
		,EventTypeId
		,EventDate
		,CreatedByUserId
		--,VisitType
		,SourceId
		,GeneralMessageControlId
		,DiagnosisCodeId
		)
	SELECT DISTINCT DT.MAXPatientEventId
		,DT.EventTypeId
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.EventDate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS EventDate
		,@i_CreatedByUserId AS CreatedByUserId
		--,NULL AS VisitType
		,DT.GeneralId
		,DT.GeneralMessageControlId
		,AD.DiagnosisCodeId
	FROM (
		SELECT COALESCE(NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS EventDate
			,[dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 0) AS MaxPatientEventId
			,[dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 1) AS PatientEventNotificationId
			,TP.PatientId
			,ET.EventTypeID
			,TP.GeneralId
			,TG.GeneralMessageControlId
		FROM ##Event_ADTGeneral TG
		INNER JOIN ##Event_ADTPatient TP ON TG.GeneralId = TP.GeneralId
		INNER JOIN EventType ET WITH (NOLOCK) ON TG.MessageTypeEvent = ET.EventCode
		WHERE TG.MessageTypeEvent = 'A03'
			AND TG.[STATUS] IN (
				'H'
				,'P'
				)
			AND TP.PatientId IS NOT NULL
		) DT
	LEFT OUTER JOIN ##Event_ADTDiagnosis AD ON AD.GeneralId = DT.GeneralId
	WHERE DT.PatientEventNotificationId IS NOT NULL
		AND EXISTS (
			SELECT 1
			FROM PatientEventNotification PEN1 WITH (NOLOCK)
			INNER JOIN PatientEvent PE WITH (NOLOCK) ON PE.PatientEventId = PEN1.PatientEventId
			INNER JOIN EventType ET ON ET.EventTypeID = PEN1.EventTypeId
			WHERE PEN1.PatientEventNotificationId = DT.PatientEventNotificationId
				AND PE.VisitDischargedate IS NOT NULL
				AND ET.EventCode IN (
					'A01'
					,'A06'
					,'A13'
					)
			)

	--------------------------------------------------------------------------------------------------------------------------------------------------------
	CREATE TABLE #MaxPatientEventNotification (
		MAXPatientEventId INT
		,PatientEventNotificationId INT
		,PatientId INT
		)

	INSERT INTO #MaxPatientEventNotification
	SELECT MAXPatientEventId
		,PatientEventNotificationId
		,PatientId
	FROM (
		SELECT [dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 0) AS MaxPatientEventId
			,[dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 1) AS PatientEventNotificationId
			,TP.PatientId
		FROM ##Event_ADTGeneral TG
		INNER JOIN ##Event_ADTPatient TP ON TG.GeneralId = TP.GeneralId
		INNER JOIN ##Event_ADTVisit TV ON TV.GeneralId = TP.GeneralId
		WHERE TG.MessageTypeEvent = 'A13'
			AND TP.PatientId IS NOT NULL
			AND TG.[STATUS] IN (
				'H'
				,'P'
				)
		) DT
	WHERE DT.PatientEventNotificationId IS NOT NULL
		AND EXISTS (
			SELECT 1
			FROM PatientEventNotification PEN WITH (NOLOCK)
			INNER JOIN EventType ET WITH (NOLOCK) ON PEN.EventTypeId = ET.EventTypeID
			WHERE DT.PatientEventNotificationId = PEN.PatientEventNotificationId
				AND ET.EventCode = 'A03'
			)

	CREATE INDEX IX_#MaxPatientEventNotification ON #MaxPatientEventNotification (MAXPatientEventId)

	UPDATE PE
	SET VisitDischargedate = NULL
		,LastModifiedUserId = @i_CreatedByUserId
		,LastModifiedDate = GETDATE()
	FROM PatientEvent PE WITH (NOLOCK)
	INNER JOIN #MaxPatientEventNotification ST ON PE.PatientEventId = ST.MAXPatientEventId

	INSERT INTO PatientEventNotification (
		PatientEventId
		,EventTypeId
		,EventDate
		,CreatedByUserId
		--,VisitType
		,SourceId
		,GeneralMessageControlId
		,DiagnosisCodeId
		)
	SELECT DISTINCT DT.MAXPatientEventId
		,DT.EventTypeId
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.EventDate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS EventDate
		,@i_CreatedByUserId AS CreatedByUserId
		--,NULL AS VisitType
		,DT.GeneralId
		,DT.GeneralMessageControlId
		,AD.DiagnosisCodeId
	FROM (
		SELECT COALESCE(NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS EventDate
			,[dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 0) AS MaxPatientEventId
			,[dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 1) AS PatientEventNotificationId
			,TP.PatientId
			,ET.EventTypeID
			,TP.GeneralId
			,TG.GeneralMessageControlId
		FROM ##Event_ADTGeneral TG
		INNER JOIN ##Event_ADTPatient TP ON TG.GeneralId = TP.GeneralId
		INNER JOIN EventType ET WITH (NOLOCK) ON TG.MessageTypeEvent = ET.EventCode
		WHERE TG.MessageTypeEvent = 'A13'
			AND TP.PatientId IS NOT NULL
			AND TG.[STATUS] IN (
				'H'
				,'P'
				)
		) DT
	LEFT OUTER JOIN ##Event_ADTDiagnosis AD ON AD.GeneralId = DT.GeneralId
	WHERE DT.PatientEventNotificationId IS NOT NULL
		AND EXISTS (
			SELECT 1
			FROM PatientEventNotification PEN1 WITH (NOLOCK)
			INNER JOIN PatientEvent PE WITH (NOLOCK) ON PE.PatientEventId = PEN1.PatientEventId
			INNER JOIN EventType ET WITH (NOLOCK) ON ET.EventTypeID = PEN1.EventTypeId
			WHERE DT.PatientEventNotificationId = PEN1.PatientEventNotificationId
				AND ET.EventCode = 'A03'
				AND PE.VisitDischargedate IS NULL
			)

	-------------------------------------------------------------------------------------------------------------------------------------------------------------------
	INSERT INTO PatientEvent (
		PatientId
		,IsReadmit
		,FacilityId
		,VisitAdmitdate
		,VisitDischargedate
		,CreatedByUserId
		,HospitalServiceId
		)
	SELECT DISTINCT DT.PatientId
		,NULL IsReadmit
		,ISNULL(Pr.ProviderID, @i_ProviderId)
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(VisitAdmitdate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS VisitAdmitdate
		,NULL AS VisitDischargedate
		,@i_CreatedByUserId
		,LHS.HospitalServiceId
	FROM (
		SELECT TP.PatientId
			,ISNULL(NULLIF(TG.GeneralEventFacility, ''), TV.FacilityIdentifier) AS FacilityAlternateIdentifier
			,COALESCE(NULLIF(TV.VisitAdmitDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitAdmitdate
			,TG.GeneralId
			,TG.MessageTypeEvent
			,[dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 1) AS PatientEventNotificationId
			,TV.HospitalServiceIdentifier
		FROM ##Event_ADTVisit TV
		INNER JOIN ##Event_ADTGeneral TG ON TV.GeneralId = TG.GeneralId
		INNER JOIN ##Event_ADTPatient TP ON TV.GeneralId = TP.GeneralId
		WHERE TP.PatientId IS NOT NULL
			AND TG.MessageTypeEvent = 'A06'
			AND TG.[STATUS] IN (
				'H'
				,'P'
				)
		) DT
	LEFT JOIN Provider Pr ON pr.TaxID_EIN_SSN = DT.FacilityAlternateIdentifier
	LEFT JOIN LkUpHospitalService LHS ON LHS.HospitalService = DT.HospitalServiceIdentifier
	WHERE DT.PatientEventNotificationId IS NOT NULL
		AND EXISTS (
			SELECT 1
			FROM PatientEvent PE
			INNER JOIN PatientEventNotification PEN1 WITH (NOLOCK) ON PE.PatientEventId = PEN1.PatientEventId
			INNER JOIN EventType ET WITH (NOLOCK) ON PEN1.EventTypeId = ET.EventTypeID
			WHERE PEN1.PatientEventNotificationId = DT.PatientEventNotificationId
				AND ET.EventCode = 'A04'
			HAVING CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.VisitAdmitdate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) >= MAX(PE.VisitDischargedate)
			)

	INSERT INTO PatientEventNotification (
		PatientEventId
		,EventTypeId
		,EventDate
		,CreatedByUserId
		--,VisitType
		,SourceId
		,GeneralMessageControlId
		,DiagnosisCodeId
		,VisitTypeId
		)
	SELECT DISTINCT DT.PatientEventId
		,SE.EventTypeId
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.EventDate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS EventDate
		,@i_CreatedByUserId AS CreatedByUserId
		--,NULL AS VisitType
		,DT.GeneralId
		,DT.GeneralMessageControlId
		,AD.DiagnosisCodeId
		,LVT.VisitTypeId
	FROM (
		SELECT TG.MessageTypeEvent
			,COALESCE(NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS EventDate
			,TP.PatientId
			,TG.GeneralId
			,TG.GeneralMessageControlId
			,TV.VisitPatientClass
			,[dbo].[ufn_GetLatestADTEventNotificationId](TP.PatientId, 0) AS PatientEventId
		FROM ##Event_ADTGeneral TG
		INNER JOIN ##Event_ADTVisit TV ON TV.GeneralId = TG.GeneralId
		INNER JOIN ##Event_ADTPatient TP ON TV.GeneralId = TP.GeneralId
		WHERE TG.MessageTypeEvent = 'A06'
			AND TP.PatientId IS NOT NULL
			AND TG.[STATUS] IN (
				'H'
				,'P'
				)
		) DT
	INNER JOIN EventType SE WITH (NOLOCK) ON DT.MessageTypeEvent = SE.EventCode
	LEFT OUTER JOIN ##Event_ADTDiagnosis AD ON AD.GeneralId = DT.GeneralId
	LEFT OUTER JOIN LkUpVisitType LVT ON LVT.[Description] = DT.VisitPatientClass
	WHERE DT.PatientEventId IS NOT NULL
		AND NOT EXISTS (
			SELECT 1
			FROM PatientEventNotification PEE WITH (NOLOCK)
			WHERE PEE.PatientEventId = DT.PatientEventId
			)

	----------------------------------------------------------------------------------------------------------------------------------	
	UPDATE ADT1
	SET IsReadmit = CASE 
			WHEN ADT1.VisitAdmitdate - DT.VisitDischargedate <= 30
				THEN 1
			ELSE 0
			END
	FROM PatientEvent ADT1 WITH (NOLOCK)
	INNER JOIN PatientEventNotification PEN WITH (NOLOCK) ON ADT1.PatientEventId = PEN.PatientEventId
	INNER JOIN ##Event_ADTGeneral TG ON PEN.SourceId = TG.GeneralId
	INNER JOIN (
		SELECT MAX(ISNULL(VisitDischargedate, '1900-01-01')) AS VisitDischargedate
			,TP.GeneralId AS SourceId
			,PE.PatientId
		FROM PatientEvent PE WITH (NOLOCK)
		INNER JOIN PatientEventNotification PEN WITH (NOLOCK) ON PE.PatientEventId = PEN.PatientEventId
		INNER JOIN EventType ET WITH (NOLOCK) ON ET.EventTypeID = PEN.EventTypeID
		INNER JOIN ##Event_ADTPatient TP ON PE.PatientId = TP.PatientId
		INNER JOIN ##Event_ADTGeneral TG ON TP.GeneralId = TG.GeneralId
		WHERE ET.EventCode <> 'A04'
			AND PE.AssessmentID IS NULL
			AND PE.MergePatientId IS NULL
			AND TG.MessageTypeEvent IN (
				'A01'
				,'A06'
				)
		GROUP BY PE.PatientId
			,TP.GeneralId
		) DT ON ADT1.PatientId = DT.PatientId
	WHERE TG.MessageTypeEvent IN (
			'A01'
			,'A06'
			)
		AND PEN.SourceId = DT.SourceId

	UPDATE TG
	SET [Status] = 'F'
		,[Comments] = 'Invalid operation, Uniqueidentifier mismatch'
	FROM ##Event_ADTPatient TP
	INNER JOIN ##Event_ADTGeneral TG ON TG.GeneralId = TP.GeneralId
	INNER JOIN Patient P ON P.PatientID = TP.PatientId
	WHERE TG.MessageTypeEvent = 'A08'
		AND TP.PatientId IS NOT NULL
		AND P.MedicalRecordNumber <> TP.IdentifiersId

	UPDATE P
	SET FirstName = DT.NameGivenName
		,LastName = DT.NameFamilyName
		,NamePrefix = DT.NamePrefix
		,NameSuffix = DT.NameSuffix
		,SSN = DT.PatientSSN
		,DateOfBirth = CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.DateOfBirth)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATE)
		,DateDeceased = CASE 
			WHEN NULLIF(DT.PatientDeathDateTime, '') IS NOT NULL
				THEN CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.PatientDeathDateTime)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATE)
			ELSE NULL
			END
		,Gender = DT.PatientSex
		,MedicalRecordNumber = DT.IdentifiersId
		,PrimaryAddressLine1 = DT.AddressesStreetAddress
		,PrimaryAddressLine2 = DT.AddressesOtherDesignation
		,PrimaryAddressCity = DT.AddressesCity
		,PrimaryAddressStateCodeID = CSS.StateID
		,PrimaryAddressCountyID = NULL
		,PrimaryAddressPostalCode = DT.AddressesZipOrPostalCode
		,PrimaryAddressCountryCodeID = CSC.CountryID
		,PrimaryPhoneNumber = ISNULL(DT.HomePhoneNumbersAreaCode, '') + DT.HomePhoneNumbersLocalNumber
		,PrimaryEmailAddress = ISNULL(NULLIF(DT.HomePhoneNumbersCommAddress, ''), DT.BusinessPhoneNumbersCommAddress)
		,AccountStatusCode = CASE 
			WHEN NULLIF(DT.PatientDeathDateTime, '') IS NOT NULL
				THEN 'I'
			ELSE 'A'
			END
		,LastModifiedByUserID = @i_CreatedByUserId
		,LastModifiedDate = GETDATE()
		,SourceTypeId = @i_SourceTypeId
		,SecondaryIdentifier = STUFF((
				SELECT ', ' + IdentifiersId + ISNULL(' (' + NULLIF(IdentifiersAssigningFacility, '') + ')', '')
				FROM ##Event_ADTPatient EP
				WHERE EP.GeneralId = DT.GeneralId
					AND NULLIF(EP.PrimaryIdId, '') IS NULL
				FOR XML PATH('')
				), 1, 2, '')
	FROM Patient P WITH (NOLOCK)
	INNER JOIN (
		SELECT DENSE_RANK() OVER (
				PARTITION BY TP.PatientId ORDER BY TG.GeneralMsgDateTime DESC
				) SNO
			,TP.*
		FROM ##Event_ADTPatient TP
		INNER JOIN ##Event_ADTGeneral TG ON TG.GeneralId = TP.GeneralId
		WHERE TG.MessageTypeEvent = 'A08'
			AND TP.PatientId IS NOT NULL
			AND TG.GeneralSendingFacility <> 'Claim'
			AND TG.[Status] <> 'F'
		) DT ON DT.PatientId = P.PatientId
	LEFT JOIN CodeSetState CSS WITH (NOLOCK) ON DT.AddressesStateOrProvince = CSS.StateCode
	LEFT JOIN CodeSetCountry CSC WITH (NOLOCK) ON DT.AddressesCountry = CSC.CountryName
	WHERE DT.SNO = 1

	UPDATE ##Event_ADTGeneral
	SET [Status] = 'C'
		,[Comments] = NULL
	FROM PatientEventNotification PEN
	WHERE PEN.SourceId = ##Event_ADTGeneral.GeneralId

	UPDATE #ADTA04
	SET [Status] = 'C'
		,[Comments] = NULL
	FROM PatientEventNotification PEN
	WHERE PEN.SourceId = #ADTA04.GeneralId

	UPDATE EG
	SET [Status] = 'D'
		,[Comments] = NULL
	FROM ##Event_ADTGeneral EG
	INNER JOIN #ADTA04 TA041 ON EG.GeneralId = TA041.GeneralId
	INNER JOIN #ADTA04 TA042 ON TA041.PatientId = TA042.PatientId
	WHERE TA042.[Status] = 'C'
		AND EG.[Status] IN (
			'P'
			,'H'
			)
		AND TA041.SNO > 1

	UPDATE #ADTA01
	SET [Status] = 'C'
		,[Comments] = NULL
	FROM PatientEventNotification PEN
	WHERE PEN.SourceId = #ADTA01.GeneralId

	UPDATE EG
	SET [Status] = 'D'
		,[Comments] = NULL
	FROM ##Event_ADTGeneral EG
	INNER JOIN #ADTA01 TA011 ON EG.GeneralId = TA011.GeneralId
	INNER JOIN #ADTA01 TA012 ON TA011.PatientId = TA012.PatientId
	WHERE TA012.[Status] = 'C'
		AND EG.[Status] IN (
			'P'
			,'H'
			)
		AND TA011.SNO > 1

	UPDATE TG
	SET [Status] = 'F'
		,[Comments] = 'Admit date is less than last discharge date'
	FROM ##Event_ADTGeneral TG
	INNER JOIN (
		SELECT DISTINCT COALESCE(NULLIF(TV.VisitAdmitDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitAdmitDate
			,COALESCE(NULLIF(TV.VisitDischargeDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitDischargeDate
			,TP.PatientId
			,TP.GeneralId
		FROM ##Event_ADTPatient TP
		INNER JOIN ##Event_ADTVisit TV ON TP.GeneralId = TV.GeneralId
		INNER JOIN ##Event_ADTGeneral TG ON TP.GeneralId = TG.GeneralId
		WHERE TG.MessageTypeEvent = 'A01'
		) DT ON DT.GeneralId = TG.GeneralId
	WHERE EXISTS (
			SELECT 1
			FROM PatientEvent PE
			INNER JOIN PatientEventNotification PEN ON PE.PatientEventId = PEN.PatientEventId
			INNER JOIN EventType ET ON ET.EventTypeID = PEN.EventTypeId
			WHERE DT.PatientId = PE.PatientId
				AND PE.AssessmentID IS NULL
				AND PE.MergePatientId IS NULL
				AND ISNULL(PE.IsInternal, 0) = 0
			HAVING CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.VisitAdmitdate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) <= MAX(PE.VisitDischargedate)
			)
		AND [Status] IN (
			'P'
			,'H'
			)

	UPDATE TG
	SET [Status] = 'F'
		,[Comments] = 'Admit date is less than last discharge date'
	FROM ##Event_ADTGeneral TG
	INNER JOIN (
		SELECT DISTINCT COALESCE(NULLIF(TV.VisitAdmitDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitAdmitDate
			,COALESCE(NULLIF(TV.VisitDischargeDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitDischargeDate
			,TP.PatientId
			,TP.GeneralId
		FROM ##Event_ADTPatient TP
		INNER JOIN ##Event_ADTVisit TV ON TP.GeneralId = TV.GeneralId
		INNER JOIN ##Event_ADTGeneral TG ON TP.GeneralId = TG.GeneralId
		WHERE TG.MessageTypeEvent = 'A06'
		) DT ON DT.GeneralId = TG.GeneralId
	WHERE EXISTS (
			SELECT 1
			FROM PatientEvent PE
			INNER JOIN PatientEventNotification PEN ON PE.PatientEventId = PEN.PatientEventId
			INNER JOIN EventType ET ON ET.EventTypeID = PEN.EventTypeId
			WHERE DT.PatientId = PE.PatientId
				AND PE.AssessmentID IS NULL
				AND PE.MergePatientId IS NULL
				AND ISNULL(PE.IsInternal, 0) = 0
			HAVING CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.VisitAdmitdate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) < MAX(PE.VisitDischargedate)
			)
		AND [Status] IN (
			'P'
			,'H'
			)

	UPDATE TG
	SET [Status] = 'F'
		,[Comments] = 'Discharge date is less than admit date'
	FROM ##Event_ADTGeneral TG
	INNER JOIN (
		SELECT DISTINCT COALESCE(NULLIF(TV.VisitAdmitDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitAdmitDate
			,COALESCE(NULLIF(TV.VisitDischargeDateTime, ''), NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS VisitDischargeDate
			,TP.PatientId
			,TP.GeneralId
		FROM ##Event_ADTPatient TP
		INNER JOIN ##Event_ADTVisit TV ON TP.GeneralId = TV.GeneralId
		INNER JOIN ##Event_ADTGeneral TG ON TP.GeneralId = TG.GeneralId
		WHERE TG.MessageTypeEvent = 'A03'
		) DT ON DT.GeneralId = TG.GeneralId
	WHERE EXISTS (
			SELECT 1
			FROM PatientEvent PE
			INNER JOIN PatientEventNotification PEN ON PE.PatientEventId = PEN.PatientEventId
			INNER JOIN EventType ET ON ET.EventTypeID = PEN.EventTypeId
			WHERE DT.PatientId = PE.PatientId
				AND PE.AssessmentID IS NULL
				AND PE.MergePatientId IS NULL
				AND ISNULL(PE.IsInternal, 0) = 0
			HAVING CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.VisitDischargeDate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) <= MAX(PE.VisitAdmitdate)
			)
		AND [Status] IN (
			'P'
			,'H'
			)

	UPDATE TG
	SET [Status] = CASE 
			WHEN SNO = 1
				THEN 'C'
			ELSE 'D'
			END
		,[Comments] = NULL
	FROM ##Event_ADTGeneral TG
	INNER JOIN (
		SELECT DENSE_RANK() OVER (
				PARTITION BY TP.PatientId ORDER BY TG.GeneralMsgDateTime DESC
				) SNO
			,TP.GeneralId
		FROM ##Event_ADTPatient TP
		INNER JOIN ##Event_ADTGeneral TG ON TG.GeneralId = TP.GeneralId
		WHERE TG.MessageTypeEvent = 'A08'
			AND TG.GeneralSendingFacility <> 'Claim'
			AND TP.PatientId IS NOT NULL
			AND TG.[Status] = 'P'
		) DT ON TG.GeneralId = DT.GeneralId

	UPDATE TG
	SET [Status] = 'C'
		,[Comments] = NULL
	FROM ##Event_ADTGeneral TG
	INNER JOIN ##Event_ADTPatient TP ON TG.GeneralId = TP.GeneralId
	WHERE TG.MessageTypeEvent = 'A08'
		AND TG.GeneralSendingFacility = 'Claim'
		AND TG.[Status] = 'P'

	UPDATE ##Event_ADTGeneral
	SET [Status] = 'H'
		,[Comments] = 'This event is waiting for its dependent event'
	WHERE [Status] = 'P'

	DECLARE @tbEventPatient TTYPEKEYID

	INSERT INTO @tbEventPatient
	SELECT DISTINCT PatientId
	FROM ##Event_ADTPatient TP
	INNER JOIN ##Event_ADTGeneral TG ON TP.GeneralId = TG.GeneralId
	WHERE TG.[Status] = 'C'
		AND TP.PatientId IS NOT NULL

	IF EXISTS (
			SELECT 1
			FROM @tbEventPatient
			)
	BEGIN
		DECLARE @tblADT TABLE (
			ProgramID INT
			,PDID INT
			,ADTtype VARCHAR(1)
			)

		INSERT INTO @tblADT
		SELECT DISTINCT p.ProgramId
			,pd.PopulationDefinitionID
			,pd.ADTtype
		FROM Program p WITH (NOLOCK)
		INNER JOIN PopulationDefinition pd WITH (NOLOCK) ON p.PopulationDefinitionID = pd.PopulationDefinitionID
		WHERE p.StatusCode = 'A'
			AND pd.StatusCode = 'A'
			AND (
				pd.ADTtype IS NOT NULL
				OR IsADT = 1
				)
			AND p.ProductionStatus = 'F'

		DECLARE @i_MinPD INT
			,@i_MaxPD INT

		SELECT @i_MinPD = MIN(PDID)
		FROM @tblADT

		SELECT @i_MaxPD = MAX(PDID)
		FROM @tblADT

		WHILE @i_MinPD <= @i_MaxPD
		BEGIN
			EXEC [usp_PopulationDefinitionUsers_InsertByCriteria] @i_AppUserId = 1
				,@i_PopulationDefinitionID = @i_MinPD
				,@v_Source = 'ADT'

			SELECT @i_MinPD = MIN(PDID)
			FROM @tblADT
			WHERE PDID > @i_MinPD
		END
	END

	DECLARE @i_ClaimSourceTypeId INT

	SELECT @i_ClaimSourceTypeId = FileSourceID
	FROM LkUpFileSource WITH (NOLOCK)
	WHERE FileSourceName = 'Claim'

	DECLARE @i_DeceasedEventId INT

	SELECT @i_DeceasedEventId = EventTypeId
	FROM EventType
	WHERE EventDescription = 'Deceased'

	INSERT INTO PatientEvent (
		PatientId
		,IsReadmit
		,FacilityId
		,VisitAdmitdate
		,VisitDischargedate
		,CreatedByUserId
		,IsInternal
		)
	SELECT DISTINCT TP.PatientId
		,NULL
		,NULL
		,NULL
		,NULL
		,@i_CreatedByUserId
		,1
	FROM ##Event_ADTPatient TP
	INNER JOIN ##Event_ADTGeneral TG ON TG.GeneralId = TP.GeneralId
	WHERE TG.MessageTypeEvent IN (
			'A01'
			,'A03'
			,'A08'
			)
		AND tp.PatientDeathIndicator = 'True'
		AND TG.[Status] = 'C'
		AND NOT EXISTS (
			SELECT 1
			FROM Patient P
			WHERE P.PatientID = TP.PATIENTID
				AND ISNULL(P.IsDeceased, 0) = 1
			)

	INSERT INTO PatientEventNotification (
		PatientEventId
		,EventTypeId
		,EventDate
		,CreatedByUserId
		--,VisitType
		,SourceId
		)
	SELECT DISTINCT PE.PatientEventId
		,@i_DeceasedEventId
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.EventDate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS EventDate
		,@i_CreatedByUserId
		--,NULL
		,DT.GeneralId
	FROM PatientEvent PE
	INNER JOIN (
		SELECT MAX(PE.PatientEventId) AS MAXPatientEventId
			,COALESCE(NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS EventDate
			,TP.GeneralId
		FROM ##Event_ADTPatient TP
		INNER JOIN ##Event_ADTGeneral TG ON TG.GeneralId = TP.GeneralId
		INNER JOIN PatientEvent PE ON TP.PatientId = PE.PatientId
		WHERE TG.MessageTypeEvent IN (
				'A01'
				,'A03'
				,'A08'
				)
			AND tp.PatientDeathIndicator = 'True'
			AND TG.[Status] = 'C'
		GROUP BY TP.GeneralId
			,TG.GeneralEventDateTime
			,TG.GeneralMsgDateTime
		) DT ON PE.PatientEventId = DT.MAXPatientEventId
	WHERE PE.IsInternal = 1
		AND NOT EXISTS (
			SELECT 1
			FROM PatientEventNotification PEN
			WHERE PE.PatientEventId = PEN.PatientEventId
			)

	UPDATE P
	SET IsDeceased = 1
		,DateDeceased = CASE 
			WHEN NULLIF(TP.PatientDeathDateTime, '') IS NOT NULL
				THEN CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(TP.PatientDeathDateTime)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATE)
			ELSE NULL
			END
		,LastModifiedByUserID = @i_CreatedByUserId
		,LastModifiedDate = GETDATE()
		,SourceTypeId = CASE 
			WHEN TG.GeneralSendingFacility = 'Claim'
				THEN @i_ClaimSourceTypeId
			ELSE @i_SourceTypeId
			END
	FROM Patient P
	INNER JOIN ##Event_ADTPatient TP ON P.PatientId = TP.PatientId
	INNER JOIN ##Event_ADTGeneral TG ON TG.GeneralId = TP.GeneralId
	WHERE (
			TG.MessageTypeEvent IN (
				'A01'
				,'A03'
				,'A08'
				)
			)
		AND tp.PatientDeathIndicator = 'True'
		AND TG.[Status] = 'C'
		AND NOT EXISTS (
			SELECT 1
			FROM Patient PA
			WHERE PA.PatientID = P.PatientID
				AND PA.IsDeceased = 1
			)

	INSERT INTO PatientEvent (
		PatientId
		,IsReadmit
		,FacilityId
		,VisitAdmitdate
		,VisitDischargedate
		,CreatedByUserId
		,IsInternal
		)
	SELECT DISTINCT TP.PatientId
		,NULL
		,NULL
		,NULL
		,NULL
		,@i_CreatedByUserId
		,1
	FROM ##Event_ADTPatient TP
	INNER JOIN ##Event_ADTGeneral TG ON TG.GeneralId = TP.GeneralId
	WHERE TG.MessageTypeEvent IN (
			'A01'
			,'A03'
			,'A08'
			)
		AND tp.PatientDeathIndicator = 'False'
		AND TG.[Status] = 'C'
		AND EXISTS (
			SELECT 1
			FROM Patient PA
			WHERE PA.PatientID = TP.PatientID
				AND ISNULL(PA.IsDeceased, 0) = 1
			)

	SELECT @i_DeceasedEventId = EventTypeId
	FROM EventType
	WHERE EventDescription = 'Not Deceased'

	INSERT INTO PatientEventNotification (
		PatientEventId
		,EventTypeId
		,EventDate
		,CreatedByUserId
		--,VisitType
		,SourceId
		,GeneralMessageControlId
		,DiagnosisCodeId
		)
	SELECT DISTINCT PE.PatientEventId
		,@i_DeceasedEventId
		,CAST(CONVERT(VARCHAR(19), TRY_CONVERT(DATETIME, STUFF(STUFF(STUFF(STUFF(STUFF(STUFF(LEFT(LTRIM(RTRIM(DT.EventDate)) + '00000000000000', 14), 5, 0, '-'), 8, 0, '-'), 11, 0, ' '), 14, 0, ':'), 17, 0, ':'), 19, 0, '')), 121) AS DATETIME) AS EventDate
		,@i_CreatedByUserId
		--,NULL
		,DT.GeneralId
		,DT.GeneralMessageControlId
		,AD.DiagnosisCodeId
	FROM PatientEvent PE
	INNER JOIN (
		SELECT MAX(PE.PatientEventId) AS MAXPatientEventId
			,COALESCE(NULLIF(TG.GeneralEventDateTime, ''), NULLIF(TG.GeneralMsgDateTime, '')) AS EventDate
			,TP.GeneralId
			,TG.GeneralMessageControlId
		FROM ##Event_ADTPatient TP
		INNER JOIN ##Event_ADTGeneral TG ON TG.GeneralId = TP.GeneralId
		INNER JOIN PatientEvent PE ON TP.PatientId = PE.PatientId
		WHERE TG.MessageTypeEvent IN (
				'A01'
				,'A03'
				,'A08'
				)
			AND tp.PatientDeathIndicator = 'False'
			AND TG.[Status] = 'C'
		GROUP BY TP.GeneralId
			,TG.GeneralMessageControlId
			,TG.GeneralEventDateTime
			,TG.GeneralMsgDateTime
		) DT ON PE.PatientEventId = DT.MAXPatientEventId
	LEFT OUTER JOIN ##Event_ADTDiagnosis AD ON AD.GeneralId = DT.GeneralId
	WHERE PE.IsInternal = 1
		AND NOT EXISTS (
			SELECT 1
			FROM PatientEventNotification PEN
			WHERE PE.PatientEventId = PEN.PatientEventId
			)
		AND EXISTS (
			SELECT 1
			FROM Patient PA
			WHERE PA.PatientID = PE.PatientID
				AND ISNULL(PA.IsDeceased, 0) = 1
			)

	UPDATE P
	SET IsDeceased = 0
		,DateDeceased = NULL
		,LastModifiedByUserID = @i_CreatedByUserId
		,LastModifiedDate = GETDATE()
		,SourceTypeId = CASE 
			WHEN TG.GeneralSendingFacility = 'Claim'
				THEN @i_ClaimSourceTypeId
			ELSE @i_SourceTypeId
			END
	FROM Patient P
	INNER JOIN ##Event_ADTPatient TP ON P.PatientId = TP.PatientId
	INNER JOIN ##Event_ADTGeneral TG ON TG.GeneralId = TP.GeneralId
	WHERE (
			TG.MessageTypeEvent IN (
				'A01'
				,'A03'
				,'A08'
				)
			)
		AND tp.PatientDeathIndicator = 'False'
		AND TG.[Status] = 'C'
		AND EXISTS (
			SELECT 1
			FROM Patient PA
			WHERE PA.PatientID = P.PatientID
				AND PA.IsDeceased = 1
			)

	SELECT DISTINCT t.PatientID
		,pen.PatientEventNotificationId
	INTO #pat
	FROM ##Event_ADTPatient t
	INNER JOIN PatientEventNotification pen WITH (NOLOCK) ON pen.SourceId = t.GeneralId
	WHERE VisitType = 'E'
		OR VisitType IS NULL

	SELECT ProviderID
		,PatientEventNotificationId
	INTO #Prov
	FROM (
		SELECT DISTINCT pp.ProviderID
			,p.PatientEventNotificationId
		FROM PatientProgram pm WITH (NOLOCK)
		INNER JOIN #pat p ON pm.PatientID = p.PatientID
		INNER JOIN ProgramProvider pp WITH (NOLOCK) ON pp.ProgramID = pm.ProgramID
		WHERE pm.StatusCode = 'E'
			AND pm.ProgramID <> @i_ProgramID
		
		UNION
		
		SELECT DISTINCT phc.ParentProviderID ProviderID
			,p.PatientEventNotificationId
		FROM ProviderHierarchyDetail phc WITH (NOLOCK)
		INNER JOIN PatientPCP pcp WITH (NOLOCK) ON phc.ChildProviderID = pcp.ProviderID
		INNER JOIN #pat p ON p.PatientID = pcp.PatientId
		
		UNION
		
		SELECT DISTINCT pcp.ProviderID
			,p.PatientEventNotificationId
		FROM PatientPCP pcp WITH (NOLOCK)
		INNER JOIN #pat p ON p.PatientID = pcp.PatientId
		
		UNION
		
		SELECT DISTINCT pr.ProviderID
			,p.PatientEventNotificationId
		FROM PatientInsurance ui WITH (NOLOCK)
		INNER JOIN PatientInsuranceBenefit b WITH (NOLOCK) ON b.PatientInsuranceID = ui.PatientInsuranceID
		INNER JOIN #pat p ON p.PatientID = ui.PatientId
		INNER JOIN InsuranceGroupPlan igp WITH (NOLOCK) ON igp.InsuranceGroupPlanID = ui.InsuranceGroupPlanID
		INNER JOIN InsuranceGroup ig WITH (NOLOCK) ON ig.InsuranceGroupID = igp.InsuranceGroupID
		INNER JOIN Provider Pr WITH (NOLOCK) ON Pr.InsuranceGroupID = ig.InsuranceGroupID
		) Prov

	INSERT INTO ProviderEventNotification (
		PatientEventNotificationID
		,ProviderID
		)
	SELECT p.PatientEventNotificationId
		,p.ProviderID
	FROM #prov p
	WHERE NOT EXISTS (
			SELECT 1
			FROM ProviderEventNotification pren
			WHERE pren.PatientEventNotificationID = p.PatientEventNotificationID
				AND pren.ProviderID = P.ProviderID
			)

	UPDATE TG
	SET [Status] = 'C'
		,[Comments] = NULL
	FROM ##Event_ADTGeneral TG
	INNER JOIN ##Event_ADTPatient TP ON TG.GeneralId = TP.GeneralId
	WHERE TG.MessageTypeEvent = 'A08'
		AND TP.PatientId IS NOT NULL
		AND TG.[Status] <> 'F'
		AND TG.GeneralSendingFacility = 'Claim'

	IF (@l_TranStarted = 1) -- If transactions are there, then commit
	BEGIN
		SET @l_TranStarted = 0

		COMMIT TRANSACTION
	END
END TRY

----------------------------------------------
BEGIN CATCH
	IF (@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK TRANSACTION;
	END

	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_CreatedByUserId
		,'Database'
		,@ErrorSeverity
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH