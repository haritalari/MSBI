﻿/*      
--------------------------------------------------------------------------------------------------------------      
Procedure Name: EXEC [usp_CareProviderDashBoard_CareManagementByTypeID] @i_AppUserId=10,@vc_TaskTypeName='Questionnaire',@vc_Status='Scheduled' 
,@i_TabRowId=54 ,@v_EnrollmentTaskType=null  
Description   : This proc is used to retive the patients from CareManagement report  
Created By    : Rathnam  
Created Date  : 18-Jan-2013  
---------------------------------------------------------------------------------------------------------------      
Log History   :       
DD-Mon-YYYY  BY  DESCRIPTION    
29/07/2013:Santosh Changed the Name 'Program Enrollment' to 'Managed Popolation Enrollment''     
21/08/2013:Mohan added Function to get the Taskname in the place of TaskTypeName.  
04/09/2013:Mohan added IF Condition  to get all records.   
02/18/2014:Santosh removed the distributed logic for caremanager 
02/20/2014:Santosh added the parameter @t_TaskTypeID and modified the logic with the respect to TaskType
18-Sep-2014    Nagasiva     2012 SQL SERVER Pagination logic applied to result data sets . 
24-sep-2014	   Nagasiva   Used sp_executesql feature instead exec statements for dynamic Sql execution
11-08-2014	   Yugandhar  TaskDueDate,TaskCompletedDate column added in #tblTask
30-Sep-2015 NagaBabu Modified the code to filter data properly as per DueDate NAVI-3982
13-Apr-2016 Rathnam Modified as per NAVI-5791
20-Apr-2016 Rathnam Modified as per NAVI-5805
---------------------------------------------------------------------------------------------------------------    
*/

CREATE PROCEDURE [dbo].[usp_CareProviderDashBoard_CareManagementByTypeID] (
	@i_AppUserId KEYID
	,@vc_TaskTypeName VARCHAR(150)
	,@t_ProgramID TTYPEKEYID READONLY
	,@i_TabRowId KEYID
	,@vc_Status VARCHAR(50)
	,@t_CareTeamMembers TTYPEKEYID READONLY
	,@t_TaskTypeID TTYPEKEYID READONLY
	,@i_DueDate KEYID = NULL
	,@v_SortBy VARCHAR(50) = NULL
	,@v_SortType VARCHAR(5) = NULL
	,@i_StartIndex INT = 1
	,@i_EndIndex INT = 10
	,@v_EnrollmentTaskType VARCHAR(150)
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	-- Check if valid Application User ID is passed                
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END

	DECLARE @v_paramdefintion NVARCHAR(MAX) 
		,@v_DueDateValue INT = NULL
		,@v_DueDateStatus VARCHAR(1) = NULL 

	SET @v_paramdefintion = '    @i_AppUserId KEYID  
								,@vc_TaskTypeName VARCHAR(150)  
								,@i_TabRowId KEYID  
								,@vc_Status VARCHAR(30)  
								,@i_DueDate KEYID 
								,@v_SortBy VARCHAR(50)
								,@v_SortType VARCHAR(5)
								,@i_StartIndex INT 
								,@i_EndIndex INT 
								,@v_EnrollmentTaskType VARCHAR(150)
								,@v_DueDateValue INT
								,@v_DueDateStatus VARCHAR(1)  '

	CREATE TABLE #Program (ProgramID INT)

	INSERT INTO #Program
	SELECT tKeyId
	FROM @t_ProgramID

	CREATE TABLE #TaskType (TaskTypeID INT)

	INSERT INTO #TaskType
	SELECT tKeyId
	FROM @t_TaskTypeID

	CREATE TABLE #tblTask (
		 ID INT IDENTITY(1, 1)
		,TaskID INT
		,patientid INT
		,MemberNum VARCHAR(30)
		,PatientName VARCHAR(200)
		,Age INT
		,gender VARCHAR(1)
		,TaskDueDate DATETIME
		,DateTaken DATETIME
				
		)

	DECLARE @v_Select NVARCHAR(MAX)
		,@v_WhereClause NVARCHAR(MAX)
		,@v_JoinClause NVARCHAR(MAX) = ''
		,@v_SQL NVARCHAR(MAX) = ''
		,@v_OrderByClause NVARCHAR(MAX) = ''
		,@v_SelectCount NVARCHAR(MAX)
		,@v_SQLCount NVARCHAR(MAX) = ''

              
            
            SET @v_WhereClause = ' WHERE ty.TaskTypeName =  @vc_TaskTypeName  AND t.TypeID =  @i_TabRowId ' + 
      
        CASE
				 WHEN @vc_Status IN ('Scheduled','Open','Closed Complete','Closed Incomplete','DisEnroll') 
					THEN ' AND ts.TaskStatusText  = @vc_Status '
				 WHEN @vc_Status = 'Incomplete' 
					THEN  ' AND ts.TaskStatusText  IN  (''Closed Incomplete'',''DisEnroll'')'
		END
         
	SET @v_Select = '  
            INSERT INTO #tblTask  
            SELECT   
                t.PatientTaskId ,
				t.PatientID
				,p.MedicalRecordNumber
				,COALESCE(ISNULL(p.LastName , '''') + '', '' + ISNULL(p.FirstName , '''') + ''. '' + ISNULL(p.MiddleName , '''')  + ISNULL(p.NameSuffix , '''') , '''') AS FullName
				,dbo.ufn_GetAgeByDOB(p.DateOfBirth)
				,p.gender
				,DueDate
				,DateTaken 
            FROM  
                PatientTask t WITH(NOLOCK)
			INNER JOIN patient P
			 ON P.Patientid = t.patientid	  
            INNER JOIN #Program pr
                ON pr.ProgramID = t.ManagedPopulationID
		  INNER JOIN #TaskType ty1
			 ON ty1.TaskTypeID = t.TaskTypeID
            INNER JOIN TaskType ty WITH(NOLOCK)
                ON t.TaskTypeId = ty.TaskTypeId
            INNER JOIN TaskStatus ts WITH(NOLOCK)
                ON ts.TaskStatusId = t.TaskStatusId '
	
	set @v_SelectCount = '  SELECT COUNT(t.PatientTaskId ) TotalCnt
								FROM  
									PatientTask t WITH(NOLOCK)  
								INNER JOIN #Program pr
									ON pr.ProgramID = t.ManagedPopulationID
							  INNER JOIN #TaskType ty1
								 ON ty1.TaskTypeID = t.TaskTypeID
								INNER JOIN TaskType ty WITH(NOLOCK)
									ON t.TaskTypeId = ty.TaskTypeId
								INNER JOIN TaskStatus ts WITH(NOLOCK)
									ON ts.TaskStatusId = t.TaskStatusId '

	IF @i_DueDate IS NOT NULL
	BEGIN
		SELECT 
			@v_DueDateValue = Value ,
			@v_DueDateStatus = TaskStatus
		FROM TaskDueDates 
		WHERE TaskDueDateId = @i_DueDate

		

		SET @v_WhereClause = @v_WhereClause + 
			' AND (  
						 (  ts.TaskStatusText = ''Open'' AND   
						   DATEDIFF(DAY , t.DueDate , getdate()) BETWEEN  CASE WHEN @v_DueDateValue = 0 AND @v_DueDateStatus = ''C'' THEN ''1'' ELSE  @v_DueDateValue END AND 0   
										)    
										OR  
										(  
						   ts.TaskStatusText = ''Closed complete'' AND   
						  DATEDIFF(DAY , t.DateTaken , getdate()) BETWEEN 0 AND  REPLACE(@v_DueDateValue , ''-'' , '''')
                      
										)   
                      
										OR  
										(  
						   ts.TaskStatusText = ''Closed Incomplete''   AND ty.IsTask = 1 AND   
						  DATEDIFF(DD,  t.DateTaken,GETDATE()) BETWEEN 0 AND  REPLACE(@v_DueDateValue , ''-'' , '''')
										)
										OR  
										(  
						   ts.TaskStatusText = ''DisEnroll''  AND   
						  DATEDIFF(DD,  t.DateTaken,GETDATE()) BETWEEN 0 AND  REPLACE(@v_DueDateValue , ''-'' , '''')
										)  
                                                 
					 )'
	END

	IF @v_SortBy IS NOT NULL
	BEGIN
		IF @v_SortBy IN( 'PatientID','TaskTypeName')
			SET @v_OrderByClause = ' ORDER BY 2 ' + ISNULL(@v_SortType, '')

		IF @v_SortBy = 'membernum'
			SET @v_OrderByClause = ' ORDER BY 3 ' + ISNULL(@v_SortType, '')

		IF @v_SortBy = 'patientName'
			SET @v_OrderByClause = ' ORDER BY 4 ' + ISNULL(@v_SortType, '')

        IF @v_SortBy = 'TaskDueDate'
			SET @v_OrderByClause = ' ORDER BY  7 ' + ISNULL(@v_SortType, '')

        IF @v_SortBy = 'DateTaken'
			SET @v_OrderByClause = ' ORDER BY 8 ' +  ISNULL(@v_SortType, '')

		IF @v_SortBy = 'Age'
			SET @v_OrderByClause = ' ORDER BY  5 ' + ISNULL(@v_SortType, '')

        IF @v_SortBy = 'Gender'
			SET @v_OrderByClause = ' ORDER BY 6 ' + ISNULL(@v_SortType, '')
	END
	ELSE 
	  BEGIN

	    SET @v_OrderByClause = 'ORDER BY 4'

	  END

	IF @i_StartIndex <> 0
	BEGIN
		SET @v_OrderByClause = @v_OrderByClause + ' OFFSET (@i_StartIndex-1) * @i_EndIndex  ROWS  FETCH NEXT  @i_EndIndex   ROWS ONLY'
		SET @v_SQL = @v_Select + ISNULL(@v_JoinClause, '') + ISNULL(@v_WhereClause, '') + ISNULL(@v_OrderByClause, '')
	END
	ELSE
	BEGIN
		SET @v_SQL = @v_Select + ISNULL(@v_JoinClause, '') + ISNULL(@v_WhereClause, '') + ISNULL(@v_OrderByClause, '')
	END

	SELECT @v_SQLCount = @v_SelectCount + ISNULL(@v_JoinClause, '') + ISNULL(@v_WhereClause, '')
	EXEC SP_EXECUTESQL @v_SQL
		,@v_paramdefintion
		,@i_AppUserId = @i_AppUserId
		,@vc_TaskTypeName = @vc_TaskTypeName
		,@i_TabRowId = @i_TabRowId
		,@vc_Status = @vc_Status
		,@i_DueDate = @i_DueDate
		,@v_SortBy = @v_SortBy
		,@v_SortType = @v_SortType
		,@i_StartIndex = @i_StartIndex
		,@i_EndIndex = @i_EndIndex
		,@v_EnrollmentTaskType = @v_EnrollmentTaskType
		,@v_DueDateValue = @v_DueDateValue
		,@v_DueDateStatus = @v_DueDateStatus

		 
		 SELECT  t.PatientID
				,t.MemberNum
				,t.PatientName
				,CONVERT(VARCHAR, t.Age) + '/' + (t.Gender) AS AgeGender 
				,t.TaskDueDate AS TaskDueDate
				,dbo.ufn_GetTypeNamesByTypeId(@vc_TaskTypeName, @i_TabRowId) AS TaskTypeName
				,t.DateTaken AS DateTaken
				,t.TaskId
		FROM #tblTask t
	
	EXEC SP_EXECUTESQL @v_SQLCount
		,@v_paramdefintion
		,@i_AppUserId = @i_AppUserId
		,@vc_TaskTypeName = @vc_TaskTypeName
		,@i_TabRowId = @i_TabRowId
		,@vc_Status = @vc_Status
		,@i_DueDate = @i_DueDate
		,@v_SortBy = @v_SortBy
		,@v_SortType = @v_SortType
		,@i_StartIndex = @i_StartIndex
		,@i_EndIndex = @i_EndIndex
		,@v_EnrollmentTaskType = @v_EnrollmentTaskType
		,@v_DueDateValue = @v_DueDateValue
		,@v_DueDateStatus = @v_DueDateStatus


END TRY

--------------------------------------------------------                   
BEGIN CATCH
	-- Handle exception  
	IF (@@TRANCOUNT > 0)
	BEGIN
	ROLLBACK TRANSACTION;
	END
		DECLARE @ErrorNumber INT = ERROR_NUMBER();
		DECLARE @ErrorLine INT = ERROR_LINE();
		DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
		DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
		DECLARE @ErrorState INT = ERROR_STATE();
		DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

		INSERT INTO Audit_Errors (
			Userid
			,Source
			,Type
			,ErrorDate
			,[Message]
			,[Procedure]
			)
		SELECT @i_AppUserId
			,'Database'
			,@ErrorSeverity
			,GETDATE()
			,@ErrorMessage
			,@ErrorProcedure
END CATCH