﻿
/*            
--------------------------------------------------------------------------------------------------------------            
Procedure Name: [dbo].[usp_CareMember_AssignedManagedPopulation] 
Description   : This procedure is used to pull managedpopulations for Caremanager & Careteam      
Created By    : Rathnam         
Created Date  : 05-05-2016
---------------------------------------------------------------------------------------------------------------            
Log History   :             
DD-Mon-YYYY  BY  DESCRIPTION 
----------------------------------------------------------------------------------------------------------------        
 */
CREATE PROCEDURE [dbo].[usp_CareMember_AssignedManagedPopulation] (
	@i_AppUserId INT
	,@i_CareTeamId INT
	,@i_ProviderId INT
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	SELECT DISTINCT pp.ProgramId Id, c.ProgramName Name
	FROM PatientProgram pp WITH(NOLOCK)
	INNER JOIN (
		SELECT p.ProgramId, p.ProgramName
		FROM ProgramCareTeam pc WITH(NOLOCK) 
		INNER JOIN Program p WITH(NOLOCK)
		on pc.ProgramId = p.ProgramId
		WHERE CareTeamId = @i_CareTeamId
		) c ON c.ProgramId = pp.ProgramID
	WHERE pp.ProviderID = @i_ProviderId
	AND StatusCode in ('E','P')
END TRY

BEGIN CATCH
	----------------------------------------------------------------------------------------------------------           
	-- Handle exception            
	DECLARE @ErrorNumber INT = ERROR_NUMBER();
	DECLARE @ErrorLine INT = ERROR_LINE();
	DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
	DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
	DECLARE @ErrorState INT = ERROR_STATE();
	DECLARE @ErrorProcedure VARCHAR(500) = ERROR_PROCEDURE()

	INSERT INTO Audit_Errors (
		Userid
		,Source
		,Type
		,ErrorDate
		,[Message]
		,[Procedure]
		)
	SELECT @i_AppUserId
		,'Database'
		,@ErrorLine
		,GETDATE()
		,@ErrorMessage
		,@ErrorProcedure
END CATCH