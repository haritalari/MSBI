﻿/*          
-----------------------------------------------------------------------------------------------------------------                 
Procedure Name: [usp_Batch_LabresultLoad]
Description   : This Stored procedure is used to process the Labresults
Created By    : NagaBabu
Created Date  : 20-July-2015
-----------------------------------------------------------------------------------------------------------------                 
Log History   :           
DD-MM-YYYY  BY   DESCRIPTION
25-Aug-2015 NagaBabu Added the logic for checking the HEDIS codegroupes for loinc codes as well.
16-Oct-2015 NagaBabu Added the codegroups in this logic as CodeTypeGroupersName = 'Internal'	AND CodeGroupType = 'Lab Groupers' for fetching labdata 
12-Nov-2015 Santosh Modified the code as per NAVI-4378
23-Aug-2016 Rathnam modified the conditions logic as per NAVI-6524 
-----------------------------------------------------------------------------------------------------------------                
*/  
CREATE PROCEDURE [dbo].[usp_Batch_LabresultLoad]
AS
BEGIN TRY
	SET NOCOUNT ON
	
	DECLARE @i_SourceTypeId INT 
	SELECT @i_SourceTypeId = FileSourceID
	FROM LkUpFileSource WITH (NOLOCK)
	WHERE FileSourceName = 'HL7'

	UPDATE TLR
	SET PatientId = P.PatientID
	FROM ##Event_LabResult TLR
	INNER JOIN ##Event_Lab TL
	ON TLR.EventLabId = TL.EventLabId
	INNER JOIN Patient P 
	ON TL.MID = P.PatientPrimaryId

	UPDATE TLR
	SET LoincCodeId = CSL.LoincCodeId
	FROM ##Event_LabResult TLR
	INNER JOIN CodeSetLoinc CSL 
	ON TLR.ComponentCode = CSL.LoincCode

	INSERT INTO MeasureUOM
	(
		UOMText ,
		UOMDescription ,
		SortOrder ,
		CreatedByUserId
	)
	SELECT DISTINCT RTRIM(LTRIM(TLR.ObservationsUnits)) ,
		RTRIM(LTRIM(TLR.ObservationsUnits)) ,
		1 ,
		1
	FROM ##Event_LabResult TLR
	WHERE NOT EXISTS (SELECT 1
					  FROM MeasureUOM MUM
					  WHERE MUM.UOMText = RTRIM(LTRIM(TLR.ObservationsUnits)))
	
	; WITH CTE_LabProcess AS 
	(SELECT EventLabId,MID, DENSE_RANK() OVER (PARTITION BY MID ORDER BY EventLabId DESC) SNO
	FROM 
	(SELECT DISTINCT MID,EventLabId 
	FROM ##Event_Lab
	WHERE MID IS NOT NULL)DT)

	UPDATE TL
	SET [Status] = 'D'
	FROM ##Event_Lab TL
	INNER JOIN CTE_LabProcess CTELP
	ON TL.EventLabId = CTELP.EventLabId
	WHERE SNO > 1

	UPDATE TLR
	SET [Status] = 'D'
	FROM ##Event_Lab TL
	INNER JOIN ##Event_LabResult TLR
	ON TL.EventLabId = TLR.EventLabId
	WHERE TL.[Status] = 'D'
	
	
	UPDATE ##Event_LabResult
	SET [Status] = CASE WHEN PatientId IS NULL THEN 'F'
						WHEN ObservationsStatus NOT IN ('completed','Done') THEN 'F '
						WHEN NULLIF(ComponentCode,'') IS NULL THEN 'F'
						WHEN NULLIF(ComponentCode,'') IS NOT NULL AND LoincCodeId IS NULL THEN 'F'
						WHEN TestResultDate IS NULL THEN 'F'
						ELSE 'P'
					END	,
		Comments = CASE WHEN PatientId IS NULL THEN 'Patient does not exists'
						WHEN ObservationsStatus NOT IN ('completed','Done') THEN 'Event Not yet completed '
						WHEN NULLIF(ComponentCode,'') IS NULL THEN 'LoincCode is not provided'
						WHEN NULLIF(ComponentCode,'') IS NOT NULL AND LoincCodeId IS NULL THEN 'LoincCode does not exists in our codeset'
						WHEN TestResultDate IS NULL THEN 'Lab resultdate is missing'
				   END
	WHERE [Status] = 'P'

	INSERT INTO PatientMeasure
	(
	PatientID ,
	MeasureUOMId ,
	MeasureValueText ,
	MeasureValueNumeric ,
	Comments ,
	DateTaken ,
	DueDate ,
	CreatedByUserId ,
	LOINCCodeID ,
	SourceTypeId
	)
	SELECT DISTINCT TLR.PatientId ,
		MUM.MeasureUOMId ,
		CASE WHEN ISNUMERIC(TLR.ObservationsValue) = 0 THEN TLR.ObservationsValue
			ELSE NULL
		END ,
		CASE WHEN ISNUMERIC(TLR.ObservationsValue) = 1 THEN TLR.ObservationsValue
			ELSE NULL
		END ,
		'This data is from HL7' ,
		TestResultDate ,
		TestResultDate ,
		1 ,
		TLR.LoincCodeId ,
		@i_SourceTypeId
	FROM ##Event_LabResult TLR
	LEFT JOIN MeasureUOM MUM
	ON MUM.UOMText = RTRIM(LTRIM(TLR.ObservationsUnits))
	WHERE [Status] = 'P'
	AND NOT EXISTS (SELECT 1
					  FROM PatientMeasure PM
					  WHERE PM.PatientID = TLR.PatientId
					  AND PM.LOINCCodeID = TLR.LOINCCodeID
					  AND PM.DateTaken = TLR.TestResultDate)	
	

	
	UPDATE TLR
	SET PatientMeasureId = PM.PatientMeasureID
	FROM ##Event_LabResult TLR
	INNER JOIN PatientMeasure PM
	ON TLR.PatientId = PM.PatientID
	AND TLR.LoincCodeId = PM.LOINCCodeID
	AND TLR.TestResultDate = PM.DateTaken
	AND [Status] = 'P'


	UPDATE ##Event_LabResult
	SET [Status] = 'C' 
	WHERE PatientMeasureId IS NOT NULL

	UPDATE ##Event_Lab
	SET [Status] = 'C' 
	WHERE [Status] = 'P' 


	SELECT DISTINCT PM.PatientMeasureID
	INTO #PatientMeasure
	FROM PatientMeasure PM
	INNER JOIN ##Event_LabResult TLR
	ON PM.PatientID = TLR.PatientId
	WHERE PM.SourceTypeId = @i_SourceTypeId
	AND NOT EXISTS (SELECT 1
					FROM ##Event_LabResult TLR
					WHERE TLR.PatientMeasureId = PM.PatientMeasureID )

	DELETE FROM LabCodeGroup 
	WHERE EXISTS (SELECT 1
				  FROM #PatientMeasure TPM
				  WHERE TPM.PatientMeasureID = LabCodeGroup.PatientMeasureId)

	DELETE FROM PatientMeasure 
	WHERE EXISTS (SELECT 1
				  FROM #PatientMeasure TPM
				  WHERE TPM.PatientMeasureID = PatientMeasure.PatientMeasureId)

	--------------------------------------------------------------------------------------------------
	CREATE TABLE #CodeGroups (CodeGroupingID INT)

	INSERT INTO #CodeGroups (CodeGroupingID)
	SELECT DISTINCT pdc.CodeGroupingID
	FROM PopulationDefinitionConfiguration pdc WITH(NOLOCK)
	WHERE pdc.CodeGroupingID IS NOT NULL
	UNION
	SELECT cg.CodeGroupingID
	FROM CodeGrouping cg WITH(NOLOCK)
	INNER JOIN CodeTypeGroupers ctg WITH(NOLOCK)
		ON ctg.CodeTypeGroupersID = cg.CodeTypeGroupersID
	WHERE ctg.CodeTypeGroupersName IN (
			'Encounter Types(Internal)'
			,'Utilization Type (Internal)'
			,'Encounter Type (Internal) by Code Type'
			,'CCS ICD Procedure 4Classes'
			,'CCS Chronic Diagnosis Group'
			,'AHRQ Diagnosis Groupers')
	UNION
	SELECT CodeGroupingID
	FROM CodeGrouping WITH(NOLOCK)
	WHERE CodeGroupingName IN (
			'A1C'
			,'LDL')
	UNION
	SELECT cg.CodeGroupingID
	FROM CodeGrouping cg WITH(NOLOCK)
	INNER JOIN CodeTypeGroupers ctg WITH(NOLOCK)
		ON ctg.CodeTypeGroupersID = cg.CodeTypeGroupersID
	INNER JOIN CodeGroupingType CGT
		ON CGT.CodeGroupingTypeID = CTG.CodeGroupingTypeID
	WHERE ctg.CodeTypeGroupersName = 'Internal'
		AND CodeGroupType = 'Lab Groupers'
	
	CREATE TABLE #CodeGroupLoinc
	(
		CodeGroupingID INT
		,LoincCodeId INT
	)
	INSERT INTO #CodeGroupLoinc
	(
		CodeGroupingID ,
		LoincCodeId
	)
	SELECT DISTINCT gpet.CodeGroupingID
		,CSL.LoincCodeId
	FROM CodeGroupingECTTable gpet WITH(NOLOCK)
	INNER JOIN CodeSetHEDIS_ECTCode ec WITH(NOLOCK)
		ON gpet.ECThedisTableID = ec.ECTHedisTableID
	INNER JOIN CodeSetECTHedisCodeType ECT WITH(NOLOCK)
		ON ect.ECTHedisCodeTypeID = ec.ECTHedisCodeTypeID
	INNER JOIN CodeGrouping cg WITH(NOLOCK)
		ON cg.CodeGroupingID = gpet.CodeGroupingID
	INNER JOIN #CodeGroups TCG
		ON CG.CodeGroupingID = TCG.CodeGroupingID
	INNER JOIN CodeSetLoinc CSL
		ON CSL.LoincCode = EC.ECTCode		
	WHERE (
			(
				gpet.ECTTableDescription = ec.ECTCodeDescription
				AND ISNULL(gpet.ECTTableDescription, '') <> ''
				)
			OR ISNULL(gpet.ECTTableDescription, '') = ''
			)
		AND (
			(
				gpet.ECTHedisCodeTypeID = ec.ECTHedisCodeTypeID
				AND ISNULL(gpet.ECTHedisCodeTypeID, 0) <> 0
				)
			OR ISNULL(gpet.ECTHedisCodeTypeID, 0) = 0
			)
		AND CG.StatusCode = 'A'
		AND GPET.StatusCode = 'A'
		AND ECT.LkupCode = 'LOINC'
	UNION 
	SELECT CGDI.CodeGroupingID ,
		   CSL.LoincCodeId	
	FROM CodeSetLoinc CSL  WITH(NOLOCK)
	INNER JOIN CodeGroupingDetailInternal CGDI WITH(NOLOCK)
		ON CSL.LOINCCodeID = CGDI.CodeGroupingCodeID
	INNER JOIN #CodeGroups TCG
		ON TCG.CodeGroupingID = CGDI.CodeGroupingID	
	INNER JOIN LkUpCodeType LCT WITH(NOLOCK)
		ON LCT.CodeTypeID = CGDI.CodeGroupingCodeTypeID
	WHERE LCT.CodeTypeCode = 'LOINC'
		AND CGDI.StatusCode = 'A'	
	
	INSERT INTO LabCodeGroup
	(
		PatientMeasureId ,
		CodeGroupingId
	)
	SELECT DISTINCT
		TEL.PatientMeasureId ,
		TCGL.CodeGroupingID
	FROM ##Event_LabResult TEL  WITH(NOLOCK)
	INNER JOIN #CodeGroupLoinc TCGL WITH(NOLOCK)
	ON TEL.LOINCCodeID = TCGL.LOINCCodeID
	AND NOT EXISTS (SELECT 1
					FROM LabCodeGroup LCG
					WHERE LCG.PatientMeasureId = TEL.PatientMeasureID
					AND LCG.CodeGroupingId = TCGL.CodeGroupingID)
   AND TEL.PatientMeasureId IS NOT NULL
  

END TRY

-----------------------------------------------------------------------------------------------------------------       
BEGIN CATCH
	DECLARE @i_ReturnedErrorID INT
	
	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = 1
END CATCH