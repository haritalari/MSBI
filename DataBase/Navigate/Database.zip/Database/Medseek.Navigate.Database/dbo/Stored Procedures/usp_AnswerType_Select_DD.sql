﻿/*
---------------------------------------------------------------------------------
Procedure Name: [dbo].[usp_AnswerType_Select_DD]
Description	  : This procedure is used to select all the active answer types for  
				the answer type dropdown.
Created By    :	Aditya 
Created Date  : 20-Jan-2010
----------------------------------------------------------------------------------
Log History   : 
DD-MM-YYYY		BY			DESCRIPTION

----------------------------------------------------------------------------------
*/

CREATE PROCEDURE [dbo].[usp_AnswerType_Select_DD] @i_AppUserId KEYID
AS
SET NOCOUNT ON
BEGIN TRY 

	-- Check if valid Application User ID is passed
      IF ( @i_AppUserId IS NULL ) OR ( @i_AppUserId <= 0 )
         BEGIN
               RAISERROR ( N'Invalid Application User ID %d passed.' ,
               17 ,
               1 ,
               @i_AppUserId )
         END
---------------- All the Active Answer Type are retrieved --------
      SELECT
          AnswerTypeId ,
          AnswerTypeCode ,
          Description 
     FROM
          AnswerType
     WHERE
          StatusCode = 'A'
     ORDER BY
          SortOrder ,
          Description
END TRY
BEGIN CATCH

    -- Handle exception
      DECLARE @i_ReturnedErrorID INT
      EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId

      RETURN @i_ReturnedErrorID
END CATCH
