﻿/*          
------------------------------------------------------------------------------          
Procedure Name: [usp_AllPatientsManagedpopulation_Enrollment]
Description   : This Procedure is used to Enroll patients in to 'All Patients Managed population'
Created By    : Nagababu
Created Date  : 11-Aug-2016
------------------------------------------------------------------------------          
Log History   :           
DD-MM-YYYY  BY   DESCRIPTION
------------------------------------------------------------------------------                
*/
CREATE PROCEDURE [dbo].[usp_AllPatientsManagedpopulation_Enrollment]
(
	@i_ProgramID INT
)
AS
	DECLARE @i_PopulationDefinitionId INT ,
			@i_CreatedByUserId INT 

	SELECT @i_CreatedByUserId = ProviderId
	FROM Provider P
	INNER JOIN CodeSetProviderType CSP
		ON P.ProviderTypeID = CSP.ProviderTypeCodeID
	WHERE CSP.[Description] = 'Administrator'
	AND P.FirstName = 'User'
	AND P.LastName = 'HL7'


	SELECT @i_PopulationDefinitionId = PopulationDefinitionId
	FROM Program WITH (NOLOCK)
	WHERE ProgramID = @i_ProgramID

	INSERT INTO PopulationDefinitionPatients (
		PopulationDefinitionID
		,PatientID
		,StatusCode
		,CreatedByUserId
		)
	SELECT DISTINCT @i_PopulationDefinitionId
		,P.PatientID
		,'A'
		,@i_CreatedByUserId
	FROM Patient p
	WHERE NOT EXISTS (
			SELECT 1
			FROM PopulationDefinitionPatients WITH (NOLOCK)
			WHERE PopulationDefinitionPatients.PopulationDefinitionID = @i_PopulationDefinitionId
				AND PopulationDefinitionPatients.PatientID = P.PatientID
			)
	

		INSERT INTO PatientProgram (
			ProgramId
			,PatientID
			,EnrollmentStartDate
			,CreatedByUserId
			,StatusCode
			,IsAutoEnrollment
			)
		SELECT DISTINCT @i_ProgramID
			,P.PatientID
			,GETDATE()
			,@i_CreatedByUserId
			,'A'
			,1
		FROM Patient P
		WHERE NOT EXISTS (
				SELECT 1
				FROM PatientProgram WITH (NOLOCK)
				WHERE PatientProgram.PatientID = P.PatientID
					AND PatientProgram.ProgramId = @i_ProgramID
					AND PatientProgram.EnrollmentEndDate IS NULL
				)