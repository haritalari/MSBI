﻿
/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_SCOLAP_TopCountProcedureByCost] 1
Description   : This proc is used to extact  the data from Transaction DB to OLAP TABLES to refresh the cube 
Created By    : Nagasiva  
Created Date  : 23-Jan-2015
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION
13-Feb-2015 Nagasiva  assigned null value to  @i_AppUserId  Parameter to remove the hardcoded userid in cube execution package  
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_SCOLAP_TopCountProcedureByCost] (@i_AppUserId KEYID=NULL)
AS
BEGIN TRY
	SET NOCOUNT ON

	SELECT @i_AppUserId =MIN(UserId) FROM Users WITH (NOLOCK)
	
	CREATE TABLE #Proc (
		ProcedureCodeKey INT
		,DateKey INT
		,BilledAmount MONEY
		,ClaimID INT
		)
		
	INSERT INTO #Proc
	SELECT DISTINCT csp1.ProcedureCodeKey
		,ad.DateKey
		,BilledAmount
		,ClaiminfoID
	FROM ClaimLine cl WITH (NOLOCK)
	INNER JOIN CodesetProcedure csp WITH (NOLOCK) ON csp.ProcedureCodeID = cl.ProcedureCodeID
	INNER JOIN ##OLAP_SC_DimCodesetProcedure csp1 ON csp1.ProcedureId = csp.ProcedureCodeID
		AND csp1.ProcedureCode = csp.ProcedureCode
		AND csp1.CodeTypeKey = csp.CodeTypeID
	INNER JOIN ##OLAP_SC_DimAnchordate ad WITH (NOLOCK) ON ad.AnchorDate = CASE 
			WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(cl.BeginServiceDate) - 1), cl.BeginServiceDate)
					AND DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, cl.EndServiceDate) + 1, 0))
				THEN ad.AnchorDate
			ELSE NULL
			END
	WHERE BilledAmount IS NOT NULL
	
	UNION
	
	SELECT DISTINCT csp1.ProcedureCodeKey
		,ad.DateKey
		,ci.ChargeAmount
		,ci.ClaimInfoID
	FROM ClaimProcedure cp WITH (NOLOCK)
	INNER JOIN ClaimInfo ci WITH (NOLOCK) ON ci.ClaimInfoID = cp.ClaimInfoID
	INNER JOIN CodeSetICDProcedure csp WITH (NOLOCK) ON csp.ProcedureCodeID = cp.ProcedureCodeID
	INNER JOIN ##OLAP_SC_DimCodesetProcedure csp1 ON csp1.ProcedureId = csp.ProcedureCodeID
		AND csp1.ProcedureCode = csp.ProcedureCode
		AND csp1.CodeTypeKey = csp.CodeTypeID
	INNER JOIN ##OLAP_SC_DimAnchordate ad WITH (NOLOCK) ON ad.AnchorDate = CASE 
			WHEN ad.AnchorDate BETWEEN DATEADD(dd, - (DAY(ci.DateOfAdmit) - 1), ci.DateOfAdmit)
					AND DATEADD(d, - 1, DATEADD(m, DATEDIFF(m, 0, ISNULL(ci.DateOfDischarge, ci.DateOfAdmit)) + 1, 0))
				THEN ad.AnchorDate
			ELSE NULL
			END
	WHERE ci.ChargeAmount IS NOT NULL

	IF OBJECT_ID('TEMPDB..##OLAP_SC_FactProcedureByCost') IS NOT NULL
		DROP TABLE ##OLAP_SC_FactProcedureByCost;

	SELECT p.ProcedureCodeKey
		,p.ClaimID
		,p.DateKey
		,p.BilledAmount AS ClaimAmt
	INTO ##OLAP_SC_FactProcedureByCost
	FROM #Proc p
	WHERE p.BilledAmount IS NOT NULL

	DROP TABLE #Proc
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH