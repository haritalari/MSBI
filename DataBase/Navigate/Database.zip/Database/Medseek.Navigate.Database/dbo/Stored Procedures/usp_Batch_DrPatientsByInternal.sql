﻿/*  
---------------------------------------------------------------------------------------  
Procedure Name: [dbo].[usp_Batch_DrPatientsByInternal]  
Description   : This proc is used to extract the data from CodeGroupers 
Created By    : Rathnam  
Created Date  : 28-June-2013
----------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY DESCRIPTION  
----------------------------------------------------------------------------------------  
*/
CREATE PROCEDURE [dbo].[usp_Batch_DrPatientsByInternal] --1,20121231
	(
	@i_AppUserId KEYID
	,@v_DateKey VARCHAR(8)
	,@i_DrID KEYID
	)
AS
BEGIN TRY
	SET NOCOUNT ON

	-- Check if valid Application User ID is passed  
	IF (@i_AppUserId IS NULL)
		OR (@i_AppUserId <= 0)
	BEGIN
		RAISERROR (
				N'Invalid Application User ID %d passed.'
				,17
				,1
				,@i_AppUserId
				)
	END

	DECLARE @d_NullFromDate DATE
		,@d_DateKey DATE
		,@vc_SQL NVARCHAR(MAX)
		,@vc_Paramdef  NVARCHAR(MAX)
		,@i_PDrID INT

		SELECT @d_NullFromDate = CONVERT(DATE, DATEADD(YYYY, - 200, GETDATE()))

		SET @d_DateKey = CONVERT(DATE, SUBSTRING(@v_DateKey, 1, 4) + '-' + SUBSTRING(@v_DateKey, 5, 2) + '-' + SUBSTRING(@v_DateKey, 7, 2))
		SET @i_PDrID = @i_DrID
		
	SET @vc_Paramdef =' @i_CodeGroupingID INT,
						@d_DateKey DATE,
						@d_NullFromDate DATE,
						@i_PDrID INT
						  '

	SELECT @d_NullFromDate = CONVERT(DATE, DATEADD(YYYY, - 200, GETDATE()))

	SET @d_DateKey = CONVERT(DATE, SUBSTRING(@v_DateKey, 1, 4) + '-' + SUBSTRING(@v_DateKey, 5, 2) + '-' + SUBSTRING(@v_DateKey, 7, 2))

	DECLARE @i_CodeGroupingID INT

	SELECT @i_CodeGroupingID = CodeGroupingID
	FROM PopulationDefinitionConfiguration WITH(NOLOCK)
	WHERE MetricID IS NULL
		AND DrID = @i_DrID
		AND CodeGroupingID IS NOT NULL
		AND ConditionIdList IS NULL
		AND DrProcName IS NULL

	IF @i_CodeGroupingID IS NOT NULL
	BEGIN
		CREATE TABLE #PDPatients (
			CodeGroupingID INT,
			PatientID INT,
			DrID INT,
			Amt Money
			)

	SET @vc_SQL='	INSERT INTO #PDPatients
		SELECT g.CodeGroupingId
			,g.PatientID
			,pdc.DrID
			,SUM(g.Amt)
		FROM vw_PatientCodeGroupAmt g WITH (NOLOCK)
		INNER JOIN PopulationDefinitionConfiguration pdc WITH (NOLOCK)
			ON g.CodeGroupingid = pdc.CodeGroupingID
		WHERE pdc.CodeGroupingid = @i_CodeGroupingID
			AND pdc.DrID = @i_PDrID
			AND pdc.MetricID IS NULL
			AND g.DateOfService > = --DATEADD(dd, - (DAY(@d_DateKey) - 1), @d_DateKey)
			CASE 
				WHEN pdc.TimeInDays IS NULL
					THEN @d_NullFromDate
				ELSE DATEADD(DAY, - pdc.TimeInDays, @d_DateKey)
				END
				
			AND g.DateOfService < = @d_DateKey
		GROUP BY g.CodeGroupingId
			,g.PatientID
			,pdc.DrID
			,pdc.NoOfCodes
		HAVING COUNT(*) >= pdc.NoOfCodes '
		
		EXEC SP_EXECUTESQL  @vc_SQL,@vc_Paramdef,@i_CodeGroupingID =@i_CodeGroupingID,
						   @d_DateKey = @d_DateKey,
						   @d_NullFromDate = @d_NullFromDate,
						   @i_PDrID = @i_PDrID

		MERGE PopulationDefinitionPatients AS t
		USING (
			SELECT PatientID
				,DrID PopulationDefinitionID
			FROM #PDPatients
			) AS s
			ON (s.PatientID = t.PatientID)
				AND s.PopulationDefinitionID = t.PopulationDefinitionID
		WHEN NOT MATCHED BY TARGET
			THEN
				INSERT (
					PopulationDefinitionID
					,PatientID
					,CreatedByUserId
					)
				VALUES (
					s.PopulationDefinitionID
					,s.PatientID
					,1
					)
		WHEN MATCHED
			THEN
				UPDATE
				SET t.StatusCode = 'A';

		ALTER TABLE #PDPatients ADD PopulationDefinitionPatientID INT

		UPDATE #PDPatients
		SET PopulationDefinitionPatientID = PopulationDefinitionPatients.PopulationDefinitionPatientID
		FROM PopulationDefinitionPatients WITH(NOLOCK)
		WHERE PopulationDefinitionPatients.PopulationDefinitionID = #PDPatients.DrID
			AND PopulationDefinitionPatients.PatientID = #PDPatients.PatientID

		DELETE
		FROM PopulationDefinitionPatientAnchorDate  
		WHERE EXISTS (
				SELECT 1
				FROM PopulationDefinitionPatients pdp WITH(NOLOCK)
				WHERE pdp.PopulationDefinitionPatientID = PopulationDefinitionPatientAnchorDate.PopulationDefinitionPatientID
					AND pdp.PopulationDefinitionID = @i_DrID
				)
			AND DateKey = @v_DateKey

		MERGE PopulationDefinitionPatientAnchorDate AS t
		USING (
			SELECT PopulationDefinitionPatientID, Amt
			FROM #PDPatients
			) AS s
			ON (s.PopulationDefinitionPatientID = t.PopulationDefinitionPatientID)
				AND t.DateKey = CONVERT(INT, @v_DateKey)
		WHEN NOT MATCHED BY TARGET
			THEN
				INSERT (
					PopulationDefinitionPatientID
					,CreatedByUserId
					,DateKey
					,OutPutAnchorDate
					,ClaimAmt
					)
				VALUES (
					s.PopulationDefinitionPatientID
					,1
					,@v_DateKey
					,@d_DateKey
					,s.Amt
					)
		WHEN MATCHED
			THEN
				UPDATE
				SET t.ClaimAmt = s.Amt;			
	END
	ELSE
	BEGIN
		---------------- Parameter ConditionList 	
		SELECT DrID
			,pdc.ConditionIdList
		INTO #t
		FROM PopulationDefinitionConfiguration pdc
		WHERE pdc.ConditionIdList IS NOT NULL
			AND (
				DrID = @i_DrID
				OR @i_DrID IS NULL
				)

		IF EXISTS (
				SELECT 1
				FROM #t
				)
		BEGIN
			DECLARE @tblDr TABLE (
				DrID INT
				,DerivedPDID INT
				)
			DECLARE @i INT

			SELECT @i = MIN(Drid)
			FROM #t

			WHILE @i >= 0
			BEGIN
				INSERT INTO @tblDr (
					DrID
					,DerivedPDID
					)
				SELECT @i
					,usstt.KeyValue
				FROM dbo.udf_SplitStringToTable((
							SELECT ConditionIdList
							FROM #t
							WHERE Drid = @i
							), ',') usstt

				DELETE
				FROM #t
				WHERE Drid = @i

				SELECT @i = MIN(Drid)
				FROM #t
			END

			SELECT Dr.DrID PopulationDefinitionID
				,pdp.PatientID PatientID
				,sum(pdpad.ClaimAmt) Amt
			INTO #PDPatients1
			FROM @tblDr Dr
			INNER JOIN PopulationDefinition newpd WITH(NOLOCK)
				ON newpd.PopulationDefinitionID = dr.DrID
			INNER JOIN PopulationDefinition derivedpd WITH(NOLOCK)
				ON derivedpd.PopulationDefinitionID = dr.DerivedPDID
			INNER JOIN PopulationDefinitionPatients pdp WITH(NOLOCK)
				ON pdp.PopulationDefinitionID = derivedpd.PopulationDefinitionID
			INNER JOIN PopulationDefinitionPatientAnchorDate pdpad WITH(NOLOCK)
				ON pdpad.PopulationDefinitionPatientID = pdp.PopulationDefinitionPatientID
			WHERE pdpad.DateKey = @v_DateKey
			GROUP BY Dr.DrID
				,pdp.PatientID
			HAVING COUNT(*) > 1 --- its mandatory as its intersect the list of patients from the different derived PD's

			MERGE PopulationDefinitionPatients AS t
			USING (
				SELECT PatientID
					,PopulationDefinitionID
				FROM #PDPatients1
				) AS s
				ON (s.PatientID = t.PatientID)
					AND s.PopulationDefinitionID = t.PopulationDefinitionID
			WHEN NOT MATCHED BY TARGET
				THEN
					INSERT (
						PopulationDefinitionID
						,PatientID
						,CreatedByUserId
						)
					VALUES (
						s.PopulationDefinitionID
						,s.PatientID
						,1
						)
			WHEN MATCHED
				THEN
					UPDATE
					SET t.StatusCode = 'A';

			ALTER TABLE #PDPatients1 ADD PopulationDefinitionPatientID INT

			UPDATE #PDPatients1
			SET PopulationDefinitionPatientID = PopulationDefinitionPatients.PopulationDefinitionPatientID
			FROM PopulationDefinitionPatients WITH(NOLOCK)
			WHERE PopulationDefinitionPatients.PopulationDefinitionID = #PDPatients1.PopulationDefinitionID
				AND PopulationDefinitionPatients.PatientID = #PDPatients1.PatientID

			DELETE
			FROM PopulationDefinitionPatientAnchorDate  
			WHERE EXISTS (
					SELECT 1
					FROM PopulationDefinitionPatients pdp WITH(NOLOCK)
					WHERE pdp.PopulationDefinitionPatientID = PopulationDefinitionPatientAnchorDate.PopulationDefinitionPatientID
						AND pdp.PopulationDefinitionID = @i_DrID
					)
				AND DateKey = @v_DateKey

			MERGE PopulationDefinitionPatientAnchorDate AS t
			USING (
				SELECT PopulationDefinitionPatientID,Amt
				FROM #PDPatients1
				) AS s
				ON (s.PopulationDefinitionPatientID = t.PopulationDefinitionPatientID)
					AND t.DateKey = CONVERT(INT, @v_DateKey)
			WHEN NOT MATCHED BY TARGET
				THEN
					INSERT (
						PopulationDefinitionPatientID
						,CreatedByUserId
						,DateKey
						,OutPutAnchorDate
						,ClaimAmt
						)
					VALUES (
						s.PopulationDefinitionPatientID
						,1
						,@v_DateKey
						,@d_DateKey
						,s.Amt
						)
			WHEN MATCHED
			THEN
				UPDATE
				SET t.ClaimAmt = s.Amt;				
			--WHEN MATCHED
			--	THEN
			--		UPDATE
			--		SET t.StatusCode = 'A'
			--			,T.OutPutAnchorDate = @d_DateKey;
						--WHEN NOT MATCHED BY SOURCE
						--	AND EXISTS (
						--		SELECT 1
						--		FROM #PDPatients1 p
						--		WHERE p.PopulationDefinitionPatientID <> t.PopulationDefinitionPatientID
						--			AND t.DateKey = CONVERT(INT, @v_DateKey)
						--		)
						--	THEN
						--		DELETE;
		END
	END
	/*
	UPDATE PopulationDefinitionPatients
	SET StatusCode = 'I'
	WHERE NOT EXISTS (SELECT 1 FROM PopulationDefinitionPatientAnchorDate a
	WHERE a.PopulationDefinitionPatientID = PopulationDefinitionPatients.PopulationDefinitionPatientID
	)
	AND PopulationDefinitionPatients.PopulationDefinitionID = @i_DrID
	*/
	-- NOTE: No need to use datekey parameter here as we r doing inactive who are not eligibile for datakey's
	
END TRY

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
BEGIN CATCH
	-- Handle exception  
	DECLARE @i_ReturnedErrorID INT

	EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException @i_UserId = @i_AppUserId
END CATCH


