﻿/*  
-------------------------------------------------------------------------------------------------------------------  
Procedure Name: [usp_CohortListUsers_SelectByCareTeamUserId] 23
Description   : This procedure is used to get the non careteam members from specific cohort
Created By    : NagaBabu
Created Date  : 16-Aug-2011
--------------------------------------------------------------------------------------------------------------------  
Log History   :   
DD-MM-YYYY  BY   DESCRIPTION  
17-Aug-2011 NagaBabu Added @i_CareTeamId,@i_CohortListId as Input Parameters  
19-Nov-2012 P.V.P.Mohan changed parameters and added PopulationDefinitionID in 
            the place of CohortListID and PopulationDefinitionUsers
27-Oct-2016 Nagasiva modified the sp as per NAVI-6853
--------------------------------------------------------------------------------------------------------------------  
*/  
  
CREATE PROCEDURE [dbo].[usp_CohortListUsers_SelectByCareTeamUserId]
(  
 @i_AppUserId KEYID ,
 @i_CareTeamId KEYID ,
 @i_PopulationDefinitionId KEYID
)  
AS 
SET NOCOUNT ON 
BEGIN TRY   
  
 -- Check if valid Application User ID is passed  
      IF ( @i_AppUserId IS NULL ) OR ( @i_AppUserId <= 0 )  
         BEGIN  
               RAISERROR ( N'Invalid Application User ID %d passed.' ,  
               17 ,  
               1 ,  
               @i_AppUserId )  
         END  
---------------------------------------------------------------------------  
	SELECT DISTINCT
		PopulationDefinitionPatients.PatientID AS UserId  ,
		COALESCE(ISNULL(Patient.LastName , '') + ', ' + ISNULL(Patient.FirstName , '') + '. ' + ISNULL(Patient.MiddleName , '') + ' ' + ISNULL(Patient.NameSuffix , '') , '')  as Fullname,
		MedicalRecordNumber AS MemberNum,
		Gender,
		dbo.ufn_GetAgeByDOB(Patient.DateOfBirth)  as Age ,
--		Patients.CareTeamId ,
		'' AS CareTeamId,
		PopulationDefinitionPatients.PopulationDefinitionId 
	FROM
		PopulationDefinitionPatients  WITH (NOLOCK) 
	INNER JOIN Patient  WITH (NOLOCK) 
		ON  PopulationDefinitionPatients.PatientID = Patient.PatientID
	WHERE 
		PopulationDefinitionPatients.PopulationDefinitionId = @i_PopulationDefinitionId
	AND	PopulationDefinitionPatients.StatusCode = 'A'
	AND Patient.AccountStatusCode = 'A'
	--AND Patients.CareTeamId IS NULL	
	
		
END TRY  
-------------------------------------------------------------------------------
BEGIN CATCH  
  
    -- Handle exception  
      DECLARE @i_ReturnedErrorID INT  
      EXECUTE @i_ReturnedErrorID = dbo.usp_HandleException   
     @i_UserId = @i_AppUserId  
  
      RETURN @i_ReturnedErrorID  
END CATCH
